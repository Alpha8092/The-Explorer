/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.common.version;

public final class GitBuildId {
    public static final String ACRA_URI = "${acra.uri}";
    public static final String ANT_BUILD_DATE = "February 19 2024";
    public static final String GIT_BUILD_FINGERPRINT = "2965242f6c92e55bc7d049ec621aec875559c799";
    public static final String GIT_BUILD_VERSION = "nb196";

    private GitBuildId() {
    }

    public static String getAcraUri() {
        if (ACRA_URI.equals((Object)ACRA_URI)) {
            return "";
        }
        return ACRA_URI.trim();
    }

    public static String getDate() {
        return ANT_BUILD_DATE;
    }

    public static String getFingerprint() {
        return GIT_BUILD_FINGERPRINT;
    }

    public static String getVersion() {
        if (GIT_BUILD_VERSION != "" && !GIT_BUILD_VERSION.contains((CharSequence)" ")) {
            return GIT_BUILD_VERSION;
        }
        return "none";
    }
}

