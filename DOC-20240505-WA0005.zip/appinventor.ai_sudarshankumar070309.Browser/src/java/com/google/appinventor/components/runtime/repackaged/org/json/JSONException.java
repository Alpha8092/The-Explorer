/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

public class JSONException
extends RuntimeException {
    private static final long serialVersionUID = 0L;
    private Throwable cause;

    public JSONException(String string) {
        super(string);
    }

    public JSONException(Throwable throwable) {
        super(throwable.getMessage());
        this.cause = throwable;
    }

    public Throwable getCause() {
        return this.cause;
    }
}

