/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.None
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.None;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem;

abstract class Keep
implements None,
PostMortem {
    protected int capacity;
    protected int length;
    protected int power;
    protected long[] uses;

    public Keep(int n) {
        this.capacity = n = JSONzip.twos[n];
        this.length = 0;
        this.power = 0;
        this.uses = new long[n];
    }

    public static long age(long l) {
        l = l >= 32L ? 16L : (l /= 2L);
        return l;
    }

    public int bitsize() {
        int n;
        int[] nArray;
        while ((nArray = JSONzip.twos)[n = this.power] < this.length) {
            this.power = n + 1;
        }
        return n;
    }

    public void tick(int n) {
        long[] lArray = this.uses;
        lArray[n] = lArray[n] + 1L;
    }

    public abstract Object value(int var1);
}

