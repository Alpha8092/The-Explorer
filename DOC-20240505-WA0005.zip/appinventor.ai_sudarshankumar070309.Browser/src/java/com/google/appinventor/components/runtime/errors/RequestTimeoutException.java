/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime.errors;

import java.io.IOException;

public class RequestTimeoutException
extends IOException {
    final int errorNumber;

    public RequestTimeoutException() {
        this.errorNumber = 1117;
    }
}

