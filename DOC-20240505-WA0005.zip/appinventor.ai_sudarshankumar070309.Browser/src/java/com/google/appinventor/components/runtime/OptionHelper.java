/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.Component;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class OptionHelper {
    private static final Map<String, Map<String, Method>> componentMethods = new HashMap();

    private static Method getMethod(Object map, String string) {
        Class clazz = map.getClass();
        String string2 = clazz.getSimpleName();
        Map<String, Map<String, Method>> map2 = componentMethods;
        Map map3 = (Map)map2.get((Object)string2);
        map = map3;
        if (map3 == null) {
            map = OptionHelper.populateMap(clazz);
            map2.put((Object)string2, map);
        }
        return (Method)map.get((Object)string);
    }

    public static <T> Object optionListFromValue(Object object, String string, T t) {
        if ((object = OptionHelper.getMethod(object, string)) == null) {
            return t;
        }
        if ((object = (Options)object.getAnnotation(Options.class)) == null) {
            return t;
        }
        object = object.value();
        try {
            object = object.getMethod("fromUnderlyingValue", new Class[]{t.getClass()}).invoke(object, new Object[]{t});
            if (object != null) {
                return object;
            }
            return t;
        }
        catch (InvocationTargetException invocationTargetException) {
            return t;
        }
        catch (IllegalAccessException illegalAccessException) {
            return t;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return t;
        }
    }

    public static Object[] optionListsFromValues(Component annotationArray, String annotation2, Object ... objectArray) {
        if (objectArray.length == 0) {
            return objectArray;
        }
        if ((annotationArray = OptionHelper.getMethod(annotationArray, (String)annotation2)) == null) {
            return objectArray;
        }
        annotationArray = annotationArray.getParameterAnnotations();
        int n = annotationArray.length;
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            for (Annotation annotation2 : annotationArray[i]) {
                if (annotation2.annotationType() != Options.class) continue;
                annotation2 = ((Options)annotation2).value();
                try {
                    annotation2 = annotation2.getMethod("fromUnderlyingValue", new Class[]{objectArray[n2].getClass()}).invoke(annotation2, new Object[]{objectArray[n2]});
                    if (annotation2 == null) break;
                }
                catch (InvocationTargetException invocationTargetException) {
                    break;
                }
                catch (IllegalAccessException illegalAccessException) {
                    break;
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    break;
                }
                objectArray[n2] = annotation2;
                break;
            }
            ++n2;
        }
        return objectArray;
    }

    private static Map<String, Method> populateMap(Class<?> object) {
        HashMap hashMap = new HashMap();
        for (Method method : object.getMethods()) {
            if ((method.getModifiers() & 1) == 0) continue;
            object = method.getName();
            if ((SimpleEvent)method.getAnnotation(SimpleEvent.class) != null) {
                hashMap.put(object, (Object)method);
                continue;
            }
            if (method.getReturnType() == Void.TYPE) continue;
            if ((SimpleFunction)method.getAnnotation(SimpleFunction.class) != null) {
                hashMap.put(object, (Object)method);
                continue;
            }
            if ((SimpleProperty)method.getAnnotation(SimpleProperty.class) == null) continue;
            hashMap.put(object, (Object)method);
        }
        return hashMap;
    }
}

