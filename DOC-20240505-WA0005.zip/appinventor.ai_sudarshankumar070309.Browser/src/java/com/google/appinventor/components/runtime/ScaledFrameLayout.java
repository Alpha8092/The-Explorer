/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Rect
 *  android.util.AttributeSet
 *  android.view.Gravity
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  com.google.appinventor.components.runtime.util.HoneycombUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Math
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.google.appinventor.components.runtime.util.HoneycombUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;

public class ScaledFrameLayout
extends ViewGroup {
    private static final int MATRIX_SAVE_FLAG = 1;
    private int mLeftWidth;
    private int mRightWidth;
    private float mScale;
    private final Rect mTmpChildRect;
    private final Rect mTmpContainerRect;

    public ScaledFrameLayout(Context context) {
        super(context);
        this.mTmpContainerRect = new Rect();
        this.mTmpChildRect = new Rect();
        this.mScale = 1.0f;
    }

    public ScaledFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
    }

    public ScaledFrameLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.mTmpContainerRect = new Rect();
        this.mTmpChildRect = new Rect();
        this.mScale = 1.0f;
        this.setClipChildren(false);
    }

    private void updatePadding(int n, int n2) {
        float f = n;
        float f2 = this.mScale;
        this.setPadding(0, 0, (int)(f * (f2 - 1.0f) / f2), (int)((float)n2 * (f2 - 1.0f) / f2));
    }

    protected void dispatchDraw(Canvas canvas) {
        canvas.save();
        float f = this.mScale;
        canvas.scale(f, f);
        super.dispatchDraw(canvas);
        canvas.restore();
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        motionEvent.setLocation(motionEvent.getX() * (1.0f / this.mScale), motionEvent.getY() * (1.0f / this.mScale));
        super.dispatchTouchEvent(motionEvent);
        return true;
    }

    public ViewParent invalidateChildInParent(int[] object, Rect rect) {
        float f = object[0];
        float f2 = this.mScale;
        int n = (int)(f * f2);
        int n2 = (int)((float)object[1] * f2);
        object = new Rect((int)((float)rect.left * this.mScale), (int)((float)rect.top * this.mScale), (int)((float)rect.right * this.mScale), (int)((float)rect.bottom * this.mScale));
        this.invalidate((Rect)object);
        return super.invalidateChildInParent(new int[]{n, n2}, (Rect)object);
    }

    protected void onLayout(boolean bl, int n, int n2, int n3, int n4) {
        int n5 = this.getChildCount();
        n3 = this.getPaddingLeft();
        int n6 = this.getPaddingTop();
        int n7 = this.getPaddingBottom();
        for (n = 0; n < n5; ++n) {
            View view = this.getChildAt(n);
            int n8 = n3;
            if (view.getVisibility() != 8) {
                int n9 = view.getMeasuredWidth();
                int n10 = view.getMeasuredHeight();
                this.mTmpContainerRect.left = n3;
                n8 = this.mTmpContainerRect.right = n3;
                this.mTmpContainerRect.top = n6;
                this.mTmpContainerRect.bottom = n4 - n2 - n7;
                Gravity.apply((int)51, (int)n9, (int)n10, (Rect)this.mTmpContainerRect, (Rect)this.mTmpChildRect);
                view.layout(this.mTmpChildRect.left, this.mTmpChildRect.top, this.mTmpChildRect.right, this.mTmpChildRect.bottom);
            }
            n3 = n8;
        }
    }

    protected void onMeasure(int n, int n2) {
        int n3;
        int n4;
        int n5 = this.getChildCount();
        this.mLeftWidth = 0;
        this.mRightWidth = 0;
        int n6 = 0;
        int n7 = 0;
        for (n4 = 0; n4 < n5; ++n4) {
            View view = this.getChildAt(n4);
            int n8 = n6;
            n3 = n7;
            if (view.getVisibility() != 8) {
                this.measureChild(view, n, n2);
                this.mLeftWidth += Math.max((int)0, (int)view.getMeasuredWidth());
                n8 = n6 = Math.max((int)n6, (int)view.getMeasuredHeight());
                n3 = n7;
                if (SdkLevel.getLevel() >= 11) {
                    n3 = HoneycombUtil.combineMeasuredStates((ViewGroup)this, (int)n7, (int)HoneycombUtil.getMeasuredState((View)view));
                    n8 = n6;
                }
            }
            n6 = n8;
            n7 = n3;
        }
        n3 = this.mLeftWidth;
        n4 = this.mRightWidth;
        n6 = Math.max((int)n6, (int)this.getSuggestedMinimumHeight());
        n4 = Math.max((int)(0 + (n3 + n4)), (int)this.getSuggestedMinimumWidth());
        if (SdkLevel.getLevel() >= 11) {
            this.setMeasuredDimension(HoneycombUtil.resolveSizeAndState((ViewGroup)this, (int)n4, (int)n, (int)n7), HoneycombUtil.resolveSizeAndState((ViewGroup)this, (int)n6, (int)n2, (int)(n7 << 16)));
        } else {
            this.setMeasuredDimension(ScaledFrameLayout.resolveSize((int)n4, (int)n), ScaledFrameLayout.resolveSize((int)n6, (int)n2));
        }
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.updatePadding(n, n2);
    }

    public void setScale(float f) {
        this.mScale = f;
        super.updatePadding(this.getWidth(), this.getHeight());
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}

