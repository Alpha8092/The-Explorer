/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.UltrasonicSensorUnit
 *  com.google.appinventor.components.runtime.LegoMindstormsEv3Sensor
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.UltrasonicSensorUnit;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsEv3Sensor;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to an ultrasonic sensor on a LEGO MINDSTORMS EV3 robot.", iconName="images/legoMindstormsEv3.png", nonVisible=true, version=2)
@SimpleObject
public class Ev3UltrasonicSensor
extends LegoMindstormsEv3Sensor
implements Deleteable {
    private static final int DEFAULT_BOTTOM_OF_RANGE = 30;
    private static final int DEFAULT_TOP_OF_RANGE = 90;
    private static final int DELAY_MILLISECONDS = 50;
    private static final int SENSOR_TYPE = 30;
    private boolean aboveRangeEventEnabled;
    private boolean belowRangeEventEnabled;
    private int bottomOfRange;
    private Handler eventHandler;
    private UltrasonicSensorUnit mode = UltrasonicSensorUnit.Centimeters;
    private double previousDistance = -1.0;
    private final Runnable sensorValueChecker;
    private int topOfRange;
    private boolean withinRangeEventEnabled;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetaboveRangeEventEnabled(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.aboveRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetbelowRangeEventEnabled(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.belowRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetbottomOfRange(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.bottomOfRange;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgeteventHandler(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.eventHandler;
    }

    static /* bridge */ /* synthetic */ double -$$Nest$fgetpreviousDistance(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.previousDistance;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgettopOfRange(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.topOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetwithinRangeEventEnabled(Ev3UltrasonicSensor ev3UltrasonicSensor) {
        return ev3UltrasonicSensor.withinRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousDistance(Ev3UltrasonicSensor ev3UltrasonicSensor, double d) {
        ev3UltrasonicSensor.previousDistance = d;
    }

    static /* bridge */ /* synthetic */ double -$$Nest$mgetDistance(Ev3UltrasonicSensor ev3UltrasonicSensor, String string) {
        return ev3UltrasonicSensor.getDistance(string);
    }

    public Ev3UltrasonicSensor(ComponentContainer object2) {
        super((ComponentContainer)object2, "Ev3UltrasonicSensor");
        this.eventHandler = new Handler();
        object2 = new Runnable((Ev3UltrasonicSensor)this){
            final Ev3UltrasonicSensor this$0;
            {
                this.this$0 = ev3UltrasonicSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    double d = Ev3UltrasonicSensor.-$$Nest$mgetDistance(this.this$0, "");
                    if (Ev3UltrasonicSensor.-$$Nest$fgetpreviousDistance(this.this$0) < 0.0) {
                        Ev3UltrasonicSensor.-$$Nest$fputpreviousDistance(this.this$0, d);
                        Ev3UltrasonicSensor.-$$Nest$fgeteventHandler(this.this$0).postDelayed((Runnable)this, 50L);
                        return;
                    }
                    if (d < (double)Ev3UltrasonicSensor.-$$Nest$fgetbottomOfRange(this.this$0)) {
                        if (Ev3UltrasonicSensor.-$$Nest$fgetbelowRangeEventEnabled(this.this$0) && Ev3UltrasonicSensor.-$$Nest$fgetpreviousDistance(this.this$0) >= (double)Ev3UltrasonicSensor.-$$Nest$fgetbottomOfRange(this.this$0)) {
                            this.this$0.BelowRange();
                        }
                    } else if (d > (double)Ev3UltrasonicSensor.-$$Nest$fgettopOfRange(this.this$0)) {
                        if (Ev3UltrasonicSensor.-$$Nest$fgetaboveRangeEventEnabled(this.this$0) && Ev3UltrasonicSensor.-$$Nest$fgetpreviousDistance(this.this$0) <= (double)Ev3UltrasonicSensor.-$$Nest$fgettopOfRange(this.this$0)) {
                            this.this$0.AboveRange();
                        }
                    } else if (Ev3UltrasonicSensor.-$$Nest$fgetwithinRangeEventEnabled(this.this$0) && (Ev3UltrasonicSensor.-$$Nest$fgetpreviousDistance(this.this$0) < (double)Ev3UltrasonicSensor.-$$Nest$fgetbottomOfRange(this.this$0) || Ev3UltrasonicSensor.-$$Nest$fgetpreviousDistance(this.this$0) > (double)Ev3UltrasonicSensor.-$$Nest$fgettopOfRange(this.this$0))) {
                        this.this$0.WithinRange();
                    }
                    Ev3UltrasonicSensor.-$$Nest$fputpreviousDistance(this.this$0, d);
                }
                Ev3UltrasonicSensor.-$$Nest$fgeteventHandler(this.this$0).postDelayed((Runnable)this, 50L);
            }
        };
        this.sensorValueChecker = object2;
        this.eventHandler.post((Runnable)object2);
        this.TopOfRange(90);
        this.BottomOfRange(30);
        this.BelowRangeEventEnabled(false);
        this.AboveRangeEventEnabled(false);
        this.WithinRangeEventEnabled(false);
        this.UnitAbstract(UltrasonicSensorUnit.Centimeters);
    }

    private double getDistance(String string) {
        double d;
        block0: {
            d = this.readInputSI(string, 0, this.sensorPortNumber, 30, this.mode.toInt().intValue());
            if (d != 255.0) break block0;
            d = -1.0;
        }
        return d;
    }

    private void setMode(UltrasonicSensorUnit ultrasonicSensorUnit) {
        this.previousDistance = -1.0;
        this.mode = ultrasonicSensorUnit;
    }

    @SimpleEvent(description="Called when the detected distance has gone above the range.")
    public void AboveRange() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "AboveRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void AboveRangeEventEnabled(boolean bl) {
        this.aboveRangeEventEnabled = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the AboveRange event should fire when the distance goes above the TopOfRange.")
    public boolean AboveRangeEventEnabled() {
        return this.aboveRangeEventEnabled;
    }

    @SimpleEvent(description="Called when the detected distance has gone below the range.")
    public void BelowRange() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "BelowRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BelowRangeEventEnabled(boolean bl) {
        this.belowRangeEventEnabled = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the BelowRange event should fire when the distance goes below the BottomOfRange.")
    public boolean BelowRangeEventEnabled() {
        return this.belowRangeEventEnabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The bottom of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int BottomOfRange() {
        return this.bottomOfRange;
    }

    @DesignerProperty(defaultValue="30", editorType="non_negative_integer")
    @SimpleProperty
    public void BottomOfRange(int n) {
        this.bottomOfRange = n;
    }

    @SimpleFunction(description="Returns the current distance in centimeters as a value between 0 and 254, or -1 if the distance can not be read.")
    public double GetDistance() {
        return this.getDistance("GetDistance");
    }

    @SimpleFunction(description="Measure the distance in centimeters.")
    @Deprecated
    public void SetCmUnit() {
        this.setMode(UltrasonicSensorUnit.Centimeters);
    }

    @SimpleFunction(description="Measure the distance in inches.")
    @Deprecated
    public void SetInchUnit() {
        this.setMode(UltrasonicSensorUnit.Inches);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The top of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int TopOfRange() {
        return this.topOfRange;
    }

    @DesignerProperty(defaultValue="90", editorType="non_negative_integer")
    @SimpleProperty
    public void TopOfRange(int n) {
        this.topOfRange = n;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The distance unit, which can be either \"cm\" or \"inch\".")
    public String Unit() {
        return this.mode.toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="cm", editorType="lego_ev3_ultrasonic_sensor_mode")
    @SimpleProperty
    public void Unit(@Options(value=UltrasonicSensorUnit.class) String string) {
        UltrasonicSensorUnit ultrasonicSensorUnit = UltrasonicSensorUnit.fromUnderlyingValue((String)string);
        if (ultrasonicSensorUnit == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "Unit", 3103, string);
            return;
        }
        super.setMode(ultrasonicSensorUnit);
    }

    public UltrasonicSensorUnit UnitAbstract() {
        return this.mode;
    }

    public void UnitAbstract(UltrasonicSensorUnit ultrasonicSensorUnit) {
        super.setMode(ultrasonicSensorUnit);
    }

    @SimpleEvent(description="Called when the detected distance has gone within the range.")
    public void WithinRange() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "WithinRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WithinRangeEventEnabled(boolean bl) {
        this.withinRangeEventEnabled = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the WithinRange event should fire when the distance goes between the BottomOfRange and the TopOfRange.")
    public boolean WithinRangeEventEnabled() {
        return this.withinRangeEventEnabled;
    }

    @Override
    public void onDelete() {
        this.eventHandler.removeCallbacks(this.sensorValueChecker);
        super.onDelete();
    }
}

