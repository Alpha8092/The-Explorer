/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.FileAccessMode
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  com.google.appinventor.components.runtime.util.ScopedFile
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.util;

import android.net.Uri;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.FileAccessMode;
import com.google.appinventor.components.runtime.util.FileStreamOperation;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.ScopedFile;
import java.io.IOException;
import java.io.InputStream;

public class FileReadOperation
extends FileStreamOperation<InputStream> {
    public FileReadOperation(Form form, Component component, String string2, String string3, FileScope fileScope, boolean bl) {
        super(form, component, string2, string3, fileScope, FileAccessMode.READ, bl);
    }

    @Override
    protected InputStream openFile() throws IOException {
        if (this.scopedFile.getFileName().startsWith("content:")) {
            return this.form.getContentResolver().openInputStream(Uri.parse((String)this.scopedFile.getFileName()));
        }
        return FileUtil.openForReading((Form)this.form, (ScopedFile)this.scopedFile);
    }

    @Override
    protected boolean process(InputStream inputStream) throws IOException {
        return this.process(IOUtils.readStream((InputStream)inputStream));
    }

    @Override
    public boolean process(byte[] byArray) {
        return true;
    }
}

