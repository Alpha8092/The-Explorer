package com.google.appinventor.components.runtime.util;

import android.graphics.Point;
import android.view.Display;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public class JellybeanUtil {
    private JellybeanUtil() {
    }

    public static void getRealSize(Display display, Point outSize) {
        display.getRealSize(outSize);
    }
}
