/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.data.Entry
 *  com.google.appinventor.components.runtime.util.ChartDataSourceUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  gnu.mapping.Symbol
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.Entry;
import com.google.appinventor.components.runtime.util.ChartDataSourceUtil;
import com.google.appinventor.components.runtime.util.YailList;
import gnu.mapping.Symbol;
import java.util.ArrayList;
import java.util.List;

public abstract class DataModel<E> {
    protected List<E> entries = new ArrayList();
    protected int maximumTimeEntries = 200;

    protected DataModel() {
    }

    public abstract void addEntryFromTuple(YailList var1);

    public abstract void addTimeEntry(YailList var1);

    protected boolean areEntriesEqual(Entry entry, Entry entry2) {
        return entry.equalTo(entry2);
    }

    public abstract void clearEntries();

    public abstract boolean doesEntryExist(YailList var1);

    public abstract YailList findEntriesByCriterion(String var1, EntryCriterion var2);

    public abstract int findEntryIndex(Entry var1);

    protected String getDefaultValue(int n) {
        return "" + n;
    }

    public abstract List<E> getEntries();

    public YailList getEntriesAsTuples() {
        return this.findEntriesByCriterion("0", EntryCriterion.All);
    }

    public abstract Entry getEntryFromTuple(YailList var1);

    public abstract YailList getTupleFromEntry(Entry var1);

    protected abstract int getTupleSize();

    public YailList getTuplesFromColumns(YailList yailList, boolean n) {
        int n2 = ChartDataSourceUtil.determineMaximumListSize((YailList)yailList);
        ArrayList arrayList = new ArrayList();
        while (n < n2) {
            ArrayList arrayList2 = new ArrayList();
            for (int i = 0; i < yailList.size(); ++i) {
                Object object = yailList.getObject(i);
                if (!(object instanceof YailList)) {
                    arrayList2.add((Object)this.getDefaultValue(n - 1));
                    continue;
                }
                if ((object = (YailList)object).size() > n) {
                    arrayList2.add((Object)object.getString(n));
                    continue;
                }
                if (object.size() == 0) {
                    arrayList2.add((Object)this.getDefaultValue(n - 1));
                    continue;
                }
                arrayList2.add((Object)"");
            }
            arrayList.add((Object)YailList.makeList((List)arrayList2));
            ++n;
        }
        return YailList.makeList((List)arrayList);
    }

    public void importFromColumns(YailList yailList, boolean bl) {
        this.importFromList((List<?>)this.getTuplesFromColumns(yailList, bl));
    }

    public void importFromList(List<?> yailList) {
        for (Object object : yailList) {
            yailList = null;
            if (object instanceof YailList) {
                yailList = (YailList)object;
            } else if (object instanceof List) {
                yailList = YailList.makeList((List)((List)object));
            }
            if (yailList == null) continue;
            this.addEntryFromTuple(yailList);
        }
    }

    protected abstract boolean isEntryCriterionSatisfied(Entry var1, EntryCriterion var2, String var3);

    public abstract void removeEntry(int var1);

    public abstract void removeEntryFromTuple(YailList var1);

    public void removeValues(List<?> yailList) {
        for (Object object : yailList) {
            yailList = null;
            if (object instanceof YailList) {
                yailList = (YailList)object;
            } else if (object instanceof List) {
                yailList = YailList.makeList((List)((List)object));
            } else if (object instanceof Symbol) continue;
            if (yailList == null) continue;
            this.removeEntryFromTuple(yailList);
        }
    }

    protected void setDefaultStylingProperties() {
    }

    public void setElements(String string) {
        int n = this.getTupleSize();
        String[] stringArray = string.split(",");
        for (int i = n - 1; i < stringArray.length; i += n) {
            string = new ArrayList();
            for (int j = n - 1; j >= 0; --j) {
                string.add((Object)stringArray[i - j]);
            }
            this.addEntryFromTuple(YailList.makeList((List)string));
        }
    }

    public void setMaximumTimeEntries(int n) {
        this.maximumTimeEntries = n;
    }

    public static final class EntryCriterion
    extends Enum<EntryCriterion> {
        private static final EntryCriterion[] $VALUES;
        public static final /* enum */ EntryCriterion All;
        public static final /* enum */ EntryCriterion XValue;
        public static final /* enum */ EntryCriterion YValue;

        static {
            EntryCriterion entryCriterion;
            EntryCriterion entryCriterion2;
            EntryCriterion entryCriterion3;
            All = entryCriterion3 = new EntryCriterion();
            XValue = entryCriterion2 = new EntryCriterion();
            YValue = entryCriterion = new EntryCriterion();
            $VALUES = new EntryCriterion[]{entryCriterion3, entryCriterion2, entryCriterion};
        }

        public static EntryCriterion valueOf(String string) {
            return (EntryCriterion)Enum.valueOf(EntryCriterion.class, (String)string);
        }

        public static EntryCriterion[] values() {
            return (EntryCriterion[])$VALUES.clone();
        }
    }
}

