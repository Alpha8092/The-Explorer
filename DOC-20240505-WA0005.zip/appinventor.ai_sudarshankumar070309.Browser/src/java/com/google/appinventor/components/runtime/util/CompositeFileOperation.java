/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.CompositeFileOperation$FileOperand
 *  com.google.appinventor.components.runtime.util.FileAccessMode
 *  com.google.appinventor.components.runtime.util.FileOperation
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.CompositeFileOperation;
import com.google.appinventor.components.runtime.util.FileAccessMode;
import com.google.appinventor.components.runtime.util.FileOperation;
import com.google.appinventor.components.runtime.util.FileUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/*
 * Exception performing whole class analysis ignored.
 */
public abstract class CompositeFileOperation
extends FileOperation
implements Iterable<FileOperand> {
    private final List<FileOperand> files = new ArrayList();
    private boolean needsExternalStorage = false;
    private final Set<String> permissions = new HashSet();

    public CompositeFileOperation(Form form, Component component, String string, boolean bl) {
        super(form, component, string, bl);
    }

    public void addFile(FileScope fileScope, String string, FileAccessMode fileAccessMode) {
        fileScope = new /* Unavailable Anonymous Inner Class!! */;
        this.files.add((Object)fileScope);
        this.permissions.add((Object)FileUtil.getNeededPermission((Form)this.form, (String)string, (FileAccessMode)fileAccessMode));
        this.needsExternalStorage |= FileUtil.isExternalStorageUri((Form)this.form, (String)FileOperand.-$$Nest$fgetfile(fileScope));
    }

    public List<String> getPermissions() {
        return new ArrayList(this.permissions);
    }

    public Iterator<FileOperand> iterator() {
        return this.files.iterator();
    }

    protected boolean needsExternalStorage() {
        return this.needsExternalStorage;
    }

    protected abstract void performOperation();
}

