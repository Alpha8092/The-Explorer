/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.TinyWebDB$2
 *  com.google.appinventor.components.runtime.TinyWebDB$4
 *  com.google.appinventor.components.runtime.util.AsyncCallbackPair
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.WebServiceUtil
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONException
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.TinyWebDB;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.AsyncCallbackPair;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.WebServiceUtil;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.STORAGE, description="Non-visible component that communicates with a Web service to store and retrieve information.", iconName="images/tinyWebDB.png", nonVisible=true, version=2)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.INTERNET")
public class TinyWebDB
extends AndroidNonvisibleComponent
implements Component {
    private static final String GETVALUE_COMMAND = "getvalue";
    private static final String LOG_TAG = "TinyWebDB";
    private static final String STOREAVALUE_COMMAND = "storeavalue";
    private static final String TAG_PARAMETER = "tag";
    private static final String VALUE_PARAMETER = "value";
    private Handler androidUIHandler = new Handler();
    private String serviceURL = "http://tinywebdb.appinventor.mit.edu/";

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgetandroidUIHandler(TinyWebDB tinyWebDB) {
        return tinyWebDB.androidUIHandler;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostGetValue(TinyWebDB tinyWebDB, String string) {
        tinyWebDB.postGetValue(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostStoreValue(TinyWebDB tinyWebDB, String string, Object object2) {
        tinyWebDB.postStoreValue(string, object2);
    }

    public TinyWebDB(ComponentContainer componentContainer) {
        super(componentContainer.$form());
    }

    private void postGetValue(String string) {
        4 var2_2 = new 4((TinyWebDB)this, string);
        WebServiceUtil.getInstance().postCommandReturningArray(this.serviceURL, GETVALUE_COMMAND, Lists.newArrayList(new BasicNameValuePair(TAG_PARAMETER, string)), (AsyncCallbackPair)var2_2);
    }

    private void postStoreValue(String string, Object object2) {
        2 var3_4 = new 2((TinyWebDB)this);
        try {
            WebServiceUtil webServiceUtil = WebServiceUtil.getInstance();
            String string2 = this.serviceURL;
            BasicNameValuePair basicNameValuePair = new BasicNameValuePair(TAG_PARAMETER, string);
            string = new BasicNameValuePair(VALUE_PARAMETER, JsonUtil.getJsonRepresentation((Object)object2));
            webServiceUtil.postCommand(string2, STOREAVALUE_COMMAND, Lists.newArrayList(basicNameValuePair, string), (AsyncCallbackPair)var3_4);
            return;
        }
        catch (JSONException jSONException) {
            throw new YailRuntimeError("Value failed to convert to JSON.", "JSON Creation Error.");
        }
    }

    @SimpleFunction(description="Sends a request to the Web service to get the value stored under the given tag. The Web service must decide what to return if there is no value stored under the tag. This component accepts whatever is returned.")
    public void GetValue(String string) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((TinyWebDB)this, string){
            final TinyWebDB this$0;
            final String val$tag;
            {
                this.this$0 = tinyWebDB;
                this.val$tag = string;
            }

            public void run() {
                TinyWebDB.-$$Nest$mpostGetValue(this.this$0, this.val$tag);
            }
        });
    }

    @SimpleEvent(description="Indicates that a GetValue server request has succeeded.")
    public void GotValue(String string, Object object2) {
        EventDispatcher.dispatchEvent((Component)this, "GotValue", string, object2);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The URL of the web service database.")
    public String ServiceURL() {
        return this.serviceURL;
    }

    @DesignerProperty(defaultValue="http://tinywebdb.appinventor.mit.edu", editorType="string")
    @SimpleProperty
    public void ServiceURL(String string) {
        this.serviceURL = string;
    }

    @SimpleFunction(description="Asks the Web service to store the given value under the given tag")
    public void StoreValue(String string, Object object2) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((TinyWebDB)this, string, object2){
            final TinyWebDB this$0;
            final String val$tag;
            final Object val$valueToStore;
            {
                this.this$0 = tinyWebDB;
                this.val$tag = string;
                this.val$valueToStore = object2;
            }

            public void run() {
                TinyWebDB.-$$Nest$mpostStoreValue(this.this$0, this.val$tag, this.val$valueToStore);
            }
        });
    }

    @SimpleEvent(description="Event indicating that a StoreValue server request has succeeded.")
    public void ValueStored() {
        EventDispatcher.dispatchEvent(this, "ValueStored", new Object[0]);
    }

    @SimpleEvent
    public void WebServiceError(String string) {
        EventDispatcher.dispatchEvent((Component)this, "WebServiceError", string);
    }
}

