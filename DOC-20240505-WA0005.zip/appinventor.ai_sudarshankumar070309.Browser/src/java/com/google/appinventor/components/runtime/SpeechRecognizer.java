/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.IntentBasedSpeechRecognizer
 *  com.google.appinventor.components.runtime.ServiceBasedSpeechRecognizer
 *  com.google.appinventor.components.runtime.SpeechRecognizer$1$1
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.IntentBasedSpeechRecognizer;
import com.google.appinventor.components.runtime.OnClearListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.ServiceBasedSpeechRecognizer;
import com.google.appinventor.components.runtime.SpeechListener;
import com.google.appinventor.components.runtime.SpeechRecognizer;
import com.google.appinventor.components.runtime.SpeechRecognizerController;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="Component for using Voice Recognition to convert from speech to text", iconName="images/speechRecognizer.png", nonVisible=true, version=3)
@SimpleObject
@UsesPermissions(value={"android.permission.RECORD_AUDIO", "android.permission.INTERNET"})
public class SpeechRecognizer
extends AndroidNonvisibleComponent
implements Component,
OnClearListener,
SpeechListener {
    private final ComponentContainer container;
    private boolean havePermission = false;
    private String language = "";
    private Intent recognizerIntent;
    private String result;
    private SpeechRecognizerController speechRecognizerController;
    private boolean useLegacy = true;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(SpeechRecognizer speechRecognizer, boolean bl) {
        speechRecognizer.havePermission = bl;
    }

    public SpeechRecognizer(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        componentContainer.$form().registerForOnClear((OnClearListener)this);
        this.container = componentContainer;
        this.result = "";
        componentContainer = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.recognizerIntent = componentContainer;
        componentContainer.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        this.recognizerIntent.putExtra("android.speech.extra.PARTIAL_RESULTS", true);
        this.UseLegacy(this.useLegacy);
    }

    @SimpleEvent
    public void AfterGettingText(String string, boolean bl) {
        EventDispatcher.dispatchEvent((Component)this, "AfterGettingText", string, bl);
    }

    @SimpleEvent
    public void BeforeGettingText() {
        EventDispatcher.dispatchEvent(this, "BeforeGettingText", new Object[0]);
    }

    @SimpleFunction
    public void GetText() {
        if (!this.havePermission) {
            this.form.runOnUiThread(new Runnable(this, this){
                final SpeechRecognizer this$0;
                final SpeechRecognizer val$me;
                {
                    this.this$0 = speechRecognizer;
                    this.val$me = speechRecognizer2;
                }

                public void run() {
                    this.this$0.form.askPermission("android.permission.RECORD_AUDIO", (PermissionResultHandler)new 1(this));
                }
            });
            return;
        }
        this.BeforeGettingText();
        this.speechRecognizerController.addListener(this);
        this.speechRecognizerController.start();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String Language() {
        return this.language;
    }

    @SimpleProperty
    public void Language(String string) {
        this.language = string;
        if (TextUtils.isEmpty((CharSequence)string)) {
            this.recognizerIntent.removeExtra("android.speech.extra.LANGUAGE");
        } else {
            this.recognizerIntent.putExtra("android.speech.extra.LANGUAGE", string);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String Result() {
        return this.result;
    }

    @SimpleFunction
    public void Stop() {
        SpeechRecognizerController speechRecognizerController = this.speechRecognizerController;
        if (speechRecognizerController != null) {
            speechRecognizerController.stop();
        }
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(description="If true, a separate dialog is used to recognize speech (the default). If false, speech is recognized in the background and partial results are also provided.")
    public void UseLegacy(boolean bl) {
        this.useLegacy = bl;
        this.Stop();
        this.speechRecognizerController = !bl && Build.VERSION.SDK_INT >= 8 ? new ServiceBasedSpeechRecognizer(this.container, this.recognizerIntent) : new IntentBasedSpeechRecognizer(this.container, this.recognizerIntent);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true, an app can retain their older behaviour.")
    public boolean UseLegacy() {
        return this.useLegacy;
    }

    @Override
    public void onClear() {
        this.Stop();
        this.speechRecognizerController = null;
        this.recognizerIntent = null;
    }

    @Override
    public void onError(int n) {
        this.form.dispatchErrorOccurredEvent((Component)this, "GetText", n, new Object[0]);
    }

    @Override
    public void onPartialResult(String string) {
        this.result = string;
        this.AfterGettingText(string, true);
    }

    @Override
    public void onResult(String string) {
        this.result = string;
        this.AfterGettingText(string, false);
    }
}

