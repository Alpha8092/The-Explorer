/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.ActionBar
 *  android.app.Activity
 *  android.text.Html
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.util.ImageViewUtil
 *  com.google.appinventor.components.runtime.util.theme.ThemeHelper
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.util.theme;

import android.app.ActionBar;
import android.app.Activity;
import android.text.Html;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.ImageViewUtil;
import com.google.appinventor.components.runtime.util.theme.ThemeHelper;

public class HoneycombThemeHelper
implements ThemeHelper {
    private final AppInventorCompatActivity activity;

    public HoneycombThemeHelper(AppInventorCompatActivity appInventorCompatActivity) {
        this.activity = appInventorCompatActivity;
    }

    public boolean hasActionBar() {
        boolean bl = this.activity.getActionBar() != null;
        return bl;
    }

    public void requestActionBar() {
        if (!this.activity.getWindow().hasFeature(8)) {
            this.activity.getWindow().requestFeature(8);
        }
    }

    public void setActionBarAnimation(boolean bl) {
    }

    public boolean setActionBarVisible(boolean bl) {
        ActionBar actionBar = this.activity.getActionBar();
        if (actionBar == null) {
            actionBar = this.activity;
            if (actionBar instanceof Form) {
                ((Form)actionBar).dispatchErrorOccurredEvent((Form)actionBar, "ActionBar", 907, new Object[0]);
            }
            return false;
        }
        if (bl) {
            actionBar.show();
        } else {
            actionBar.hide();
        }
        return true;
    }

    public void setTitle(String string) {
        ActionBar actionBar = this.activity.getActionBar();
        if (actionBar != null) {
            actionBar.setTitle((CharSequence)string);
        }
    }

    public void setTitle(String string, boolean bl) {
        ActionBar actionBar = this.activity.getActionBar();
        if (actionBar != null) {
            if (bl) {
                actionBar.setTitle((CharSequence)Html.fromHtml((String)("<font color=\"black\">" + string + "</font>")));
                ImageViewUtil.setMenuButtonColor((Activity)this.activity, (int)-16777216);
            } else {
                actionBar.setTitle((CharSequence)string);
                ImageViewUtil.setMenuButtonColor((Activity)this.activity, (int)-1);
            }
        }
    }
}

