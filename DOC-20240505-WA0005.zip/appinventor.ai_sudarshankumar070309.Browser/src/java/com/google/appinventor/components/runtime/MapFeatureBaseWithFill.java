/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.util.MapFactory$HasFill
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.MapFeatureBase;
import com.google.appinventor.components.runtime.util.MapFactory;

@SimpleObject
public abstract class MapFeatureBaseWithFill
extends MapFeatureBase
implements MapFactory.HasFill {
    private int fillColor = -65536;
    private float fillOpacity = 1.0f;

    public MapFeatureBaseWithFill(MapFactory.MapFeatureContainer mapFeatureContainer, MapFactory.MapFeatureVisitor<Double> mapFeatureVisitor) {
        super(mapFeatureContainer, mapFeatureVisitor);
        this.FillColor(-65536);
        this.FillOpacity(1.0f);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The paint color used to fill in the %type%.")
    public int FillColor() {
        return this.fillColor;
    }

    @DesignerProperty(defaultValue="&HFFFF0000", editorType="color")
    @SimpleProperty
    public void FillColor(int n) {
        this.fillColor = n;
        this.map.getController().updateFeatureFill((MapFactory.HasFill)this);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The opacity of the interior of the map feature.")
    public float FillOpacity() {
        return this.fillOpacity;
    }

    @DesignerProperty(defaultValue="1.0", editorType="float")
    @SimpleProperty
    public void FillOpacity(float f) {
        this.fillOpacity = f;
        this.fillColor = this.fillColor & 0xFFFFFF | Math.round((float)(255.0f * f)) << 24;
        this.map.getController().updateFeatureFill((MapFactory.HasFill)this);
    }
}

