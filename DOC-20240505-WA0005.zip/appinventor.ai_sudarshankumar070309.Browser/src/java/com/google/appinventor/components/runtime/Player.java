/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.media.AudioManager
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.os.Vibrator
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Player$1
 *  com.google.appinventor.components.runtime.util.FroyoUtil
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.TiramisuUtil
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Vibrator;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.Player;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.util.FroyoUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.TiramisuUtil;
import java.io.IOException;

@DesignerComponent(category=ComponentCategory.MEDIA, description="Multimedia component that plays audio and controls phone vibration.  The name of a multimedia field is specified in the <code>Source</code> property, which can be set in the Designer or in the Blocks Editor.  The length of time for a vibration is specified in the Blocks Editor in milliseconds (thousandths of a second).\n<p>For supported audio formats, see <a href=\"http://developer.android.com/guide/appendix/media-formats.html\" target=\"_blank\">Android Supported Media Formats</a>.</p>\n<p>This component is best for long sound files, such as songs, while the <code>Sound</code> component is more efficient for short files, such as sound effects.</p>", iconName="images/player.png", nonVisible=true, version=6)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.VIBRATE, android.permission.INTERNET")
public final class Player
extends AndroidNonvisibleComponent
implements Component,
MediaPlayer.OnCompletionListener,
OnPauseListener,
OnResumeListener,
OnDestroyListener,
OnStopListener,
Deleteable {
    private static final boolean audioFocusSupported = SdkLevel.getLevel() >= 8;
    private final Activity activity;
    private Object afChangeListener;
    private AudioManager am;
    private boolean focusOn;
    private boolean loop;
    private boolean playOnlyInForeground;
    private MediaPlayer player;
    public State playerState;
    private String sourcePath;
    private final Vibrator vibe;

    public Player(ComponentContainer object2) {
        super(object2.$form());
        object2 = object2.$context();
        this.activity = object2;
        this.sourcePath = "";
        this.vibe = (Vibrator)this.form.getSystemService("vibrator");
        this.form.registerForOnDestroy((OnDestroyListener)this);
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.form.setVolumeControlStream(3);
        this.loop = false;
        this.playOnlyInForeground = false;
        this.focusOn = false;
        boolean bl = audioFocusSupported;
        Object var2_3 = null;
        object2 = bl ? FroyoUtil.setAudioManager((Activity)object2) : null;
        this.am = object2;
        object2 = var2_3;
        if (bl) {
            object2 = FroyoUtil.setAudioFocusChangeListener((Player)this);
        }
        this.afChangeListener = object2;
    }

    private void abandonFocus() {
        FroyoUtil.abandonFocus((AudioManager)this.am, (Object)this.afChangeListener);
        this.focusOn = false;
    }

    private void prepare() {
        try {
            this.player.prepare();
            this.playerState = State.PREPARED;
        }
        catch (IOException iOException) {
            this.player.release();
            this.player = null;
            this.playerState = State.INITIAL;
            this.form.dispatchErrorOccurredEvent(this, "Source", 702, this.sourcePath);
        }
    }

    private void prepareToDie() {
        if (audioFocusSupported && this.focusOn) {
            this.abandonFocus();
        }
        if (this.player != null && this.playerState != State.INITIAL) {
            this.player.stop();
        }
        this.playerState = State.INITIAL;
        MediaPlayer mediaPlayer = this.player;
        if (mediaPlayer != null) {
            mediaPlayer.release();
            this.player = null;
        }
        this.vibe.cancel();
    }

    private void requestPermanentFocus() {
        boolean bl;
        this.focusOn = bl = FroyoUtil.focusRequestGranted((AudioManager)this.am, (Object)this.afChangeListener);
        if (!bl) {
            this.form.dispatchErrorOccurredEvent(this, "Source", 709, this.sourcePath);
        }
    }

    @SimpleEvent
    public void Completed() {
        if (audioFocusSupported && this.focusOn) {
            this.abandonFocus();
        }
        EventDispatcher.dispatchEvent(this, "Completed", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Reports whether the media is playing")
    public boolean IsPlaying() {
        if (this.playerState != State.PREPARED && this.playerState != State.PLAYING) {
            return false;
        }
        return this.player.isPlaying();
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void Loop(boolean bl) {
        if (this.playerState == State.PREPARED || this.playerState == State.PLAYING || this.playerState == State.PAUSED_BY_USER) {
            this.player.setLooping(bl);
        }
        this.loop = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true, the player will loop when it plays. Setting Loop while the player is playing will affect the current playing.")
    public boolean Loop() {
        return this.loop;
    }

    @SimpleEvent(description="This event is signaled when another player has started (and the current player is playing or paused, but not stopped).")
    public void OtherPlayerStarted() {
        EventDispatcher.dispatchEvent(this, "OtherPlayerStarted", new Object[0]);
    }

    @SimpleFunction
    public void Pause() {
        MediaPlayer mediaPlayer = this.player;
        if (mediaPlayer == null) {
            return;
        }
        boolean bl = mediaPlayer.isPlaying();
        if (this.playerState == State.PLAYING) {
            this.player.pause();
            if (bl) {
                this.playerState = State.PAUSED_BY_USER;
            }
        }
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void PlayOnlyInForeground(boolean bl) {
        this.playOnlyInForeground = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true, the player will pause playing when leaving the current screen; if false (default option), the player continues playing whenever the current screen is displaying or not.")
    public boolean PlayOnlyInForeground() {
        return this.playOnlyInForeground;
    }

    @SimpleEvent(description="The PlayerError event is no longer used. Please use the Screen.ErrorOccurred event instead.", userVisible=false)
    public void PlayerError(String string) {
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String Source() {
        return this.sourcePath;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty
    @UsesPermissions(value={"android.permission.READ_EXTERNAL_STORAGE", "android.permission.READ_MEDIA_AUDIO"})
    public void Source(@Asset String string) {
        String string2 = string == null ? "" : string;
        if (TiramisuUtil.requestAudioPermissions((Form)this.form, (String)string, (PermissionResultHandler)new 1((Player)this, string2))) {
            return;
        }
        this.sourcePath = string2;
        if (this.playerState == State.PREPARED || this.playerState == State.PLAYING || this.playerState == State.PAUSED_BY_USER) {
            this.player.stop();
            this.playerState = State.INITIAL;
        }
        if ((string = this.player) != null) {
            string.release();
            this.player = null;
        }
        if (this.sourcePath.length() > 0) {
            string = new MediaPlayer();
            this.player = string;
            string.setOnCompletionListener((MediaPlayer.OnCompletionListener)this);
            try {
                MediaUtil.loadMediaPlayer((MediaPlayer)this.player, (Form)this.form, (String)this.sourcePath);
            }
            catch (IOException iOException) {
                this.player.release();
                this.player = null;
                this.form.dispatchErrorOccurredEvent((Component)this, "Source", 701, this.sourcePath);
                return;
            }
            catch (PermissionException permissionException) {
                this.player.release();
                this.player = null;
                this.form.dispatchPermissionDeniedEvent((Component)this, "Source", permissionException);
                return;
            }
            this.player.setAudioStreamType(3);
            if (audioFocusSupported) {
                super.requestPermanentFocus();
            }
            super.prepare();
        }
    }

    @SimpleFunction
    public void Start() {
        if (audioFocusSupported && !this.focusOn) {
            this.requestPermanentFocus();
        }
        if (this.playerState == State.PREPARED || this.playerState == State.PLAYING || this.playerState == State.PAUSED_BY_USER || this.playerState == State.PAUSED_BY_EVENT) {
            this.player.setLooping(this.loop);
            this.player.start();
            this.playerState = State.PLAYING;
        }
    }

    @SimpleFunction
    public void Stop() {
        if (audioFocusSupported && this.focusOn) {
            this.abandonFocus();
        }
        if (this.playerState == State.PLAYING || this.playerState == State.PAUSED_BY_USER || this.playerState == State.PAUSED_BY_EVENT) {
            this.player.stop();
            this.prepare();
            MediaPlayer mediaPlayer = this.player;
            if (mediaPlayer != null) {
                mediaPlayer.seekTo(0);
            }
        }
    }

    @SimpleFunction
    public void Vibrate(long l) {
        this.vibe.vibrate(l);
    }

    @DesignerProperty(defaultValue="50", editorType="non_negative_float")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the volume to a number between 0 and 100")
    public void Volume(int n) {
        if (this.playerState == State.PREPARED || this.playerState == State.PLAYING || this.playerState == State.PAUSED_BY_USER) {
            if (n <= 100 && n >= 0) {
                this.player.setVolume((float)n / 100.0f, (float)n / 100.0f);
            } else {
                this.form.dispatchErrorOccurredEvent((Component)this, "Volume", 712, n);
            }
        }
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        this.Completed();
    }

    @Override
    public void onDelete() {
        this.prepareToDie();
    }

    @Override
    public void onDestroy() {
        this.prepareToDie();
    }

    @Override
    public void onPause() {
        MediaPlayer mediaPlayer = this.player;
        if (mediaPlayer == null) {
            return;
        }
        if (this.playOnlyInForeground && mediaPlayer.isPlaying()) {
            this.pause();
        }
    }

    @Override
    public void onResume() {
        if (this.playOnlyInForeground && this.playerState == State.PAUSED_BY_EVENT) {
            this.Start();
        }
    }

    @Override
    public void onStop() {
        MediaPlayer mediaPlayer = this.player;
        if (mediaPlayer == null) {
            return;
        }
        if (this.playOnlyInForeground && mediaPlayer.isPlaying()) {
            this.pause();
        }
    }

    public void pause() {
        if (this.player == null) {
            return;
        }
        if (this.playerState == State.PLAYING) {
            this.player.pause();
            this.playerState = State.PAUSED_BY_EVENT;
        }
    }
}

