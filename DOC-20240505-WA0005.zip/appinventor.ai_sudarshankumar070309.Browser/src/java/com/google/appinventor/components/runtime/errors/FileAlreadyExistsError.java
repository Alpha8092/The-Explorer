/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.errors;

import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.runtime.errors.RuntimeError;

@SimpleObject
public class FileAlreadyExistsError
extends RuntimeError {
    public FileAlreadyExistsError(String string) {
        super(string);
    }
}

