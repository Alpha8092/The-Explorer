/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.appinventor.components.common;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HtmlEntities {
    private static final Pattern HTML_ENTITY_PATTERN;
    private static final Map<String, Character> lookup;

    static {
        HashMap hashMap;
        HTML_ENTITY_PATTERN = Pattern.compile((String)"&(#?[0-9a-zA-Z]+);");
        lookup = hashMap = new HashMap();
        hashMap.put((Object)"Agrave", (Object)Character.valueOf((char)'\u00c0'));
        hashMap.put((Object)"agrave", (Object)Character.valueOf((char)'\u00e0'));
        hashMap.put((Object)"Aacute", (Object)Character.valueOf((char)'\u00c1'));
        hashMap.put((Object)"aacute", (Object)Character.valueOf((char)'\u00e1'));
        hashMap.put((Object)"Acirc", (Object)Character.valueOf((char)'\u00c2'));
        hashMap.put((Object)"acirc", (Object)Character.valueOf((char)'\u00e2'));
        hashMap.put((Object)"Atilde", (Object)Character.valueOf((char)'\u00c3'));
        hashMap.put((Object)"atilde", (Object)Character.valueOf((char)'\u00e3'));
        hashMap.put((Object)"Auml", (Object)Character.valueOf((char)'\u00c4'));
        hashMap.put((Object)"auml", (Object)Character.valueOf((char)'\u00e4'));
        hashMap.put((Object)"Aring", (Object)Character.valueOf((char)'\u00c5'));
        hashMap.put((Object)"aring", (Object)Character.valueOf((char)'\u00e5'));
        hashMap.put((Object)"AElig", (Object)Character.valueOf((char)'\u00c6'));
        hashMap.put((Object)"aelig", (Object)Character.valueOf((char)'\u00e6'));
        hashMap.put((Object)"Ccedil", (Object)Character.valueOf((char)'\u00c7'));
        hashMap.put((Object)"ccedil", (Object)Character.valueOf((char)'\u00e7'));
        hashMap.put((Object)"Egrave", (Object)Character.valueOf((char)'\u00c8'));
        hashMap.put((Object)"egrave", (Object)Character.valueOf((char)'\u00e8'));
        hashMap.put((Object)"Eacute", (Object)Character.valueOf((char)'\u00c9'));
        hashMap.put((Object)"eacute", (Object)Character.valueOf((char)'\u00e9'));
        hashMap.put((Object)"Ecirc", (Object)Character.valueOf((char)'\u00ca'));
        hashMap.put((Object)"ecirc", (Object)Character.valueOf((char)'\u00ea'));
        hashMap.put((Object)"Euml", (Object)Character.valueOf((char)'\u00cb'));
        hashMap.put((Object)"euml", (Object)Character.valueOf((char)'\u00eb'));
        hashMap.put((Object)"Igrave", (Object)Character.valueOf((char)'\u00cc'));
        hashMap.put((Object)"igrave", (Object)Character.valueOf((char)'\u00ec'));
        hashMap.put((Object)"Iacute", (Object)Character.valueOf((char)'\u00cd'));
        hashMap.put((Object)"iacute", (Object)Character.valueOf((char)'\u00ed'));
        hashMap.put((Object)"Icirc", (Object)Character.valueOf((char)'\u00ce'));
        hashMap.put((Object)"icirc", (Object)Character.valueOf((char)'\u00ee'));
        hashMap.put((Object)"Iuml", (Object)Character.valueOf((char)'\u00cf'));
        hashMap.put((Object)"iuml", (Object)Character.valueOf((char)'\u00ef'));
        hashMap.put((Object)"ETH", (Object)Character.valueOf((char)'\u00d0'));
        hashMap.put((Object)"eth", (Object)Character.valueOf((char)'\u00f0'));
        hashMap.put((Object)"Ntilde", (Object)Character.valueOf((char)'\u00d1'));
        hashMap.put((Object)"ntilde", (Object)Character.valueOf((char)'\u00f1'));
        hashMap.put((Object)"Ograve", (Object)Character.valueOf((char)'\u00d2'));
        hashMap.put((Object)"ograve", (Object)Character.valueOf((char)'\u00f2'));
        hashMap.put((Object)"Oacute", (Object)Character.valueOf((char)'\u00d3'));
        hashMap.put((Object)"oacute", (Object)Character.valueOf((char)'\u00f3'));
        hashMap.put((Object)"Ocirc", (Object)Character.valueOf((char)'\u00d4'));
        hashMap.put((Object)"ocirc", (Object)Character.valueOf((char)'\u00f4'));
        hashMap.put((Object)"Otilde", (Object)Character.valueOf((char)'\u00d5'));
        hashMap.put((Object)"otilde", (Object)Character.valueOf((char)'\u00f5'));
        hashMap.put((Object)"Ouml", (Object)Character.valueOf((char)'\u00d6'));
        hashMap.put((Object)"ouml", (Object)Character.valueOf((char)'\u00f6'));
        hashMap.put((Object)"Oslash", (Object)Character.valueOf((char)'\u00d8'));
        hashMap.put((Object)"oslash", (Object)Character.valueOf((char)'\u00f8'));
        hashMap.put((Object)"Ugrave", (Object)Character.valueOf((char)'\u00d9'));
        hashMap.put((Object)"ugrave", (Object)Character.valueOf((char)'\u00f9'));
        hashMap.put((Object)"Uacute", (Object)Character.valueOf((char)'\u00da'));
        hashMap.put((Object)"uacute", (Object)Character.valueOf((char)'\u00fa'));
        hashMap.put((Object)"Ucirc", (Object)Character.valueOf((char)'\u00db'));
        hashMap.put((Object)"ucirc", (Object)Character.valueOf((char)'\u00fb'));
        hashMap.put((Object)"Uuml", (Object)Character.valueOf((char)'\u00dc'));
        hashMap.put((Object)"uuml", (Object)Character.valueOf((char)'\u00fc'));
        hashMap.put((Object)"Yacute", (Object)Character.valueOf((char)'\u00dd'));
        hashMap.put((Object)"yacute", (Object)Character.valueOf((char)'\u00fd'));
        hashMap.put((Object)"THORN", (Object)Character.valueOf((char)'\u00de'));
        hashMap.put((Object)"thorn", (Object)Character.valueOf((char)'\u00fe'));
        hashMap.put((Object)"szlig", (Object)Character.valueOf((char)'\u00df'));
        hashMap.put((Object)"yuml", (Object)Character.valueOf((char)'\u00ff'));
        hashMap.put((Object)"Yuml", (Object)Character.valueOf((char)'\u0178'));
        hashMap.put((Object)"OElig", (Object)Character.valueOf((char)'\u0152'));
        hashMap.put((Object)"oelig", (Object)Character.valueOf((char)'\u0153'));
        hashMap.put((Object)"Scaron", (Object)Character.valueOf((char)'\u0160'));
        hashMap.put((Object)"scaron", (Object)Character.valueOf((char)'\u0161'));
        hashMap.put((Object)"Alpha", (Object)Character.valueOf((char)'\u0391'));
        hashMap.put((Object)"Beta", (Object)Character.valueOf((char)'\u0392'));
        hashMap.put((Object)"Gamma", (Object)Character.valueOf((char)'\u0393'));
        hashMap.put((Object)"Delta", (Object)Character.valueOf((char)'\u0394'));
        hashMap.put((Object)"Epsilon", (Object)Character.valueOf((char)'\u0395'));
        hashMap.put((Object)"Zeta", (Object)Character.valueOf((char)'\u0396'));
        hashMap.put((Object)"Eta", (Object)Character.valueOf((char)'\u0397'));
        hashMap.put((Object)"Theta", (Object)Character.valueOf((char)'\u0398'));
        hashMap.put((Object)"Iota", (Object)Character.valueOf((char)'\u0399'));
        hashMap.put((Object)"Kappa", (Object)Character.valueOf((char)'\u039a'));
        hashMap.put((Object)"Lambda", (Object)Character.valueOf((char)'\u039b'));
        hashMap.put((Object)"Mu", (Object)Character.valueOf((char)'\u039c'));
        hashMap.put((Object)"Nu", (Object)Character.valueOf((char)'\u039d'));
        hashMap.put((Object)"Xi", (Object)Character.valueOf((char)'\u039e'));
        hashMap.put((Object)"Omicron", (Object)Character.valueOf((char)'\u039f'));
        hashMap.put((Object)"Pi", (Object)Character.valueOf((char)'\u03a0'));
        hashMap.put((Object)"Rho", (Object)Character.valueOf((char)'\u03a1'));
        hashMap.put((Object)"Sigma", (Object)Character.valueOf((char)'\u03a3'));
        hashMap.put((Object)"Tau", (Object)Character.valueOf((char)'\u03a4'));
        hashMap.put((Object)"Upsilon", (Object)Character.valueOf((char)'\u03a5'));
        hashMap.put((Object)"Phi", (Object)Character.valueOf((char)'\u03a6'));
        hashMap.put((Object)"Chi", (Object)Character.valueOf((char)'\u03a7'));
        hashMap.put((Object)"Psi", (Object)Character.valueOf((char)'\u03a8'));
        hashMap.put((Object)"Omega", (Object)Character.valueOf((char)'\u03a9'));
        hashMap.put((Object)"alpha", (Object)Character.valueOf((char)'\u03b1'));
        hashMap.put((Object)"beta", (Object)Character.valueOf((char)'\u03b2'));
        hashMap.put((Object)"gamma", (Object)Character.valueOf((char)'\u03b3'));
        hashMap.put((Object)"delta", (Object)Character.valueOf((char)'\u03b4'));
        hashMap.put((Object)"epsilon", (Object)Character.valueOf((char)'\u03b5'));
        hashMap.put((Object)"zeta", (Object)Character.valueOf((char)'\u03b6'));
        hashMap.put((Object)"eta", (Object)Character.valueOf((char)'\u03b7'));
        hashMap.put((Object)"theta", (Object)Character.valueOf((char)'\u03b8'));
        hashMap.put((Object)"iota", (Object)Character.valueOf((char)'\u03b9'));
        hashMap.put((Object)"kappa", (Object)Character.valueOf((char)'\u03ba'));
        hashMap.put((Object)"lambda", (Object)Character.valueOf((char)'\u03bb'));
        hashMap.put((Object)"mu", (Object)Character.valueOf((char)'\u03bc'));
        hashMap.put((Object)"nu", (Object)Character.valueOf((char)'\u03bd'));
        hashMap.put((Object)"xi", (Object)Character.valueOf((char)'\u03be'));
        hashMap.put((Object)"omicron", (Object)Character.valueOf((char)'\u03bf'));
        hashMap.put((Object)"pi", (Object)Character.valueOf((char)'\u03c0'));
        hashMap.put((Object)"rho", (Object)Character.valueOf((char)'\u03c1'));
        hashMap.put((Object)"sigmaf", (Object)Character.valueOf((char)'\u03c2'));
        hashMap.put((Object)"sigma", (Object)Character.valueOf((char)'\u03c3'));
        hashMap.put((Object)"tau", (Object)Character.valueOf((char)'\u03c4'));
        hashMap.put((Object)"upsilon", (Object)Character.valueOf((char)'\u03c5'));
        hashMap.put((Object)"phi", (Object)Character.valueOf((char)'\u03c6'));
        hashMap.put((Object)"chi", (Object)Character.valueOf((char)'\u03c7'));
        hashMap.put((Object)"psi", (Object)Character.valueOf((char)'\u03c8'));
        hashMap.put((Object)"omega", (Object)Character.valueOf((char)'\u03c9'));
        hashMap.put((Object)"thetasym", (Object)Character.valueOf((char)'\u03d1'));
        hashMap.put((Object)"upsih", (Object)Character.valueOf((char)'\u03d2'));
        hashMap.put((Object)"piv", (Object)Character.valueOf((char)'\u03d6'));
        hashMap.put((Object)"iexcl", (Object)Character.valueOf((char)'\u00a1'));
        hashMap.put((Object)"cent", (Object)Character.valueOf((char)'\u00a2'));
        hashMap.put((Object)"pound", (Object)Character.valueOf((char)'\u00a3'));
        hashMap.put((Object)"curren", (Object)Character.valueOf((char)'\u00a4'));
        hashMap.put((Object)"yen", (Object)Character.valueOf((char)'\u00a5'));
        hashMap.put((Object)"brvbar", (Object)Character.valueOf((char)'\u00a6'));
        hashMap.put((Object)"sect", (Object)Character.valueOf((char)'\u00a7'));
        hashMap.put((Object)"uml", (Object)Character.valueOf((char)'\u00a8'));
        hashMap.put((Object)"copy", (Object)Character.valueOf((char)'\u00a9'));
        hashMap.put((Object)"ordf", (Object)Character.valueOf((char)'\u00aa'));
        hashMap.put((Object)"laquo", (Object)Character.valueOf((char)'\u00ab'));
        hashMap.put((Object)"not", (Object)Character.valueOf((char)'\u00ac'));
        hashMap.put((Object)"shy", (Object)Character.valueOf((char)'\u00ad'));
        hashMap.put((Object)"reg", (Object)Character.valueOf((char)'\u00ae'));
        hashMap.put((Object)"macr", (Object)Character.valueOf((char)'\u00af'));
        hashMap.put((Object)"deg", (Object)Character.valueOf((char)'\u00b0'));
        hashMap.put((Object)"plusmn", (Object)Character.valueOf((char)'\u00b1'));
        hashMap.put((Object)"sup2", (Object)Character.valueOf((char)'\u00b2'));
        hashMap.put((Object)"sup3", (Object)Character.valueOf((char)'\u00b3'));
        hashMap.put((Object)"acute", (Object)Character.valueOf((char)'\u00b4'));
        hashMap.put((Object)"micro", (Object)Character.valueOf((char)'\u00b5'));
        hashMap.put((Object)"para", (Object)Character.valueOf((char)'\u00b6'));
        hashMap.put((Object)"middot", (Object)Character.valueOf((char)'\u00b7'));
        hashMap.put((Object)"cedil", (Object)Character.valueOf((char)'\u00b8'));
        hashMap.put((Object)"sup1", (Object)Character.valueOf((char)'\u00b9'));
        hashMap.put((Object)"ordm", (Object)Character.valueOf((char)'\u00ba'));
        hashMap.put((Object)"raquo", (Object)Character.valueOf((char)'\u00bb'));
        hashMap.put((Object)"frac14", (Object)Character.valueOf((char)'\u00bc'));
        hashMap.put((Object)"frac12", (Object)Character.valueOf((char)'\u00bd'));
        hashMap.put((Object)"frac34", (Object)Character.valueOf((char)'\u00be'));
        hashMap.put((Object)"iquest", (Object)Character.valueOf((char)'\u00bf'));
        hashMap.put((Object)"times", (Object)Character.valueOf((char)'\u00d7'));
        hashMap.put((Object)"divide", (Object)Character.valueOf((char)'\u00f7'));
        hashMap.put((Object)"fnof", (Object)Character.valueOf((char)'\u0192'));
        hashMap.put((Object)"circ", (Object)Character.valueOf((char)'\u02c6'));
        hashMap.put((Object)"tilde", (Object)Character.valueOf((char)'\u02dc'));
        hashMap.put((Object)"lrm", (Object)Character.valueOf((char)'\u200e'));
        hashMap.put((Object)"rlm", (Object)Character.valueOf((char)'\u200f'));
        Character c = Character.valueOf((char)'\u2013');
        hashMap.put((Object)"ndash", (Object)c);
        hashMap.put((Object)"endash", (Object)c);
        c = Character.valueOf((char)'\u2014');
        hashMap.put((Object)"mdash", (Object)c);
        hashMap.put((Object)"emdash", (Object)c);
        hashMap.put((Object)"lsquo", (Object)Character.valueOf((char)'\u2018'));
        hashMap.put((Object)"rsquo", (Object)Character.valueOf((char)'\u2019'));
        hashMap.put((Object)"sbquo", (Object)Character.valueOf((char)'\u201a'));
        hashMap.put((Object)"ldquo", (Object)Character.valueOf((char)'\u201c'));
        hashMap.put((Object)"rdquo", (Object)Character.valueOf((char)'\u201d'));
        hashMap.put((Object)"bdquo", (Object)Character.valueOf((char)'\u201e'));
        hashMap.put((Object)"dagger", (Object)Character.valueOf((char)'\u2020'));
        hashMap.put((Object)"Dagger", (Object)Character.valueOf((char)'\u2021'));
        hashMap.put((Object)"bull", (Object)Character.valueOf((char)'\u2022'));
        hashMap.put((Object)"hellip", (Object)Character.valueOf((char)'\u2026'));
        hashMap.put((Object)"permil", (Object)Character.valueOf((char)'\u2030'));
        hashMap.put((Object)"prime", (Object)Character.valueOf((char)'\u2032'));
        hashMap.put((Object)"Prime", (Object)Character.valueOf((char)'\u2033'));
        hashMap.put((Object)"lsaquo", (Object)Character.valueOf((char)'\u2039'));
        hashMap.put((Object)"rsaquo", (Object)Character.valueOf((char)'\u203a'));
        hashMap.put((Object)"oline", (Object)Character.valueOf((char)'\u203e'));
        hashMap.put((Object)"frasl", (Object)Character.valueOf((char)'\u2044'));
        hashMap.put((Object)"euro", (Object)Character.valueOf((char)'\u20ac'));
        hashMap.put((Object)"image", (Object)Character.valueOf((char)'\u2111'));
        hashMap.put((Object)"weierp", (Object)Character.valueOf((char)'\u2118'));
        hashMap.put((Object)"real", (Object)Character.valueOf((char)'\u211c'));
        hashMap.put((Object)"trade", (Object)Character.valueOf((char)'\u2122'));
        hashMap.put((Object)"alefsym", (Object)Character.valueOf((char)'\u2135'));
        hashMap.put((Object)"larr", (Object)Character.valueOf((char)'\u2190'));
        hashMap.put((Object)"uarr", (Object)Character.valueOf((char)'\u2191'));
        hashMap.put((Object)"rarr", (Object)Character.valueOf((char)'\u2192'));
        hashMap.put((Object)"darr", (Object)Character.valueOf((char)'\u2193'));
        hashMap.put((Object)"harr", (Object)Character.valueOf((char)'\u2194'));
        hashMap.put((Object)"crarr", (Object)Character.valueOf((char)'\u21b5'));
        hashMap.put((Object)"lArr", (Object)Character.valueOf((char)'\u21d0'));
        hashMap.put((Object)"uArr", (Object)Character.valueOf((char)'\u21d1'));
        hashMap.put((Object)"rArr", (Object)Character.valueOf((char)'\u21d2'));
        hashMap.put((Object)"dArr", (Object)Character.valueOf((char)'\u21d3'));
        hashMap.put((Object)"hArr", (Object)Character.valueOf((char)'\u21d4'));
        hashMap.put((Object)"forall", (Object)Character.valueOf((char)'\u2200'));
        hashMap.put((Object)"part", (Object)Character.valueOf((char)'\u2202'));
        hashMap.put((Object)"exist", (Object)Character.valueOf((char)'\u2203'));
        hashMap.put((Object)"empty", (Object)Character.valueOf((char)'\u2205'));
        hashMap.put((Object)"nabla", (Object)Character.valueOf((char)'\u2207'));
        hashMap.put((Object)"isin", (Object)Character.valueOf((char)'\u2208'));
        hashMap.put((Object)"notin", (Object)Character.valueOf((char)'\u2209'));
        hashMap.put((Object)"ni", (Object)Character.valueOf((char)'\u220b'));
        hashMap.put((Object)"prod", (Object)Character.valueOf((char)'\u220f'));
        hashMap.put((Object)"sum", (Object)Character.valueOf((char)'\u2211'));
        hashMap.put((Object)"minus", (Object)Character.valueOf((char)'\u2212'));
        hashMap.put((Object)"lowast", (Object)Character.valueOf((char)'\u2217'));
        hashMap.put((Object)"radic", (Object)Character.valueOf((char)'\u221a'));
        hashMap.put((Object)"prop", (Object)Character.valueOf((char)'\u221d'));
        hashMap.put((Object)"infin", (Object)Character.valueOf((char)'\u221e'));
        hashMap.put((Object)"ang", (Object)Character.valueOf((char)'\u2220'));
        hashMap.put((Object)"and", (Object)Character.valueOf((char)'\u2227'));
        hashMap.put((Object)"or", (Object)Character.valueOf((char)'\u2228'));
        hashMap.put((Object)"cap", (Object)Character.valueOf((char)'\u2229'));
        hashMap.put((Object)"cup", (Object)Character.valueOf((char)'\u222a'));
        hashMap.put((Object)"int", (Object)Character.valueOf((char)'\u222b'));
        hashMap.put((Object)"there4", (Object)Character.valueOf((char)'\u2234'));
        hashMap.put((Object)"sim", (Object)Character.valueOf((char)'\u223c'));
        hashMap.put((Object)"cong", (Object)Character.valueOf((char)'\u2245'));
        hashMap.put((Object)"asymp", (Object)Character.valueOf((char)'\u2248'));
        hashMap.put((Object)"ne", (Object)Character.valueOf((char)'\u2260'));
        hashMap.put((Object)"equiv", (Object)Character.valueOf((char)'\u2261'));
        hashMap.put((Object)"le", (Object)Character.valueOf((char)'\u2264'));
        hashMap.put((Object)"ge", (Object)Character.valueOf((char)'\u2265'));
        hashMap.put((Object)"sub", (Object)Character.valueOf((char)'\u2282'));
        hashMap.put((Object)"sup", (Object)Character.valueOf((char)'\u2283'));
        hashMap.put((Object)"nsub", (Object)Character.valueOf((char)'\u2284'));
        hashMap.put((Object)"sube", (Object)Character.valueOf((char)'\u2286'));
        hashMap.put((Object)"supe", (Object)Character.valueOf((char)'\u2287'));
        hashMap.put((Object)"oplus", (Object)Character.valueOf((char)'\u2295'));
        hashMap.put((Object)"otimes", (Object)Character.valueOf((char)'\u2297'));
        hashMap.put((Object)"perp", (Object)Character.valueOf((char)'\u22a5'));
        hashMap.put((Object)"sdot", (Object)Character.valueOf((char)'\u22c5'));
        hashMap.put((Object)"lceil", (Object)Character.valueOf((char)'\u2308'));
        hashMap.put((Object)"rceil", (Object)Character.valueOf((char)'\u2309'));
        hashMap.put((Object)"lfloor", (Object)Character.valueOf((char)'\u230a'));
        hashMap.put((Object)"rfloor", (Object)Character.valueOf((char)'\u230b'));
        hashMap.put((Object)"lang", (Object)Character.valueOf((char)'\u2329'));
        hashMap.put((Object)"rang", (Object)Character.valueOf((char)'\u232a'));
        hashMap.put((Object)"loz", (Object)Character.valueOf((char)'\u25ca'));
        hashMap.put((Object)"spades", (Object)Character.valueOf((char)'\u2660'));
        hashMap.put((Object)"clubs", (Object)Character.valueOf((char)'\u2663'));
        hashMap.put((Object)"hearts", (Object)Character.valueOf((char)'\u2665'));
        hashMap.put((Object)"diams", (Object)Character.valueOf((char)'\u2666'));
        c = Character.valueOf((char)'>');
        hashMap.put((Object)"gt", (Object)c);
        hashMap.put((Object)"GT", (Object)c);
        c = Character.valueOf((char)'<');
        hashMap.put((Object)"lt", (Object)c);
        hashMap.put((Object)"LT", (Object)c);
        c = Character.valueOf((char)'\"');
        hashMap.put((Object)"quot", (Object)c);
        hashMap.put((Object)"QUOT", (Object)c);
        c = Character.valueOf((char)'&');
        hashMap.put((Object)"amp", (Object)c);
        hashMap.put((Object)"AMP", (Object)c);
        hashMap.put((Object)"apos", (Object)Character.valueOf((char)'\''));
        hashMap.put((Object)"nbsp", (Object)Character.valueOf((char)'\u00a0'));
        hashMap.put((Object)"ensp", (Object)Character.valueOf((char)'\u2002'));
        hashMap.put((Object)"emsp", (Object)Character.valueOf((char)'\u2003'));
        hashMap.put((Object)"thinsp", (Object)Character.valueOf((char)'\u2009'));
        hashMap.put((Object)"zwnj", (Object)Character.valueOf((char)'\u200c'));
        hashMap.put((Object)"zwj", (Object)Character.valueOf((char)'\u200d'));
    }

    public static String decodeHtmlText(String string) {
        block8: {
            if (string.length() == 0 || string.indexOf(38) == -1) break block8;
            StringBuilder stringBuilder = new StringBuilder();
            int n = 0;
            Matcher matcher = HTML_ENTITY_PATTERN.matcher((CharSequence)string);
            while (matcher.find()) {
                String string2;
                block7: {
                    String string3;
                    block10: {
                        char c;
                        PrintStream printStream;
                        block9: {
                            string3 = matcher.group(1);
                            printStream = null;
                            string2 = null;
                            if (!string3.startsWith("#x")) break block9;
                            string3 = string3.substring(2);
                            try {
                                printStream = System.out;
                                StringBuilder stringBuilder2 = new StringBuilder();
                                printStream.println(stringBuilder2.append("hex number is ").append(string3).toString());
                                c = (char)Integer.parseInt((String)string3, (int)16);
                            }
                            catch (NumberFormatException numberFormatException) {}
                            string2 = Character.valueOf((char)c);
                            break block7;
                        }
                        if (!string3.startsWith("#")) break block10;
                        string2 = string3.substring(1);
                        try {
                            c = (char)Integer.parseInt((String)string2);
                        }
                        catch (NumberFormatException numberFormatException) {
                            string2 = printStream;
                            break block7;
                        }
                        string2 = Character.valueOf((char)c);
                        break block7;
                    }
                    string2 = (Character)lookup.get((Object)string3);
                }
                int n2 = n;
                if (string2 != null) {
                    stringBuilder.append(string.substring(n, matcher.start()));
                    stringBuilder.append((Object)string2);
                    n2 = matcher.end();
                }
                n = n2;
            }
            if (n < string.length()) {
                stringBuilder.append(string.substring(n));
            }
            return stringBuilder.toString();
        }
        return string;
    }

    public static Character toCharacter(String string) {
        return (Character)lookup.get((Object)string);
    }
}

