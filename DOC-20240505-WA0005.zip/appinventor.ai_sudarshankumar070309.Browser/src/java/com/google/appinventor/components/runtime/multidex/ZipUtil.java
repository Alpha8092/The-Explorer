/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.zip.CRC32
 *  java.util.zip.ZipException
 */
package com.google.appinventor.components.runtime.multidex;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.zip.CRC32;
import java.util.zip.ZipException;

final class ZipUtil {
    private static final int BUFFER_SIZE = 16384;
    private static final int ENDHDR = 22;
    private static final int ENDSIG = 101010256;

    ZipUtil() {
    }

    static long computeCrcOfCentralDir(RandomAccessFile randomAccessFile, CentralDirectory object) throws IOException {
        CRC32 cRC32 = new CRC32();
        long l = ((CentralDirectory)object).size;
        randomAccessFile.seek(((CentralDirectory)object).offset);
        int n = (int)Math.min((long)16384L, (long)l);
        object = new byte[16384];
        n = randomAccessFile.read((byte[])object, 0, n);
        while (n != -1) {
            cRC32.update((byte[])object, 0, n);
            if ((l -= (long)n) == 0L) break;
            n = randomAccessFile.read((byte[])object, 0, (int)Math.min((long)16384L, (long)l));
        }
        return cRC32.getValue();
    }

    static CentralDirectory findCentralDirectory(RandomAccessFile object) throws IOException, ZipException {
        long l = object.length() - 22L;
        if (l >= 0L) {
            long l2;
            long l3 = l2 = l - 65536L;
            if (l2 < 0L) {
                l3 = 0L;
            }
            int n = Integer.reverseBytes((int)101010256);
            do {
                object.seek(l);
                if (object.readInt() != n) continue;
                object.skipBytes(2);
                object.skipBytes(2);
                object.skipBytes(2);
                object.skipBytes(2);
                CentralDirectory centralDirectory = new CentralDirectory();
                centralDirectory.size = (long)Integer.reverseBytes((int)object.readInt()) & 0xFFFFFFFFL;
                centralDirectory.offset = (long)Integer.reverseBytes((int)object.readInt()) & 0xFFFFFFFFL;
                return centralDirectory;
            } while (--l >= l3);
            throw new ZipException("End Of Central Directory signature not found");
        }
        long l4 = object.length();
        object = new ZipException("File too short to be a zip file: " + l4);
        throw object;
    }

    static long getZipCrc(File file) throws IOException {
        file = new RandomAccessFile(file, "r");
        try {
            long l = ZipUtil.computeCrcOfCentralDir((RandomAccessFile)file, ZipUtil.findCentralDirectory((RandomAccessFile)file));
            return l;
        }
        finally {
            file.close();
        }
    }

    static class CentralDirectory {
        long offset;
        long size;

        CentralDirectory() {
        }
    }
}

