/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.View
 *  android.webkit.JavascriptInterface
 *  android.webkit.WebChromeClient
 *  android.webkit.WebStorage$QuotaUpdater
 *  android.webkit.WebView
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.ContextCompat
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebStorage;
import android.webkit.WebView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.util.SdkLevel;

public final class SplashActivity
extends AppInventorCompatActivity {
    Handler handler;
    WebView webview;

    public void onCreate(Bundle object2) {
        WebView webView;
        super.onCreate(object2);
        object2 = new Object((SplashActivity)this, (Context)this){
            Context mContext;
            final SplashActivity this$0;
            {
                this.this$0 = splashActivity;
                this.mContext = context;
            }

            @JavascriptInterface
            public void askPermission(String string) {
                ActivityCompat.requestPermissions((Activity)this.this$0, (String[])new String[]{string}, (int)1);
            }

            @JavascriptInterface
            public void finished() {
                this.this$0.handler.post(new Runnable(this){
                    final JavaInterface this$1;
                    {
                        this.this$1 = javaInterface;
                    }

                    public void run() {
                        this.this$1.this$0.webview.destroy();
                        this.this$1.this$0.finish();
                    }
                });
            }

            @JavascriptInterface
            public String getVersion() {
                try {
                    String string = this.mContext.getPackageName();
                    string = this.mContext.getPackageManager().getPackageInfo((String)string, (int)0).versionName;
                    return string;
                }
                catch (PackageManager.NameNotFoundException nameNotFoundException) {
                    return "Unknown";
                }
            }

            @JavascriptInterface
            public boolean hasPermission(String string) {
                if (SdkLevel.getLevel() < 23) {
                    return true;
                }
                return ContextCompat.checkSelfPermission((Context)this.mContext, (String)string) == 0;
            }
        };
        this.handler = new Handler();
        this.webview = webView = new WebView((Context)this);
        webView = webView.getSettings();
        webView.setJavaScriptEnabled(true);
        webView.setDatabaseEnabled(true);
        webView.setDomStorageEnabled(true);
        webView.setDatabasePath(this.getApplicationContext().getDir("database", 0).getPath());
        this.webview.setWebChromeClient(new WebChromeClient((SplashActivity)this){
            final SplashActivity this$0;
            {
                this.this$0 = splashActivity;
            }

            public void onExceededDatabaseQuota(String string, String string2, long l, long l2, long l3, WebStorage.QuotaUpdater quotaUpdater) {
                quotaUpdater.updateQuota(0x500000L);
            }
        });
        this.setContentView((View)this.webview);
        this.webview.addJavascriptInterface(object2, "Android");
        this.webview.loadUrl("file:///android_asset/splash.html");
    }

    public void onRequestPermissionsResult(int n, String[] stringArray, int[] nArray) {
        for (n = 0; n < stringArray.length; ++n) {
            String string = stringArray[n];
            int n2 = nArray[n];
            boolean bl = false;
            if (n2 == 0) {
                bl = true;
            }
            this.webview.loadUrl("javascript:permresult('" + string + "'," + bl + ")");
        }
    }
}

