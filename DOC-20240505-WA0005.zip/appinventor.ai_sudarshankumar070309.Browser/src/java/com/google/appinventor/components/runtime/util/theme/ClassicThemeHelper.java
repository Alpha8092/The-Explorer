/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.util.theme.ThemeHelper
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.util.theme;

import com.google.appinventor.components.runtime.util.theme.ThemeHelper;

public class ClassicThemeHelper
implements ThemeHelper {
    public boolean hasActionBar() {
        return false;
    }

    public void requestActionBar() {
    }

    public void setActionBarAnimation(boolean bl) {
    }

    public boolean setActionBarVisible(boolean bl) {
        return false;
    }

    public void setTitle(String string) {
    }

    public void setTitle(String string, boolean bl) {
    }
}

