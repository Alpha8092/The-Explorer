/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.util.ErrorMessages
 *  java.lang.Object
 *  java.util.Arrays
 */
package com.google.appinventor.components.runtime.errors;

import com.google.appinventor.components.runtime.errors.RuntimeError;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import java.util.Arrays;

public class DispatchableError
extends RuntimeError {
    private final Object[] arguments;
    private final int errorCode;

    public DispatchableError(int n) {
        super(ErrorMessages.formatMessage((int)n, null));
        this.errorCode = n;
        this.arguments = new Object[0];
    }

    public DispatchableError(int n, Object ... objectArray) {
        super(ErrorMessages.formatMessage((int)n, (Object[])objectArray));
        this.errorCode = n;
        this.arguments = objectArray;
    }

    public Object[] getArguments() {
        Object[] objectArray = this.arguments;
        return Arrays.copyOf((Object[])objectArray, (int)objectArray.length);
    }

    public int getErrorCode() {
        return this.errorCode;
    }
}

