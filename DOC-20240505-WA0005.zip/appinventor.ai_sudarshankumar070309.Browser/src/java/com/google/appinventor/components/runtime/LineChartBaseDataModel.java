/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.charts.LineChart
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.data.LineData
 *  com.github.mikephil.charting.data.LineDataSet
 *  com.github.mikephil.charting.data.LineDataSet$Mode
 *  com.github.mikephil.charting.interfaces.datasets.IDataSet
 *  com.github.mikephil.charting.interfaces.datasets.ILineDataSet
 *  com.github.mikephil.charting.utils.EntryXComparator
 *  com.google.appinventor.components.common.LineType
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.EntryXComparator;
import com.google.appinventor.components.common.LineType;
import com.google.appinventor.components.runtime.LineChartBaseDataModel;
import com.google.appinventor.components.runtime.LineChartViewBase;
import com.google.appinventor.components.runtime.PointChartDataModel;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public abstract class LineChartBaseDataModel<V extends LineChartViewBase<V>>
extends PointChartDataModel<Entry, ILineDataSet, LineData, LineChart, V> {
    protected LineChartBaseDataModel(LineData lineData, V v) {
        super(lineData, v, (ILineDataSet)new LineDataSet((List)new ArrayList(), ""));
    }

    protected LineChartBaseDataModel(LineData lineData, V v, ILineDataSet iLineDataSet) {
        super(lineData, v);
        this.dataset = iLineDataSet;
        ((LineData)this.data).addDataSet((IDataSet)iLineDataSet);
        this.setDefaultStylingProperties();
    }

    public void addEntryFromTuple(YailList yailList) {
        if ((yailList = this.getEntryFromTuple(yailList)) != null) {
            int n = Collections.binarySearch((List)this.entries, (Object)yailList, (Comparator)new EntryXComparator());
            if (n < 0) {
                n = -n - 1;
            } else {
                int n2 = this.entries.size();
                while (n < n2 && ((Entry)this.entries.get(n)).getX() == yailList.getX()) {
                    ++n;
                }
            }
            this.entries.add(n, (Object)yailList);
            yailList = ((LineDataSet)this.dataset).getCircleColors();
            yailList.add(n, ((ILineDataSet)this.dataset).getColor());
            ((LineDataSet)this.dataset).setCircleColors((List)yailList);
        }
    }

    public void setColor(int n) {
        super.setColor(n);
        if (this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setCircleColor(n);
        }
    }

    public void setColors(List<Integer> list) {
        super.setColors(list);
        if (this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setCircleColors(list);
        }
    }

    protected void setDefaultStylingProperties() {
        if (this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setDrawCircleHole(false);
        }
    }

    public void setLineType(LineType lineType) {
        if (!(this.dataset instanceof LineDataSet)) {
            return;
        }
        switch (1.$SwitchMap$com$google$appinventor$components$common$LineType[lineType.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown line type: " + lineType);
            }
            case 3: {
                ((LineDataSet)this.dataset).setMode(LineDataSet.Mode.STEPPED);
                break;
            }
            case 2: {
                ((LineDataSet)this.dataset).setMode(LineDataSet.Mode.CUBIC_BEZIER);
                break;
            }
            case 1: {
                ((LineDataSet)this.dataset).setMode(LineDataSet.Mode.LINEAR);
            }
        }
    }
}

