/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  com.google.appinventor.components.runtime.ButtonBase
 *  com.google.appinventor.components.runtime.util.AnimationUtil
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Intent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.ButtonBase;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.AnimationUtil;

@SimpleObject
public abstract class Picker
extends ButtonBase
implements ActivityResultListener {
    protected final ComponentContainer container;
    protected int requestCode;

    public Picker(ComponentContainer componentContainer) {
        super(componentContainer);
        this.container = componentContainer;
    }

    @SimpleEvent
    public void AfterPicking() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "AfterPicking", new Object[0]);
    }

    @SimpleEvent
    public void BeforePicking() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "BeforePicking", new Object[0]);
    }

    @SimpleFunction(description="Opens the %type%, as though the user clicked on it.")
    public void Open() {
        this.click();
    }

    public void click() {
        this.BeforePicking();
        if (this.requestCode == 0) {
            this.requestCode = this.container.$form().registerForActivityResult(this);
        }
        this.container.$context().startActivityForResult(this.getIntent(), this.requestCode);
        String string2 = this.container.$form().OpenScreenAnimation();
        AnimationUtil.ApplyOpenScreenAnimation((Activity)this.container.$context(), (String)string2);
    }

    protected abstract Intent getIntent();
}

