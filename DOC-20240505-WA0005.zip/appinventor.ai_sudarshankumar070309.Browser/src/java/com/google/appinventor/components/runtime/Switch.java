/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.graphics.drawable.Drawable
 *  android.widget.CheckBox
 *  android.widget.CompoundButton
 *  androidx.appcompat.widget.SwitchCompat
 *  androidx.core.graphics.drawable.DrawableCompat
 *  com.google.appinventor.components.runtime.ToggleBase
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.ToggleBase;
import com.google.appinventor.components.runtime.util.SdkLevel;

@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="Toggle switch that raises an event when the user clicks on it. There are many properties affecting its appearance that can be set in the Designer or Blocks Editor.", iconName="images/switch.png", version=1)
@SimpleObject
public final class Switch
extends ToggleBase<CompoundButton> {
    private final Activity activity;
    private final SwitchCompat switchView;
    private int thumbColorActive;
    private int thumbColorInactive;
    private int trackColorActive;
    private int trackColorInactive;

    public Switch(ComponentContainer componentContainer) {
        super(componentContainer);
        componentContainer = componentContainer.$context();
        this.activity = componentContainer;
        if (SdkLevel.getLevel() < 14) {
            this.switchView = null;
            this.view = new CheckBox((Context)componentContainer);
        } else {
            componentContainer = new SwitchCompat((Context)componentContainer);
            this.switchView = componentContainer;
            this.view = componentContainer;
        }
        this.On(false);
        this.ThumbColorActive(-1);
        this.ThumbColorInactive(-3355444);
        this.TrackColorActive(-16711936);
        this.TrackColorInactive(-7829368);
        this.initToggle();
    }

    private ColorStateList createSwitchColors(int n, int n2) {
        int[] nArray = new int[]{};
        return new ColorStateList((int[][])new int[][]{{0x10100A0}, nArray}, new int[]{n, n2});
    }

    @SimpleEvent(description="User change the state of the `Switch` from On to Off or back.")
    public void Changed() {
        super.Changed();
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void On(boolean bl) {
        this.view.setChecked(bl);
        this.view.invalidate();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean On() {
        return this.view.isChecked();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public int ThumbColorActive() {
        return this.thumbColorActive;
    }

    @DesignerProperty(defaultValue="&HFFFFFFFF", editorType="color")
    @SimpleProperty
    public void ThumbColorActive(int n) {
        this.thumbColorActive = n;
        SwitchCompat switchCompat = this.switchView;
        if (switchCompat != null) {
            DrawableCompat.setTintList((Drawable)switchCompat.getThumbDrawable(), (ColorStateList)super.createSwitchColors(n, this.thumbColorInactive));
            this.view.invalidate();
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=true)
    public int ThumbColorInactive() {
        return this.thumbColorInactive;
    }

    @DesignerProperty(defaultValue="&HFFCCCCCC", editorType="color")
    @SimpleProperty
    public void ThumbColorInactive(int n) {
        this.thumbColorInactive = n;
        SwitchCompat switchCompat = this.switchView;
        if (switchCompat != null) {
            DrawableCompat.setTintList((Drawable)switchCompat.getThumbDrawable(), (ColorStateList)super.createSwitchColors(this.thumbColorActive, n));
            this.view.invalidate();
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=true)
    public int TrackColorActive() {
        return this.trackColorActive;
    }

    @DesignerProperty(defaultValue="&HFF00FF00", editorType="color")
    @SimpleProperty(description="Color of the toggle track when switched on", userVisible=true)
    public void TrackColorActive(int n) {
        this.trackColorActive = n;
        SwitchCompat switchCompat = this.switchView;
        if (switchCompat != null) {
            DrawableCompat.setTintList((Drawable)switchCompat.getTrackDrawable(), (ColorStateList)super.createSwitchColors(n, this.trackColorInactive));
            this.view.invalidate();
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=true)
    public int TrackColorInactive() {
        return this.trackColorInactive;
    }

    @DesignerProperty(defaultValue="&HFF444444", editorType="color")
    @SimpleProperty(description="Color of the toggle track when switched off", userVisible=true)
    public void TrackColorInactive(int n) {
        this.trackColorInactive = n;
        SwitchCompat switchCompat = this.switchView;
        if (switchCompat != null) {
            DrawableCompat.setTintList((Drawable)switchCompat.getTrackDrawable(), (ColorStateList)super.createSwitchColors(this.trackColorActive, n));
            this.view.invalidate();
        }
    }
}

