/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.LayerDrawable
 *  android.graphics.drawable.StateListDrawable
 *  android.os.Build$VERSION
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.SdkLevel;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="A Slider is a progress bar that adds a draggable thumb. You can touch the thumb and drag left or right to set the slider thumb position. As the Slider thumb is dragged, it will trigger the PositionChanged event, reporting the position of the Slider thumb. The reported position of the Slider thumb can be used to dynamically update another component attribute, such as the font size of a TextBox or the radius of a Ball.", iconName="images/slider.png", version=2)
@SimpleObject
public class Slider
extends AndroidViewComponent
implements SeekBar.OnSeekBarChangeListener {
    private static final boolean DEBUG = false;
    private static final String LOG_TAG = "Slider";
    private static final int initialLeftColor = -14336;
    private static final String initialLeftColorString = "&HFFFFC800";
    private static final int initialRightColor = -7829368;
    private static final String initialRightColorString = "&HFF888888";
    private int leftColor;
    private float maxValue;
    private float minValue;
    public final boolean referenceGetThumb;
    private int rightColor;
    private final SeekBar seekbar;
    private boolean thumbEnabled;
    private float thumbPosition;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetthumbEnabled(Slider slider) {
        return slider.thumbEnabled;
    }

    public Slider(ComponentContainer componentContainer) {
        super(componentContainer);
        SeekBar seekBar;
        boolean bl = SdkLevel.getLevel() >= 16;
        this.referenceGetThumb = bl;
        this.seekbar = seekBar = new SeekBar((Context)componentContainer.$context());
        if (SdkLevel.getLevel() >= 21) {
            seekBar.setSplitTrack(false);
        }
        this.leftColor = -14336;
        this.rightColor = -7829368;
        super.setSliderColors();
        componentContainer.$add((AndroidViewComponent)this);
        this.minValue = 10.0f;
        this.maxValue = 50.0f;
        this.thumbPosition = 30.0f;
        this.thumbEnabled = true;
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)this);
        seekBar.setMax(100);
        super.setSeekbarPosition();
    }

    private void setSeekbarPosition() {
        float f = this.thumbPosition;
        float f2 = this.minValue;
        f2 = (f - f2) / (this.maxValue - f2);
        this.seekbar.setProgress((int)(f2 * 100.0f));
    }

    private void setSliderColors() {
        if (Build.VERSION.SDK_INT >= 21) {
            this.seekbar.setProgressTintList(ColorStateList.valueOf((int)this.leftColor));
            if (Build.VERSION.SDK_INT < 22 && this.seekbar.getProgressDrawable() instanceof StateListDrawable) {
                StateListDrawable stateListDrawable = (StateListDrawable)this.seekbar.getProgressDrawable();
                if (stateListDrawable.getCurrent() instanceof LayerDrawable) {
                    stateListDrawable = ((LayerDrawable)stateListDrawable.getCurrent()).findDrawableByLayerId(0x1020000);
                    stateListDrawable.setTintList(ColorStateList.valueOf((int)this.rightColor));
                    stateListDrawable.setTintMode(PorterDuff.Mode.MULTIPLY);
                }
            } else {
                this.seekbar.setProgressBackgroundTintList(ColorStateList.valueOf((int)this.rightColor));
                this.seekbar.setProgressBackgroundTintMode(PorterDuff.Mode.MULTIPLY);
            }
        } else {
            LayerDrawable layerDrawable = (LayerDrawable)this.seekbar.getProgressDrawable();
            layerDrawable.setColorFilter(this.rightColor, PorterDuff.Mode.SRC);
            layerDrawable.findDrawableByLayerId(16908301).setColorFilter(this.leftColor, PorterDuff.Mode.SRC);
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The color of slider to the left of the thumb.")
    public int ColorLeft() {
        return this.leftColor;
    }

    @DesignerProperty(defaultValue="&HFFFFC800", editorType="color")
    @SimpleProperty
    public void ColorLeft(int n) {
        this.leftColor = n;
        super.setSliderColors();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The color of slider to the right of the thumb.")
    public int ColorRight() {
        return this.rightColor;
    }

    @DesignerProperty(defaultValue="&HFF888888", editorType="color")
    @SimpleProperty
    public void ColorRight(int n) {
        this.rightColor = n;
        super.setSliderColors();
    }

    public int Height() {
        return this.getView().getHeight();
    }

    public void Height(int n) {
        this.container.setChildHeight((AndroidViewComponent)this, n);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Returns the slider max value.", userVisible=true)
    public float MaxValue() {
        return this.maxValue;
    }

    @DesignerProperty(defaultValue="50.0", editorType="float")
    @SimpleProperty(description="Sets the maximum value of slider.  Changing the maximum value also resets Thumbposition to be halfway between the minimum and the (new) maximum. If the new maximum is less than the current minimum, then minimum and maximum will both be set to this value.  Setting MaxValue resets the thumb position to halfway between MinValue and MaxValue and signals the PositionChanged event.", userVisible=true)
    public void MaxValue(float f) {
        this.maxValue = f;
        this.minValue = f = Math.min((float)f, (float)this.minValue);
        this.ThumbPosition((f + this.maxValue) / 2.0f);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Returns the value of slider min value.", userVisible=true)
    public float MinValue() {
        return this.minValue;
    }

    @DesignerProperty(defaultValue="10.0", editorType="float")
    @SimpleProperty(description="Sets the minimum value of slider.  Changing the minimum value also resets Thumbposition to be halfway between the (new) minimum and the maximum. If the new minimum is greater than the current maximum, then minimum and maximum will both be set to this value.  Setting MinValue resets the thumb position to halfway between MinValue and MaxValue and signals the PositionChanged event.", userVisible=true)
    public void MinValue(float f) {
        this.minValue = f;
        this.maxValue = f = Math.max((float)f, (float)this.maxValue);
        this.ThumbPosition((this.minValue + f) / 2.0f);
    }

    @SimpleEvent
    public void PositionChanged(float f) {
        EventDispatcher.dispatchEvent((Component)this, "PositionChanged", Float.valueOf((float)f));
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(description="Sets whether or not to display the slider thumb.", userVisible=true)
    public void ThumbEnabled(boolean bl) {
        this.thumbEnabled = bl;
        int n = bl ? 255 : 0;
        if (this.referenceGetThumb) {
            new Object((Slider)this, null){
                final Slider this$0;
                {
                    this.this$0 = slider;
                }

                public void getThumb(int n) {
                    this.this$0.seekbar.getThumb().mutate().setAlpha(n);
                }
            }.getThumb(n);
        }
        this.seekbar.setOnTouchListener(new View.OnTouchListener((Slider)this){
            final Slider this$0;
            {
                this.this$0 = slider;
            }

            public boolean onTouch(View view, MotionEvent motionEvent) {
                return Slider.-$$Nest$fgetthumbEnabled(this.this$0) ^ true;
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Returns whether or not the slider thumb is being be shown", userVisible=true)
    public boolean ThumbEnabled() {
        return this.thumbEnabled;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Returns the position of slider thumb", userVisible=true)
    public float ThumbPosition() {
        return this.thumbPosition;
    }

    @DesignerProperty(defaultValue="30.0", editorType="float")
    @SimpleProperty(description="Sets the position of the slider thumb. If this value is greater than MaxValue, then it will be set to same value as MaxValue. If this value is less than MinValue, then it will be set to same value as MinValue.", userVisible=true)
    public void ThumbPosition(float f) {
        this.thumbPosition = Math.max((float)Math.min((float)f, (float)this.maxValue), (float)this.minValue);
        super.setSeekbarPosition();
        this.PositionChanged(this.thumbPosition);
    }

    public View getView() {
        return this.seekbar;
    }

    public void onProgressChanged(SeekBar seekBar, int n, boolean bl) {
        float f = this.maxValue;
        float f2 = this.minValue;
        this.thumbPosition = f = (f - f2) * (float)n / 100.0f + f2;
        this.PositionChanged(f);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}

