/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

public interface Deleteable {
    public void onDelete();
}

