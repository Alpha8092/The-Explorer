/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.None
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem
 *  java.lang.Object
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.None;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem;

public class Huff
implements None,
PostMortem {
    private final int domain;
    private final Symbol[] symbols;
    private Symbol table;
    private boolean upToDate = false;
    private int width;

    public Huff(int n) {
        this.domain = n;
        int n2 = n * 2 - 1;
        this.symbols = new Symbol[n2];
        for (int i = 0; i < n; ++i) {
            this.symbols[i] = new Symbol(i);
        }
        while (n < n2) {
            this.symbols[n] = new Symbol(-1);
            ++n;
        }
    }

    private boolean postMortem(int n) {
        int[] nArray = new int[this.domain];
        Symbol symbol = this.symbols[n];
        int n2 = symbol.integer;
        boolean bl = false;
        if (n2 != n) {
            return false;
        }
        n2 = 0;
        while (true) {
            Symbol symbol2;
            if ((symbol2 = symbol.back) == null) {
                if (symbol != this.table) {
                    return false;
                }
                this.width = 0;
                symbol = this.table;
                while (symbol.integer == -1) {
                    if (nArray[--n2] != 0) {
                        symbol = symbol.one;
                        continue;
                    }
                    symbol = symbol.zero;
                }
                boolean bl2 = bl;
                if (symbol.integer == n) {
                    bl2 = bl;
                    if (n2 == 0) {
                        bl2 = true;
                    }
                }
                return bl2;
            }
            if (symbol2.zero == symbol) {
                nArray[n2] = 0;
            } else {
                if (symbol2.one != symbol) break;
                nArray[n2] = 1;
            }
            ++n2;
            symbol = symbol2;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void write(Symbol symbol, BitWriter bitWriter) throws JSONException {
        Symbol symbol2;
        try {
            symbol2 = symbol.back;
            if (symbol2 == null) return;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
        ++this.width;
        super.write(symbol2, bitWriter);
        if (symbol2.zero == symbol) {
            bitWriter.zero();
            return;
        } else {
            bitWriter.one();
        }
    }

    public void generate() {
        if (!this.upToDate) {
            Symbol symbol;
            Symbol symbol2;
            int n;
            Symbol symbol3;
            Symbol symbol4 = symbol3 = this.symbols[0];
            this.table = null;
            symbol3.next = null;
            for (n = 1; n < this.domain; ++n) {
                symbol2 = this.symbols[n];
                if (symbol2.weight < symbol3.weight) {
                    symbol2.next = symbol3;
                    symbol3 = symbol2;
                    continue;
                }
                symbol = symbol4;
                if (symbol2.weight < symbol4.weight) {
                    symbol = symbol3;
                }
                while ((symbol4 = symbol.next) != null && symbol2.weight >= symbol4.weight) {
                    symbol = symbol4;
                }
                symbol2.next = symbol4;
                symbol.next = symbol2;
                symbol4 = symbol2;
            }
            n = this.domain;
            symbol4 = symbol3;
            while (true) {
                symbol2 = symbol3;
                Symbol symbol5 = symbol2.next;
                symbol = symbol5.next;
                symbol3 = this.symbols[n];
                ++n;
                symbol3.weight = symbol2.weight + symbol5.weight;
                symbol3.zero = symbol2;
                symbol3.one = symbol5;
                symbol3.back = null;
                symbol2.back = symbol3;
                symbol5.back = symbol3;
                if (symbol == null) {
                    this.table = symbol3;
                    this.upToDate = true;
                    break;
                }
                if (symbol3.weight < symbol.weight) {
                    symbol3.next = symbol;
                    symbol4 = symbol3;
                    continue;
                }
                while ((symbol2 = symbol4.next) != null && symbol3.weight >= symbol2.weight) {
                    symbol4 = symbol2;
                }
                symbol3.next = symbol2;
                symbol4.next = symbol3;
                symbol4 = symbol3;
                symbol3 = symbol;
            }
        }
    }

    public boolean postMortem(PostMortem postMortem) {
        for (int i = 0; i < this.domain; ++i) {
            if (super.postMortem(i)) continue;
            JSONzip.log("\nBad huff ");
            JSONzip.logchar(i, i);
            return false;
        }
        return this.table.postMortem(((Huff)postMortem).table);
    }

    public int read(BitReader bitReader) throws JSONException {
        try {
            this.width = 0;
            Symbol symbol = this.table;
            while (symbol.integer == -1) {
                ++this.width;
                if (bitReader.bit()) {
                    symbol = symbol.one;
                    continue;
                }
                symbol = symbol.zero;
            }
            this.tick(symbol.integer);
            int n = symbol.integer;
            return n;
        }
        catch (Throwable throwable) {
            JSONException jSONException = new JSONException(throwable);
            throw jSONException;
        }
    }

    public void tick(int n) {
        Symbol symbol = this.symbols[n];
        ++symbol.weight;
        this.upToDate = false;
    }

    public void tick(int n, int n2) {
        while (n <= n2) {
            this.tick(n);
            ++n;
        }
    }

    public void write(int n, BitWriter bitWriter) throws JSONException {
        this.width = 0;
        super.write(this.symbols[n], bitWriter);
        this.tick(n);
    }

    private static class Symbol
    implements PostMortem {
        public Symbol back;
        public final int integer;
        public Symbol next;
        public Symbol one;
        public long weight;
        public Symbol zero;

        public Symbol(int n) {
            this.integer = n;
            this.weight = 0L;
            this.next = null;
            this.back = null;
            this.one = null;
            this.zero = null;
        }

        public boolean postMortem(PostMortem postMortem) {
            boolean bl = true;
            postMortem = (Symbol)postMortem;
            if (this.integer == postMortem.integer && this.weight == postMortem.weight) {
                Symbol symbol = this.back;
                boolean bl2 = true;
                boolean bl3 = symbol != null;
                if (postMortem.back == null) {
                    bl2 = false;
                }
                if (bl3 != bl2) {
                    return false;
                }
                symbol = this.zero;
                Symbol symbol2 = this.one;
                if (symbol == null) {
                    if (postMortem.zero != null) {
                        return false;
                    }
                } else {
                    bl = symbol.postMortem(postMortem.zero);
                }
                if (symbol2 == null) {
                    if (postMortem.one != null) {
                        return false;
                    }
                } else {
                    bl = symbol2.postMortem(postMortem.one);
                }
                return bl;
            }
            return false;
        }
    }
}

