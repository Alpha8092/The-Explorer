package com.google.appinventor.components.runtime;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface ObservableDataSource<K, V> extends DataSource<K, V> {
    void addDataObserver(DataSourceChangeListener dataSourceChangeListener);

    void notifyDataObservers(K k, Object obj);

    void removeDataObserver(DataSourceChangeListener dataSourceChangeListener);
}
