/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.common;

import com.google.appinventor.components.common.OptionList;
import java.util.HashMap;
import java.util.Map;

public final class FileType
extends Enum<FileType>
implements OptionList<String> {
    private static final FileType[] $VALUES;
    public static final /* enum */ FileType Any;
    public static final /* enum */ FileType Audio;
    public static final /* enum */ FileType Image;
    private static final Map<String, FileType> LOOKUP;
    public static final /* enum */ FileType Video;
    private final String mimeType;

    static {
        FileType fileType;
        FileType fileType22;
        FileType fileType3;
        FileType[] fileTypeArray = new FileType("*/*");
        Any = fileTypeArray;
        Audio = fileType3 = new FileType("audio/*");
        Image = fileType22 = new FileType("image/*");
        Video = fileType = new FileType("video/*");
        $VALUES = new FileType[]{fileTypeArray, fileType3, fileType22, fileType};
        LOOKUP = new HashMap();
        for (FileType fileType22 : FileType.values()) {
            LOOKUP.put(fileType22.toUnderlyingValue(), (Object)fileType22);
        }
    }

    private FileType(String string3) {
        this.mimeType = string3;
    }

    public static FileType fromUnderlyingValue(String string2) {
        return (FileType)LOOKUP.get((Object)string2);
    }

    public static FileType valueOf(String string2) {
        return (FileType)Enum.valueOf(FileType.class, (String)string2);
    }

    public static FileType[] values() {
        return (FileType[])$VALUES.clone();
    }

    @Override
    public String toUnderlyingValue() {
        return this.mimeType;
    }
}

