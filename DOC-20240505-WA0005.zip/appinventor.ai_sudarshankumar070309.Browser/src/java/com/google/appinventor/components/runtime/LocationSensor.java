/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.location.Address
 *  android.location.Criteria
 *  android.location.Geocoder
 *  android.location.Location
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.location.LocationProvider
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.LocationSensor$1$1
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  com.google.appinventor.components.runtime.util.BulkPermissionRequest
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LocationSensor;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.SENSORS, description="Non-visible component providing location information, including longitude, latitude, altitude (if supported by the device), speed (if supported by the device), and address.  This can also perform \"geocoding\", converting a given address (not necessarily the current one) to a latitude (with the <code>LatitudeFromAddress</code> method) and a longitude (with the <code>LongitudeFromAddress</code> method).</p>\n<p>In order to function, the component must have its <code>Enabled</code> property set to True, and the device must have location sensing enabled through wireless networks or GPS satellites (if outdoors).</p>\nLocation information might not be immediately available when an app starts.  You'll have to wait a short time for a location provider to be found and used, or wait for the LocationChanged event", iconName="images/locationSensor.png", nonVisible=true, version=3)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.ACCESS_FINE_LOCATION,android.permission.ACCESS_COARSE_LOCATION,android.permission.ACCESS_MOCK_LOCATION,android.permission.ACCESS_LOCATION_EXTRA_COMMANDS")
public class LocationSensor
extends AndroidNonvisibleComponent
implements Component,
OnStopListener,
OnResumeListener,
Deleteable,
RealTimeDataSource<String, Float> {
    private static final String LOG_TAG = LocationSensor.class.getSimpleName();
    public static final int UNKNOWN_VALUE = 0;
    private List<String> allProviders;
    private double altitude;
    private final Handler androidUIHandler;
    private Set<DataSourceChangeListener> dataSourceObservers;
    private int distanceInterval;
    private boolean enabled;
    private Geocoder geocoder;
    private final Handler handler;
    private boolean hasAltitude;
    private boolean hasLocationData;
    private boolean havePermission;
    private boolean initialized;
    private Location lastLocation;
    private double latitude;
    private final Set<LocationSensorListener> listeners;
    private boolean listening;
    private final Criteria locationCriteria;
    private final LocationManager locationManager;
    private LocationProvider locationProvider;
    private double longitude;
    private MyLocationListener myLocationListener;
    private boolean providerLocked;
    private String providerName;
    private float speed;
    private int timeInterval;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(LocationSensor locationSensor, boolean bl) {
        locationSensor.havePermission = bl;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$sfgetLOG_TAG() {
        return LOG_TAG;
    }

    public LocationSensor(ComponentContainer componentContainer) {
        super(componentContainer, true);
    }

    public LocationSensor(ComponentContainer componentContainer, boolean bl) {
        super(componentContainer.$form());
        this.dataSourceObservers = new HashSet();
        this.listeners = new HashSet();
        this.providerLocked = false;
        this.initialized = false;
        this.listening = false;
        this.longitude = 0.0;
        this.latitude = 0.0;
        this.altitude = 0.0;
        this.speed = 0.0f;
        this.hasLocationData = false;
        this.hasAltitude = false;
        this.androidUIHandler = new Handler();
        this.enabled = true;
        this.havePermission = false;
        this.enabled = bl;
        this.handler = new Handler();
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.timeInterval = 60000;
        this.distanceInterval = 5;
        componentContainer = componentContainer.$context();
        this.geocoder = new Geocoder((Context)componentContainer);
        this.locationManager = (LocationManager)componentContainer.getSystemService("location");
        this.locationCriteria = new Criteria();
        this.myLocationListener = new LocationListener((LocationSensor)this, null){
            final LocationSensor this$0;
            {
                this.this$0 = locationSensor;
            }

            public void onLocationChanged(Location location2) {
                this.this$0.lastLocation = location2;
                this.this$0.longitude = location2.getLongitude();
                this.this$0.latitude = location2.getLatitude();
                this.this$0.speed = location2.getSpeed();
                if (location2.hasAltitude()) {
                    this.this$0.hasAltitude = true;
                    this.this$0.altitude = location2.getAltitude();
                }
                if (this.this$0.longitude != 0.0 || this.this$0.latitude != 0.0) {
                    this.this$0.hasLocationData = true;
                    double d = this.this$0.latitude;
                    double d2 = this.this$0.longitude;
                    double d3 = this.this$0.altitude;
                    float f = this.this$0.speed;
                    this.this$0.androidUIHandler.post(new Runnable(this, d, d2, d3, f, location2){
                        final MyLocationListener this$1;
                        final double val$argAltitude;
                        final double val$argLatitude;
                        final double val$argLongitude;
                        final float val$argSpeed;
                        final Location val$location;
                        {
                            this.this$1 = myLocationListener;
                            this.val$argLatitude = d;
                            this.val$argLongitude = d2;
                            this.val$argAltitude = d3;
                            this.val$argSpeed = f;
                            this.val$location = location2;
                        }

                        public void run() {
                            this.this$1.this$0.LocationChanged(this.val$argLatitude, this.val$argLongitude, this.val$argAltitude, this.val$argSpeed);
                            Iterator iterator = this.this$1.this$0.listeners.iterator();
                            while (iterator.hasNext()) {
                                (iterator.next()).onLocationChanged(this.val$location);
                            }
                        }
                    });
                }
            }

            public void onProviderDisabled(String string) {
                this.this$0.StatusChanged(string, "Disabled");
                this.this$0.stopListening();
                if (this.this$0.enabled) {
                    this.this$0.RefreshProvider("onProviderDisabled");
                }
            }

            public void onProviderEnabled(String string) {
                this.this$0.StatusChanged(string, "Enabled");
                this.this$0.RefreshProvider("onProviderEnabled");
            }

            public void onStatusChanged(String string, int n, Bundle bundle) {
                switch (n) {
                    default: {
                        break;
                    }
                    case 2: {
                        this.this$0.StatusChanged(string, "AVAILABLE");
                        if (string.equals((Object)this.this$0.providerName) || this.this$0.allProviders.contains((Object)string)) break;
                        this.this$0.RefreshProvider("onStatusChanged");
                        break;
                    }
                    case 1: {
                        this.this$0.StatusChanged(string, "TEMPORARILY_UNAVAILABLE");
                        break;
                    }
                    case 0: {
                        this.this$0.StatusChanged(string, "OUT_OF_SERVICE");
                        if (!string.equals((Object)this.this$0.providerName)) break;
                        this.this$0.stopListening();
                        this.this$0.RefreshProvider("onStatusChanged");
                    }
                }
            }
        };
        this.allProviders = new ArrayList();
        this.Enabled(bl);
    }

    private boolean empty(String string) {
        boolean bl = string == null || string.length() == 0;
        return bl;
    }

    private boolean startProvider(String string) {
        this.providerName = string;
        LocationProvider locationProvider = this.locationManager.getProvider(string);
        if (locationProvider == null) {
            Log.d((String)LOG_TAG, (String)("getProvider(" + string + ") returned null"));
            return false;
        }
        super.stopListening();
        this.locationProvider = locationProvider;
        this.locationManager.requestLocationUpdates(string, (long)this.timeInterval, (float)this.distanceInterval, (LocationListener)this.myLocationListener);
        this.listening = true;
        return true;
    }

    private void stopListening() {
        if (this.listening) {
            this.locationManager.removeUpdates((LocationListener)this.myLocationListener);
            this.locationProvider = null;
            this.listening = false;
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The most recent measure of accuracy, in meters.  If no value is available, 0 will be returned.")
    public double Accuracy() {
        Location location2 = this.lastLocation;
        if (location2 != null && location2.hasAccuracy()) {
            return this.lastLocation.getAccuracy();
        }
        location2 = this.locationProvider;
        if (location2 != null) {
            return location2.getAccuracy();
        }
        return 0.0;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The most recently available altitude value, in meters.  If no value is available, 0 will be returned.")
    public double Altitude() {
        return this.altitude;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public List<String> AvailableProviders() {
        return this.allProviders;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Provides a textual representation of the current address or \"No address available\".")
    public String CurrentAddress() {
        block9: {
            double d;
            if (this.hasLocationData && (d = this.latitude) <= 90.0 && d >= -90.0 && this.longitude <= 180.0 || this.longitude >= -180.0) {
                String string = this.geocoder.getFromLocation(this.latitude, this.longitude, 1);
                if (string == null) break block9;
                if (string.size() != 1 || (string = (Address)string.get(0)) == null) break block9;
                StringBuilder stringBuilder = new StringBuilder();
                int n = 0;
                while (true) {
                    if (n > string.getMaxAddressLineIndex()) break;
                    stringBuilder.append(string.getAddressLine(n));
                    stringBuilder.append("\n");
                    ++n;
                    continue;
                    break;
                }
                try {
                    string = stringBuilder.toString();
                    return string;
                }
                catch (Exception exception) {
                    if (!(exception instanceof IllegalArgumentException || exception instanceof IOException || exception instanceof IndexOutOfBoundsException)) {
                        string = LOG_TAG;
                        String string2 = exception.getMessage();
                        Log.e((String)string, (String)("Unexpected exception thrown by getting current address " + string2));
                        break block9;
                    }
                    string = LOG_TAG;
                    String string3 = exception.getMessage();
                    Log.e((String)string, (String)("Exception thrown by getting current address " + string3));
                }
            }
        }
        return "No address available";
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Determines the minimum distance interval, in meters, that the sensor will try to use for sending out location updates. For example, if this is set to 5, then the sensor will fire a LocationChanged event only after 5 meters have been traversed. However, the sensor does not guarantee that an update will be received at exactly the distance interval. It may take more than 5 meters to fire an event, for instance.")
    public int DistanceInterval() {
        return this.distanceInterval;
    }

    @DesignerProperty(defaultValue="5", editorType="sensor_dist_interval")
    @SimpleProperty
    public void DistanceInterval(int n) {
        if (n >= 0 && n <= 1000) {
            this.distanceInterval = n;
            if (this.enabled) {
                this.RefreshProvider("DistanceInterval");
            }
            Iterator iterator = this.listeners.iterator();
            while (iterator.hasNext()) {
                (iterator.next()).onDistanceIntervalChanged(this.distanceInterval);
            }
            return;
        }
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void Enabled(boolean bl) {
        this.enabled = bl;
        if (!this.initialized) {
            return;
        }
        if (!bl) {
            super.stopListening();
        } else {
            this.RefreshProvider("Enabled");
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Enabled() {
        return this.enabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean HasAccuracy() {
        boolean bl = this.Accuracy() != 0.0 && this.enabled;
        return bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean HasAltitude() {
        boolean bl = this.hasAltitude && this.enabled;
        return bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean HasLongitudeLatitude() {
        boolean bl = this.hasLocationData && this.enabled;
        return bl;
    }

    public void Initialize() {
        this.initialized = true;
        this.Enabled(this.enabled);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public double Latitude() {
        return this.latitude;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SimpleFunction(description="Derives latitude of given address")
    public double LatitudeFromAddress(String string) {
        try {
            List list = this.geocoder.getFromLocationName(string, 1);
            String string2 = LOG_TAG;
            int n = list.size();
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)string2, (String)stringBuilder.append("latitude addressObjs size is ").append(n).append(" for ").append(string).toString());
            if (list != null && list.size() != 0) {
                return ((Address)list.get(0)).getLatitude();
            }
            IOException iOException = new IOException("");
            throw iOException;
        }
        catch (IOException iOException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LatitudeFromAddress", 101, string);
            return 0.0;
        }
    }

    @SimpleEvent(description="Indicates that a new location has been detected.")
    public void LocationChanged(double d, double d2, double d3, float f) {
        this.notifyDataObservers("latitude", (Object)d);
        this.notifyDataObservers("longitude", (Object)d2);
        this.notifyDataObservers("altitude", (Object)d3);
        this.notifyDataObservers("speed", (Object)Float.valueOf((float)f));
        EventDispatcher.dispatchEvent((Component)this, "LocationChanged", d, d2, d3, Float.valueOf((float)f));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public double Longitude() {
        return this.longitude;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SimpleFunction(description="Derives longitude of given address")
    public double LongitudeFromAddress(String string) {
        try {
            List list = this.geocoder.getFromLocationName(string, 1);
            String string2 = LOG_TAG;
            int n = list.size();
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)string2, (String)stringBuilder.append("longitude addressObjs size is ").append(n).append(" for ").append(string).toString());
            if (list != null && list.size() != 0) {
                return ((Address)list.get(0)).getLongitude();
            }
            IOException iOException = new IOException("");
            throw iOException;
        }
        catch (IOException iOException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LongitudeFromAddress", 102, string);
            return 0.0;
        }
    }

    @SimpleProperty
    public void ProviderLocked(boolean bl) {
        this.providerLocked = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean ProviderLocked() {
        return this.providerLocked;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String ProviderName() {
        String string = this.providerName;
        if (string == null) {
            return "NO PROVIDER";
        }
        return string;
    }

    @SimpleProperty
    public void ProviderName(String string) {
        this.providerName = string;
        if (!super.empty(string) && super.startProvider(string)) {
            return;
        }
        this.RefreshProvider("ProviderName");
    }

    public void RefreshProvider(String string) {
        if (!this.initialized) {
            return;
        }
        super.stopListening();
        if (!this.havePermission) {
            this.androidUIHandler.post(new Runnable((LocationSensor)this, (LocationSensor)this, string){
                final LocationSensor this$0;
                final String val$caller;
                final LocationSensor val$me;
                {
                    this.this$0 = locationSensor;
                    this.val$me = locationSensor2;
                    this.val$caller = string;
                }

                public void run() {
                    this.val$me.form.askPermission((BulkPermissionRequest)new 1(this, (Component)this.val$me, "RefreshProvider", new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}));
                }
            });
        }
        if (this.providerLocked && !super.empty(this.providerName)) {
            this.listening = super.startProvider(this.providerName);
            return;
        }
        this.allProviders = this.locationManager.getProviders(true);
        string = this.locationManager.getBestProvider(this.locationCriteria, true);
        if (string != null && !string.equals(this.allProviders.get(0))) {
            this.allProviders.add(0, (Object)string);
        }
        for (String string2 : this.allProviders) {
            boolean bl;
            this.listening = bl = super.startProvider(string2);
            if (!bl) continue;
            if (!this.providerLocked) {
                this.providerName = string2;
            }
            return;
        }
    }

    @SimpleEvent
    public void StatusChanged(String string, String string2) {
        if (this.enabled) {
            EventDispatcher.dispatchEvent((Component)this, "StatusChanged", string, string2);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Determines the minimum time interval, in milliseconds, that the sensor will try to use for sending out location updates. However, location updates will only be received when the location of the phone actually changes, and use of the specified time interval is not guaranteed. For example, if 1000 is used as the time interval, location updates will never be fired sooner than 1000ms, but they may be fired anytime after.")
    public int TimeInterval() {
        return this.timeInterval;
    }

    @DesignerProperty(defaultValue="60000", editorType="sensor_time_interval")
    @SimpleProperty
    public void TimeInterval(int n) {
        if (n >= 0 && n <= 1000000) {
            this.timeInterval = n;
            if (this.enabled) {
                this.RefreshProvider("TimeInterval");
            }
            Iterator iterator = this.listeners.iterator();
            while (iterator.hasNext()) {
                (iterator.next()).onTimeIntervalChanged(this.timeInterval);
            }
            return;
        }
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    public void addListener(LocationSensorListener locationSensorListener) {
        locationSensorListener.setSource((LocationSensor)this);
        this.listeners.add((Object)locationSensorListener);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Float getDataValue(String string) {
        int n;
        block12: {
            switch (string.hashCode()) {
                case 2036550306: {
                    if (!string.equals((Object)"altitude")) break;
                    n = 2;
                    break block12;
                }
                case 137365935: {
                    if (!string.equals((Object)"longitude")) break;
                    n = 1;
                    break block12;
                }
                case 109641799: {
                    if (!string.equals((Object)"speed")) break;
                    n = 3;
                    break block12;
                }
                case -1439978388: {
                    if (!string.equals((Object)"latitude")) break;
                    n = 0;
                    break block12;
                }
            }
            n = -1;
        }
        switch (n) {
            default: {
                return Float.valueOf((float)0.0f);
            }
            case 3: {
                return Float.valueOf((float)this.speed);
            }
            case 2: {
                return Float.valueOf((float)((float)this.altitude));
            }
            case 1: {
                return Float.valueOf((float)((float)this.longitude));
            }
            case 0: 
        }
        return Float.valueOf((float)((float)this.latitude));
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    @Override
    public void onDelete() {
        this.stopListening();
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.RefreshProvider("onResume");
        }
    }

    @Override
    public void onStop() {
        this.stopListening();
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }

    public void removeListener(LocationSensorListener locationSensorListener) {
        this.listeners.remove((Object)locationSensorListener);
        locationSensorListener.setSource(null);
    }
}

