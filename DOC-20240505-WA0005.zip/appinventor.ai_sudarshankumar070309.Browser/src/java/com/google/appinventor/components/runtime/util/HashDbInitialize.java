package com.google.appinventor.components.runtime.util;

import android.provider.BaseColumns;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public class HashDbInitialize {

    /* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
    public static class HashTable implements BaseColumns {
        public static final String COLUMN_1_NAME = "fileName";
        public static final String COLUMN_2_NAME = "hashFile";
        public static final String COLUMN_3_NAME = "timeStamp";
        public static final String TABLE_NAME = "HashDatabase";
    }

    private HashDbInitialize() {
    }
}
