/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.ElementType
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.lang.annotation.Target
 */
package com.google.appinventor.components.annotations.androidmanifest;

import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.annotations.androidmanifest.MetaDataElement;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.TYPE})
public @interface ActivityElement {
    public String allowEmbedded() default "";

    public String allowTaskReparenting() default "";

    public String alwaysRetainTaskState() default "";

    public String autoRemoveFromRecents() default "";

    public String banner() default "";

    public String clearTaskOnLaunch() default "";

    public String colorMode() default "";

    public String configChanges() default "";

    public String directBootAware() default "";

    public String documentLaunchMode() default "";

    public String enabled() default "";

    public String excludeFromRecents() default "";

    public String exported() default "true";

    public String finishOnTaskLaunch() default "";

    public String hardwareAccelerated() default "";

    public String icon() default "";

    public String immersive() default "";

    public IntentFilterElement[] intentFilters() default {};

    public String label() default "";

    public String launchMode() default "";

    public String lockTaskMode() default "";

    public String maxAspectRatio() default "";

    public String maxRecents() default "";

    public MetaDataElement[] metaDataElements() default {};

    public String multiprocess() default "";

    public String name();

    public String noHistory() default "";

    public String parentActivityName() default "";

    public String permission() default "";

    public String persistableMode() default "";

    public String process() default "";

    public String relinquishTaskIdentity() default "";

    public String resizableActivity() default "";

    public String screenOrientation() default "";

    public String showForAllUsers() default "";

    public String stateNotNeeded() default "";

    public String supportsPictureInPicture() default "";

    public String taskAffinity() default "";

    public String theme() default "";

    public String uiOptions() default "";

    public String windowSoftInputMode() default "";
}

