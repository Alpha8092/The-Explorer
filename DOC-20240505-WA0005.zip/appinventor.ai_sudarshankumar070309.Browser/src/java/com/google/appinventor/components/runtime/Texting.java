/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences$Editor
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.telephony.SmsManager
 *  android.telephony.SmsMessage
 *  android.text.TextUtils
 *  android.util.Log
 *  android.widget.Toast
 *  com.google.appinventor.components.common.ReceivingState
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Texting$1$1
 *  com.google.appinventor.components.runtime.Texting$3$1
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.OAuth2Helper
 *  com.google.appinventor.components.runtime.util.OnInitializeListener
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.io.BufferedReader
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.net.CookieManager
 *  java.net.HttpCookie
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLEncoder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Queue
 *  java.util.concurrent.ConcurrentLinkedQueue
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesBroadcastReceivers;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.annotations.androidmanifest.ReceiverElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.ReceivingState;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.Texting;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.OAuth2Helper;
import com.google.appinventor.components.runtime.util.OnInitializeListener;
import com.google.appinventor.components.runtime.util.SdkLevel;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.SOCIAL, description="<p>A component that will, when the <code>SendMessage</code> method is called, send the text message specified in the <code>Message</code> property to the phone number specified in the <code>PhoneNumber</code> property.</p> <p>If the <code>ReceivingEnabled</code> property is set to 1 messages will <b>not</b> be received. If <code>ReceivingEnabled</code> is set to 2 messages will be received only when the application is running. Finally if <code>ReceivingEnabled</code> is set to 3, messages will be received when the application is running <b>and</b> when the application is not running they will be queued and a notification displayed to the user.</p> <p>When a message arrives, the <code>MessageReceived</code> event is raised and provides the sending number and message.</p> <p> An app that includes this component will receive messages even when it is in the background (i.e. when it's not visible on the screen) and, moreso, even if the app is not running, so long as it's installed on the phone. If the phone receives a text message when the app is not in the foreground, the phone will show a notification in the notification bar.  Selecting the notification will bring up the app.  As an app developer, you'll probably want to give your users the ability to control ReceivingEnabled so that they can make the phone ignore text messages.</p> <p>If the GoogleVoiceEnabled property is true, messages can be sent over Wifi using Google Voice. This option requires that the user have a Google Voice account and that the mobile Voice app is installed on the phone. The Google Voice option works only on phones that support Android 2.0 (Eclair) or higher.</p> <p>To specify the phone number (e.g., 650-555-1212), set the <code>PhoneNumber</code> property to a Text string with the specified digits (e.g., 6505551212).  Dashes, dots, and parentheses may be included (e.g., (650)-555-1212) but will be ignored; spaces may not be included.</p> <p>Another way for an app to specify a phone number would be to include a <code>PhoneNumberPicker</code> component, which lets the users select a phone numbers from the ones stored in the the phone's contacts.</p>", iconName="images/texting.png", nonVisible=true, version=5)
@SimpleObject
@UsesLibraries(libraries="google-api-client.jar,google-api-client-android2-beta.jar,google-http-client.jar,google-http-client-android2-beta.jar,google-http-client-android3-beta.jar,google-oauth-client.jar,guava.jar")
@UsesPermissions(permissionNames="com.google.android.apps.googlevoice.permission.RECEIVE_SMS, com.google.android.apps.googlevoice.permission.SEND_SMS, android.permission.ACCOUNT_MANAGER, android.permission.MANAGE_ACCOUNTS, android.permission.GET_ACCOUNTS, android.permission.USE_CREDENTIALS")
public class Texting
extends AndroidNonvisibleComponent
implements Component,
OnResumeListener,
OnPauseListener,
OnInitializeListener,
OnStopListener,
Deleteable,
ActivityResultListener {
    private static final String CACHE_FILE = "textingmsgcache";
    public static final String GV_INTENT_FILTER = "com.google.android.apps.googlevoice.SMS_RECEIVED";
    public static final String GV_PACKAGE_NAME = "com.google.android.apps.googlevoice";
    private static final String GV_SERVICE = "grandcentral";
    public static final String GV_SMS_RECEIVED = "com.google.android.apps.googlevoice.SMS_RECEIVED";
    public static final String GV_SMS_SEND_URL = "https://www.google.com/voice/b/0/sms/send/";
    public static final String GV_URL = "https://www.google.com/voice/b/0/redirection/voice";
    private static final String MESSAGE_DELIMITER = "\u0001";
    public static final String MESSAGE_TAG = "com.google.android.apps.googlevoice.TEXT";
    public static final String META_DATA_SMS_KEY = "sms_handler_component";
    public static final String META_DATA_SMS_VALUE = "Texting";
    public static final String PHONE_NUMBER_TAG = "com.google.android.apps.googlevoice.PHONE_NUMBER";
    private static final String PREF_FILE = "TextingState";
    private static final String PREF_GVENABLED = "gvenabled";
    private static final String PREF_RCVENABLED = "receiving2";
    private static final String PREF_RCVENABLED_LEGACY = "receiving";
    private static final String SENT = "SMS_SENT";
    private static final int SERVER_TIMEOUT_MS = 30000;
    public static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    public static final String TAG = "Texting Component";
    public static final String TELEPHONY_INTENT_FILTER = "android.provider.Telephony.SMS_RECEIVED";
    public static final int TEXTING_REQUEST_CODE = 0x54455854;
    private static final String USER_AGENT = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13";
    private static final String UTF8 = "UTF-8";
    private static Activity activity;
    private static Object cacheLock;
    private static Component component;
    private static boolean isRunning;
    private static int messagesCached;
    private static ReceivingState receivingState;
    private String authToken;
    private ComponentContainer container;
    private boolean googleVoiceEnabled;
    private GoogleVoiceUtil gvHelper;
    private boolean havePermission = false;
    private boolean haveReceivePermission = false;
    private boolean isInitialized;
    private String message;
    private Queue<String> pendingQueue = new ConcurrentLinkedQueue();
    private String phoneNumber;
    private SmsManager smsManager;

    static /* bridge */ /* synthetic */ String -$$Nest$fgetmessage(Texting texting) {
        return texting.message;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(Texting texting, boolean bl) {
        texting.havePermission = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputhaveReceivePermission(Texting texting, boolean bl) {
        texting.haveReceivePermission = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mhandleSentMessage(Texting texting, Context context, BroadcastReceiver broadcastReceiver, int n, String string) {
        texting.handleSentMessage(context, broadcastReceiver, n, string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$msendViaSms(Texting texting, String string) {
        texting.sendViaSms(string);
    }

    static {
        receivingState = ReceivingState.Foreground;
        cacheLock = new Object();
    }

    public Texting(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        Activity activity;
        Log.d((String)TAG, (String)"Texting constructor");
        this.container = componentContainer;
        component = this;
        Texting.activity = activity = componentContainer.$context();
        activity = activity.getSharedPreferences(PREF_FILE, 0);
        if (activity != null) {
            int n = activity.getInt(PREF_RCVENABLED, -1);
            receivingState = n == -1 ? (activity.getBoolean(PREF_RCVENABLED_LEGACY, true) ? ReceivingState.Foreground : ReceivingState.Off) : ReceivingState.fromUnderlyingValue((Integer)n);
            this.googleVoiceEnabled = activity.getBoolean(PREF_GVENABLED, false);
            activity = receivingState.toUnderlyingValue();
            boolean bl = this.googleVoiceEnabled;
            Log.i((String)TAG, (String)("Starting with receiving Enabled=" + activity + " GV enabled=" + bl));
        } else {
            receivingState = ReceivingState.Off;
            this.googleVoiceEnabled = false;
        }
        if (this.googleVoiceEnabled) {
            new AsyncTask<Void, Void, String>((Texting)this){
                final Texting this$0;
                {
                    this.this$0 = texting;
                }

                protected String doInBackground(Void ... voidArray) {
                    Log.i((String)Texting.TAG, (String)"Authenticating");
                    return new OAuth2Helper().getRefreshedAuthToken(activity, Texting.GV_SERVICE);
                }

                protected void onPostExecute(String string) {
                    Log.i((String)Texting.TAG, (String)("authToken = " + string));
                    this.this$0.authToken = string;
                    Toast.makeText((Context)activity, (CharSequence)"Finished authentication", (int)0).show();
                    this.this$0.processPendingQueue();
                }
            }.execute((Object[])new Void[0]);
        }
        this.smsManager = SmsManager.getDefault();
        this.PhoneNumber("");
        this.isInitialized = false;
        isRunning = false;
        componentContainer.$form().registerForOnInitialize((OnInitializeListener)this);
        componentContainer.$form().registerForOnResume((OnResumeListener)this);
        componentContainer.$form().registerForOnPause((OnPauseListener)this);
        componentContainer.$form().registerForOnStop((OnStopListener)this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SimpleEvent
    public static void MessageReceived(String string, String string2) {
        Object object2;
        if (receivingState == ReceivingState.Off) {
            return;
        }
        Log.i((String)TAG, (String)("MessageReceived from " + string + ":" + string2));
        if (EventDispatcher.dispatchEvent(component, "MessageReceived", string, string2)) {
            Log.i((String)TAG, (String)"Dispatch successful");
            return;
        }
        Log.i((String)TAG, (String)"Dispatch failed, caching");
        Object object3 = object2 = cacheLock;
        synchronized (object3) {
            Texting.addMessageToCache((Context)activity, string, string2);
            return;
        }
    }

    private static void addMessageToCache(Context context, String string, String string2) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            string = stringBuilder.append(string).append(":").append(string2).append(MESSAGE_DELIMITER).toString();
            string2 = new StringBuilder();
            Log.i((String)TAG, (String)string2.append("Caching ").append(string).toString());
            context = context.openFileOutput(CACHE_FILE, 32768);
            context.write(string.getBytes());
            context.close();
            ++messagesCached;
            context = new StringBuilder();
            Log.i((String)TAG, (String)context.append("Cached ").append(string).toString());
        }
        catch (IOException iOException) {
            Log.e((String)TAG, (String)"I/O Error writing to cache file");
            iOException.printStackTrace();
        }
        catch (FileNotFoundException fileNotFoundException) {
            Log.e((String)TAG, (String)"File not found error writing to cache file");
            fileNotFoundException.printStackTrace();
        }
    }

    public static int getCachedMsgCount() {
        return messagesCached;
    }

    public static SmsMessage[] getMessagesFromIntent(Intent object2) {
        int n;
        Object object3 = (Object[])object2.getSerializableExtra("pdus");
        object2 = new byte[((Object[])object3).length][];
        for (n = 0; n < ((Object[])object3).length; ++n) {
            object2[n] = (Intent)((byte[])object3[n]);
        }
        object3 = new byte[((Intent)object2).length][];
        int n2 = ((Object[])object3).length;
        SmsMessage[] smsMessageArray = new SmsMessage[n2];
        for (n = 0; n < n2; ++n) {
            object3[n] = object2[n];
            smsMessageArray[n] = SmsMessage.createFromPdu((byte[])object3[n]);
        }
        return smsMessageArray;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void handleSentMessage(Context context, BroadcastReceiver broadcastReceiver, int n, String string) {
        void var0_2;
        void var5_5 = var0_2;
        synchronized (var5_5) {
            void var3_4;
            switch (var3_4) {
                default: {
                    break;
                }
                case 4: {
                    context = new StringBuilder();
                    Log.e((String)TAG, (String)context.append("Received no service error, msg:").append(string).toString());
                    Toast.makeText((Context)activity, (CharSequence)"No Sms service available. Message not sent.", (int)0).show();
                    break;
                }
                case 3: {
                    context = new StringBuilder();
                    Log.e((String)TAG, (String)context.append("Received null PDU error, msg:").append(string).toString());
                    Toast.makeText((Context)activity, (CharSequence)"Received null PDU error. Message not sent.", (int)0).show();
                    break;
                }
                case 2: {
                    context = new StringBuilder();
                    Log.e((String)TAG, (String)context.append("Received radio off error, msg:").append(string).toString());
                    Toast.makeText((Context)activity, (CharSequence)"Could not send SMS message: radio off.", (int)1).show();
                    break;
                }
                case 1: {
                    context = new StringBuilder();
                    Log.e((String)TAG, (String)context.append("Received generic failure, msg:").append(string).toString());
                    Toast.makeText((Context)activity, (CharSequence)"Generic failure: message not sent", (int)0).show();
                    break;
                }
                case -1: {
                    context = new StringBuilder();
                    Log.i((String)TAG, (String)context.append("Received OK, msg:").append(string).toString());
                    Toast.makeText((Context)activity, (CharSequence)"Message sent", (int)0).show();
                    break;
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void handledReceivedMessage(Context context, String string, String string2) {
        Object object2;
        if (isRunning) {
            Texting.MessageReceived(string, string2);
            return;
        }
        Object object3 = object2 = cacheLock;
        synchronized (object3) {
            Texting.addMessageToCache(context, string, string2);
            return;
        }
    }

    public static int isReceivingEnabled(Context context) {
        int n = (context = context.getSharedPreferences(PREF_FILE, 0)).getInt(PREF_RCVENABLED, -1);
        if (n == -1) {
            if (context.getBoolean(PREF_RCVENABLED_LEGACY, true)) {
                return 2;
            }
            return 1;
        }
        return n;
    }

    public static boolean isRunning() {
        return isRunning;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void processCachedMessages() {
        String[] stringArray;
        Object object2;
        Object object3 = object2 = cacheLock;
        synchronized (object3) {
            stringArray = this.retrieveCachedMessages();
            // MONITOREXIT @DISABLED, blocks:[0, 2] lbl5 : w: MONITOREXIT : var5_2
            if (stringArray == null) {
                return;
            }
            {
                catch (Throwable throwable) {}
                {
                    throw throwable;
                }
            }
        }
        int n = stringArray.length;
        Log.i((String)TAG, (String)("processing " + n + " cached messages "));
        n = 0;
        while (n < stringArray.length) {
            object2 = stringArray[n];
            Log.i((String)TAG, (String)("Message + " + n + " " + (String)object2));
            int n2 = object2.indexOf(":");
            if (receivingState != ReceivingState.Off && n2 != -1) {
                Texting.MessageReceived(object2.substring(0, n2), object2.substring(n2 + 1));
            }
            ++n;
        }
    }

    private void processPendingQueue() {
        while (this.pendingQueue.size() != 0) {
            String string = (String)this.pendingQueue.remove();
            String string2 = string.substring(0, string.indexOf(":::"));
            string = string.substring(string.indexOf(":::") + 3);
            Log.i((String)TAG, (String)("Sending queued message " + string2 + " " + string));
            new AsyncTask<String, Void, String>(this){
                final Texting this$0;
                {
                    this.this$0 = texting;
                }

                /*
                 * Enabled force condition propagation
                 * Lifted jumps to return sites
                 */
                protected String doInBackground(String ... object2) {
                    String string;
                    Object object3;
                    String string2;
                    block18: {
                        Object object4 = object2[0];
                        Object string3 = object2[1];
                        string2 = "";
                        Log.i((String)Texting.TAG, (String)("Async sending phoneNumber = " + (String)object4 + " message = " + (String)string3));
                        object2 = string2;
                        object3 = URLEncoder.encode((String)"phoneNumber", (String)Texting.UTF8);
                        object2 = string2;
                        string = URLEncoder.encode((String)object4, (String)Texting.UTF8);
                        object2 = string2;
                        object4 = URLEncoder.encode((String)"text", (String)Texting.UTF8);
                        object2 = string2;
                        string3 = URLEncoder.encode((String)string3, (String)Texting.UTF8);
                        object2 = string2;
                        object2 = string2;
                        StringBuilder stringBuilder = new StringBuilder();
                        object2 = string2;
                        string = stringBuilder.append((String)object3).append("=").append(string).append("&").append((String)object4).append("=").append((String)string3).toString();
                        object2 = string2;
                        if (this.this$0.gvHelper != null) break block18;
                        object2 = string2;
                        object3 = this.this$0;
                        object2 = string2;
                        object2 = string2;
                        object4 = new Object((Texting)object3, ((Texting)object3).authToken){
                            private static final String COOKIES_HEADER = "Set-Cookie";
                            private final int MAX_REDIRECTS;
                            String authToken;
                            CookieManager cookies;
                            String general;
                            private boolean isInitialized;
                            int redirectCounter;
                            String rnrSEE;
                            final Texting this$0;
                            {
                                this.this$0 = object2;
                                this.MAX_REDIRECTS = 5;
                                this.cookies = new CookieManager();
                                Log.i((String)Texting.TAG, (String)"Creating GV Util");
                                this.authToken = string;
                                try {
                                    this.general = object2 = this.getGeneral();
                                    Log.i((String)Texting.TAG, (String)string.append("general = ").append((String)object2).toString());
                                    super.setRNRSEE();
                                    this.isInitialized = true;
                                }
                                catch (IOException iOException) {
                                    iOException.printStackTrace();
                                }
                            }

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            private String sendGvSms(String object2) {
                                Log.i((String)Texting.TAG, (String)"sendGvSms()");
                                Object object3 = new StringBuilder();
                                try {
                                    String string = URLEncoder.encode((String)"_rnr_se", (String)Texting.UTF8);
                                    String string2 = URLEncoder.encode((String)this.rnrSEE, (String)Texting.UTF8);
                                    StringBuilder stringBuilder = new StringBuilder();
                                    string = stringBuilder.append(object2).append("&").append(string).append("=").append(string2).toString();
                                    object2 = new StringBuilder();
                                    Log.i((String)Texting.TAG, (String)object2.append("smsData = ").append(string).toString());
                                    object2 = new URL(Texting.GV_SMS_SEND_URL);
                                    object2 = (HttpURLConnection)object2.openConnection();
                                    string2 = this.authToken;
                                    stringBuilder = new StringBuilder();
                                    object2.setRequestProperty("Authorization", stringBuilder.append("GoogleLogin auth=").append(string2).toString());
                                    object2.setRequestProperty("User-agent", Texting.USER_AGENT);
                                    this.setCookies((HttpURLConnection)object2);
                                    object2.setDoOutput(true);
                                    object2.setConnectTimeout(30000);
                                    stringBuilder = new StringBuilder();
                                    Log.i((String)Texting.TAG, (String)stringBuilder.append("sms request = ").append(object2).toString());
                                    stringBuilder = new OutputStreamWriter(object2.getOutputStream());
                                    stringBuilder.write(string);
                                    stringBuilder.flush();
                                    this.processCookies((HttpURLConnection)object2);
                                    string2 = new InputStreamReader(object2.getInputStream());
                                    string = new BufferedReader((Reader)string2);
                                    while ((object2 = string.readLine()) != null) {
                                        object3.append(object2);
                                        object3.append("\n");
                                    }
                                    object2 = new StringBuilder();
                                    Log.i((String)Texting.TAG, (String)object2.append("sendGvSms:  Sent SMS, response = ").append(object3).toString());
                                    stringBuilder.close();
                                    string.close();
                                    if (object3.length() != 0) {
                                        return object3.toString();
                                    }
                                    object2 = new IOException("No Response Data Received.");
                                    throw object2;
                                }
                                catch (IOException iOException) {
                                    object3 = iOException.getMessage();
                                    Log.i((String)Texting.TAG, (String)("IO Error on Send " + (String)object3), (Throwable)iOException);
                                    return "IO Error Message not sent";
                                }
                            }

                            private void setRNRSEE() throws IOException {
                                Log.i((String)Texting.TAG, (String)"setRNRSEE()");
                                String string = this.general;
                                if (string != null) {
                                    if (string.contains((CharSequence)"'_rnr_se': '")) {
                                        this.rnrSEE = this.general.split("'_rnr_se': '", 2)[1].split("',", 2)[0];
                                        Log.i((String)Texting.TAG, (String)"Successfully Received rnr_se.");
                                        return;
                                    }
                                    string = this.general;
                                    Log.i((String)Texting.TAG, (String)("Answer did not contain rnr_se! " + string));
                                    string = this.general;
                                    throw new IOException("Answer did not contain rnr_se! " + string);
                                }
                                Log.i((String)Texting.TAG, (String)"setRNRSEE(): Answer was null!");
                                throw new IOException("setRNRSEE(): Answer was null!");
                            }

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            String get(String object2) throws IOException {
                                Object object3;
                                int n;
                                int n2;
                                Object object4;
                                block14: {
                                    String string;
                                    block13: {
                                        block12: {
                                            object4 = (HttpURLConnection)new URL(object2).openConnection();
                                            n = n2 = 0;
                                            try {
                                                string = this.authToken;
                                                n = n2;
                                                n = n2;
                                                object3 = new StringBuilder();
                                                n = n2;
                                                object4.setRequestProperty("Authorization", object3.append("GoogleLogin auth=").append(string).toString());
                                                n = n2;
                                                object4.setRequestProperty("User-agent", Texting.USER_AGENT);
                                                n = n2;
                                                object4.setInstanceFollowRedirects(false);
                                                n = n2;
                                                this.setCookies((HttpURLConnection)object4);
                                                n = n2;
                                                object4.connect();
                                                n = n2;
                                                n = n2 = object4.getResponseCode();
                                                string = object4.getResponseMessage();
                                                n = n2;
                                                n = n2;
                                                object3 = new StringBuilder();
                                                n = n2;
                                                Log.i((String)Texting.TAG, (String)object3.append(object2).append(" - ").append(string).toString());
                                            }
                                            catch (Exception exception) {
                                                String string2 = object4.getResponseMessage();
                                                object2 = new IOException(object2 + " : " + string2 + "(" + n + ") : IO Error.");
                                                throw object2;
                                            }
                                            this.processCookies((HttpURLConnection)object4);
                                            if (n2 != 200) break block12;
                                            object3 = object4.getInputStream();
                                            break block13;
                                        }
                                        if (n2 == 301 || n2 == 302 || n2 == 303 || n2 == 307) break block14;
                                        object3 = object4.getErrorStream();
                                    }
                                    this.redirectCounter = 0;
                                    if (object3 == null) {
                                        object3 = object4.getResponseMessage();
                                        throw new IOException(object2 + " : " + (String)object3 + "(" + n2 + ") : InputStream was null : exiting.");
                                    }
                                    try {
                                        InputStreamReader inputStreamReader = new InputStreamReader((InputStream)object3);
                                        string = new BufferedReader((Reader)inputStreamReader);
                                        StringBuffer stringBuffer = new StringBuffer();
                                        while (true) {
                                            if ((object3 = string.readLine()) == null) {
                                                string.close();
                                                return stringBuffer.toString();
                                            }
                                            inputStreamReader = new StringBuilder();
                                            stringBuffer.append(inputStreamReader.append((String)object3).append("\n\r").toString());
                                        }
                                    }
                                    catch (Exception exception) {
                                        object3 = object4.getResponseMessage();
                                        object4 = exception.getLocalizedMessage();
                                        throw new IOException(object2 + " - " + (String)object3 + "(" + n2 + ") - " + (String)object4);
                                    }
                                }
                                this.redirectCounter = n = this.redirectCounter + 1;
                                if (n > 5) {
                                    this.redirectCounter = 0;
                                    object3 = object4.getResponseMessage();
                                    throw new IOException(object2 + " : " + (String)object3 + "(" + n2 + ") : Too many redirects. exiting.");
                                }
                                object3 = object4.getHeaderField("Location");
                                if (object3 != null && !object3.equals((Object)"")) {
                                    System.out.println(object2 + " - " + n2 + " - new URL: " + (String)object3);
                                    return this.get((String)object3);
                                }
                                object3 = object4.getResponseMessage();
                                throw new IOException(object2 + " : " + (String)object3 + "(" + n2 + ") : Received moved answer but no Location. exiting.");
                            }

                            public String getGeneral() throws IOException {
                                Log.i((String)Texting.TAG, (String)"getGeneral()");
                                return this.get(Texting.GV_URL);
                            }

                            public boolean isInitialized() {
                                return this.isInitialized;
                            }

                            void processCookies(HttpURLConnection object22) {
                                if ((object22 = (List)object22.getHeaderFields().get((Object)COOKIES_HEADER)) != null) {
                                    for (Object object22 : object22) {
                                        this.cookies.getCookieStore().add(null, (HttpCookie)HttpCookie.parse((String)object22).get(0));
                                    }
                                }
                            }

                            void setCookies(HttpURLConnection httpURLConnection) {
                                if (this.cookies.getCookieStore().getCookies().size() > 0) {
                                    httpURLConnection.setRequestProperty("Cookie", TextUtils.join((CharSequence)";", (Iterable)this.cookies.getCookieStore().getCookies()));
                                }
                            }
                        };
                        object2 = string2;
                        ((Texting)object3).gvHelper = object4;
                    }
                    object2 = string2;
                    if (!this.this$0.gvHelper.isInitialized()) return "IO Error: unable to create GvHelper";
                    object2 = string2;
                    string2 = this.this$0.gvHelper.sendGvSms(string);
                    object2 = string2;
                    object2 = string2;
                    object3 = new StringBuilder();
                    object2 = string2;
                    try {
                        Log.i((String)Texting.TAG, (String)object3.append("Sent SMS, response = ").append(string2).toString());
                        return string2;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    return object2;
                }

                protected void onPostExecute(String string) {
                    int n;
                    super.onPostExecute((Object)string);
                    boolean bl = false;
                    int n2 = 0;
                    boolean bl2 = bl;
                    bl2 = bl;
                    JSONObject jSONObject = new JSONObject(string);
                    bl2 = bl;
                    bl2 = bl = jSONObject.getBoolean("ok");
                    try {
                        n = jSONObject.getJSONObject("data").getInt("code");
                        bl2 = bl;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        n = n2;
                    }
                    if (bl2) {
                        Toast.makeText((Context)activity, (CharSequence)"Message sent", (int)0).show();
                    } else if (n == 58) {
                        Toast.makeText((Context)activity, (CharSequence)"Errcode 58: SMS limit reached", (int)0).show();
                    } else if (string.contains((CharSequence)"IO Error")) {
                        Toast.makeText((Context)activity, (CharSequence)string, (int)0).show();
                    }
                }
            }.execute((Object[])new String[]{string2, string});
        }
    }

    private void requestReceiveSmsPermission(String string) {
        this.form.runOnUiThread(new Runnable((Texting)this, string){
            final Texting this$0;
            final String val$caller;
            {
                this.this$0 = texting;
                this.val$caller = string;
            }

            public void run() {
                this.this$0.form.askPermission("android.permission.RECEIVE_SMS", (PermissionResultHandler)new 1(this));
            }
        });
    }

    private String[] retrieveCachedMessages() {
        String string;
        Log.i((String)TAG, (String)"Retrieving cached messages");
        try {
            Object object2 = FileUtil.readFile((Form)this.form, (String)CACHE_FILE);
            string = new String(object2);
            activity.deleteFile(CACHE_FILE);
            messagesCached = 0;
            object2 = new StringBuilder;
            object2();
            Log.i((String)TAG, (String)object2.append("Retrieved cache ").append(string).toString());
        }
        catch (IOException iOException) {
            Log.e((String)TAG, (String)"I/O Error reading from cache file");
            iOException.printStackTrace();
            return null;
        }
        catch (FileNotFoundException fileNotFoundException) {
            Log.e((String)TAG, (String)"No Cache file found -- this is not (usually) an error");
            return null;
        }
        return string.split(MESSAGE_DELIMITER);
    }

    private void sendViaSms(String string) {
        Log.i((String)TAG, (String)"Sending via built-in Sms");
        if (!this.havePermission) {
            Form form = this.container.$form();
            form.runOnUiThread(new Runnable((Texting)this, form, (Texting)this, string){
                final Texting this$0;
                final String val$caller;
                final Form val$form;
                final Texting val$me;
                {
                    this.this$0 = texting;
                    this.val$form = form;
                    this.val$me = texting2;
                    this.val$caller = string;
                }

                public void run() {
                    this.val$form.askPermission("android.permission.SEND_SMS", (PermissionResultHandler)new 1(this));
                }
            });
            return;
        }
        ArrayList arrayList = this.smsManager.divideMessage(this.message);
        int n = arrayList.size();
        string = new ArrayList();
        for (int i = 0; i < n; ++i) {
            string.add((Object)PendingIntent.getBroadcast((Context)activity, (int)0, (Intent)new Intent(SENT), (int)0x4000000));
        }
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver((Texting)this){
            final Texting this$0;
            {
                this.this$0 = texting;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onReceive(Context context, Intent intent) {
                void var4_5 = this;
                synchronized (var4_5) {
                    Throwable throwable2;
                    block5: {
                        try {
                            try {
                                Texting.-$$Nest$mhandleSentMessage(this.this$0, context, null, this.getResultCode(), Texting.-$$Nest$fgetmessage(this.this$0));
                                Texting.-$$Nest$sfgetactivity().unregisterReceiver((BroadcastReceiver)this);
                            }
                            catch (Exception exception) {
                                String string = intent.getAction();
                                intent = new StringBuilder();
                                Log.e((String)"BroadcastReceiver", (String)intent.append("Error in onReceive for msgId ").append(string).toString());
                                Log.e((String)"BroadcastReceiver", (String)exception.getMessage());
                                exception.printStackTrace();
                            }
                        }
                        catch (Throwable throwable2) {
                            break block5;
                        }
                        return;
                    }
                    throw throwable2;
                }
            }
        };
        activity.registerReceiver(broadcastReceiver, new IntentFilter(SENT));
        this.smsManager.sendMultipartTextMessage(this.phoneNumber, null, arrayList, (ArrayList)string, null);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    @UsesBroadcastReceivers(receivers={@ReceiverElement(intentFilters={@IntentFilterElement(actionElements={@ActionElement(name="com.google.android.apps.googlevoice.SMS_RECEIVED")})}, name="com.google.appinventor.components.runtime.util.SmsBroadcastReceiver")})
    public void GoogleVoiceEnabled(boolean bl) {
        if (SdkLevel.getLevel() >= 5) {
            this.googleVoiceEnabled = bl;
            SharedPreferences.Editor editor = activity.getSharedPreferences(PREF_FILE, 0).edit();
            editor.putBoolean(PREF_GVENABLED, bl);
            editor.commit();
        } else {
            Toast.makeText((Context)activity, (CharSequence)"Sorry, your phone's system does not support this option.", (int)1).show();
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true, then SendMessage will attempt to send messages over Wifi using Google Voice.  This requires that the Google Voice app must be installed and set up on the phone or tablet, with a Google Voice account.  If GoogleVoiceEnabled is false, the device must have phone and texting service in order to send or receive messages with this component.")
    public boolean GoogleVoiceEnabled() {
        return this.googleVoiceEnabled;
    }

    public void Initialize() {
        if (receivingState != ReceivingState.Off && !this.haveReceivePermission) {
            this.requestReceiveSmsPermission("Initialize");
        }
    }

    @SimpleProperty
    public String Message() {
        return this.message;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The message that will be sent when the SendMessage method is called.")
    public void Message(String string) {
        Log.i((String)TAG, (String)("Message set: " + string));
        this.message = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The number that the message will be sent to when the SendMessage method is called. The number is a text string with the specified digits (e.g., 6505551212).  Dashes, dots, and parentheses may be included (e.g., (650)-555-1212) but will be ignored; spaces should not be included.")
    public String PhoneNumber() {
        return this.phoneNumber;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void PhoneNumber(String string) {
        Log.i((String)TAG, (String)("PhoneNumber set: " + string));
        this.phoneNumber = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If set to 1 (OFF) no messages will be received.  If set to 2 (FOREGROUND) or3 (ALWAYS) the component will respond to messages if it is running. If the app is not running then the message will be discarded if set to 2 (FOREGROUND). If set to 3 (ALWAYS) and the app is not running the phone will show a notification.  Selecting the notification will bring up the app and signal the MessageReceived event.  Messages received when the app is dormant will be queued, and so several MessageReceived events might appear when the app awakens.  As an app developer, it would be a good idea to give your users control over this property, so they can make their phones ignore text messages when your app is installed.")
    public int ReceivingEnabled() {
        return this.ReceivingEnabledAbstract().toUnderlyingValue();
    }

    @DesignerProperty(alwaysSend=true, defaultValue="1", editorType="text_receiving")
    @SimpleProperty
    @UsesBroadcastReceivers(receivers={@ReceiverElement(intentFilters={@IntentFilterElement(actionElements={@ActionElement(name="android.provider.Telephony.SMS_RECEIVED")})}, name="com.google.appinventor.components.runtime.util.SmsBroadcastReceiver")})
    @UsesPermissions(value={"android.permission.RECEIVE_SMS"})
    public void ReceivingEnabled(@Options(value=ReceivingState.class) int n) {
        ReceivingState receivingState = ReceivingState.fromUnderlyingValue((Integer)n);
        if (receivingState == null) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, META_DATA_SMS_VALUE, 1701, n);
            return;
        }
        this.ReceivingEnabledAbstract(receivingState);
    }

    public ReceivingState ReceivingEnabledAbstract() {
        return receivingState;
    }

    public void ReceivingEnabledAbstract(ReceivingState receivingState) {
        Texting.receivingState = receivingState;
        SharedPreferences.Editor editor = activity.getSharedPreferences(PREF_FILE, 0).edit();
        editor.putInt(PREF_RCVENABLED, receivingState.toUnderlyingValue().intValue());
        editor.remove(PREF_RCVENABLED_LEGACY);
        editor.commit();
        if (receivingState != ReceivingState.Off && !this.haveReceivePermission) {
            super.requestReceiveSmsPermission("ReceivingEnabled");
        }
    }

    @SimpleFunction
    public void SendMessage() {
        String string = this.phoneNumber;
        String string2 = this.message;
        string = new Intent("android.intent.action.SENDTO", Uri.parse((String)("smsto:" + string)));
        string.putExtra("sms_body", string2);
        if (string.resolveActivity(this.form.getPackageManager()) != null) {
            this.form.registerForActivityResult(this, 0x54455854);
            this.form.startActivityForResult((Intent)string, 0x54455854);
        }
    }

    @SimpleFunction
    @UsesPermissions(value={"android.permission.SEND_SMS", "android.permission.READ_PHONE_STATE"})
    public void SendMessageDirect() {
        String string = this.message;
        String string2 = this.phoneNumber;
        Log.i((String)TAG, (String)("Sending message " + string + " to " + string2));
        string = this.phoneNumber;
        string2 = this.message;
        if (this.googleVoiceEnabled) {
            if (this.authToken == null) {
                Log.i((String)TAG, (String)("Need to get an authToken -- enqueing " + string + " " + string2));
                if (!this.pendingQueue.offer((Object)(string + ":::" + string2))) {
                    Toast.makeText((Context)activity, (CharSequence)"Pending message queue full. Can't send message", (int)0).show();
                    return;
                }
                if (this.pendingQueue.size() == 1) {
                    new /* invalid duplicate definition of identical inner class */.execute((Object[])new Void[0]);
                }
            } else {
                Log.i((String)TAG, (String)"Creating AsyncSendMessage");
                new /* invalid duplicate definition of identical inner class */.execute((Object[])new String[]{string, string2});
            }
        } else {
            Log.i((String)TAG, (String)"Sending via SMS");
            this.sendViaSms("SendMessage");
        }
    }

    @Override
    public void onDelete() {
        this.form.unregisterForActivityResult(this);
    }

    public void onInitialize() {
        Log.i((String)TAG, (String)"onInitialize()");
        this.isInitialized = true;
        isRunning = true;
        this.processCachedMessages();
        ((NotificationManager)activity.getSystemService("notification")).cancel(8647);
    }

    @Override
    public void onPause() {
        Log.i((String)TAG, (String)"onPause()");
        isRunning = false;
    }

    @Override
    public void onResume() {
        Log.i((String)TAG, (String)"onResume()");
        isRunning = true;
        if (this.isInitialized) {
            this.processCachedMessages();
            ((NotificationManager)activity.getSystemService("notification")).cancel(8647);
        }
    }

    @Override
    public void onStop() {
        SharedPreferences.Editor editor = activity.getSharedPreferences(PREF_FILE, 0).edit();
        editor.putInt(PREF_RCVENABLED, receivingState.toUnderlyingValue().intValue());
        editor.putBoolean(PREF_GVENABLED, this.googleVoiceEnabled);
        editor.commit();
    }

    @Override
    public void resultReturned(int n, int n2, Intent object2) {
        if (n == 0x54455854) {
            Form form = this.form;
            object2 = object2 == null ? "" : object2.getStringExtra("sms_body");
            super.handleSentMessage((Context)form, null, n2, (String)object2);
            this.form.unregisterForActivityResult((ActivityResultListener)this);
        }
    }
}

