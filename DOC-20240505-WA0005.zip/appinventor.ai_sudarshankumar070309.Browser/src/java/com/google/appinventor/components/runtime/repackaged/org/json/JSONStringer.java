/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONWriter;
import java.io.StringWriter;
import java.io.Writer;

public class JSONStringer
extends JSONWriter {
    public JSONStringer() {
        super((Writer)new StringWriter());
    }

    public String toString() {
        String string = this.mode == 'd' ? this.writer.toString() : null;
        return string;
    }
}

