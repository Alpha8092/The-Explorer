/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@DesignerComponent(category=ComponentCategory.SENSORS, description="<p>Non-visible component that can measure angular velocity in three dimensions in units of degrees per second.</p><p>In order to function, the component must have its <code>Enabled</code> property set to True, and the device must have a gyroscope sensor.</p>", iconName="images/gyroscopesensor.png", nonVisible=true, version=1)
@SimpleObject
public class GyroscopeSensor
extends AndroidNonvisibleComponent
implements SensorEventListener,
Deleteable,
OnPauseListener,
OnResumeListener,
RealTimeDataSource<String, Float> {
    private Set<DataSourceChangeListener> dataSourceObservers = new HashSet();
    private boolean enabled;
    private final Sensor gyroSensor;
    private boolean listening;
    private final SensorManager sensorManager;
    private float xAngularVelocity;
    private float yAngularVelocity;
    private float zAngularVelocity;

    public GyroscopeSensor(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        componentContainer = (SensorManager)this.form.getSystemService("sensor");
        this.sensorManager = componentContainer;
        this.gyroSensor = componentContainer.getDefaultSensor(4);
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        this.Enabled(true);
    }

    private void startListening() {
        if (!this.listening) {
            this.sensorManager.registerListener((SensorEventListener)this, this.gyroSensor, 0);
            this.listening = true;
        }
    }

    private void stopListening() {
        if (this.listening) {
            this.sensorManager.unregisterListener((SensorEventListener)this);
            this.listening = false;
            this.xAngularVelocity = 0.0f;
            this.yAngularVelocity = 0.0f;
            this.zAngularVelocity = 0.0f;
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates whether a gyroscope sensor is available.")
    public boolean Available() {
        boolean bl = this.sensorManager.getSensorList(4).size() > 0;
        return bl;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(description="If enabled, then sensor events will be generated and XAngularVelocity, YAngularVelocity, and ZAngularVelocity properties will have meaningful values.")
    public void Enabled(boolean bl) {
        if (this.enabled != bl) {
            this.enabled = bl;
            if (bl) {
                super.startListening();
            } else {
                super.stopListening();
            }
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Enabled() {
        return this.enabled;
    }

    @SimpleEvent(description="Indicates that the gyroscope sensor data has changed. The timestamp parameter is the time in nanoseconds at which the event occurred.")
    public void GyroscopeChanged(float f, float f2, float f3, long l) {
        EventDispatcher.dispatchEvent((Component)this, "GyroscopeChanged", Float.valueOf((float)f), Float.valueOf((float)f2), Float.valueOf((float)f3), l);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The angular velocity around the X axis, in degrees per second.")
    public float XAngularVelocity() {
        return this.xAngularVelocity;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The angular velocity around the Y axis, in degrees per second.")
    public float YAngularVelocity() {
        return this.yAngularVelocity;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The angular velocity around the Z axis, in degrees per second.")
    public float ZAngularVelocity() {
        return this.zAngularVelocity;
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Float getDataValue(String string) {
        int n;
        block10: {
            switch (string.hashCode()) {
                case 90: {
                    if (!string.equals((Object)"Z")) break;
                    n = 2;
                    break block10;
                }
                case 89: {
                    if (!string.equals((Object)"Y")) break;
                    n = 1;
                    break block10;
                }
                case 88: {
                    if (!string.equals((Object)"X")) break;
                    n = 0;
                    break block10;
                }
            }
            n = -1;
        }
        switch (n) {
            default: {
                return Float.valueOf((float)0.0f);
            }
            case 2: {
                return Float.valueOf((float)this.zAngularVelocity);
            }
            case 1: {
                return Float.valueOf((float)this.yAngularVelocity);
            }
            case 0: 
        }
        return Float.valueOf((float)this.xAngularVelocity);
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    @Override
    public void onDelete() {
        this.stopListening();
    }

    @Override
    public void onPause() {
        this.stopListening();
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.startListening();
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.enabled) {
            this.xAngularVelocity = (float)Math.toDegrees((double)sensorEvent.values[0]);
            this.yAngularVelocity = (float)Math.toDegrees((double)sensorEvent.values[1]);
            this.zAngularVelocity = (float)Math.toDegrees((double)sensorEvent.values[2]);
            this.notifyDataObservers("X", (Object)Float.valueOf((float)this.xAngularVelocity));
            this.notifyDataObservers("Y", (Object)Float.valueOf((float)this.yAngularVelocity));
            this.notifyDataObservers("Z", (Object)Float.valueOf((float)this.zAngularVelocity));
            this.GyroscopeChanged(this.xAngularVelocity, this.yAngularVelocity, this.zAngularVelocity, sensorEvent.timestamp);
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }
}

