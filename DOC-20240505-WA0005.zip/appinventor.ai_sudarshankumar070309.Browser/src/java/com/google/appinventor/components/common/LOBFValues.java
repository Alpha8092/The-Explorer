/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.common;

import com.google.appinventor.components.common.Default;
import com.google.appinventor.components.common.OptionList;
import java.util.HashMap;
import java.util.Map;

public final class LOBFValues
extends Enum<LOBFValues>
implements OptionList<String> {
    private static final LOBFValues[] $VALUES;
    public static final /* enum */ LOBFValues AllValues;
    public static final /* enum */ LOBFValues CorrCoef;
    public static final /* enum */ LOBFValues ExponentialBase;
    public static final /* enum */ LOBFValues ExponentialCoefficient;
    public static final /* enum */ LOBFValues LinearCoefficient;
    public static final /* enum */ LOBFValues LogarithmCoefficient;
    public static final /* enum */ LOBFValues LogarithmConstant;
    public static final /* enum */ LOBFValues Predictions;
    public static final /* enum */ LOBFValues QuadraticCoefficient;
    public static final /* enum */ LOBFValues RSquared;
    @Default
    public static final /* enum */ LOBFValues Slope;
    public static final /* enum */ LOBFValues XIntercepts;
    public static final /* enum */ LOBFValues Yintercept;
    private static final Map<String, LOBFValues> lookup;
    private final String lobfValues;

    static {
        LOBFValues lOBFValues;
        LOBFValues lOBFValues2;
        LOBFValues lOBFValues3;
        LOBFValues lOBFValues4;
        LOBFValues lOBFValues5;
        LOBFValues lOBFValues6;
        LOBFValues lOBFValues7;
        LOBFValues lOBFValues82;
        LOBFValues lOBFValues9;
        LOBFValues lOBFValues10;
        LOBFValues lOBFValues11;
        LOBFValues lOBFValues12;
        CorrCoef = lOBFValues12 = new LOBFValues("correlation coefficient");
        Slope = lOBFValues11 = new LOBFValues("slope");
        Yintercept = lOBFValues10 = new LOBFValues("Yintercept");
        LOBFValues[] lOBFValuesArray = new LOBFValues("predictions");
        Predictions = lOBFValuesArray;
        AllValues = lOBFValues9 = new LOBFValues("all values");
        QuadraticCoefficient = lOBFValues82 = new LOBFValues("Quadratic Coefficient");
        LinearCoefficient = lOBFValues7 = new LOBFValues("slope");
        ExponentialCoefficient = lOBFValues6 = new LOBFValues("a");
        ExponentialBase = lOBFValues5 = new LOBFValues("b");
        LogarithmCoefficient = lOBFValues4 = new LOBFValues("b");
        LogarithmConstant = lOBFValues3 = new LOBFValues("a");
        XIntercepts = lOBFValues2 = new LOBFValues("Xintercepts");
        RSquared = lOBFValues = new LOBFValues("r^2");
        $VALUES = new LOBFValues[]{lOBFValues12, lOBFValues11, lOBFValues10, lOBFValuesArray, lOBFValues9, lOBFValues82, lOBFValues7, lOBFValues6, lOBFValues5, lOBFValues4, lOBFValues3, lOBFValues2, lOBFValues};
        lookup = new HashMap();
        for (LOBFValues lOBFValues82 : LOBFValues.values()) {
            lookup.put(lOBFValues82.toUnderlyingValue(), (Object)lOBFValues82);
        }
    }

    private LOBFValues(String string3) {
        this.lobfValues = string3;
    }

    public static LOBFValues fromUnderlyingValue(String string2) {
        return (LOBFValues)lookup.get((Object)string2);
    }

    public static LOBFValues valueOf(String string2) {
        return (LOBFValues)Enum.valueOf(LOBFValues.class, (String)string2);
    }

    public static LOBFValues[] values() {
        return (LOBFValues[])$VALUES.clone();
    }

    @Override
    public String toUnderlyingValue() {
        return this.lobfValues;
    }
}

