/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.MenuItem
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.view.MenuItem;

public interface OnOptionsItemSelectedListener {
    public boolean onOptionsItemSelected(MenuItem var1);
}

