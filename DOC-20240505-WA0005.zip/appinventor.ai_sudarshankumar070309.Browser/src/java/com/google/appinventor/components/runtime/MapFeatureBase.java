/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.Map
 *  com.google.appinventor.components.runtime.MapFeatureBase$1
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.MapFactory$HasStroke
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  org.locationtech.jts.geom.Geometry
 *  org.locationtech.jts.geom.Point
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.Map;
import com.google.appinventor.components.runtime.MapFeatureBase;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import com.google.appinventor.components.runtime.util.YailList;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.Point;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

@SimpleObject
public abstract class MapFeatureBase
implements MapFactory.MapFeature,
MapFactory.HasStroke {
    private GeoPoint centroid = null;
    protected MapFactory.MapFeatureContainer container = null;
    private String description = "";
    private final MapFactory.MapFeatureVisitor<Double> distanceComputation;
    private MapFactory.MapFeatureVisitor<Double> distanceToPoint;
    private boolean draggable = false;
    private Geometry geometry;
    private boolean infobox = false;
    protected Map map = null;
    private int strokeColor = -16777216;
    private float strokeOpacity = 1.0f;
    private int strokeWidth = 1;
    private String title = "";
    private boolean visible = true;

    protected MapFeatureBase(MapFactory.MapFeatureContainer mapFeatureContainer, MapFactory.MapFeatureVisitor<Double> mapFeatureVisitor) {
        this.distanceToPoint = new 1((MapFeatureBase)this);
        this.geometry = null;
        this.container = mapFeatureContainer;
        this.map = mapFeatureContainer.getMap();
        this.distanceComputation = mapFeatureVisitor;
        this.Description("");
        this.Draggable(false);
        this.EnableInfobox(false);
        this.StrokeColor(-16777216);
        this.StrokeOpacity(1.0f);
        this.StrokeWidth(1);
        this.Title("");
        this.Visible(true);
    }

    public YailList Centroid() {
        return GeometryUtil.asYailList((IGeoPoint)this.getCentroid());
    }

    @Override
    @SimpleEvent(description="The user clicked on the %type%.")
    public void Click() {
        EventDispatcher.dispatchEvent(this, "Click", new Object[0]);
        this.container.FeatureClick((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The description displayed in the info window that appears when the user clicks on the %type%.")
    public String Description() {
        return this.description;
    }

    @Override
    @DesignerProperty
    @SimpleProperty
    public void Description(String string) {
        this.description = string;
        this.map.getController().updateFeatureText((MapFactory.MapFeature)this);
    }

    @SimpleFunction(description="Compute the distance, in meters, between two map features.")
    public double DistanceToFeature(MapFactory.MapFeature mapFeature, boolean bl) {
        double d = mapFeature == null ? -1.0 : mapFeature.accept(this.distanceComputation, this, bl);
        return d;
    }

    @SimpleFunction(description="Compute the distance, in meters, between a %type% and a latitude, longitude point.")
    public double DistanceToPoint(double d, double d2, boolean bl) {
        return (Double)this.accept(this.distanceToPoint, new Object[]{new GeoPoint(d, d2), bl});
    }

    @Override
    @SimpleEvent(description="The user dragged the %type%.")
    public void Drag() {
        EventDispatcher.dispatchEvent(this, "Drag", new Object[0]);
        this.container.FeatureDrag((MapFactory.MapFeature)this);
    }

    @Override
    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void Draggable(boolean bl) {
        this.draggable = bl;
        this.map.getController().updateFeatureDraggable((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleProperty(description="The Draggable property is used to set whether or not the user can drag the %type% by long-pressing and then dragging the %type% to a new location.")
    public boolean Draggable() {
        return this.draggable;
    }

    @Override
    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void EnableInfobox(boolean bl) {
        this.infobox = bl;
        this.map.getController().updateFeatureText((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Enable or disable the infobox window display when the user taps the %type%.")
    public boolean EnableInfobox() {
        return this.infobox;
    }

    @Override
    @SimpleFunction(description="Hide the infobox if it is shown. If the infobox is not visible this function has no effect.")
    public void HideInfobox() {
        this.map.getController().hideInfobox((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleEvent(description="The user long-pressed on the %type%. This event will only trigger if Draggable is false.")
    public void LongClick() {
        EventDispatcher.dispatchEvent(this, "LongClick", new Object[0]);
        this.container.FeatureLongClick((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleFunction(description="Show the infobox for the %type%. This will show the infobox even if EnableInfobox is set to false.")
    public void ShowInfobox() {
        this.map.getController().showInfobox((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleEvent(description="The user started a drag operation.")
    public void StartDrag() {
        EventDispatcher.dispatchEvent(this, "StartDrag", new Object[0]);
        this.container.FeatureStartDrag((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleEvent(description="The user stopped a drag operation.")
    public void StopDrag() {
        EventDispatcher.dispatchEvent(this, "StopDrag", new Object[0]);
        this.container.FeatureStopDrag((MapFactory.MapFeature)this);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The paint color used to outline the %type%.")
    public int StrokeColor() {
        return this.strokeColor;
    }

    @DesignerProperty(defaultValue="&HFF000000", editorType="color")
    @SimpleProperty
    public void StrokeColor(int n) {
        this.strokeColor = n;
        this.map.getController().updateFeatureStroke((MapFactory.HasStroke)this);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The opacity of the stroke used to outline the map feature.")
    public float StrokeOpacity() {
        return this.strokeOpacity;
    }

    @DesignerProperty(defaultValue="1.0", editorType="float")
    @SimpleProperty
    public void StrokeOpacity(float f) {
        this.strokeOpacity = f;
        this.strokeColor = this.strokeColor & 0xFFFFFF | Math.round((float)(255.0f * f)) << 24;
        this.map.getController().updateFeatureStroke((MapFactory.HasStroke)this);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The width of the stroke used to outline the %type%.")
    public int StrokeWidth() {
        return this.strokeWidth;
    }

    @DesignerProperty(defaultValue="1", editorType="integer")
    @SimpleProperty
    public void StrokeWidth(int n) {
        this.strokeWidth = n;
        this.map.getController().updateFeatureStroke((MapFactory.HasStroke)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The title displayed in the info window that appears when the user clicks on the %type%.")
    public String Title() {
        return this.title;
    }

    @Override
    @DesignerProperty
    @SimpleProperty
    public void Title(String string) {
        this.title = string;
        this.map.getController().updateFeatureText((MapFactory.MapFeature)this);
    }

    @Override
    @DesignerProperty(defaultValue="True", editorType="visibility")
    @SimpleProperty
    public void Visible(boolean bl) {
        if (this.visible == bl) {
            return;
        }
        this.visible = bl;
        if (bl) {
            this.map.getController().showFeature((MapFactory.MapFeature)this);
        } else {
            this.map.getController().hideFeature((MapFactory.MapFeature)this);
        }
        this.map.getView().invalidate();
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Specifies whether the %type% should be visible on the screen. Value is true if the component is showing and false if hidden.")
    public boolean Visible() {
        return this.visible;
    }

    protected final void clearGeometry() {
        MapFeatureBase mapFeatureBase = this;
        synchronized (mapFeatureBase) {
            this.centroid = null;
            this.geometry = null;
            return;
        }
    }

    protected abstract Geometry computeGeometry();

    @Override
    public final GeoPoint getCentroid() {
        MapFeatureBase mapFeatureBase = this;
        synchronized (mapFeatureBase) {
            if (this.centroid == null) {
                this.centroid = GeometryUtil.jtsPointToGeoPoint((Point)this.getGeometry().getCentroid());
            }
            GeoPoint geoPoint = this.centroid;
            return geoPoint;
        }
    }

    @Override
    public HandlesEventDispatching getDispatchDelegate() {
        return this.map.getDispatchDelegate();
    }

    @Override
    public final Geometry getGeometry() {
        MapFeatureBase mapFeatureBase = this;
        synchronized (mapFeatureBase) {
            if (this.geometry == null) {
                this.geometry = this.computeGeometry();
            }
            Geometry geometry = this.geometry;
            return geometry;
        }
    }

    @Override
    public void removeFromMap() {
        this.map.getController().removeFeature((MapFactory.MapFeature)this);
    }

    @Override
    public void setMap(MapFactory.MapFeatureContainer mapFeatureContainer) {
        this.map = mapFeatureContainer.getMap();
    }
}

