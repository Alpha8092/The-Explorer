/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.NxtMotorMode
 *  com.google.appinventor.components.common.NxtMotorPort
 *  com.google.appinventor.components.common.NxtRegulationMode
 *  com.google.appinventor.components.common.NxtRunState
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtMotorMode;
import com.google.appinventor.components.common.NxtMotorPort;
import com.google.appinventor.components.common.NxtRegulationMode;
import com.google.appinventor.components.common.NxtRunState;
import com.google.appinventor.components.runtime.BluetoothConnectionBase;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.LegoMindstormsNxtBase;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to a LEGO MINDSTORMS NXT robot, with functions that can move and turn the robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtDrive
extends LegoMindstormsNxtBase {
    private List<NxtMotorPort> driveMotorPorts;
    private String driveMotors;
    private boolean stopBeforeDisconnect;
    private double wheelDiameter;

    public NxtDrive(ComponentContainer componentContainer) {
        super(componentContainer, "NxtDrive");
        this.DriveMotors("CB");
        this.WheelDiameter(4.32f);
        this.StopBeforeDisconnect(true);
    }

    private void move(String string, int n, long l) {
        if (!this.checkBluetooth(string)) {
            return;
        }
        Iterator iterator = this.driveMotorPorts.iterator();
        while (iterator.hasNext()) {
            this.setOutputState(string, (NxtMotorPort)iterator.next(), n, NxtMotorMode.On, NxtRegulationMode.Speed, 0, NxtRunState.Running, l);
        }
    }

    private void turnIndefinitely(String string, int n, int n2, int n3) {
        if (!this.checkBluetooth(string)) {
            return;
        }
        this.setOutputState(string, (NxtMotorPort)this.driveMotorPorts.get(n2), n, NxtMotorMode.On, NxtRegulationMode.Speed, 0, NxtRunState.Running, 0L);
        this.setOutputState(string, (NxtMotorPort)this.driveMotorPorts.get(n3), -n, NxtMotorMode.On, NxtRegulationMode.Speed, 0, NxtRunState.Running, 0L);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The motor ports that are used for driving: the left wheel's motor port followed by the right wheel's motor port.", userVisible=false)
    public String DriveMotors() {
        return this.driveMotors;
    }

    @DesignerProperty(defaultValue="CB", editorType="string")
    @SimpleProperty
    public void DriveMotors(String string) {
        this.driveMotors = string;
        this.driveMotorPorts = new ArrayList();
        for (int i = 0; i < string.length(); ++i) {
            String string2 = String.valueOf((char)string.charAt(i));
            NxtMotorPort nxtMotorPort = NxtMotorPort.fromUnderlyingValue((String)string2);
            if (nxtMotorPort == null) {
                this.form.dispatchErrorOccurredEvent((Component)this, "DriveMotors", 407, string2);
                continue;
            }
            this.driveMotorPorts.add((Object)nxtMotorPort);
        }
    }

    @SimpleFunction(description="Move the robot backward the given distance, with the specified percentage of maximum power, by powering both drive motors backward.")
    public void MoveBackward(int n, double d) {
        long l = (long)(360.0 * d / (this.wheelDiameter * Math.PI));
        super.move("MoveBackward", -n, l);
    }

    @SimpleFunction(description="Move the robot backward indefinitely, with the specified percentage of maximum power, by powering both drive motors backward.")
    public void MoveBackwardIndefinitely(int n) {
        super.move("MoveBackwardIndefinitely", -n, 0L);
    }

    @SimpleFunction(description="Move the robot forward the given distance, with the specified percentage of maximum power, by powering both drive motors forward.")
    public void MoveForward(int n, double d) {
        super.move("MoveForward", n, (long)(360.0 * d / (this.wheelDiameter * Math.PI)));
    }

    @SimpleFunction(description="Move the robot forward indefinitely, with the specified percentage of maximum power, by powering both drive motors forward.")
    public void MoveForwardIndefinitely(int n) {
        super.move("MoveForwardIndefinitely", n, 0L);
    }

    @SimpleFunction(description="Stop the drive motors of the robot.")
    public void Stop() {
        if (!this.checkBluetooth("Stop")) {
            return;
        }
        Iterator iterator = this.driveMotorPorts.iterator();
        while (iterator.hasNext()) {
            this.setOutputState("Stop", (NxtMotorPort)iterator.next(), 0, NxtMotorMode.Brake, NxtRegulationMode.Disabled, 0, NxtRunState.Disabled, 0L);
        }
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void StopBeforeDisconnect(boolean bl) {
        this.stopBeforeDisconnect = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether to stop the drive motors before disconnecting.")
    public boolean StopBeforeDisconnect() {
        return this.stopBeforeDisconnect;
    }

    @SimpleFunction(description="Turn the robot clockwise indefinitely, with the specified percentage of maximum power, by powering the left drive motor forward and the right drive motor backward.")
    public void TurnClockwiseIndefinitely(int n) {
        int n2 = this.driveMotorPorts.size();
        if (n2 >= 2) {
            super.turnIndefinitely("TurnClockwiseIndefinitely", n, 0, n2 - 1);
        }
    }

    @SimpleFunction(description="Turn the robot counterclockwise indefinitely, with the specified percentage of maximum power, by powering the right drive motor forward and the left drive motor backward.")
    public void TurnCounterClockwiseIndefinitely(int n) {
        int n2 = this.driveMotorPorts.size();
        if (n2 >= 2) {
            super.turnIndefinitely("TurnCounterClockwiseIndefinitely", n, n2 - 1, 0);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The diameter of the wheels used for driving.", userVisible=false)
    public float WheelDiameter() {
        return (float)this.wheelDiameter;
    }

    @DesignerProperty(defaultValue="4.32", editorType="float")
    @SimpleProperty
    public void WheelDiameter(float f) {
        this.wheelDiameter = f;
    }

    @Override
    public void beforeDisconnect(BluetoothConnectionBase bluetoothConnectionBase) {
        if (this.stopBeforeDisconnect) {
            bluetoothConnectionBase = this.driveMotorPorts.iterator();
            while (bluetoothConnectionBase.hasNext()) {
                this.setOutputState("Disconnect", (NxtMotorPort)bluetoothConnectionBase.next(), 0, NxtMotorMode.Brake, NxtRegulationMode.Disabled, 0, NxtRunState.Disabled, 0L);
            }
        }
    }
}

