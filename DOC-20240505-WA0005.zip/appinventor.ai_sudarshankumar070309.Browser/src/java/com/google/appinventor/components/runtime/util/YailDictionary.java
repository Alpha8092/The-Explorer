/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.YailDictionary$1
 *  com.google.appinventor.components.runtime.util.YailDictionary$KeyTransformer
 *  com.google.appinventor.components.runtime.util.YailList
 *  com.google.appinventor.components.runtime.util.YailObject
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  org.json.JSONException
 */
package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.errors.DispatchableError;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.YailDictionary;
import com.google.appinventor.components.runtime.util.YailList;
import com.google.appinventor.components.runtime.util.YailObject;
import gnu.lists.FString;
import gnu.lists.LList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

public class YailDictionary
extends LinkedHashMap<Object, Object>
implements YailObject<YailList> {
    public static final Object ALL = new 1();
    private static final KeyTransformer IDENTITY = new KeyTransformer(){

        public Object transform(Object object2) {
            return object2;
        }
    };
    private static final String LOG_TAG = "YailDictionary";
    private final KeyTransformer keyTransformer;

    public YailDictionary() {
        this.keyTransformer = IDENTITY;
    }

    public YailDictionary(Map<?, ?> map) {
        super(map, IDENTITY);
    }

    public YailDictionary(Map<?, ?> entry2, KeyTransformer keyTransformer) {
        this.keyTransformer = keyTransformer;
        for (Map.Entry entry2 : entry2.entrySet()) {
            this.put(entry2.getKey(), entry2.getValue());
        }
    }

    private static Object alistLookup(YailList object2, Object object3) {
        Iterator iterator = ((LList)object2.getCdr()).iterator();
        while (iterator.hasNext()) {
            object2 = iterator.next();
            if (object2 instanceof YailList) {
                if (!object2.getObject(0).equals(object3)) continue;
                return object2.getObject(1);
            }
            return null;
        }
        return null;
    }

    public static YailDictionary alistToDict(YailList yailList) {
        YailDictionary yailDictionary = new YailDictionary();
        yailList = ((LList)yailList.getCdr()).iterator();
        while (yailList.hasNext()) {
            Object object2 = (YailList)yailList.next();
            Object object3 = object2.getObject(0);
            if ((object2 = object2.getObject(1)) instanceof YailList && YailDictionary.isAlist(object2).booleanValue()) {
                yailDictionary.put(object3, (Object)YailDictionary.alistToDict(object2));
                continue;
            }
            if (object2 instanceof YailList) {
                yailDictionary.put(object3, YailDictionary.checkList(object2));
                continue;
            }
            yailDictionary.put(object3, object2);
        }
        return yailDictionary;
    }

    private static Collection<Object> allOf(Object object2) {
        if (object2 instanceof Map) {
            return YailDictionary.allOf((Map<Object, Object>)((Map)object2));
        }
        if (object2 instanceof List) {
            return YailDictionary.allOf((List<Object>)((List)object2));
        }
        return Collections.emptyList();
    }

    private static Collection<Object> allOf(List<Object> iterator) {
        if (iterator instanceof YailList) {
            if (YailDictionary.isAlist((YailList)iterator).booleanValue()) {
                ArrayList arrayList = new ArrayList();
                iterator = ((LList)((YailList)iterator).getCdr()).iterator();
                while (iterator.hasNext()) {
                    arrayList.add(((YailList)iterator.next()).getObject(1));
                }
                return arrayList;
            }
            return (Collection)((YailList)iterator).getCdr();
        }
        return iterator;
    }

    private static Collection<Object> allOf(Map<Object, Object> map) {
        return map.values();
    }

    private static YailList checkList(YailList yailList) {
        Object[] objectArray = new Object[yailList.size()];
        int n = 0;
        Iterator iterator = yailList.iterator();
        iterator.next();
        boolean bl = false;
        while (iterator.hasNext()) {
            Object object2 = iterator.next();
            if (object2 instanceof YailList) {
                if (YailDictionary.isAlist((YailList)object2).booleanValue()) {
                    objectArray[n] = YailDictionary.alistToDict((YailList)object2);
                    bl = true;
                } else {
                    objectArray[n] = YailDictionary.checkList((YailList)object2);
                    if (objectArray[n] != object2) {
                        bl = true;
                    }
                }
            } else {
                objectArray[n] = object2;
            }
            ++n;
        }
        if (bl) {
            return YailList.makeList((Object[])objectArray);
        }
        return yailList;
    }

    private static YailList checkListForDicts(YailList yailList) {
        ArrayList arrayList = new ArrayList();
        yailList = ((LList)yailList.getCdr()).iterator();
        while (yailList.hasNext()) {
            Object object2 = yailList.next();
            if (object2 instanceof YailDictionary) {
                arrayList.add((Object)YailDictionary.dictToAlist((YailDictionary)((Object)object2)));
                continue;
            }
            if (object2 instanceof YailList) {
                arrayList.add((Object)YailDictionary.checkListForDicts((YailList)object2));
                continue;
            }
            arrayList.add(object2);
        }
        return YailList.makeList((List)arrayList);
    }

    public static YailList dictToAlist(YailDictionary yailDictionary) {
        ArrayList arrayList = new ArrayList();
        for (Map.Entry entry : yailDictionary.entrySet()) {
            arrayList.add((Object)YailList.makeList((Object[])new Object[]{entry.getKey(), entry.getValue()}));
        }
        return YailList.makeList((List)arrayList);
    }

    private Object getFromList(List<?> object2, Object object3) {
        int n = object2 instanceof YailList ^ 1;
        try {
            if (object3 instanceof FString) {
                return object2.get(Integer.parseInt((String)object3.toString()) - n);
            }
            if (object3 instanceof String) {
                return object2.get(Integer.parseInt((String)((String)object3)) - n);
            }
            if (object3 instanceof Number) {
                object2 = object2.get(((Number)object3).intValue() - n);
                return object2;
            }
            return null;
        }
        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            Log.w((String)LOG_TAG, (String)("Requested too large of an index: " + object3), (Throwable)indexOutOfBoundsException);
            throw new YailRuntimeError("Requested too large of an index: " + object3, "IndexOutOfBoundsException");
        }
        catch (NumberFormatException numberFormatException) {
            Log.w((String)LOG_TAG, (String)("Unable to parse key as integer: " + object3), (Throwable)numberFormatException);
            throw new YailRuntimeError("Unable to parse key as integer: " + object3, "NumberParseException");
        }
    }

    private static Boolean isAlist(YailList yailList) {
        boolean bl = false;
        yailList = ((LList)yailList.getCdr()).iterator();
        while (yailList.hasNext()) {
            Object object2 = yailList.next();
            if (!(object2 instanceof YailList)) {
                return false;
            }
            if (((YailList)object2).size() != 2) {
                return false;
            }
            bl = true;
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static int keyToIndex(List<?> list, Object object2) {
        int n;
        int n2 = list instanceof YailList ^ 1;
        if (object2 instanceof Number) {
            n = ((Number)object2).intValue();
        } else {
            try {
                n = Integer.parseInt((String)object2.toString());
            }
            catch (NumberFormatException numberFormatException) {
                throw new DispatchableError(3202, object2.toString());
            }
        }
        if ((n -= n2) >= 0 && n < list.size() + 1 - n2) {
            return n;
        }
        try {
            object2 = new DispatchableError(3201, n + n2, JsonUtil.getJsonRepresentation(list));
            throw object2;
        }
        catch (JSONException jSONException) {
            Log.e((String)LOG_TAG, (String)"Unable to serialize object as JSON", (Throwable)jSONException);
            throw new YailRuntimeError(jSONException.getMessage(), "JSON Error");
        }
    }

    private Object lookupTargetForKey(Object object2, Object object3) {
        if (object2 instanceof YailDictionary) {
            return ((YailDictionary)((Object)object2)).get(object3);
        }
        if (object2 instanceof List) {
            return ((List)object2).get(YailDictionary.keyToIndex((List)object2, object3));
        }
        object2 = object2 == null ? "null" : object2.getClass().getSimpleName();
        throw new DispatchableError(3203, object2);
    }

    public static YailDictionary makeDictionary() {
        return new YailDictionary();
    }

    public static YailDictionary makeDictionary(List<YailList> yailList2) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (YailList yailList2 : yailList2) {
            linkedHashMap.put(yailList2.getObject(0), yailList2.getObject(1));
        }
        return new YailDictionary((Map<?, ?>)linkedHashMap);
    }

    public static YailDictionary makeDictionary(Map<Object, Object> map) {
        return new YailDictionary(map);
    }

    public static YailDictionary makeDictionary(Object ... object2) {
        if (((Object[])object2).length % 2 != 1) {
            YailDictionary yailDictionary = new YailDictionary();
            for (int i = 0; i < ((Object[])object2).length; i += 2) {
                yailDictionary.put(object2[i], object2[i + 1]);
            }
            return yailDictionary;
        }
        object2 = new IllegalArgumentException("Expected an even number of key-value entries.");
        throw object2;
    }

    public static <T> List<Object> walkKeyPath(YailObject<?> yailObject, List<T> list) {
        return YailDictionary.walkKeyPath(yailObject, list, (List<Object>)new ArrayList());
    }

    private static <T> List<Object> walkKeyPath(Object object2, List<T> list, List<Object> list2) {
        block8: {
            Object object3;
            block10: {
                block9: {
                    block7: {
                        if (list.isEmpty()) {
                            if (object2 != null) {
                                list2.add(object2);
                            }
                            return list2;
                        }
                        if (object2 == null) {
                            return list2;
                        }
                        object3 = list.get(0);
                        list = list.subList(1, list.size());
                        if (object3 != ALL) break block7;
                        object2 = YailDictionary.allOf(object2).iterator();
                        while (object2.hasNext()) {
                            YailDictionary.walkKeyPath(object2.next(), list, list2);
                        }
                        break block8;
                    }
                    if (!(object2 instanceof Map)) break block9;
                    YailDictionary.walkKeyPath(((Map)object2).get(object3), list, list2);
                    break block8;
                }
                if (!(object2 instanceof YailList) || !YailDictionary.isAlist((YailList)object2).booleanValue()) break block10;
                if ((object2 = YailDictionary.alistLookup((YailList)object2, object3)) == null) break block8;
                YailDictionary.walkKeyPath(object2, list, list2);
                break block8;
            }
            if (object2 instanceof List) {
                int n = YailDictionary.keyToIndex((List)object2, object3);
                try {
                    YailDictionary.walkKeyPath(((List)object2).get(n), list, list2);
                }
                catch (Exception exception) {
                }
            }
        }
        return list2;
    }

    public boolean containsKey(Object object2) {
        Object object3 = object2;
        if (object2 instanceof FString) {
            object3 = object2.toString();
        }
        return super.containsKey(this.keyTransformer.transform(object3));
    }

    public boolean containsValue(Object object2) {
        if (object2 instanceof FString) {
            return super.containsValue((Object)object2.toString());
        }
        return super.containsValue(object2);
    }

    public Object get(Object object2) {
        Object object3 = object2;
        if (object2 instanceof FString) {
            object3 = object2.toString();
        }
        return super.get(this.keyTransformer.transform(object3));
    }

    public Object getObject(int n) {
        if (n >= 0 && n < this.size()) {
            for (Map.Entry entry : this.entrySet()) {
                if (n == 0) {
                    return Lists.newArrayList(entry.getKey(), entry.getValue());
                }
                --n;
            }
            throw new IndexOutOfBoundsException();
        }
        IndexOutOfBoundsException indexOutOfBoundsException = new IndexOutOfBoundsException();
        throw indexOutOfBoundsException;
    }

    public Object getObjectAtKeyPath(List<?> object2) {
        Object object3 = this;
        Iterator iterator = object2.iterator();
        object2 = object3;
        while (iterator.hasNext()) {
            object3 = iterator.next();
            if (object2 instanceof Map) {
                object2 = ((Map)object2).get(object3);
                continue;
            }
            if (object2 instanceof YailList && YailDictionary.isAlist((YailList)object2).booleanValue()) {
                object2 = YailDictionary.alistToDict((YailList)object2).get(object3);
                continue;
            }
            if (object2 instanceof List) {
                object2 = super.getFromList((List<?>)object2, object3);
                continue;
            }
            return null;
        }
        return object2;
    }

    public Iterator<YailList> iterator() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public Object put(Object object2, Object object3) {
        Object object4 = object2;
        if (object2 instanceof FString) {
            object4 = object2.toString();
        }
        object4 = this.keyTransformer.transform(object4);
        object2 = object3;
        if (object3 instanceof FString) {
            object2 = object3.toString();
        }
        return super.put(object4, object2);
    }

    public Object remove(Object object2) {
        Object object3 = object2;
        if (object2 instanceof FString) {
            object3 = object2.toString();
        }
        return super.remove(this.keyTransformer.transform(object3));
    }

    public void setPair(YailList yailList) {
        this.put(yailList.getObject(0), yailList.getObject(1));
    }

    public void setValueForKeyPath(List<?> object2, Object object3) {
        Object object4 = this;
        Iterator iterator = object2.iterator();
        if (object2.isEmpty()) {
            return;
        }
        while (iterator.hasNext()) {
            object2 = iterator.next();
            if (iterator.hasNext()) {
                object4 = super.lookupTargetForKey(object4, object2);
                continue;
            }
            if (object4 instanceof YailDictionary) {
                ((YailDictionary)((Object)object4)).put(object2, object3);
                continue;
            }
            if (object4 instanceof YailList) {
                ((LList)object4).getIterator(YailDictionary.keyToIndex((List)object4, object2)).set(object3);
                continue;
            }
            if (object4 instanceof List) {
                ((List)object4).set(YailDictionary.keyToIndex((List)object4, object2), object3);
                continue;
            }
            throw new DispatchableError(3203);
        }
    }

    public String toString() {
        try {
            String string = JsonUtil.getJsonRepresentation((Object)((Object)this));
            return string;
        }
        catch (JSONException jSONException) {
            throw new YailRuntimeError(jSONException.getMessage(), "JSON Error");
        }
    }
}

