/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.util.Log
 *  com.google.api.client.googleapis.auth.oauth2.GoogleCredential
 *  com.google.api.client.http.HttpRequestInitializer
 *  com.google.api.client.http.HttpTransport
 *  com.google.api.client.http.javanet.NetHttpTransport
 *  com.google.api.client.json.JsonFactory
 *  com.google.api.client.json.jackson2.JacksonFactory
 *  com.google.api.services.sheets.v4.Sheets
 *  com.google.api.services.sheets.v4.Sheets$Builder
 *  com.google.api.services.sheets.v4.Sheets$Spreadsheets$Get
 *  com.google.api.services.sheets.v4.Sheets$Spreadsheets$Values
 *  com.google.api.services.sheets.v4.model.AddSheetRequest
 *  com.google.api.services.sheets.v4.model.AppendValuesResponse
 *  com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest
 *  com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse
 *  com.google.api.services.sheets.v4.model.ClearValuesRequest
 *  com.google.api.services.sheets.v4.model.ClearValuesResponse
 *  com.google.api.services.sheets.v4.model.DeleteDimensionRequest
 *  com.google.api.services.sheets.v4.model.DeleteSheetRequest
 *  com.google.api.services.sheets.v4.model.DimensionRange
 *  com.google.api.services.sheets.v4.model.Request
 *  com.google.api.services.sheets.v4.model.Response
 *  com.google.api.services.sheets.v4.model.Sheet
 *  com.google.api.services.sheets.v4.model.SheetProperties
 *  com.google.api.services.sheets.v4.model.Spreadsheet
 *  com.google.api.services.sheets.v4.model.UpdateValuesResponse
 *  com.google.api.services.sheets.v4.model.ValueRange
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.ObservableDataSource
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.ChartDataSourceUtil
 *  com.google.appinventor.components.runtime.util.CsvUtil
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  gnu.math.DFloNum
 *  gnu.math.IntNum
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.UnsupportedEncodingException
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.net.HttpURLConnection
 *  java.net.SocketTimeoutException
 *  java.net.URL
 *  java.net.URLEncoder
 *  java.security.GeneralSecurityException
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.FutureTask
 *  java.util.regex.Pattern
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.util.Log;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.AddSheetRequest;
import com.google.api.services.sheets.v4.model.AppendValuesResponse;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse;
import com.google.api.services.sheets.v4.model.ClearValuesRequest;
import com.google.api.services.sheets.v4.model.ClearValuesResponse;
import com.google.api.services.sheets.v4.model.DeleteDimensionRequest;
import com.google.api.services.sheets.v4.model.DeleteSheetRequest;
import com.google.api.services.sheets.v4.model.DimensionRange;
import com.google.api.services.sheets.v4.model.Request;
import com.google.api.services.sheets.v4.model.Response;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesActivities;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.ActivityElement;
import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSource;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.ObservableDataSource;
import com.google.appinventor.components.runtime.Spreadsheet;
import com.google.appinventor.components.runtime.WebViewActivity;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.ChartDataSourceUtil;
import com.google.appinventor.components.runtime.util.CsvUtil;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.YailList;
import gnu.lists.LList;
import gnu.math.DFloNum;
import gnu.math.IntNum;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.regex.Pattern;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.STORAGE, description="Spreadsheet is a non-visible component for storing and receiving data from a Spreadsheet document using the Google Sheets API. <p>In order to utilize this component, one must first have a Google Developer Account. Then, one must create a new project under that Google Developer Account, enable the Google Sheets API on that project, and finally create a Service Account for the Sheets API.</p><p>Instructions on how to create the Service Account, as well as where to find other relevant information for using the Spreadsheet Component, can be found <a href='/reference/other/googlesheets-api-setup.html'>here</a>.</p>", iconName="images/spreadsheet.png", nonVisible=true, version=3)
@SimpleObject
@UsesActivities(activities={@ActivityElement(configChanges="orientation|keyboardHidden", intentFilters={@IntentFilterElement(actionElements={@ActionElement(name="android.intent.action.MAIN")})}, name="com.google.appinventor.components.runtime.WebViewActivity", screenOrientation="behind")})
@UsesLibraries(value={"googlesheets.jar", "jackson-core.jar", "google-api-client.jar", "google-api-client-jackson2.jar", "google-http-client.jar", "google-http-client-jackson2.jar", "google-oauth-client.jar", "google-oauth-client-jetty.jar", "grpc-context.jar", "opencensus.jar", "opencensus-contrib-http-util.jar", "guava.jar", "jetty.jar", "jetty-util.jar"})
@UsesPermissions(value={"android.permission.INTERNET", "android.permission.ACCOUNT_MANAGER", "android.permission.GET_ACCOUNTS", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"})
public class Spreadsheet
extends AndroidNonvisibleComponent
implements Component,
ObservableDataSource<YailList, Future<YailList>> {
    private static final Pattern INTEGER = Pattern.compile((String)"^[0-9]+$");
    private static final String LOG_TAG = "SPREADSHEET";
    private static final String WEBVIEW_ACTIVITY_CLASS = WebViewActivity.class.getName();
    private String accessToken = null;
    private final Activity activity;
    private String apiKey;
    private String applicationName = "App Inventor";
    private File cachedCredentialsFile = null;
    private YailList columns = new YailList();
    private final ComponentContainer container;
    private String credentialsPath;
    private FutureTask<Void> lastTask = null;
    private final Set<DataSourceChangeListener> observers = new HashSet();
    private int requestCode;
    private final Map<String, Integer> sheetIdMap = new HashMap();
    private Sheets sheetsService = null;
    private String spreadsheetID = "";

    static /* bridge */ /* synthetic */ Activity -$$Nest$fgetactivity(Spreadsheet spreadsheet) {
        return spreadsheet.activity;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetcredentialsPath(Spreadsheet spreadsheet) {
        return spreadsheet.credentialsPath;
    }

    static /* bridge */ /* synthetic */ Set -$$Nest$fgetobservers(Spreadsheet spreadsheet) {
        return spreadsheet.observers;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetspreadsheetID(Spreadsheet spreadsheet) {
        return spreadsheet.spreadsheetID;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$mgetColString(Spreadsheet spreadsheet, int n) {
        return spreadsheet.getColString(n);
    }

    static /* bridge */ /* synthetic */ int -$$Nest$mgetSheetID(Spreadsheet spreadsheet, Sheets sheets, String string) {
        return spreadsheet.getSheetID(sheets, string);
    }

    static /* bridge */ /* synthetic */ Sheets -$$Nest$mgetSheetsService(Spreadsheet spreadsheet) {
        return spreadsheet.getSheetsService();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mremoveSheetID(Spreadsheet spreadsheet, String string) {
        spreadsheet.removeSheetID(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mupdateColumns(Spreadsheet spreadsheet, YailList yailList) {
        spreadsheet.updateColumns(yailList);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mupdateSheetID(Spreadsheet spreadsheet, String string, int n) {
        spreadsheet.updateSheetID(string, n);
    }

    static /* bridge */ /* synthetic */ String -$$Nest$smgetResponseContent(HttpURLConnection httpURLConnection) {
        return Spreadsheet.getResponseContent(httpURLConnection);
    }

    public Spreadsheet(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.container = componentContainer;
        this.activity = componentContainer.$context();
    }

    private GoogleCredential authorize() throws IOException {
        FileInputStream fileInputStream;
        FileInputStream fileInputStream2;
        if (this.cachedCredentialsFile == null) {
            this.cachedCredentialsFile = MediaUtil.copyMediaToTempFile((Form)this.container.$form(), (String)this.credentialsPath);
        }
        Object object2 = fileInputStream2 = null;
        object2 = fileInputStream2;
        try {
            object2 = fileInputStream2 = (fileInputStream = new FileInputStream(this.cachedCredentialsFile));
        }
        catch (Throwable throwable) {
            IOUtils.closeQuietly((String)LOG_TAG, object2);
            throw throwable;
        }
        fileInputStream = GoogleCredential.fromStream((InputStream)fileInputStream2).createScoped((Collection)Collections.singletonList((Object)"https://www.googleapis.com/auth/spreadsheets"));
        object2 = fileInputStream2;
        fileInputStream.refreshToken();
        object2 = fileInputStream2;
        this.accessToken = fileInputStream.getAccessToken();
        IOUtils.closeQuietly((String)LOG_TAG, (Closeable)fileInputStream2);
        object2 = this.accessToken;
        Log.d((String)LOG_TAG, (String)("Credential after refresh token: " + (String)object2));
        return fileInputStream;
    }

    private int getColNum(String object2) {
        if (object2 != null && !object2.isEmpty()) {
            int n = 0;
            object2 = object2.toCharArray();
            int n2 = ((Object)object2).length;
            for (int i = 0; i < n2; ++i) {
                n = n * 26 + (object2[i] - 65) + 1;
            }
            return n;
        }
        return -1;
    }

    private String getColString(int n) {
        if (n == 0) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        while (n > 0) {
            stringBuilder.insert(0, (new String[]{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"})[(n - 1) % 26]);
            n = (n - 1) / 26;
        }
        return stringBuilder.toString();
    }

    private YailList getColumn(int n) {
        YailList yailList = new YailList();
        if (n < this.columns.size()) {
            yailList = (YailList)this.columns.getObject(n);
        }
        return yailList;
    }

    private YailList getColumn(String string) {
        YailList yailList;
        YailList yailList2 = new YailList();
        int n = 0;
        while (true) {
            yailList = yailList2;
            if (n >= this.columns.size() || !(yailList = (YailList)this.columns.getObject(n)).isEmpty() && yailList.getString(0).equals((Object)string)) break;
            ++n;
        }
        return yailList;
    }

    private static InputStream getConnectionStream(HttpURLConnection httpURLConnection) throws SocketTimeoutException {
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            return inputStream;
        }
        catch (IOException iOException) {
            return httpURLConnection.getErrorStream();
        }
        catch (SocketTimeoutException socketTimeoutException) {
            throw socketTimeoutException;
        }
    }

    private static String getResponseContent(HttpURLConnection object2) throws IOException {
        int n;
        char[] cArray;
        String string;
        String string2;
        block14: {
            block13: {
                string = string2 = object2.getContentEncoding();
                if (string2 == null) {
                    string = "UTF-8";
                }
                cArray = null;
                string2 = cArray;
                string2 = cArray;
                InputStreamReader inputStreamReader = new InputStreamReader(Spreadsheet.getConnectionStream(object2), string);
                string2 = string = inputStreamReader;
                n = object2.getContentLength();
                if (n == -1) break block13;
                string2 = string;
                string2 = string;
                object2 = new StringBuilder(n);
                break block14;
            }
            string2 = string;
            object2 = new StringBuilder();
        }
        string2 = string;
        cArray = new char[1024];
        while (true) {
            string2 = string;
            n = string.read(cArray);
            if (n == -1) break;
            string2 = string;
            object2.append(cArray, 0, n);
            continue;
            break;
        }
        string2 = string;
        try {
            object2 = object2.toString();
        }
        catch (Throwable throwable) {
            IOUtils.closeQuietly((String)LOG_TAG, (Closeable)string2);
            throw throwable;
        }
        IOUtils.closeQuietly((String)LOG_TAG, (Closeable)string);
        return object2;
    }

    private int getSheetID(Sheets sheets, String string) {
        void var5_8 = this;
        synchronized (var5_8) {
            int n;
            block11: {
                block10: {
                    if (!this.sheetIdMap.containsKey((Object)string)) break block10;
                    int n2 = (Integer)this.sheetIdMap.get((Object)string);
                    return n2;
                }
                Sheets.Spreadsheets.Get get = sheets.spreadsheets().get(this.spreadsheetID);
                sheets = new ArrayList();
                sheets.add((Object)string);
                get.setRanges((List)sheets);
                get.setIncludeGridData(Boolean.valueOf((boolean)false));
                sheets = (com.google.api.services.sheets.v4.model.Spreadsheet)get.execute();
                n = sheets.size();
                if (n != 0) break block11;
                return -1;
            }
            try {
                n = ((Sheet)sheets.getSheets().get(0)).getProperties().getSheetId();
                this.sheetIdMap.put((Object)string, (Object)n);
                return n;
            }
            catch (Exception exception) {
                String string2 = exception.getMessage();
                string = new StringBuilder();
                this.ErrorOccurred(string.append("getSheetID: Unknown Exception - ").append(string2).toString());
            }
            catch (IOException iOException) {
                string = iOException.getMessage();
                StringBuilder stringBuilder = new StringBuilder();
                this.ErrorOccurred(stringBuilder.append("getSheetID: IOException - ").append(string).toString());
            }
            finally {
            }
        }
    }

    private Sheets getSheetsService() throws IOException, GeneralSecurityException {
        if (this.sheetsService == null) {
            GoogleCredential googleCredential = this.authorize();
            this.sheetsService = new Sheets.Builder((HttpTransport)new NetHttpTransport(), (JsonFactory)JacksonFactory.getDefaultInstance(), (HttpRequestInitializer)googleCredential).setApplicationName(this.applicationName).build();
        }
        return this.sheetsService;
    }

    private void removeSheetID(String string) {
        void var2_3 = this;
        synchronized (var2_3) {
            this.sheetIdMap.remove((Object)string);
            return;
        }
    }

    private static List<Object> sanitizeList(YailList yailList) {
        ArrayList arrayList = new ArrayList();
        yailList = ((LList)yailList.getCdr()).iterator();
        while (yailList.hasNext()) {
            arrayList.add(Spreadsheet.sanitizeObject(yailList.next()));
        }
        return arrayList;
    }

    private static Object sanitizeObject(Object object2) {
        if (object2 instanceof Boolean) {
            return object2;
        }
        if (object2 instanceof IntNum) {
            return ((IntNum)object2).longValue();
        }
        if (object2 instanceof DFloNum) {
            return ((DFloNum)object2).doubleValue();
        }
        if (!(object2 instanceof Integer) && !(object2 instanceof Long)) {
            if (object2 instanceof Number) {
                return ((Number)object2).doubleValue();
            }
            if (object2 instanceof String) {
                return object2;
            }
            return object2.toString();
        }
        return object2;
    }

    private void updateColumns(YailList yailList) {
        try {
            this.columns = ChartDataSourceUtil.getTranspose((YailList)yailList);
        }
        catch (Exception exception) {
            this.columns = new YailList();
        }
    }

    private void updateSheetID(String string, int n) {
        void var3_4 = this;
        synchronized (var3_4) {
            this.sheetIdMap.put((Object)string, (Object)n);
            return;
        }
    }

    @SimpleFunction(description="Given a list of values as `data`, appends the values to the next empty column of the sheet.")
    public void AddColumn(String string, YailList yailList) {
        String string2 = this.spreadsheetID;
        if (string2 != null && !string2.isEmpty()) {
            string2 = this.credentialsPath;
            if (string2 != null && !string2.isEmpty()) {
                string2 = new ArrayList();
                Iterator iterator = ((LList)yailList.getCdr()).iterator();
                while (iterator.hasNext()) {
                    Object object2 = iterator.next();
                    yailList = new ArrayList();
                    yailList.add(Spreadsheet.sanitizeObject(object2));
                    string2.add((Object)yailList);
                }
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, new ValueRange().setValues((List)string2)){
                    final Spreadsheet this$0;
                    final ValueRange val$body;
                    final String val$sheetName;
                    {
                        this.this$0 = spreadsheet;
                        this.val$sheetName = string;
                        this.val$body = valueRange;
                    }

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    public void run() {
                        Object object2;
                        try {
                            object2 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                            List list = ((ValueRange)object2.spreadsheets().values().get(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$sheetName).execute()).getValues();
                            if (list != null && !list.isEmpty()) {
                                int n = 0;
                                Iterator iterator = list.iterator();
                                while (iterator.hasNext()) {
                                    n = Math.max((int)n, (int)((List)iterator.next()).size());
                                }
                                String string = Spreadsheet.-$$Nest$mgetColString(this.this$0, ++n);
                                String string2 = this.val$sheetName;
                                StringBuilder stringBuilder = new StringBuilder();
                                String string3 = stringBuilder.append(string2).append("!").append(string).append("1").toString();
                                object2 = (UpdateValuesResponse)object2.spreadsheets().values().update(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), string3, this.val$body).setValueInputOption("USER_ENTERED").execute();
                                Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                object2 = new Runnable(this, n){
                                    final 10 this$1;
                                    final int val$addedColumn;
                                    {
                                        this.this$1 = var1;
                                        this.val$addedColumn = n;
                                    }

                                    public void run() {
                                        this.this$1.this$0.FinishedAddColumn(this.val$addedColumn);
                                    }
                                };
                                activity.runOnUiThread((Runnable)object2);
                                return;
                            }
                            this.this$0.ErrorOccurred("AddColumn: No data found");
                            return;
                        }
                        catch (GeneralSecurityException generalSecurityException) {
                            generalSecurityException.printStackTrace();
                            object2 = this.this$0;
                            String string = generalSecurityException.getMessage();
                            ((Spreadsheet)object2).ErrorOccurred("AddColumn GeneralSecurityException: " + string);
                            return;
                        }
                        catch (IOException iOException) {
                            iOException.printStackTrace();
                            object2 = this.this$0;
                            String string = iOException.getMessage();
                            ((Spreadsheet)object2).ErrorOccurred("AddColumn IOException: " + string);
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("AddColumn: Credentials JSON is required.");
            return;
        }
        this.ErrorOccurred("AddColumn: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Given a list of values as `data`, appends the values to the next empty row of the sheet. Additionally, this returns the row number for the new row.")
    public void AddRow(String string, YailList yailList) {
        String string2 = this.spreadsheetID;
        if (string2 != null && !string2.isEmpty()) {
            string2 = this.credentialsPath;
            if (string2 != null && !string2.isEmpty()) {
                string2 = new ArrayList();
                string2.add(Spreadsheet.sanitizeList(yailList));
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, new ValueRange().setValues((List)string2).setRange(string)){
                    final Spreadsheet this$0;
                    final ValueRange val$body;
                    final String val$sheetName;
                    {
                        this.this$0 = spreadsheet;
                        this.val$sheetName = string;
                        this.val$body = valueRange;
                    }

                    /*
                     * Enabled aggressive block sorting
                     * Enabled unnecessary exception pruning
                     * Enabled aggressive exception aggregation
                     */
                    public void run() {
                        try {
                            Object object2 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                            List list = ((ValueRange)object2.spreadsheets().values().get(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$sheetName).execute()).getValues();
                            int n = list == null ? 1 : list.size() + 1;
                            list = object2.spreadsheets().values();
                            object2 = Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0);
                            String string = this.val$sheetName;
                            StringBuilder stringBuilder = new StringBuilder();
                            string = stringBuilder.append(string).append("!A").append(n).toString();
                            ValueRange valueRange = this.val$body;
                            String string2 = this.val$sheetName;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            n = Integer.parseInt((String)((AppendValuesResponse)list.append((String)object2, string, valueRange.setRange(stringBuilder2.append(string2).append("!A").append(n).toString())).setValueInputOption("USER_ENTERED").setInsertDataOption("INSERT_ROWS").execute()).getUpdates().getUpdatedRange().split("!")[1].split(":")[0].replaceAll("[^\\d.]", ""));
                            list = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object2 = new Runnable(this, n){
                                final 6 this$1;
                                final int val$rowNumber;
                                {
                                    this.this$1 = var1;
                                    this.val$rowNumber = n;
                                }

                                public void run() {
                                    this.this$1.this$0.FinishedAddRow(this.val$rowNumber);
                                }
                            };
                            list.runOnUiThread((Runnable)object2);
                            if (Spreadsheet.-$$Nest$fgetobservers(this.this$0).size() <= 0) return;
                            this.this$0.RetrieveSheet(this.val$sheetName, -1, null, false, false);
                            return;
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            Spreadsheet spreadsheet = this.this$0;
                            String string = exception.getMessage();
                            spreadsheet.ErrorOccurred("AddRow: " + string);
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("AddRow: Credentials JSON is required.");
            return;
        }
        this.ErrorOccurred("AddRow: SpreadsheetID is empty.");
    }

    @SimpleFunction
    public void AddSheet(String string) {
        String string2 = this.spreadsheetID;
        if (string2 != null && !string2.isEmpty()) {
            string2 = this.credentialsPath;
            if (string2 != null && !string2.isEmpty()) {
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string){
                    final Spreadsheet this$0;
                    final String val$sheetName;
                    {
                        this.this$0 = spreadsheet;
                        this.val$sheetName = string;
                    }

                    public void run() {
                        try {
                            Sheets sheets = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                            AddSheetRequest addSheetRequest = new AddSheetRequest();
                            Object object2 = new SheetProperties();
                            addSheetRequest = addSheetRequest.setProperties(object2.setTitle(this.val$sheetName));
                            object2 = new ArrayList();
                            Request request2 = new Request();
                            object2.add((Object)request2.setAddSheet(addSheetRequest));
                            addSheetRequest = new BatchUpdateSpreadsheetRequest();
                            object2 = addSheetRequest.setRequests((List)object2);
                            sheets = (BatchUpdateSpreadsheetResponse)sheets.spreadsheets().batchUpdate(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), (BatchUpdateSpreadsheetRequest)object2).execute();
                            Spreadsheet.-$$Nest$mupdateSheetID(this.this$0, this.val$sheetName, ((Response)sheets.getReplies().get(0)).getAddSheet().getProperties().getSheetId());
                            sheets = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object2 = new Runnable(this){
                                final 4 this$1;
                                {
                                    this.this$1 = var1;
                                }

                                public void run() {
                                    this.this$1.this$0.FinishedAddSheet(this.this$1.val$sheetName);
                                }
                            };
                            sheets.runOnUiThread((Runnable)object2);
                        }
                        catch (Exception exception) {
                            Spreadsheet.-$$Nest$fgetactivity(this.this$0).runOnUiThread(new Runnable(this, exception){
                                final 4 this$1;
                                final Exception val$e;
                                {
                                    this.this$1 = var1;
                                    this.val$e = exception;
                                }

                                public void run() {
                                    Log.e((String)"SPREADSHEET", (String)"Error occurred in AddSheet", (Throwable)this.val$e);
                                    Spreadsheet spreadsheet = this.this$1.this$0;
                                    String string = this.val$e.getMessage();
                                    spreadsheet.ErrorOccurred("AddSheet: " + string);
                                }
                            });
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("AddSheet: Credentials JSON is required.");
            return;
        }
        this.ErrorOccurred("AddSheet: SpreadsheetID is empty.");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, userVisible=false)
    public String ApplicationName() {
        return this.applicationName;
    }

    @DesignerProperty(defaultValue="App Inventor", editorType="string")
    @SimpleProperty(description="The name of your application, used when making API calls.")
    public void ApplicationName(String string) {
        this.applicationName = string;
    }

    @SimpleFunction(description="Empties the cells in the given range. Once complete, this block triggers the FinishedClearRange callback event.")
    public void ClearRange(String string, String string2) {
        String string3 = this.spreadsheetID;
        if (string3 != "" && string3 != null) {
            if (this.credentialsPath == null) {
                this.ErrorOccurred("ClearRange: Credential JSON is required.");
                return;
            }
            string = string + "!" + string2;
            Log.d((String)LOG_TAG, (String)("Clearing Range: " + string));
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string){
                final Spreadsheet this$0;
                final String val$rangeRef;
                {
                    this.this$0 = spreadsheet;
                    this.val$rangeRef = string;
                }

                public void run() {
                    try {
                        Object object2 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                        Sheets.Spreadsheets.Values values = object2.spreadsheets().values();
                        String string = Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0);
                        Runnable runnable = this.val$rangeRef;
                        object2 = new ClearValuesRequest();
                        object2 = (ClearValuesResponse)values.clear(string, (String)runnable, (ClearValuesRequest)object2).execute();
                        object2 = this.this$0.form;
                        runnable = new Runnable(this){
                            final 16 this$1;
                            {
                                this.this$1 = var1;
                            }

                            public void run() {
                                this.this$1.this$0.FinishedClearRange();
                            }
                        };
                        object2.runOnUiThread(runnable);
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        Spreadsheet spreadsheet = this.this$0;
                        String string = exception.getMessage();
                        spreadsheet.ErrorOccurred("ClearRange: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("ClearRange: SpreadsheetID is empty.");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String CredentialsJson() {
        return this.credentialsPath;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty(description="The JSON File with credentials for the Service Account")
    public void CredentialsJson(String string) {
        this.credentialsPath = string;
    }

    @SimpleFunction
    public void DeleteSheet(String string) {
        String string2 = this.spreadsheetID;
        if (string2 != null && !string2.isEmpty()) {
            string2 = this.credentialsPath;
            if (string2 != null && !string2.isEmpty()) {
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string){
                    final Spreadsheet this$0;
                    final String val$sheetName;
                    {
                        this.this$0 = spreadsheet;
                        this.val$sheetName = string;
                    }

                    public void run() {
                        try {
                            Sheets sheets = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                            Object object2 = new DeleteSheetRequest();
                            DeleteSheetRequest deleteSheetRequest = object2.setSheetId(Integer.valueOf((int)Spreadsheet.-$$Nest$mgetSheetID(this.this$0, sheets, this.val$sheetName)));
                            object2 = new ArrayList();
                            Request request2 = new Request();
                            object2.add((Object)request2.setDeleteSheet(deleteSheetRequest));
                            request2 = new BatchUpdateSpreadsheetRequest();
                            object2 = request2.setRequests((List)object2);
                            sheets.spreadsheets().batchUpdate(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), (BatchUpdateSpreadsheetRequest)object2).execute();
                            Spreadsheet.-$$Nest$mremoveSheetID(this.this$0, this.val$sheetName);
                            sheets = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object2 = new Runnable(this){
                                final 5 this$1;
                                {
                                    this.this$1 = var1;
                                }

                                public void run() {
                                    this.this$1.this$0.FinishedDeleteSheet(this.this$1.val$sheetName);
                                }
                            };
                            sheets.runOnUiThread((Runnable)object2);
                        }
                        catch (Exception exception) {
                            Spreadsheet.-$$Nest$fgetactivity(this.this$0).runOnUiThread(new Runnable(this, exception){
                                final 5 this$1;
                                final Exception val$e;
                                {
                                    this.this$1 = var1;
                                    this.val$e = exception;
                                }

                                public void run() {
                                    Log.e((String)"SPREADSHEET", (String)"Error occurred in DeleteSheet", (Throwable)this.val$e);
                                    Spreadsheet spreadsheet = this.this$1.this$0;
                                    String string = this.val$e.getMessage();
                                    spreadsheet.ErrorOccurred("DeleteSheet: " + string);
                                }
                            });
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("DeleteSheet: Credentials JSON is required.");
            return;
        }
        this.ErrorOccurred("DeleteSheet: SpreadsheetID is empty.");
    }

    @SimpleEvent(description="Triggered whenever an API call encounters an error. Details about the error are in `errorMessage`.")
    public void ErrorOccurred(String string) {
        Log.d((String)LOG_TAG, (String)string);
        this.activity.runOnUiThread(new Runnable((Spreadsheet)this, (Spreadsheet)this, string){
            final Spreadsheet this$0;
            final String val$errorMessage;
            final Spreadsheet val$thisInstance;
            {
                this.this$0 = spreadsheet;
                this.val$thisInstance = spreadsheet2;
                this.val$errorMessage = string;
            }

            public void run() {
                if (!EventDispatcher.dispatchEvent(this.val$thisInstance, "ErrorOccurred", this.val$errorMessage)) {
                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "ErrorOccurred", 4401, this.val$errorMessage);
                }
            }
        });
    }

    @SimpleEvent(description="This event will be triggered once the AddColumn method has finished executing and the values on the spreadsheet have been updated. Additionally, this returns the column number for the new column.")
    public void FinishedAddColumn(int n) {
        EventDispatcher.dispatchEvent((Component)this, "FinishedAddColumn", n);
    }

    @SimpleEvent(description="The callback event for the AddRow block, called once the values on the table have been updated.")
    public void FinishedAddRow(int n) {
        EventDispatcher.dispatchEvent((Component)this, "FinishedAddRow", n);
    }

    @SimpleEvent(description="The callback event for the addSheet block, called once the values on the table have been updated.")
    public void FinishedAddSheet(String string) {
        EventDispatcher.dispatchEvent((Component)this, "FinishedAddSheet", string);
    }

    @SimpleEvent(description="The callback event for the ClearRange block.")
    public void FinishedClearRange() {
        EventDispatcher.dispatchEvent(this, "FinishedClearRange", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the DeleteSheet block, called once the values on the table have been updated.")
    public void FinishedDeleteSheet(String string) {
        EventDispatcher.dispatchEvent((Component)this, "FinishedDeleteSheet", string);
    }

    @SimpleEvent(description="The callback event for the RemoveColumn block, called once the values on the table have been updated.")
    public void FinishedRemoveColumn() {
        EventDispatcher.dispatchEvent(this, "FinishedRemoveColumn", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the RemoveRow block, called once thevalues on the table have been updated.")
    public void FinishedRemoveRow() {
        EventDispatcher.dispatchEvent(this, "FinishedRemoveRow", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the WriteCell block.")
    public void FinishedWriteCell() {
        EventDispatcher.dispatchEvent(this, "FinishedWriteCell", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the WriteColumn block, called once thevalues on the table have been updated.")
    public void FinishedWriteColumn() {
        EventDispatcher.dispatchEvent(this, "FinishedWriteColumn", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the WriteRange block.")
    public void FinishedWriteRange() {
        EventDispatcher.dispatchEvent(this, "FinishedWriteRange", new Object[0]);
    }

    @SimpleEvent(description="The callback event for the WriteRow block, called after the values on the table have finished updating")
    public void FinishedWriteRow() {
        EventDispatcher.dispatchEvent(this, "FinishedWriteRow", new Object[0]);
    }

    @SimpleFunction(description="Converts the integer representation of rows and columns to A1-Notation used in Google Sheets for a single cell.")
    public String GetCellReference(int n, int n2) {
        String string = super.getColString(n2);
        return string + n;
    }

    @SimpleFunction(description="Converts the integer representation of rows and columns for the corners of the range to A1-Notation used in Google Sheets.")
    public String GetRangeReference(int n, int n2, int n3, int n4) {
        String string = this.GetCellReference(n, n2);
        String string2 = this.GetCellReference(n3, n4);
        return string + ":" + string2;
    }

    @SimpleEvent(description="The callback event for the ReadCell block. The `cellData` is the text value in the cell (and not the underlying formula).")
    public void GotCellData(String string) {
        Log.d((String)LOG_TAG, (String)("GotCellData got: " + string));
        EventDispatcher.dispatchEvent((Component)this, "GotCellData", string);
    }

    @SimpleEvent(description="After calling the ReadColumn method, the data in the column will be stored as a list of text values in `columnData`.")
    public void GotColumnData(List<String> list) {
        Log.d((String)LOG_TAG, (String)("GotColumnData got: " + list));
        EventDispatcher.dispatchEvent((Component)this, "GotColumnData", list);
    }

    @SimpleEvent(description="The callback event for the ReadWithExactQuery or ReadWithPartialQuery block. The `response` is a list of rows numbers and a list of rows containing cell data.", userVisible=false)
    public void GotFilterResult(List<Integer> list, List<List<String>> list2) {
        Log.d((String)LOG_TAG, (String)("GotFilterResult got: " + list));
        EventDispatcher.dispatchEvent((Component)this, "GotFilterResult", list, list2);
    }

    @SimpleEvent(description="The callback event for the ReadRange block. The `rangeData` is a list of rows with the requested dimensions.")
    public void GotRangeData(List<List<String>> list) {
        Log.d((String)LOG_TAG, (String)("GotRangeData got: " + list));
        EventDispatcher.dispatchEvent((Component)this, "GotRangeData", list);
    }

    @SimpleEvent(description="The callback event for the ReadRow block. The `rowDataList` is a list of cell values in order of increasing column number.")
    public void GotRowData(List<String> list) {
        EventDispatcher.dispatchEvent((Component)this, "GotRowData", list);
    }

    @SimpleEvent(description="The callback event for the ReadSheet block. The `sheetData` is a list of rows.")
    public void GotSheetData(List<List<String>> list) {
        Log.d((String)LOG_TAG, (String)("GotSheetData got: " + list));
        EventDispatcher.dispatchEvent((Component)this, "GotSheetData", list);
    }

    @SimpleFunction(description="On the page with the provided sheetName, reads the cell at the given cellReference and triggers the GotCellData callback event.")
    public void ReadCell(String string, String string2) {
        String string3 = this.spreadsheetID;
        if (string3 != null && !string3.isEmpty()) {
            if (!string2.matches("[a-zA-Z]+[0-9]+")) {
                this.ErrorOccurred("ReadCell: Invalid Cell Reference");
                return;
            }
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string2, string){
                final Spreadsheet this$0;
                final String val$cellReference;
                final String val$sheetName;
                {
                    this.this$0 = spreadsheet;
                    this.val$cellReference = string;
                    this.val$sheetName = string2;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Runnable runnable = this.val$cellReference;
                    Log.d((String)"SPREADSHEET", (String)("Reading Cell: " + (String)runnable));
                    try {
                        Runnable runnable2 = Spreadsheet.-$$Nest$fgetcredentialsPath(this.this$0);
                        runnable = "";
                        if (runnable2 == null) {
                            try {
                                runnable2 = URLEncoder.encode((String)this.val$cellReference, (String)"UTF-8");
                            }
                            catch (UnsupportedEncodingException unsupportedEncodingException) {
                                this.this$0.ErrorOccurred("ReadCell: Error occurred encoding the query. UTF-8 is unsupported?");
                                return;
                            }
                            runnable2 = String.format((String)"https://docs.google.com/spreadsheets/d/%s/export?format=csv&range=%s", (Object[])new Object[]{Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), runnable2});
                            Object object2 = new StringBuilder();
                            Log.d((String)"SPREADSHEET", (String)object2.append("ReadCell url: ").append((String)runnable2).toString());
                            object2 = new URL((String)runnable2);
                            object2 = (HttpURLConnection)object2.openConnection();
                            object2.setRequestMethod("GET");
                            if (object2.getResponseCode() == 400) {
                                object2 = this.this$0;
                                runnable = new StringBuilder();
                                ((Spreadsheet)object2).ErrorOccurred(runnable.append("ReadCell: Bad HTTP Request. Please check the address and try again. ").append((String)runnable2).toString());
                                return;
                            }
                            object2 = ((LList)CsvUtil.fromCsvTable((String)Spreadsheet.-$$Nest$smgetResponseContent((HttpURLConnection)object2)).getCdr()).iterator();
                            do {
                                if (object2.hasNext()) continue;
                                this.this$0.ErrorOccurred("ReadCell: Error reading cell data from HTTP Request");
                                return;
                            } while (!((runnable2 = object2.next()) instanceof YailList));
                            if (!(runnable2 = (YailList)runnable2).isEmpty()) {
                                runnable = runnable2.get(1);
                            }
                            object2 = String.format((String)"%s", (Object[])new Object[]{runnable});
                            runnable = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            runnable2 = new Runnable(this, (String)object2){
                                final 12 this$1;
                                final String val$cellData;
                                {
                                    this.this$1 = var1;
                                    this.val$cellData = string;
                                }

                                public void run() {
                                    this.this$1.this$0.GotCellData(this.val$cellData);
                                }
                            };
                            runnable.runOnUiThread(runnable2);
                            return;
                        }
                        Sheets.Spreadsheets.Values values = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values();
                        String string = Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0);
                        runnable2 = this.val$sheetName;
                        String string2 = this.val$cellReference;
                        StringBuilder stringBuilder = new StringBuilder();
                        if ((runnable2 = ((ValueRange)values.get(string, stringBuilder.append((String)runnable2).append("!").append(string2).toString()).execute()).getValues()) != null && !runnable2.isEmpty()) {
                            if (!((List)runnable2.get(0)).isEmpty()) {
                                runnable = ((List)runnable2.get(0)).get(0);
                            }
                            string = String.format((String)"%s", (Object[])new Object[]{runnable});
                            runnable2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            runnable = new Runnable(this, string){
                                final 12 this$1;
                                final String val$result;
                                {
                                    this.this$1 = var1;
                                    this.val$result = string;
                                }

                                public void run() {
                                    this.this$1.this$0.GotCellData(this.val$result);
                                }
                            };
                            runnable2.runOnUiThread(runnable);
                            return;
                        }
                        runnable2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                        runnable = new Runnable(this){
                            final 12 this$1;
                            {
                                this.this$1 = var1;
                            }

                            public void run() {
                                this.this$1.this$0.GotCellData("");
                            }
                        };
                        runnable2.runOnUiThread(runnable);
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        runnable = this.this$0;
                        String string = exception.getMessage();
                        runnable.ErrorOccurred("ReadCell: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("ReadCell: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="On the page with the provided sheetName, reads the column at the given index and triggers the GotColumnData callback event.")
    public void ReadColumn(String string, String string2) {
        String string3 = this.spreadsheetID;
        if (string3 != null && !string3.isEmpty()) {
            string3 = string2;
            if (Pattern.compile((String)"^[0-9]+$").matcher((CharSequence)string2).find()) {
                string3 = super.getColString(Integer.parseInt((String)string2));
            }
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string + "!" + string3 + ":" + string3){
                final Spreadsheet this$0;
                final String val$rangeRef;
                {
                    this.this$0 = spreadsheet;
                    this.val$rangeRef = string;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    try {
                        Object object2 = Spreadsheet.-$$Nest$fgetcredentialsPath(this.this$0);
                        if (object2 == null) {
                            try {
                                object2 = URLEncoder.encode((String)this.val$rangeRef, (String)"UTF-8");
                            }
                            catch (UnsupportedEncodingException unsupportedEncodingException) {
                                this.this$0.ErrorOccurred("ReadColumn: Error occurred encoding the query. UTF-8 is unsupported?");
                                return;
                            }
                            object2 = String.format((String)"https://docs.google.com/spreadsheets/d/%s/export?format=csv&range=%s", (Object[])new Object[]{Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), object2});
                            Object object3 = new StringBuilder();
                            Log.d((String)"SPREADSHEET", (String)object3.append("ReadColumn url: ").append((String)object2).toString());
                            object3 = new URL((String)object2);
                            object3 = (HttpURLConnection)object3.openConnection();
                            object3.setRequestMethod("GET");
                            if (object3.getResponseCode() == 400) {
                                object3 = this.this$0;
                                StringBuilder stringBuilder = new StringBuilder();
                                ((Spreadsheet)object3).ErrorOccurred(stringBuilder.append("ReadColumn: Bad HTTP Request. Please check the address and try again. ").append((String)object2).toString());
                                return;
                            }
                            object2 = CsvUtil.fromCsvTable((String)Spreadsheet.-$$Nest$smgetResponseContent((HttpURLConnection)object3));
                            object3 = new ArrayList();
                            Object object4 = ((LList)object2.getCdr()).iterator();
                            while (true) {
                                if (!object4.hasNext()) {
                                    object2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                    object4 = new Runnable(this, (List)object3){
                                        final 8 this$1;
                                        final List val$col;
                                        {
                                            this.this$1 = var1;
                                            this.val$col = list;
                                        }

                                        public void run() {
                                            this.this$1.this$0.GotColumnData((List<String>)this.val$col);
                                        }
                                    };
                                    object2.runOnUiThread((Runnable)object4);
                                    return;
                                }
                                object2 = object4.next();
                                if (!(object2 instanceof YailList)) continue;
                                object2 = (object2 = (YailList)object2).isEmpty() ? "" : object2.get(1);
                                object3.add((Object)String.format((String)"%s", (Object[])new Object[]{object2}));
                            }
                        }
                        object2 = ((ValueRange)Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().get(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeRef).execute()).getValues();
                        if (object2 != null && !object2.isEmpty()) {
                            ArrayList arrayList = new ArrayList();
                            Object object5 = object2.iterator();
                            while (true) {
                                if (!object5.hasNext()) {
                                    object2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                    object5 = new Runnable(this, (List)arrayList){
                                        final 8 this$1;
                                        final List val$ret;
                                        {
                                            this.this$1 = var1;
                                            this.val$ret = list;
                                        }

                                        public void run() {
                                            this.this$1.this$0.GotColumnData((List<String>)this.val$ret);
                                        }
                                    };
                                    object2.runOnUiThread((Runnable)object5);
                                    return;
                                }
                                object2 = (List)object5.next();
                                object2 = object2.isEmpty() ? "" : object2.get(0).toString();
                                arrayList.add(object2);
                            }
                        }
                        this.this$0.ErrorOccurred("ReadColumn: No data found.");
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        Spreadsheet spreadsheet = this.this$0;
                        String string = exception.getMessage();
                        spreadsheet.ErrorOccurred("ReadColumn: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("ReadColumn: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="On the page with the provided sheetName, reads the cells at the given range. Triggers the getRangeReference once complete.")
    public void ReadRange(String string, String string2) {
        String string3 = this.spreadsheetID;
        if (string3 != "" && string3 != null) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string2, string){
                final Spreadsheet this$0;
                final String val$rangeReference;
                final String val$sheetName;
                {
                    this.this$0 = spreadsheet;
                    this.val$rangeReference = string;
                    this.val$sheetName = string2;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Object object22 = this.val$rangeReference;
                    Log.d((String)"SPREADSHEET", (String)("Reading Range: " + (String)object22));
                    try {
                        object22 = Spreadsheet.-$$Nest$fgetcredentialsPath(this.this$0);
                        if (object22 == null) {
                            try {
                                object22 = URLEncoder.encode((String)this.val$rangeReference, (String)"UTF-8");
                            }
                            catch (UnsupportedEncodingException unsupportedEncodingException) {
                                this.this$0.ErrorOccurred("ReadRange: Error occurred encoding the query. UTF-8 is unsupported?");
                                return;
                            }
                            object22 = String.format((String)"https://docs.google.com/spreadsheets/d/%s/export?format=csv&range=%s", (Object[])new Object[]{Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), object22});
                            Object object3 = new StringBuilder();
                            Log.d((String)"SPREADSHEET", (String)object3.append("ReadRange url: ").append((String)object22).toString());
                            object3 = new URL((String)object22);
                            object3 = (HttpURLConnection)object3.openConnection();
                            object3.setRequestMethod("GET");
                            if (object3.getResponseCode() == 400) {
                                Spreadsheet spreadsheet = this.this$0;
                                object3 = new StringBuilder();
                                spreadsheet.ErrorOccurred(object3.append("ReadRange: Bad HTTP Request. Please check the address and try again. ").append((String)object22).toString());
                                return;
                            }
                            YailList yailList = CsvUtil.fromCsvTable((String)Spreadsheet.-$$Nest$smgetResponseContent((HttpURLConnection)object3));
                            object22 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object3 = new Runnable(this, yailList){
                                final 14 this$1;
                                final YailList val$parsedCsv;
                                {
                                    this.this$1 = var1;
                                    this.val$parsedCsv = yailList;
                                }

                                public void run() {
                                    this.this$1.this$0.GotRangeData((List<List<String>>)this.val$parsedCsv);
                                }
                            };
                            object22.runOnUiThread((Runnable)object3);
                            return;
                        }
                        object22 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values();
                        String string = Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0);
                        String string2 = this.val$sheetName;
                        String string3 = this.val$rangeReference;
                        StringBuilder stringBuilder = new StringBuilder();
                        if ((object22 = ((ValueRange)object22.get(string, stringBuilder.append(string2).append("!").append(string3).toString()).execute()).getValues()) != null && !object22.isEmpty()) {
                            string = new ArrayList();
                            string3 = object22.iterator();
                            while (true) {
                                if (!string3.hasNext()) {
                                    string3 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                    object22 = new Runnable(this, (List)string){
                                        final 14 this$1;
                                        final List val$ret;
                                        {
                                            this.this$1 = var1;
                                            this.val$ret = list;
                                        }

                                        public void run() {
                                            this.this$1.this$0.GotRangeData((List<List<String>>)this.val$ret);
                                        }
                                    };
                                    string3.runOnUiThread(object22);
                                    return;
                                }
                                object22 = (List)string3.next();
                                string2 = new ArrayList();
                                for (Object object22 : object22) {
                                    if (object22 == null) {
                                        object22 = "";
                                    }
                                    string2.add((Object)String.format((String)"%s", (Object[])new Object[]{object22}));
                                }
                                string.add((Object)string2);
                            }
                        }
                        this.this$0.ErrorOccurred("ReadRange: No data found.");
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        object22 = this.this$0;
                        String string = exception.getMessage();
                        object22.ErrorOccurred("ReadRange: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("ReadRange: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="On the page with the provided sheetName, this method will read the row at the given rowNumber and trigger the GotRowData callback event.")
    public void ReadRow(String string, int n) {
        String string2 = this.spreadsheetID;
        if (string2 != "" && string2 != null) {
            Log.d((String)LOG_TAG, (String)("Read Row number: " + n));
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string + "!" + n + ":" + n){
                final Spreadsheet this$0;
                final String val$rangeReference;
                {
                    this.this$0 = spreadsheet;
                    this.val$rangeReference = string;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    try {
                        Object object2 = Spreadsheet.-$$Nest$fgetcredentialsPath(this.this$0);
                        if (object2 == null) {
                            try {
                                object2 = URLEncoder.encode((String)this.val$rangeReference, (String)"UTF-8");
                            }
                            catch (UnsupportedEncodingException unsupportedEncodingException) {
                                this.this$0.ErrorOccurred("ReadRow: Error occurred encoding the query. UTF-8 is unsupported?");
                                return;
                            }
                            object2 = String.format((String)"https://docs.google.com/spreadsheets/d/%s/export?format=csv&range=%s", (Object[])new Object[]{Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), object2});
                            Object object3 = new StringBuilder();
                            Log.d((String)"SPREADSHEET", (String)object3.append("ReadRow url: ").append((String)object2).toString());
                            object3 = new URL((String)object2);
                            object3 = (HttpURLConnection)object3.openConnection();
                            object3.setRequestMethod("GET");
                            if (object3.getResponseCode() == 400) {
                                Spreadsheet spreadsheet = this.this$0;
                                object3 = new StringBuilder();
                                spreadsheet.ErrorOccurred(object3.append("ReadRow: Bad HTTP Request. Please check the address and try again. ").append((String)object2).toString());
                                return;
                            }
                            object3 = ((LList)CsvUtil.fromCsvTable((String)Spreadsheet.-$$Nest$smgetResponseContent((HttpURLConnection)object3)).getCdr()).iterator();
                            do {
                                if (object3.hasNext()) continue;
                                this.this$0.ErrorOccurred("ReadRow: Could not find a row from the HTTP Request.");
                                return;
                            } while (!((object2 = object3.next()) instanceof YailList));
                            YailList yailList = (YailList)object2;
                            object2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object3 = new Runnable(this, yailList){
                                final 2 this$1;
                                final YailList val$row;
                                {
                                    this.this$1 = var1;
                                    this.val$row = yailList;
                                }

                                public void run() {
                                    this.this$1.this$0.GotRowData((List<String>)this.val$row);
                                }
                            };
                            object2.runOnUiThread((Runnable)object3);
                            return;
                        }
                        object2 = ((ValueRange)Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().get(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeReference).execute()).getValues();
                        if (object2 != null && !object2.isEmpty()) {
                            ArrayList arrayList = new ArrayList();
                            Iterator iterator = ((List)object2.get(0)).iterator();
                            while (true) {
                                if (!iterator.hasNext()) {
                                    iterator = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                    object2 = new Runnable(this, (List)arrayList){
                                        final 2 this$1;
                                        final List val$ret;
                                        {
                                            this.this$1 = var1;
                                            this.val$ret = list;
                                        }

                                        public void run() {
                                            this.this$1.this$0.GotRowData((List<String>)this.val$ret);
                                        }
                                    };
                                    iterator.runOnUiThread(object2);
                                    return;
                                }
                                object2 = iterator.next();
                                if (object2 == null) {
                                    object2 = "";
                                }
                                arrayList.add((Object)String.format((String)"%s", (Object[])new Object[]{object2}));
                            }
                        }
                        this.this$0.ErrorOccurred("ReadRow: No data found");
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        Spreadsheet spreadsheet = this.this$0;
                        String string = exception.getMessage();
                        spreadsheet.ErrorOccurred("ReadRow: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("ReadRow: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Reads the *entire* Google Sheet document and triggers the GotSheetData callback event.")
    public void ReadSheet(String string) {
        String string2 = this.spreadsheetID;
        if (string2 != null && !string2.isEmpty()) {
            AsynchUtil.runAsynchronously((Runnable)this.RetrieveSheet(string, -1, null, false, true));
            return;
        }
        this.ErrorOccurred("ReadSheet: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Filters a Google Sheet for rows where the given column number matches the provided value.")
    public void ReadWithExactFilter(String string, int n, String string2) {
        Log.d((String)LOG_TAG, (String)("ReadRowsWithFilter colID " + n + ", value " + string2));
        String string3 = this.spreadsheetID;
        if (string3 != null && !string3.isEmpty()) {
            AsynchUtil.runAsynchronously((Runnable)this.RetrieveSheet(string, n, string2, true, true));
            return;
        }
        this.ErrorOccurred("ReadWithExactFilter: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Filters a Google Sheet for rows where the given column number contains the provided value string.")
    public void ReadWithPartialFilter(String string, int n, String string2) {
        Log.d((String)LOG_TAG, (String)("ReadWithPartialFilter colID " + n + ", value " + string2));
        String string3 = this.spreadsheetID;
        if (string3 != null && !string3.isEmpty()) {
            AsynchUtil.runAsynchronously((Runnable)this.RetrieveSheet(string, n, string2, false, true));
            return;
        }
        this.ErrorOccurred("ReadWithPartialFilter: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Deletes the column with the given column number from the table.This does not clear the column, but removes it entirely.")
    public void RemoveColumn(String string, String string2) {
        int n = Pattern.compile((String)"^[0-9]+$").matcher((CharSequence)string2).find() ? Integer.parseInt((String)string2) : super.getColNum(string2);
        AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, n){
            final Spreadsheet this$0;
            final int val$columnNumber;
            final String val$sheetName;
            {
                this.this$0 = spreadsheet;
                this.val$sheetName = string;
                this.val$columnNumber = n;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                try {
                    Sheets sheets = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                    int n = Spreadsheet.-$$Nest$mgetSheetID(this.this$0, sheets, this.val$sheetName);
                    if (n == -1) {
                        this.this$0.ErrorOccurred("RemoveColumn: sheetName not found");
                        return;
                    }
                    DeleteDimensionRequest deleteDimensionRequest = new DeleteDimensionRequest();
                    DimensionRange dimensionRange = new DimensionRange();
                    DeleteDimensionRequest deleteDimensionRequest2 = deleteDimensionRequest.setRange(dimensionRange.setSheetId(Integer.valueOf((int)n)).setDimension("COLUMNS").setStartIndex(Integer.valueOf((int)(this.val$columnNumber - 1))).setEndIndex(Integer.valueOf((int)this.val$columnNumber)));
                    ArrayList arrayList = new ArrayList();
                    deleteDimensionRequest = new Request();
                    arrayList.add((Object)deleteDimensionRequest.setDeleteDimension(deleteDimensionRequest2));
                    deleteDimensionRequest = new BatchUpdateSpreadsheetRequest();
                    BatchUpdateSpreadsheetRequest batchUpdateSpreadsheetRequest = deleteDimensionRequest.setRequests((List)arrayList);
                    sheets.spreadsheets().batchUpdate(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), batchUpdateSpreadsheetRequest).execute();
                    sheets = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                    Runnable runnable = new Runnable(this){
                        final 11 this$1;
                        {
                            this.this$1 = var1;
                        }

                        public void run() {
                            this.this$1.this$0.FinishedRemoveColumn();
                        }
                    };
                    sheets.runOnUiThread(runnable);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    Spreadsheet spreadsheet = this.this$0;
                    String string = exception.getMessage();
                    spreadsheet.ErrorOccurred("RemoveColumn: " + string);
                }
            }
        });
    }

    @SimpleFunction(description="Deletes the row with the given row number from the table.This does not clear the row, but removes it entirely.")
    public void RemoveRow(String string, int n) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, n){
            final Spreadsheet this$0;
            final int val$rowNumber;
            final String val$sheetName;
            {
                this.this$0 = spreadsheet;
                this.val$sheetName = string;
                this.val$rowNumber = n;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                try {
                    Object object2 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                    int n = Spreadsheet.-$$Nest$mgetSheetID(this.this$0, object2, this.val$sheetName);
                    if (n == -1) {
                        this.this$0.ErrorOccurred("RemoveCol: sheetName not found");
                        return;
                    }
                    DeleteDimensionRequest deleteDimensionRequest = new DeleteDimensionRequest();
                    DimensionRange dimensionRange = new DimensionRange();
                    deleteDimensionRequest = deleteDimensionRequest.setRange(dimensionRange.setSheetId(Integer.valueOf((int)n)).setDimension("ROWS").setStartIndex(Integer.valueOf((int)(this.val$rowNumber - 1))).setEndIndex(Integer.valueOf((int)this.val$rowNumber)));
                    dimensionRange = new ArrayList();
                    Request request2 = new Request();
                    dimensionRange.add((Object)request2.setDeleteDimension(deleteDimensionRequest));
                    deleteDimensionRequest = new BatchUpdateSpreadsheetRequest();
                    dimensionRange = deleteDimensionRequest.setRequests((List)dimensionRange);
                    object2.spreadsheets().batchUpdate(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), (BatchUpdateSpreadsheetRequest)dimensionRange).execute();
                    dimensionRange = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                    object2 = new Runnable(this){
                        final 7 this$1;
                        {
                            this.this$1 = var1;
                        }

                        public void run() {
                            this.this$1.this$0.FinishedRemoveRow();
                        }
                    };
                    dimensionRange.runOnUiThread((Runnable)object2);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    Spreadsheet spreadsheet = this.this$0;
                    String string = exception.getMessage();
                    spreadsheet.ErrorOccurred("RemoveRow: " + string);
                }
            }
        });
    }

    Runnable RetrieveSheet(String string, int n, String string2, boolean bl, boolean bl2) {
        return new Runnable(this, string, bl2, n, bl, string2){
            final Spreadsheet this$0;
            final int val$colID;
            final boolean val$exact;
            final boolean val$fireEvent;
            final String val$sheetName;
            final String val$value;
            {
                this.this$0 = spreadsheet;
                this.val$sheetName = string;
                this.val$fireEvent = bl;
                this.val$colID = n;
                this.val$exact = bl2;
                this.val$value = string2;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                if (Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0) != null && !Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0).isEmpty()) {
                    Object object22 = this.val$sheetName;
                    Log.d((String)"SPREADSHEET", (String)("Reading Sheet: " + (String)object22));
                    try {
                        object22 = Spreadsheet.-$$Nest$fgetcredentialsPath(this.this$0);
                        if (object22 == null) {
                            Log.d((String)"SPREADSHEET", (String)"Reading Sheet: No credentials");
                            try {
                                object22 = URLEncoder.encode((String)this.val$sheetName, (String)"UTF-8");
                            }
                            catch (UnsupportedEncodingException unsupportedEncodingException) {
                                this.this$0.ErrorOccurred("ReadRange: Error occurred encoding the query. UTF-8 is unsupported?");
                                return;
                            }
                            object22 = String.format((String)"https://docs.google.com/spreadsheets/d/%s/gviz/tq?tqx=out:csv&sheet=%s", (Object[])new Object[]{Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), object22});
                            URL uRL = new URL((String)object22);
                            uRL = (HttpURLConnection)uRL.openConnection();
                            uRL.setRequestMethod("GET");
                            if (uRL.getResponseCode() == 400) {
                                Spreadsheet spreadsheet = this.this$0;
                                uRL = new StringBuilder();
                                spreadsheet.ErrorOccurred(uRL.append("ReadSheet: Bad HTTP Request. Please check the address and try again. ").append((String)object22).toString());
                                return;
                            }
                            uRL = CsvUtil.fromCsvTable((String)Spreadsheet.-$$Nest$smgetResponseContent((HttpURLConnection)uRL));
                            Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            object22 = new Runnable(this, (YailList)uRL){
                                final 17 this$1;
                                final YailList val$parsedCsv;
                                {
                                    this.this$1 = var1;
                                    this.val$parsedCsv = yailList;
                                }

                                public void run() {
                                    Spreadsheet.-$$Nest$mupdateColumns(this.this$1.this$0, this.val$parsedCsv);
                                    this.this$1.this$0.notifyDataObservers(null, null);
                                    if (this.this$1.val$fireEvent) {
                                        if (this.this$1.val$colID >= 0) {
                                            YailList yailList = new YailList();
                                            String string = new YailList();
                                            int n = 0;
                                            while (true) {
                                                if (n >= this.val$parsedCsv.size()) break;
                                                YailList yailList2 = CsvUtil.fromCsvRow((String)this.val$parsedCsv.get(n).toString());
                                                int n2 = n;
                                                if (yailList2.size() >= this.this$1.val$colID) {
                                                    if (this.this$1.val$exact && yailList2.get(this.this$1.val$colID - 1).equals((Object)this.this$1.val$value) || !this.this$1.val$exact && yailList2.get(this.this$1.val$colID - 1).toString().contains((CharSequence)this.this$1.val$value)) {
                                                        yailList.add((Object)n);
                                                        string.add((Object)yailList2);
                                                    }
                                                    n2 = n + 1;
                                                }
                                                n = n2;
                                                continue;
                                                break;
                                            }
                                            try {
                                                this.this$1.this$0.GotFilterResult((List<Integer>)yailList, (List<List<String>>)string);
                                            }
                                            catch (Exception exception) {
                                                string = exception.getMessage();
                                                Log.d((String)"SPREADSHEET", (String)("ReadWithFilter (no creds) Error: " + string));
                                                this.this$1.this$0.ErrorOccurred(exception.getMessage());
                                            }
                                        } else {
                                            this.this$1.this$0.GotSheetData((List<List<String>>)this.val$parsedCsv);
                                        }
                                    }
                                }
                            };
                            activity.runOnUiThread(object22);
                            return;
                        }
                        Log.d((String)"SPREADSHEET", (String)"Reading Sheet: Credentials located.");
                        object22 = Spreadsheet.-$$Nest$mgetSheetsService(this.this$0);
                        Log.d((String)"SPREADSHEET", (String)"Reading Sheet: Got sheet service");
                        object22 = (ValueRange)object22.spreadsheets().values().get(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$sheetName).execute();
                        Log.d((String)"SPREADSHEET", (String)"Got read result");
                        object22 = object22.getValues();
                        int n = object22.size();
                        StringBuilder stringBuilder = new StringBuilder();
                        Log.d((String)"SPREADSHEET", (String)stringBuilder.append("Reading Sheet: values count ").append(n).toString());
                        if (object22 != null && !object22.isEmpty()) {
                            stringBuilder = new ArrayList();
                            StringBuilder stringBuilder2 = new StringBuilder();
                            Log.d((String)"SPREADSHEET", (String)stringBuilder2.append("RetriveSheet data: ").append(object22).toString());
                            stringBuilder2 = object22.iterator();
                            while (true) {
                                if (!stringBuilder2.hasNext()) {
                                    n = stringBuilder.size();
                                    object22 = new StringBuilder();
                                    Log.d((String)"SPREADSHEET", (String)object22.append("RetriveSheet return rowcount: ").append(n).toString());
                                    stringBuilder2 = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                                    object22 = new Runnable(this, (List)stringBuilder){
                                        final 17 this$1;
                                        final List val$ret;
                                        {
                                            this.this$1 = var1;
                                            this.val$ret = list;
                                        }

                                        public void run() {
                                            Spreadsheet.-$$Nest$mupdateColumns(this.this$1.this$0, YailList.makeList((List)this.val$ret));
                                            this.this$1.this$0.notifyDataObservers(null, null);
                                            Log.d((String)"SPREADSHEET", (String)"RetriveSheet UIThread ");
                                            if (this.this$1.val$colID >= 0) {
                                                String string;
                                                int n = this.this$1.val$colID;
                                                Log.d((String)"SPREADSHEET", (String)("RetriveWithFilter: colID " + n));
                                                ArrayList arrayList = new ArrayList();
                                                Object object2 = new ArrayList();
                                                n = 0;
                                                while (true) {
                                                    if (n >= this.val$ret.size()) break;
                                                    string = new StringBuilder();
                                                    Log.d((String)"SPREADSHEET", (String)string.append("Reading row row: ").append(n).toString());
                                                    string = (List)this.val$ret.get(n);
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    Log.d((String)"SPREADSHEET", (String)stringBuilder.append("Read with Filter row: ").append((Object)string).toString());
                                                    if (string.size() >= this.this$1.val$colID) {
                                                        String string2 = (String)string.get(this.this$1.val$colID - 1);
                                                        stringBuilder = new StringBuilder();
                                                        Log.d((String)"SPREADSHEET", (String)stringBuilder.append("Checking field : |").append(string2).append("|").toString());
                                                        if (this.this$1.val$exact && ((String)string.get(this.this$1.val$colID - 1)).equals((Object)this.this$1.val$value) || !this.this$1.val$exact && ((String)string.get(this.this$1.val$colID - 1)).contains((CharSequence)this.this$1.val$value)) {
                                                            stringBuilder = new StringBuilder();
                                                            Log.d((String)"SPREADSHEET", (String)stringBuilder.append("Read with Filter check col: ").append(n).toString());
                                                            arrayList.add((Object)(n + 1));
                                                            object2.add((Object)string);
                                                        }
                                                    }
                                                    ++n;
                                                    continue;
                                                    break;
                                                }
                                                try {
                                                    this.this$1.this$0.GotFilterResult((List<Integer>)arrayList, (List<List<String>>)object2);
                                                }
                                                catch (Exception exception) {
                                                    string = exception.getClass().getName();
                                                    object2 = exception.getMessage();
                                                    Log.d((String)"SPREADSHEET", (String)("Read with Filter Error: " + string + (String)object2));
                                                    this.this$1.this$0.ErrorOccurred(exception.getMessage());
                                                    return;
                                                }
                                            } else {
                                                this.this$1.this$0.GotSheetData((List<List<String>>)this.val$ret);
                                            }
                                        }
                                    };
                                    stringBuilder2.runOnUiThread(object22);
                                    return;
                                }
                                object22 = (List)stringBuilder2.next();
                                ArrayList arrayList = new ArrayList();
                                for (Object object22 : object22) {
                                    if (object22 == null) {
                                        object22 = "";
                                    }
                                    arrayList.add((Object)String.format((String)"%s", (Object[])new Object[]{object22}));
                                }
                                stringBuilder.add((Object)arrayList);
                            }
                        }
                        this.this$0.ErrorOccurred("ReadSheet: No data found.");
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        object22 = this.this$0;
                        String string = exception.getMessage();
                        object22.ErrorOccurred("RetrieveSheet Error: " + string);
                    }
                    return;
                }
                this.this$0.ErrorOccurred("ReadSheet: SpreadsheetID is empty.");
            }
        };
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String SpreadsheetID() {
        return this.spreadsheetID;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(description="The ID for the Google Sheets file you want to edit. You can find the spreadsheetID in the URL of the Google Sheets file.")
    public void SpreadsheetID(String string) {
        String string2 = string;
        if (string.startsWith("https:")) {
            string2 = string.substring(8).split("/")[3];
        }
        this.spreadsheetID = string2;
    }

    @SimpleFunction(description="Given text or a number as `data`, writes the value into the cell. Once complete, it triggers the FinishedWriteCell callback event")
    public void WriteCell(String string, String string2, Object object2) {
        if (this.spreadsheetID == "") {
            this.ErrorOccurred("WriteCell: SpreadsheetID is empty.");
            return;
        }
        if (this.credentialsPath == null) {
            this.ErrorOccurred("WriteCell: Credentials JSON is required.");
            return;
        }
        string = string + "!" + string2;
        string2 = new ValueRange().setValues(Arrays.asList((Object[])new List[]{Arrays.asList((Object[])new Object[]{Spreadsheet.sanitizeObject(object2)})}));
        Log.d((String)LOG_TAG, (String)("Writing Cell: " + string));
        AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, (ValueRange)string2){
            final Spreadsheet this$0;
            final ValueRange val$body;
            final String val$rangeRef;
            {
                this.this$0 = spreadsheet;
                this.val$rangeRef = string;
                this.val$body = valueRange;
            }

            public void run() {
                try {
                    Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().update(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeRef, this.val$body).setValueInputOption("USER_ENTERED").execute();
                    Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                    Runnable runnable = new Runnable(this){
                        final 13 this$1;
                        {
                            this.this$1 = var1;
                        }

                        public void run() {
                            this.this$1.this$0.FinishedWriteCell();
                        }
                    };
                    activity.runOnUiThread(runnable);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    Spreadsheet spreadsheet = this.this$0;
                    String string = exception.getMessage();
                    spreadsheet.ErrorOccurred("WriteCell: " + string);
                }
            }
        });
    }

    @SimpleFunction(description="Given a list of values as `data`, this method will write the values to the column of the sheet and calls the FinishedWriteColumn event once complete.")
    public void WriteColumn(String string, String string2, YailList yailList) {
        String string3 = this.spreadsheetID;
        if (string3 != null && !string3.isEmpty()) {
            string3 = this.credentialsPath;
            if (string3 != null && !string3.isEmpty()) {
                string3 = string2;
                if (INTEGER.matcher((CharSequence)string2).matches()) {
                    string3 = super.getColString(Integer.parseInt((String)string2));
                }
                string = string + "!" + string3 + ":" + string3;
                string2 = new ArrayList();
                yailList = ((LList)yailList.getCdr()).iterator();
                while (yailList.hasNext()) {
                    string2.add((Object)new ArrayList((Collection)Collections.singletonList((Object)Spreadsheet.sanitizeObject(yailList.next()))));
                }
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, new ValueRange().setValues((List)string2)){
                    final Spreadsheet this$0;
                    final ValueRange val$body;
                    final String val$rangeRef;
                    {
                        this.this$0 = spreadsheet;
                        this.val$rangeRef = string;
                        this.val$body = valueRange;
                    }

                    public void run() {
                        try {
                            Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().update(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeRef, this.val$body).setValueInputOption("USER_ENTERED").execute();
                            Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            Runnable runnable = new Runnable(this){
                                final 9 this$1;
                                {
                                    this.this$1 = var1;
                                }

                                public void run() {
                                    this.this$1.this$0.FinishedWriteColumn();
                                }
                            };
                            activity.runOnUiThread(runnable);
                        }
                        catch (GeneralSecurityException generalSecurityException) {
                            generalSecurityException.printStackTrace();
                            Spreadsheet spreadsheet = this.this$0;
                            String string = generalSecurityException.getMessage();
                            spreadsheet.ErrorOccurred("WriteColumn GeneralSecurityException: " + string);
                        }
                        catch (IOException iOException) {
                            iOException.printStackTrace();
                            Spreadsheet spreadsheet = this.this$0;
                            String string = iOException.getMessage();
                            spreadsheet.ErrorOccurred("WriteColumn IOException: " + string);
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("WriteColumn: Credentials JSON is required.");
            return;
        }
        this.ErrorOccurred("WriteColumn: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Given list of lists as `data`, writes the values into the range. The number of rows and columns in the range reference must match the dimensions of the data.")
    public void WriteRange(String string, String string2, YailList object2) {
        Object object3 = this.spreadsheetID;
        if (object3 != "" && object3 != null) {
            if (this.credentialsPath == null) {
                this.ErrorOccurred("WriteRange: Credentials JSON is required.");
                return;
            }
            string = string + "!" + string2;
            Log.d((String)LOG_TAG, (String)("Writing Range: " + string));
            string2 = new ArrayList();
            int n = -1;
            object2 = ((LList)object2.getCdr()).iterator();
            while (object2.hasNext()) {
                object3 = object2.next();
                if (!(object3 instanceof YailList)) continue;
                object3 = Spreadsheet.sanitizeList((YailList)object3);
                string2.add(object3);
                int n2 = n;
                if (n == -1) {
                    n2 = object3.size();
                }
                if (object3.size() != n2) {
                    this.ErrorOccurred("WriteRange: Rows must have the same length");
                    return;
                }
                n = n2;
            }
            if (string2.size() == 0) {
                this.ErrorOccurred("WriteRange: Data must be a list of lists.");
                return;
            }
            string2 = new ValueRange().setValues((List)string2);
            object2 = string2.getRange();
            Log.d((String)LOG_TAG, (String)("Body's Range in A1: " + (String)object2));
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, (ValueRange)string2){
                final Spreadsheet this$0;
                final ValueRange val$body;
                final String val$rangeRef;
                {
                    this.this$0 = spreadsheet;
                    this.val$rangeRef = string;
                    this.val$body = valueRange;
                }

                public void run() {
                    try {
                        Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().update(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeRef, this.val$body).setValueInputOption("USER_ENTERED").execute();
                        Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                        Runnable runnable = new Runnable(this){
                            final 15 this$1;
                            {
                                this.this$1 = var1;
                            }

                            public void run() {
                                this.this$1.this$0.FinishedWriteRange();
                            }
                        };
                        activity.runOnUiThread(runnable);
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        Spreadsheet spreadsheet = this.this$0;
                        String string = exception.getMessage();
                        spreadsheet.ErrorOccurred("WriteRange: " + string);
                    }
                }
            });
            return;
        }
        this.ErrorOccurred("WriteRange: SpreadsheetID is empty.");
    }

    @SimpleFunction(description="Given a list of values as `data`, writes the values to the row of the sheet with the given row number.")
    public void WriteRow(String string, int n, YailList yailList) {
        Object object2 = this.spreadsheetID;
        if (object2 != "" && object2 != null) {
            object2 = this.credentialsPath;
            if (object2 != "" && object2 != null) {
                string = String.format((String)"%s!A%d", (Object[])new Object[]{string, n});
                object2 = (LList)yailList.getCdr();
                yailList = new ArrayList();
                yailList.add((Object)new ArrayList((Collection)object2));
                AsynchUtil.runAsynchronously((Runnable)new Runnable((Spreadsheet)this, string, new ValueRange().setValues((List)yailList)){
                    final Spreadsheet this$0;
                    final ValueRange val$body;
                    final String val$rangeRef;
                    {
                        this.this$0 = spreadsheet;
                        this.val$rangeRef = string;
                        this.val$body = valueRange;
                    }

                    public void run() {
                        try {
                            Spreadsheet.-$$Nest$mgetSheetsService(this.this$0).spreadsheets().values().update(Spreadsheet.-$$Nest$fgetspreadsheetID(this.this$0), this.val$rangeRef, this.val$body).setValueInputOption("USER_ENTERED").execute();
                            Activity activity = Spreadsheet.-$$Nest$fgetactivity(this.this$0);
                            Runnable runnable = new Runnable(this){
                                final 3 this$1;
                                {
                                    this.this$1 = var1;
                                }

                                public void run() {
                                    this.this$1.this$0.FinishedWriteRow();
                                }
                            };
                            activity.runOnUiThread(runnable);
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            Spreadsheet spreadsheet = this.this$0;
                            String string = exception.getMessage();
                            spreadsheet.ErrorOccurred("WriteRow: " + string);
                        }
                    }
                });
                return;
            }
            this.ErrorOccurred("WriteRow: Credentials JSON file is required.");
            return;
        }
        this.ErrorOccurred("WriteRow: SpreadsheetID is empty.");
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.observers.add((Object)dataSourceChangeListener);
    }

    YailList getColumns(YailList yailList, boolean bl) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < yailList.size(); ++i) {
            Object object2 = yailList.getString(i);
            if (bl) {
                object2 = super.getColumn((String)object2);
            } else {
                int n = 0;
                object2 = object2.toCharArray();
                int n2 = ((Object)object2).length;
                for (int j = 0; j < n2; ++j) {
                    n = n * 26 + (object2[j] - 65);
                }
                object2 = super.getColumn(n);
            }
            arrayList.add(object2);
        }
        return YailList.makeList((List)arrayList);
    }

    public Future<YailList> getDataValue(YailList yailList) {
        return this.getDataValue(yailList, false);
    }

    public Future<YailList> getDataValue(YailList yailList, boolean bl) {
        yailList = new FutureTask((Callable)new Callable<YailList>((Spreadsheet)this, this.lastTask, yailList, bl){
            final Spreadsheet this$0;
            final FutureTask val$currentTask;
            final YailList val$key;
            final boolean val$useHeaders;
            {
                this.this$0 = spreadsheet;
                this.val$currentTask = futureTask;
                this.val$key = yailList;
                this.val$useHeaders = bl;
            }

            public YailList call() throws Exception {
                FutureTask futureTask = this.val$currentTask;
                if (futureTask != null && !futureTask.isDone() && !this.val$currentTask.isCancelled()) {
                    try {
                        this.val$currentTask.get();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
                return this.this$0.getColumns(this.val$key, this.val$useHeaders);
            }
        });
        AsynchUtil.runAsynchronously((Runnable)yailList);
        return yailList;
    }

    public void notifyDataObservers(YailList yailList, Object object2) {
        yailList = this.observers.iterator();
        while (yailList.hasNext()) {
            ((DataSourceChangeListener)yailList.next()).onDataSourceValueChange((DataSource<?, ?>)this, null, this.columns);
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.observers.remove((Object)dataSourceChangeListener);
    }
}

