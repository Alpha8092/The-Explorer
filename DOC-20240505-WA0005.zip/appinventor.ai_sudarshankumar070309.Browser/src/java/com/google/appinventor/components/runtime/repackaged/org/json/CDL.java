/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONArray;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;

public class CDL {
    private static String getValue(JSONTokener jSONTokener) throws JSONException {
        char c;
        while ((c = jSONTokener.next()) == ' ' || c == '\t') {
        }
        switch (c) {
            default: {
                jSONTokener.back();
                return jSONTokener.nextTo(',');
            }
            case ',': {
                jSONTokener.back();
                return "";
            }
            case '\"': 
            case '\'': {
                StringBuffer stringBuffer = new StringBuffer();
                while (true) {
                    char c2;
                    if ((c2 = jSONTokener.next()) == c) {
                        return stringBuffer.toString();
                    }
                    if (c2 == '\u0000' || c2 == '\n' || c2 == '\r') break;
                    stringBuffer.append(c2);
                }
                throw jSONTokener.syntaxError(new StringBuffer().append("Missing close quote '").append(c).append("'.").toString());
            }
            case '\u0000': 
        }
        return null;
    }

    public static JSONArray rowToJSONArray(JSONTokener jSONTokener) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        block0: while (true) {
            String string = CDL.getValue(jSONTokener);
            char c = jSONTokener.next();
            if (string == null || jSONArray.length() == 0 && string.length() == 0 && c != ',') break;
            jSONArray.put(string);
            while (true) {
                if (c == ',') continue block0;
                if (c != ' ') {
                    if (c != '\n' && c != '\r' && c != '\u0000') {
                        throw jSONTokener.syntaxError(new StringBuffer().append("Bad character '").append(c).append("' (").append((int)c).append(").").toString());
                    }
                    return jSONArray;
                }
                c = jSONTokener.next();
            }
            break;
        }
        return null;
    }

    public static JSONObject rowToJSONObject(JSONArray jSONArray, JSONTokener object) throws JSONException {
        jSONArray = (object = CDL.rowToJSONArray((JSONTokener)object)) != null ? ((JSONArray)object).toJSONObject(jSONArray) : null;
        return jSONArray;
    }

    public static String rowToString(JSONArray jSONArray) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < jSONArray.length(); ++i) {
            Object object;
            if (i > 0) {
                stringBuffer.append(',');
            }
            if ((object = jSONArray.opt(i)) == null) continue;
            if ((object = object.toString()).length() > 0 && (object.indexOf(44) >= 0 || object.indexOf(10) >= 0 || object.indexOf(13) >= 0 || object.indexOf(0) >= 0 || object.charAt(0) == '\"')) {
                stringBuffer.append('\"');
                int n = object.length();
                for (int j = 0; j < n; ++j) {
                    char c = object.charAt(j);
                    if (c < ' ' || c == '\"') continue;
                    stringBuffer.append(c);
                }
                stringBuffer.append('\"');
                continue;
            }
            stringBuffer.append((String)object);
        }
        stringBuffer.append('\n');
        return stringBuffer.toString();
    }

    public static JSONArray toJSONArray(JSONArray jSONArray, JSONTokener jSONTokener) throws JSONException {
        if (jSONArray != null && jSONArray.length() != 0) {
            JSONArray jSONArray2 = new JSONArray();
            while (true) {
                JSONObject jSONObject;
                if ((jSONObject = CDL.rowToJSONObject(jSONArray, jSONTokener)) == null) {
                    if (jSONArray2.length() == 0) {
                        return null;
                    }
                    return jSONArray2;
                }
                jSONArray2.put(jSONObject);
            }
        }
        return null;
    }

    public static JSONArray toJSONArray(JSONArray jSONArray, String string) throws JSONException {
        return CDL.toJSONArray(jSONArray, new JSONTokener(string));
    }

    public static JSONArray toJSONArray(JSONTokener jSONTokener) throws JSONException {
        return CDL.toJSONArray(CDL.rowToJSONArray(jSONTokener), jSONTokener);
    }

    public static JSONArray toJSONArray(String string) throws JSONException {
        return CDL.toJSONArray(new JSONTokener(string));
    }

    public static String toString(JSONArray jSONArray) throws JSONException {
        Object object = jSONArray.optJSONObject(0);
        if (object != null && (object = object.names()) != null) {
            return new StringBuffer().append(CDL.rowToString((JSONArray)object)).append(CDL.toString((JSONArray)object, jSONArray)).toString();
        }
        return null;
    }

    public static String toString(JSONArray jSONArray, JSONArray jSONArray2) throws JSONException {
        if (jSONArray != null && jSONArray.length() != 0) {
            StringBuffer stringBuffer = new StringBuffer();
            for (int i = 0; i < jSONArray2.length(); ++i) {
                JSONObject jSONObject = jSONArray2.optJSONObject(i);
                if (jSONObject == null) continue;
                stringBuffer.append(CDL.rowToString(jSONObject.toJSONArray(jSONArray)));
            }
            return stringBuffer.toString();
        }
        return null;
    }
}

