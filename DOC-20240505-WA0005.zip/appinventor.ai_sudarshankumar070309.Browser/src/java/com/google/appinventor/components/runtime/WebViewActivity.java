/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;

public final class WebViewActivity
extends AppInventorCompatActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        bundle = new WebView((Context)this);
        bundle.getSettings().setJavaScriptEnabled(true);
        bundle.setWebViewClient(new WebViewClient((WebViewActivity)this){
            final WebViewActivity this$0;
            {
                this.this$0 = webViewActivity;
            }

            public boolean shouldOverrideUrlLoading(WebView webView, String string) {
                Log.i((String)"WebView", (String)("Handling url " + string));
                Uri uri = Uri.parse((String)string);
                if (uri.getScheme().equals((Object)"appinventor")) {
                    webView = new Intent();
                    webView.setData(uri);
                    this.this$0.setResult(-1, (Intent)webView);
                    this.this$0.finish();
                } else {
                    webView.loadUrl(string);
                }
                return true;
            }
        });
        this.setContentView((View)bundle);
        Object object2 = this.getIntent();
        if (object2 != null && object2.getData() != null) {
            Uri uri = object2.getData();
            object2 = uri.getScheme();
            String string = uri.getHost();
            Log.i((String)"WebView", (String)("Got intent with URI: " + uri + ", scheme=" + (String)object2 + ", host=" + string));
            bundle.loadUrl(uri.toString());
        }
    }
}

