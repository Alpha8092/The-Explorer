/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.ElementType
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.lang.annotation.Target
 */
package com.google.appinventor.components.annotations;

import com.google.appinventor.components.common.ComponentCategory;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.TYPE})
public @interface DesignerComponent {
    public int androidMinSdk() default 7;

    public ComponentCategory category() default ComponentCategory.UNINITIALIZED;

    public String dateBuilt() default "";

    public String description() default "";

    public String designerHelpDescription() default "";

    public String helpUrl() default "";

    public String iconName() default "";

    public String licenseName() default "";

    public boolean nonVisible() default false;

    public boolean showOnPalette() default true;

    public int version();

    public String versionName() default "";
}

