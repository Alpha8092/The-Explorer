/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.util.Log
 *  android.view.Display
 *  android.view.WindowManager
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  com.google.appinventor.components.runtime.util.FroyoUtil
 *  com.google.appinventor.components.runtime.util.OrientationSensorUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import com.google.appinventor.components.runtime.util.FroyoUtil;
import com.google.appinventor.components.runtime.util.OrientationSensorUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@DesignerComponent(category=ComponentCategory.SENSORS, description="<p>Non-visible component providing information about the device's physical orientation in three dimensions: <ul> <li> <strong>Roll</strong>: 0 degrees when the device is level, increases to      90 degrees as the device is tilted up on its left side, and      decreases to -90 degrees when the device is tilted up on its right side.      </li> <li> <strong>Pitch</strong>: 0 degrees when the device is level, up to      90 degrees as the device is tilted so its top is pointing down,      up to 180 degrees as it gets turned over.  Similarly, as the device      is tilted so its bottom points down, pitch decreases to -90      degrees, then further decreases to -180 degrees as it gets turned all the way      over.</li> <li> <strong>Azimuth</strong>: 0 degrees when the top of the device is      pointing north, 90 degrees when it is pointing east, 180 degrees      when it is pointing south, 270 degrees when it is pointing west,      etc.</li></ul>     These measurements assume that the device itself is not moving.</p>", iconName="images/orientationsensor.png", nonVisible=true, version=2)
@SimpleObject
public class OrientationSensor
extends AndroidNonvisibleComponent
implements SensorEventListener,
Deleteable,
OnPauseListener,
OnResumeListener,
RealTimeDataSource<String, Float> {
    private static final int AZIMUTH = 0;
    private static final int DIMENSIONS = 3;
    private static final String LOG_TAG = "OrientationSensor";
    private static final int PITCH = 1;
    private static final int ROLL = 2;
    private final Sensor accelerometerSensor;
    private final float[] accels = new float[3];
    private boolean accelsFilled;
    private int accuracy;
    private float azimuth;
    private Set<DataSourceChangeListener> dataSourceObservers;
    private boolean enabled;
    private final float[] inclinationMatrix;
    private boolean listening;
    private final Sensor magneticFieldSensor;
    private final float[] mags = new float[3];
    private boolean magsFilled;
    private float pitch;
    private float roll;
    private final float[] rotationMatrix = new float[9];
    private final SensorManager sensorManager;
    private final float[] values;

    public OrientationSensor(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.inclinationMatrix = new float[9];
        this.values = new float[3];
        this.dataSourceObservers = new HashSet();
        componentContainer = (SensorManager)componentContainer.$context().getSystemService("sensor");
        this.sensorManager = componentContainer;
        this.accelerometerSensor = componentContainer.getDefaultSensor(1);
        this.magneticFieldSensor = componentContainer.getDefaultSensor(2);
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        this.Enabled(true);
    }

    static float computeAngle(float f, float f2) {
        return (float)Math.toDegrees((double)Math.atan2((double)Math.toRadians((double)f), (double)(-Math.toRadians((double)f2))));
    }

    private int getScreenRotation() {
        Display display = ((WindowManager)this.form.getSystemService("window")).getDefaultDisplay();
        if (SdkLevel.getLevel() >= 8) {
            return FroyoUtil.getRotation((Display)display);
        }
        return display.getOrientation();
    }

    private void startListening() {
        if (!this.listening) {
            this.sensorManager.registerListener((SensorEventListener)this, this.accelerometerSensor, 3);
            this.sensorManager.registerListener((SensorEventListener)this, this.magneticFieldSensor, 3);
            this.listening = true;
        }
    }

    private void stopListening() {
        if (this.listening) {
            this.sensorManager.unregisterListener((SensorEventListener)this);
            this.listening = false;
            this.accelsFilled = false;
            this.magsFilled = false;
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public float Angle() {
        return OrientationSensor.computeAngle(this.pitch, this.roll);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Available() {
        SensorManager sensorManager = this.sensorManager;
        boolean bl = true;
        if (sensorManager.getSensorList(1).size() <= 0 || this.sensorManager.getSensorList(2).size() <= 0) {
            bl = false;
        }
        return bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public float Azimuth() {
        return this.azimuth;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void Enabled(boolean bl) {
        if (this.enabled != bl) {
            this.enabled = bl;
            if (bl) {
                super.startListening();
            } else {
                super.stopListening();
            }
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Enabled() {
        return this.enabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public float Magnitude() {
        double d = Math.toRadians((double)Math.min((float)90.0f, (float)Math.abs((float)this.pitch)));
        double d2 = Math.toRadians((double)Math.min((float)90.0f, (float)Math.abs((float)this.roll)));
        return (float)(1.0 - Math.cos((double)d) * Math.cos((double)d2));
    }

    @SimpleEvent(description="Called when the orientation has changed.")
    public void OrientationChanged(float f, float f2, float f3) {
        this.notifyDataObservers("azimuth", (Object)Float.valueOf((float)f));
        this.notifyDataObservers("pitch", (Object)Float.valueOf((float)f2));
        this.notifyDataObservers("roll", (Object)Float.valueOf((float)f3));
        EventDispatcher.dispatchEvent((Component)this, "OrientationChanged", Float.valueOf((float)f), Float.valueOf((float)f2), Float.valueOf((float)f3));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public float Pitch() {
        return this.pitch;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public float Roll() {
        return this.roll;
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Float getDataValue(String string) {
        int n;
        block10: {
            switch (string.hashCode()) {
                case 106677056: {
                    if (!string.equals((Object)"pitch")) break;
                    n = 1;
                    break block10;
                }
                case 3506301: {
                    if (!string.equals((Object)"roll")) break;
                    n = 2;
                    break block10;
                }
                case -513366676: {
                    if (!string.equals((Object)"azimuth")) break;
                    n = 0;
                    break block10;
                }
            }
            n = -1;
        }
        switch (n) {
            default: {
                return Float.valueOf((float)0.0f);
            }
            case 2: {
                return Float.valueOf((float)this.roll);
            }
            case 1: {
                return Float.valueOf((float)this.pitch);
            }
            case 0: 
        }
        return Float.valueOf((float)this.azimuth);
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    @Override
    public void onDelete() {
        this.stopListening();
    }

    @Override
    public void onPause() {
        this.stopListening();
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.startListening();
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.enabled) {
            int n = sensorEvent.sensor.getType();
            switch (n) {
                default: {
                    Log.e((String)LOG_TAG, (String)("Unexpected sensor type: " + n));
                    return;
                }
                case 2: {
                    System.arraycopy((Object)sensorEvent.values, (int)0, (Object)this.mags, (int)0, (int)3);
                    this.magsFilled = true;
                    break;
                }
                case 1: {
                    System.arraycopy((Object)sensorEvent.values, (int)0, (Object)this.accels, (int)0, (int)3);
                    this.accelsFilled = true;
                    this.accuracy = sensorEvent.accuracy;
                }
            }
            if (this.accelsFilled && this.magsFilled) {
                SensorManager.getRotationMatrix((float[])this.rotationMatrix, (float[])this.inclinationMatrix, (float[])this.accels, (float[])this.mags);
                SensorManager.getOrientation((float[])this.rotationMatrix, (float[])this.values);
                this.azimuth = OrientationSensorUtil.normalizeAzimuth((float)((float)Math.toDegrees((double)this.values[0])));
                this.pitch = OrientationSensorUtil.normalizePitch((float)((float)Math.toDegrees((double)this.values[1])));
                this.roll = OrientationSensorUtil.normalizeRoll((float)((float)(-Math.toDegrees((double)this.values[2]))));
                n = super.getScreenRotation();
                switch (n) {
                    default: {
                        Log.e((String)LOG_TAG, (String)("Illegal value for getScreenRotation(): " + n));
                        break;
                    }
                    case 3: {
                        float f = this.pitch;
                        this.pitch = this.roll;
                        this.roll = f;
                        break;
                    }
                    case 2: {
                        this.roll = -this.roll;
                        break;
                    }
                    case 1: {
                        float f = -this.pitch;
                        this.pitch = -this.roll;
                        this.roll = f;
                    }
                    case 0: 
                }
                this.OrientationChanged(this.azimuth, this.pitch, this.roll);
            }
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }
}

