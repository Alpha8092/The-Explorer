/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 */
package com.google.appinventor.components.runtime.errors;

public final class StopBlocksExecution
extends RuntimeException {
}

