/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.github.mikephil.charting.charts.LineChart
 *  com.github.mikephil.charting.data.ChartData
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.data.LineData
 *  com.github.mikephil.charting.interfaces.dataprovider.LineDataProvider
 *  com.github.mikephil.charting.interfaces.datasets.ILineDataSet
 *  com.github.mikephil.charting.renderer.DataRenderer
 *  com.google.appinventor.components.runtime.Chart
 *  com.google.appinventor.components.runtime.util.LineWithTrendlineRenderer
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.interfaces.dataprovider.LineDataProvider;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.renderer.DataRenderer;
import com.google.appinventor.components.runtime.Chart;
import com.google.appinventor.components.runtime.PointChartView;
import com.google.appinventor.components.runtime.util.LineWithTrendlineRenderer;

public abstract class LineChartViewBase<V extends LineChartViewBase<V>>
extends PointChartView<Entry, ILineDataSet, LineData, LineChart, V> {
    protected LineChartViewBase(Chart chart) {
        super(chart);
        this.chart = new LineChart((Context)this.form);
        ((LineChart)this.chart).setRenderer((DataRenderer)new LineWithTrendlineRenderer((LineDataProvider)this.chart, ((LineChart)this.chart).getAnimator(), ((LineChart)this.chart).getViewPortHandler()));
        this.data = new LineData();
        ((LineChart)this.chart).setData((ChartData)((LineData)this.data));
        this.initializeDefaultSettings();
    }
}

