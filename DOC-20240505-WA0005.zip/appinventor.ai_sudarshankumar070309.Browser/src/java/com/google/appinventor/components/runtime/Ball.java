/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  com.google.appinventor.components.runtime.Sprite
 *  com.google.appinventor.components.runtime.util.PaintUtil
 *  java.lang.Double
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Sprite;
import com.google.appinventor.components.runtime.util.PaintUtil;

@DesignerComponent(category=ComponentCategory.ANIMATION, description="<p>A round 'sprite' that can be placed on a <code>Canvas</code>, where it can react to touches and drags, interact with other sprites (<code>ImageSprite</code>s and other <code>Ball</code>s) and the edge of the Canvas, and move according to its property values.</p><p>For example, to have a <code>Ball</code> move 4 pixels toward the top of a <code>Canvas</code> every 500 milliseconds (half second), you would set the <code>Speed</code> property to 4 [pixels], the <code>Interval</code> property to 500 [milliseconds], the <code>Heading</code> property to 90 [degrees], and the <code>Enabled</code> property to <code>True</code>.</p><p>The difference between a <code>Ball</code> and an <code>ImageSprite</code> is that the latter can get its appearance from an image file, while a <code>Ball</code>'s appearance can be changed only by varying its <code>PaintColor</code> and <code>Radius</code> properties.</p>", iconName="images/ball.png", version=8)
@SimpleObject
public final class Ball
extends Sprite {
    static final int DEFAULT_RADIUS = 5;
    private Paint paint = new Paint();
    private int paintColor;
    private int radius;

    public Ball(ComponentContainer componentContainer) {
        super(componentContainer);
        this.PaintColor(-16777216);
        this.Radius(5);
    }

    public int Height() {
        return this.radius * 2;
    }

    public void Height(int n) {
    }

    public void HeightPercent(int n) {
    }

    @SimpleFunction(description="Sets the x and y coordinates of the Ball. If CenterAtOrigin is true, the center of the Ball will be placed here. Otherwise, the top left edge of the Ball will be placed at the specified coordinates.")
    public void MoveTo(double d, double d2) {
        super.MoveTo(d, d2);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the x- and y-coordinates should represent the center of the Ball (true) or its left and top edges (false).", userVisible=false)
    public void OriginAtCenter(boolean bl) {
        super.OriginAtCenter(bl);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The color of the Ball.")
    public int PaintColor() {
        return this.paintColor;
    }

    @DesignerProperty(defaultValue="&HFF000000", editorType="color")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void PaintColor(int n) {
        this.paintColor = n;
        if (n != 0) {
            PaintUtil.changePaint((Paint)this.paint, (int)n);
        } else {
            PaintUtil.changePaint((Paint)this.paint, (int)-16777216);
        }
        this.registerChange();
    }

    @SimpleProperty
    public int Radius() {
        return this.radius;
    }

    @DesignerProperty(defaultValue="5", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The distance from the edge of the Ball to its center.")
    public void Radius(int n) {
        int n2 = n - this.radius;
        if (this.originAtCenter) {
            double d = this.xLeft;
            double d2 = n2;
            Double.isNaN((double)d2);
            this.xLeft = d - d2;
            d2 = this.yTop;
            d = n2;
            Double.isNaN((double)d);
            this.yTop = d2 - d;
        }
        this.radius = n;
        this.registerChange();
    }

    public int Width() {
        return this.radius * 2;
    }

    public void Width(int n) {
    }

    public void WidthPercent(int n) {
    }

    @SimpleProperty(description="The horizontal coordinate of the Ball, increasing as the Ball moves right. If the property OriginAtCenter is true, the coordinate is for the center of the Ball; otherwise, it is for the leftmost point of the Ball.")
    public double X() {
        return super.X();
    }

    @SimpleProperty(description="The vertical coordinate of the Ball, increasing as the Ball moves down. If the property OriginAtCenter is true, the coordinate is for the center of the Ball; otherwise, it is for the uppermost point of the Ball.")
    public double Y() {
        return super.Y();
    }

    public boolean containsPoint(double d, double d2) {
        double d3 = this.xCenter;
        double d4 = this.xCenter;
        double d5 = this.yCenter;
        double d6 = this.yCenter;
        int n = this.radius;
        boolean bl = (d - d3) * (d - d4) + (d2 - d5) * (d2 - d6) <= (double)(n * n);
        return bl;
    }

    protected void onDraw(Canvas canvas) {
        if (this.visible) {
            double d = this.xLeft;
            double d2 = this.form.deviceDensity();
            Double.isNaN((double)d2);
            float f = (float)(d * d2);
            d2 = this.yTop;
            d = this.form.deviceDensity();
            Double.isNaN((double)d);
            float f2 = (float)(d2 * d);
            float f3 = (float)this.radius * this.form.deviceDensity();
            canvas.drawCircle(f + f3, f2 + f3, f3, this.paint);
        }
    }
}

