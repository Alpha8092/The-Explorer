/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build$VERSION
 *  android.util.Log
 *  dalvik.system.DexFile
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Array
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashSet
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.Set
 *  java.util.regex.Pattern
 *  java.util.zip.ZipFile
 */
package com.google.appinventor.components.runtime.multidex;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import com.google.appinventor.components.runtime.multidex.MultiDexExtractor;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class MultiDex {
    private static final boolean IS_VM_MULTIDEX_CAPABLE;
    private static final int MAX_SUPPORTED_SDK_VERSION = 20;
    private static final int MIN_SDK_VERSION = 4;
    private static final String OLD_SECONDARY_FOLDER_NAME = "secondary-dexes";
    private static final String SECONDARY_FOLDER_NAME;
    static final String TAG = "MultiDex";
    private static final int VM_WITH_MULTIDEX_VERSION_MAJOR = 2;
    private static final int VM_WITH_MULTIDEX_VERSION_MINOR = 1;
    private static final Set<String> installedApk;

    static {
        String string = File.separator;
        SECONDARY_FOLDER_NAME = "code_cache" + string + OLD_SECONDARY_FOLDER_NAME;
        installedApk = new HashSet();
        IS_VM_MULTIDEX_CAPABLE = MultiDex.isVMMultidexCapable(System.getProperty((String)"java.vm.version"));
    }

    private MultiDex() {
    }

    private static boolean checkValidZipFiles(List<File> iterator) {
        iterator = iterator.iterator();
        while (iterator.hasNext()) {
            if (MultiDexExtractor.verifyZipFile((File)iterator.next())) continue;
            return false;
        }
        return true;
    }

    private static void clearOldDexDir(Context object) throws Exception {
        if ((object = new File(object.getFilesDir(), OLD_SECONDARY_FOLDER_NAME)).isDirectory()) {
            File[] fileArray = object.getPath();
            Log.i((String)TAG, (String)("Clearing old secondary dex dir (" + (String)fileArray + ")."));
            fileArray = object.listFiles();
            if (fileArray == null) {
                object = object.getPath();
                Log.w((String)TAG, (String)("Failed to list secondary dex dir content (" + (String)object + ")."));
                return;
            }
            for (File file : fileArray) {
                String string = file.getPath();
                long l = file.length();
                Log.i((String)TAG, (String)("Trying to delete old file " + string + " of size " + l));
                if (!file.delete()) {
                    string = file.getPath();
                    Log.w((String)TAG, (String)("Failed to delete old file " + string));
                    continue;
                }
                string = file.getPath();
                Log.i((String)TAG, (String)("Deleted old file " + string));
            }
            if (!object.delete()) {
                object = object.getPath();
                Log.w((String)TAG, (String)("Failed to delete secondary dex dir " + (String)object));
            } else {
                object = object.getPath();
                Log.i((String)TAG, (String)("Deleted old secondary dex dir " + (String)object));
            }
        }
    }

    private static void expandFieldArray(Object object, String objectArray, Object[] objectArray2) throws NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Field field = MultiDex.findField(object, (String)objectArray);
        objectArray = (Object[])field.get(object);
        Object[] objectArray3 = (Object[])Array.newInstance((Class)objectArray.getClass().getComponentType(), (int)(objectArray.length + objectArray2.length));
        System.arraycopy((Object)objectArray, (int)0, (Object)objectArray3, (int)0, (int)objectArray.length);
        System.arraycopy((Object)objectArray2, (int)0, (Object)objectArray3, (int)objectArray.length, (int)objectArray2.length);
        field.set(object, (Object)objectArray3);
    }

    private static Field findField(Object object, String string) throws NoSuchFieldException {
        for (Class clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                Field field = clazz.getDeclaredField(string);
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                return field;
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
        }
        object = object.getClass();
        object = new NoSuchFieldException("Field " + string + " not found in " + object);
        throw object;
    }

    private static Method findMethod(Object object, String string, Class<?> ... list) throws NoSuchMethodException {
        for (Class clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                Method method = clazz.getDeclaredMethod(string, (Class[])list);
                if (!method.isAccessible()) {
                    method.setAccessible(true);
                }
                return method;
            }
            catch (NoSuchMethodException noSuchMethodException) {
                continue;
            }
        }
        list = Arrays.asList((Object[])list);
        object = object.getClass();
        object = new NoSuchMethodException("Method " + string + " with parameters " + list + " not found in " + object);
        throw object;
    }

    private static ApplicationInfo getApplicationInfo(Context object) throws PackageManager.NameNotFoundException {
        block2: {
            PackageManager packageManager;
            try {
                packageManager = object.getPackageManager();
                object = object.getPackageName();
                if (packageManager == null || object == null) break block2;
            }
            catch (RuntimeException runtimeException) {
                Log.w((String)TAG, (String)"Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", (Throwable)runtimeException);
                return null;
            }
            return packageManager.getApplicationInfo((String)object, 128);
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean install(Context object, boolean bl) {
        ApplicationInfo applicationInfo;
        Set<String> set = installedApk;
        set.clear();
        Log.i((String)TAG, (String)("install: doIt = " + bl));
        if (IS_VM_MULTIDEX_CAPABLE) {
            Log.i((String)TAG, (String)"VM has multidex support, MultiDex support library is disabled.");
            return true;
        }
        if (Build.VERSION.SDK_INT < 4) {
            int n = Build.VERSION.SDK_INT;
            throw new RuntimeException("Multi dex installation failed. SDK " + n + " is unsupported. Min SDK version is 4.");
        }
        try {
            applicationInfo = MultiDex.getApplicationInfo((Context)object);
            if (applicationInfo == null) {
                Log.d((String)TAG, (String)"applicationInfo is null, returning");
                return true;
            }
            Set<String> set2 = set;
            synchronized (set2) {
            }
        }
        catch (Exception exception) {
            Log.e((String)TAG, (String)"Multidex installation failure", (Throwable)exception);
            String string = exception.getMessage();
            throw new RuntimeException("Multi dex installation failed (" + string + ").");
        }
        {
            String string;
            String string2;
            block20: {
                string2 = applicationInfo.sourceDir;
                if (set.contains((Object)string2)) {
                    return true;
                }
                set.add((Object)string2);
                if (Build.VERSION.SDK_INT > 20) {
                    int n = Build.VERSION.SDK_INT;
                    string = System.getProperty((String)"java.vm.version");
                    string2 = new StringBuilder();
                    Log.w((String)TAG, (String)string2.append("MultiDex is not guaranteed to work in SDK version ").append(n).append(": SDK version higher than 20 should be backed by runtime with built-in multidex capabilty but it's not the case here: java.vm.version=\"").append(string).append("\"").toString());
                }
                try {
                    string2 = object.getClassLoader();
                    if (string2 != null) break block20;
                }
                catch (RuntimeException runtimeException) {
                    Log.w((String)TAG, (String)"Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", (Throwable)runtimeException);
                    return true;
                }
                Log.e((String)TAG, (String)"Context class loader is null. Must be running in test mode. Skip patching.");
                return true;
            }
            try {
                MultiDex.clearOldDexDir((Context)object);
            }
            catch (Throwable throwable) {
                Log.w((String)TAG, (String)"Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning.", (Throwable)throwable);
            }
            string = new File(applicationInfo.dataDir, SECONDARY_FOLDER_NAME);
            if (!bl && MultiDexExtractor.mustLoad((Context)object, applicationInfo)) {
                Log.d((String)TAG, (String)"Returning because of mustLoad");
                return false;
            }
            Log.d((String)TAG, (String)"Proceeding with installation...");
            List<File> list = MultiDexExtractor.load((Context)object, applicationInfo, (File)string, false);
            if (MultiDex.checkValidZipFiles(list)) {
                MultiDex.installSecondaryDexes((ClassLoader)string2, (File)string, list);
            } else {
                Log.w((String)TAG, (String)"Files were not valid zip files.  Forcing a reload.");
                object = MultiDexExtractor.load((Context)object, applicationInfo, (File)string, true);
                if (!MultiDex.checkValidZipFiles(object)) {
                    object = new Object("Zip files were not valid.");
                    throw object;
                }
                MultiDex.installSecondaryDexes((ClassLoader)string2, (File)string, object);
            }
        }
        Log.i((String)TAG, (String)"install done");
        return true;
    }

    private static void installSecondaryDexes(ClassLoader classLoader, File file, List<File> list) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException, IOException {
        if (!list.isEmpty()) {
            if (Build.VERSION.SDK_INT >= 19) {
                V19.install(classLoader, (List<File>)list, file);
            } else if (Build.VERSION.SDK_INT >= 14) {
                V14.install(classLoader, (List<File>)list, file);
            } else {
                V4.install(classLoader, (List<File>)list);
            }
        }
    }

    static boolean isVMMultidexCapable(String string) {
        String string2;
        boolean bl;
        boolean bl2 = bl = false;
        if (string != null) {
            string2 = Pattern.compile((String)"(\\d+)\\.(\\d+)(\\.\\d+)?").matcher((CharSequence)string);
            bl2 = bl;
            if (string2.matches()) {
                boolean bl3 = true;
                try {
                    int n = Integer.parseInt((String)string2.group(1));
                    int n2 = Integer.parseInt((String)string2.group(2));
                    bl2 = bl3;
                    if (n <= 2) {
                        bl2 = n == 2 && n2 >= 1 ? bl3 : false;
                    }
                }
                catch (NumberFormatException numberFormatException) {
                    bl2 = bl;
                }
            }
        }
        string2 = bl2 ? " has multidex support" : " does not have multidex support";
        Log.i((String)TAG, (String)("VM with version " + string + string2));
        return bl2;
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private static final class V14 {
        private V14() {
        }

        private static void install(ClassLoader object, List<File> list, File file) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            object = MultiDex.findField(object, "pathList").get(object);
            MultiDex.expandFieldArray(object, "dexElements", V14.makeDexElements(object, (ArrayList<File>)new ArrayList(list), file));
        }

        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            return (Object[])MultiDex.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class}).invoke(object, new Object[]{arrayList, file});
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private static final class V19 {
        private V19() {
        }

        private static void install(ClassLoader classLoader, List<File> objectArray, File file) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, InvocationTargetException, NoSuchMethodException {
            IOException[] iOExceptionArray = MultiDex.findField(classLoader, "pathList").get((Object)classLoader);
            ArrayList arrayList = new ArrayList();
            MultiDex.expandFieldArray(iOExceptionArray, "dexElements", V19.makeDexElements(iOExceptionArray, (ArrayList<File>)new ArrayList(objectArray), file, (ArrayList<IOException>)arrayList));
            if (arrayList.size() > 0) {
                objectArray = arrayList.iterator();
                while (objectArray.hasNext()) {
                    Log.w((String)MultiDex.TAG, (String)"Exception in makeDexElement", (Throwable)((IOException)objectArray.next()));
                }
                file = MultiDex.findField(classLoader, "dexElementsSuppressedExceptions");
                iOExceptionArray = (IOException[])file.get((Object)classLoader);
                if (iOExceptionArray == null) {
                    objectArray = (IOException[])arrayList.toArray((Object[])new IOException[arrayList.size()]);
                } else {
                    objectArray = new IOException[arrayList.size() + iOExceptionArray.length];
                    arrayList.toArray(objectArray);
                    System.arraycopy((Object)iOExceptionArray, (int)0, (Object)objectArray, (int)arrayList.size(), (int)iOExceptionArray.length);
                }
                file.set((Object)classLoader, (Object)objectArray);
            }
        }

        private static Object[] makeDexElements(Object object, ArrayList<File> arrayList, File file, ArrayList<IOException> arrayList2) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
            return (Object[])MultiDex.findMethod(object, "makeDexElements", new Class[]{ArrayList.class, File.class, ArrayList.class}).invoke(object, new Object[]{arrayList, file, arrayList2});
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private static final class V4 {
        private V4() {
        }

        private static void install(ClassLoader classLoader, List<File> object) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, IOException {
            int n = object.size();
            Field field = MultiDex.findField(classLoader, "path");
            StringBuilder stringBuilder = new StringBuilder((String)field.get((Object)classLoader));
            Object[] objectArray = new String[n];
            Object[] objectArray2 = new File[n];
            Object[] objectArray3 = new ZipFile[n];
            Object[] objectArray4 = new DexFile[n];
            ListIterator listIterator = object.listIterator();
            while (listIterator.hasNext()) {
                File file = (File)listIterator.next();
                object = file.getAbsolutePath();
                stringBuilder.append(':').append(object);
                n = listIterator.previousIndex();
                objectArray[n] = object;
                objectArray2[n] = file;
                objectArray3[n] = new ZipFile(file);
                objectArray4[n] = DexFile.loadDex(object, (String)(object + ".dex"), (int)0);
            }
            field.set((Object)classLoader, (Object)stringBuilder.toString());
            MultiDex.expandFieldArray(classLoader, "mPaths", objectArray);
            MultiDex.expandFieldArray(classLoader, "mFiles", objectArray2);
            MultiDex.expandFieldArray(classLoader, "mZips", objectArray3);
            MultiDex.expandFieldArray(classLoader, "mDexs", objectArray4);
        }
    }
}

