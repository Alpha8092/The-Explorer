/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.FileReadOperation;
import com.google.appinventor.components.runtime.util.IOUtils;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public abstract class FileStreamReadOperation
extends FileReadOperation {
    private static final String LOG_TAG = FileStreamReadOperation.class.getSimpleName();

    public FileStreamReadOperation(Form form, Component component, String string2, String string3, FileScope fileScope, boolean bl) {
        super(form, component, string2, string3, fileScope, bl);
    }

    @Override
    protected boolean process(InputStream inputStream) throws IOException {
        boolean bl;
        block5: {
            InputStream inputStream2;
            InputStream inputStream3 = inputStream2 = null;
            inputStream3 = inputStream2;
            try {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                inputStream3 = inputStream = inputStreamReader;
            }
            catch (Throwable throwable) {
                if (true) {
                    IOUtils.closeQuietly((String)LOG_TAG, inputStream3);
                }
                throw throwable;
            }
            bl = this.process((InputStreamReader)inputStream);
            if (!bl) break block5;
            IOUtils.closeQuietly((String)LOG_TAG, (Closeable)inputStream);
        }
        return bl;
    }

    @Override
    protected boolean process(InputStreamReader inputStreamReader) throws IOException {
        return this.process(IOUtils.readReader((InputStreamReader)inputStreamReader));
    }

    @Override
    protected abstract boolean process(String var1);
}

