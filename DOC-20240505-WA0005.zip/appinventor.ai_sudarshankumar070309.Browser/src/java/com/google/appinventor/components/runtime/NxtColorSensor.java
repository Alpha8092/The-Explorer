/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorType
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsNxtSensor;
import java.util.HashMap;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to a color sensor on a LEGO MINDSTORMS NXT robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtColorSensor
extends LegoMindstormsNxtSensor
implements Deleteable {
    private static final int DEFAULT_BOTTOM_OF_RANGE = 256;
    private static final String DEFAULT_SENSOR_PORT = "3";
    private static final int DEFAULT_TOP_OF_RANGE = 767;
    private static final Map<Integer, NxtSensorType> mapColorToSensorType;
    private static final Map<Integer, Integer> mapSensorValueToColor;
    private boolean aboveRangeEventEnabled;
    private boolean belowRangeEventEnabled;
    private int bottomOfRange;
    private boolean colorChangedEventEnabled;
    private boolean detectColor;
    private int generateColor;
    private Handler handler = new Handler();
    private int previousColor = 0xFFFFFF;
    private State previousState = State.UNKNOWN;
    private final Runnable sensorReader;
    private int topOfRange;
    private boolean withinRangeEventEnabled;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetaboveRangeEventEnabled(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.aboveRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetbelowRangeEventEnabled(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.belowRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetbottomOfRange(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.bottomOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetdetectColor(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.detectColor;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.handler;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetpreviousColor(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.previousColor;
    }

    static /* bridge */ /* synthetic */ State -$$Nest$fgetpreviousState(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.previousState;
    }

    static /* bridge */ /* synthetic */ Runnable -$$Nest$fgetsensorReader(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.sensorReader;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgettopOfRange(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.topOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetwithinRangeEventEnabled(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.withinRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousColor(NxtColorSensor nxtColorSensor, int n) {
        nxtColorSensor.previousColor = n;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousState(NxtColorSensor nxtColorSensor, State state) {
        nxtColorSensor.previousState = state;
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetColorValue(NxtColorSensor nxtColorSensor, String string2) {
        return nxtColorSensor.getColorValue(string2);
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetLightValue(NxtColorSensor nxtColorSensor, String string2) {
        return nxtColorSensor.getLightValue(string2);
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$misHandlerNeeded(NxtColorSensor nxtColorSensor) {
        return nxtColorSensor.isHandlerNeeded();
    }

    static {
        HashMap hashMap;
        mapColorToSensorType = hashMap = new HashMap();
        Integer n = -65536;
        hashMap.put((Object)n, (Object)NxtSensorType.ColorRed);
        Integer n2 = -16711936;
        hashMap.put((Object)n2, (Object)NxtSensorType.ColorGreen);
        Integer n3 = -16776961;
        hashMap.put((Object)n3, (Object)NxtSensorType.ColorBlue);
        hashMap.put((Object)0xFFFFFF, (Object)NxtSensorType.ColorNone);
        mapSensorValueToColor = hashMap = new HashMap();
        hashMap.put((Object)1, (Object)-16777216);
        hashMap.put((Object)2, (Object)n3);
        hashMap.put((Object)3, (Object)n2);
        hashMap.put((Object)4, (Object)-256);
        hashMap.put((Object)5, (Object)n);
        hashMap.put((Object)6, (Object)-1);
    }

    public NxtColorSensor(ComponentContainer componentContainer) {
        super(componentContainer, "NxtColorSensor");
        this.sensorReader = new Runnable((NxtColorSensor)this){
            final NxtColorSensor this$0;
            {
                this.this$0 = nxtColorSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    if (NxtColorSensor.-$$Nest$fgetdetectColor(this.this$0)) {
                        LegoMindstormsNxtSensor.SensorValue sensorValue = NxtColorSensor.-$$Nest$mgetColorValue(this.this$0, "");
                        if (sensorValue.valid) {
                            int n = (Integer)sensorValue.value;
                            if (n != NxtColorSensor.-$$Nest$fgetpreviousColor(this.this$0)) {
                                this.this$0.ColorChanged(n);
                            }
                            NxtColorSensor.-$$Nest$fputpreviousColor(this.this$0, n);
                        }
                    } else {
                        Object object = NxtColorSensor.-$$Nest$mgetLightValue(this.this$0, "");
                        if (object.valid) {
                            object = (Integer)object.value < NxtColorSensor.-$$Nest$fgetbottomOfRange(this.this$0) ? State.BELOW_RANGE : ((Integer)object.value > NxtColorSensor.-$$Nest$fgettopOfRange(this.this$0) ? State.ABOVE_RANGE : State.WITHIN_RANGE);
                            if (object != NxtColorSensor.-$$Nest$fgetpreviousState(this.this$0)) {
                                if (object == State.BELOW_RANGE && NxtColorSensor.-$$Nest$fgetbelowRangeEventEnabled(this.this$0)) {
                                    this.this$0.BelowRange();
                                }
                                if (object == State.WITHIN_RANGE && NxtColorSensor.-$$Nest$fgetwithinRangeEventEnabled(this.this$0)) {
                                    this.this$0.WithinRange();
                                }
                                if (object == State.ABOVE_RANGE && NxtColorSensor.-$$Nest$fgetaboveRangeEventEnabled(this.this$0)) {
                                    this.this$0.AboveRange();
                                }
                            }
                            NxtColorSensor.-$$Nest$fputpreviousState(this.this$0, (Object)object);
                        }
                    }
                }
                if (NxtColorSensor.-$$Nest$misHandlerNeeded(this.this$0)) {
                    NxtColorSensor.-$$Nest$fgethandler(this.this$0).post(NxtColorSensor.-$$Nest$fgetsensorReader(this.this$0));
                }
            }
        };
        this.SensorPort(DEFAULT_SENSOR_PORT);
        this.DetectColor(true);
        this.ColorChangedEventEnabled(false);
        this.BottomOfRange(256);
        this.TopOfRange(767);
        this.BelowRangeEventEnabled(false);
        this.WithinRangeEventEnabled(false);
        this.AboveRangeEventEnabled(false);
        this.GenerateColor(0xFFFFFF);
    }

    private LegoMindstormsNxtSensor.SensorValue<Integer> getColorValue(String map) {
        int n;
        if ((map = (Map<Integer, Integer>)this.getInputValues((String)map, this.port)) != null && this.getBooleanValueFromBytes((byte[])map, 4) && (map = mapSensorValueToColor).containsKey((Object)(n = this.getSWORDValueFromBytes((byte[])map, 12)))) {
            return new Object(true, (int)((Integer)map.get((Object)n))){
                final boolean valid;
                final T value;
                {
                    this.valid = bl;
                    this.value = t;
                }
            };
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private LegoMindstormsNxtSensor.SensorValue<Integer> getLightValue(String object) {
        if ((object = (Object)this.getInputValues((String)object, this.port)) != null && this.getBooleanValueFromBytes((byte[])object, 4)) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private boolean isHandlerNeeded() {
        if (this.detectColor) {
            return this.colorChangedEventEnabled;
        }
        boolean bl = this.belowRangeEventEnabled || this.withinRangeEventEnabled || this.aboveRangeEventEnabled;
        return bl;
    }

    @SimpleEvent(description="Light level has gone above the range. The AboveRange event will not occur if the DetectColor property is set to True or if the AboveRangeEventEnabled property is set to False.")
    public void AboveRange() {
        EventDispatcher.dispatchEvent(this, "AboveRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void AboveRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.aboveRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the AboveRange event should fire when the DetectColor property is set to False and the light level goes above the TopOfRange.")
    public boolean AboveRangeEventEnabled() {
        return this.aboveRangeEventEnabled;
    }

    @SimpleEvent(description="Light level has gone below the range. The BelowRange event will not occur if the DetectColor property is set to True or if the BelowRangeEventEnabled property is set to False.")
    public void BelowRange() {
        EventDispatcher.dispatchEvent(this, "BelowRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BelowRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.belowRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the BelowRange event should fire when the DetectColor property is set to False and the light level goes below the BottomOfRange.")
    public boolean BelowRangeEventEnabled() {
        return this.belowRangeEventEnabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The bottom of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int BottomOfRange() {
        return this.bottomOfRange;
    }

    @DesignerProperty(defaultValue="256", editorType="non_negative_integer")
    @SimpleProperty
    public void BottomOfRange(int n) {
        this.bottomOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleEvent(description="Detected color has changed. The ColorChanged event will not occur if the DetectColor property is set to False or if the ColorChangedEventEnabled property is set to False.")
    public void ColorChanged(int n) {
        EventDispatcher.dispatchEvent((Component)this, "ColorChanged", n);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void ColorChangedEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.colorChangedEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousColor = 0xFFFFFF;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the ColorChanged event should fire when the DetectColor property is set to True and the detected color changes.")
    public boolean ColorChangedEventEnabled() {
        return this.colorChangedEventEnabled;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void DetectColor(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.detectColor = bl;
        if (this.bluetooth != null && this.bluetooth.IsConnected()) {
            this.initializeSensor("DetectColor");
        }
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        this.previousColor = 0xFFFFFF;
        this.previousState = State.UNKNOWN;
        if (!bl2 && bl) {
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the sensor should detect color or light. True indicates that the sensor should detect color; False indicates that the sensor should detect light. If the DetectColor property is set to True, the BelowRange, WithinRange, and AboveRange events will not occur and the sensor will not generate color. If the DetectColor property is set to False, the ColorChanged event will not occur.")
    public boolean DetectColor() {
        return this.detectColor;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The color that should generated by the sensor. Only None, Red, Green, or Blue are valid values. The sensor will not generate color when the DetectColor property is set to True.")
    public int GenerateColor() {
        return this.generateColor;
    }

    @DesignerProperty(defaultValue="&H00FFFFFF", editorType="lego_nxt_generated_color")
    @SimpleProperty
    public void GenerateColor(int n) {
        if (mapColorToSensorType.containsKey((Object)n)) {
            this.generateColor = n;
            if (this.bluetooth != null && this.bluetooth.IsConnected()) {
                this.initializeSensor("GenerateColor");
            }
        } else {
            this.form.dispatchErrorOccurredEvent((Component)this, "GenerateColor", 419, new Object[0]);
        }
    }

    @SimpleFunction(description="Returns the current detected color, or the color None if the color can not be read or if the DetectColor property is set to False.")
    public int GetColor() {
        if (!this.checkBluetooth("GetColor")) {
            return 0xFFFFFF;
        }
        if (!this.detectColor) {
            this.form.dispatchErrorOccurredEvent(this, "GetColor", 417, new Object[0]);
            return 0xFFFFFF;
        }
        LegoMindstormsNxtSensor.SensorValue<Integer> sensorValue = this.getColorValue("GetColor");
        if (sensorValue.valid) {
            return (Integer)sensorValue.value;
        }
        return 0xFFFFFF;
    }

    @SimpleFunction(description="Returns the current light level as a value between 0 and 1023, or -1 if the light level can not be read or if the DetectColor property is set to True.")
    public int GetLightLevel() {
        if (!this.checkBluetooth("GetLightLevel")) {
            return -1;
        }
        if (this.detectColor) {
            this.form.dispatchErrorOccurredEvent(this, "GetLightLevel", 418, new Object[0]);
            return -1;
        }
        LegoMindstormsNxtSensor.SensorValue<Integer> sensorValue = this.getLightValue("GetLightLevel");
        if (sensorValue.valid) {
            return (Integer)sensorValue.value;
        }
        return -1;
    }

    @Override
    @DesignerProperty(defaultValue="3", editorType="lego_nxt_sensor_port")
    @SimpleProperty(userVisible=false)
    public void SensorPort(String string2) {
        this.setSensorPort(string2);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The top of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int TopOfRange() {
        return this.topOfRange;
    }

    @DesignerProperty(defaultValue="767", editorType="non_negative_integer")
    @SimpleProperty
    public void TopOfRange(int n) {
        this.topOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleEvent(description="Light level has gone within the range. The WithinRange event will not occur if the DetectColor property is set to True or if the WithinRangeEventEnabled property is set to False.")
    public void WithinRange() {
        EventDispatcher.dispatchEvent(this, "WithinRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WithinRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.withinRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the WithinRange event should fire when the DetectColor property is set to False and the light level goes between the BottomOfRange and the TopOfRange.")
    public boolean WithinRangeEventEnabled() {
        return this.withinRangeEventEnabled;
    }

    @Override
    protected void initializeSensor(String string2) {
        NxtSensorType nxtSensorType = this.detectColor ? NxtSensorType.ColorFull : (NxtSensorType)mapColorToSensorType.get((Object)this.generateColor);
        this.setInputMode(string2, this.port, nxtSensorType, NxtSensorMode.Raw);
        this.resetInputScaledValue(string2, this.port);
    }

    @Override
    public void onDelete() {
        this.handler.removeCallbacks(this.sensorReader);
        super.onDelete();
    }
}

