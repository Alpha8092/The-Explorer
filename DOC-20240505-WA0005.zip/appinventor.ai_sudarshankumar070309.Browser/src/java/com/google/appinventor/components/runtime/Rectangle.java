/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.MapFeature
 *  com.google.appinventor.components.runtime.Rectangle$1
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  org.locationtech.jts.geom.Geometry
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.MapFeature;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.PolygonBase;
import com.google.appinventor.components.runtime.Rectangle;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import com.google.appinventor.components.runtime.util.YailList;
import org.locationtech.jts.geom.Geometry;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

@DesignerComponent(category=ComponentCategory.MAPS, description="Rectangles are polygons with fixed latitudes and longitudes for the north, south, east, and west boundaries. Moving a vertex of the Rectangle updates the appropriate edges accordingly.", iconName="images/rectangle.png", version=2)
@SimpleObject
public class Rectangle
extends PolygonBase
implements MapFactory.MapRectangle {
    private static final MapFactory.MapFeatureVisitor<Double> distanceComputation = new 1();
    private double east = 0.0;
    private double north = 0.0;
    private double south = 0.0;
    private double west = 0.0;

    public Rectangle(MapFactory.MapFeatureContainer mapFeatureContainer) {
        super(mapFeatureContainer, distanceComputation);
        mapFeatureContainer.addFeature((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleFunction(description="Returns the bounding box of the Rectangle in the format ((North West) (South East)).")
    public YailList Bounds() {
        return YailList.makeList(new YailList[]{YailList.makeList(new Double[]{this.north, this.west}), YailList.makeList(new Double[]{this.south, this.east})});
    }

    @Override
    @SimpleFunction(description="Returns the center of the Rectangle as a list of the form (Latitude Longitude).")
    public YailList Center() {
        return GeometryUtil.asYailList((IGeoPoint)this.getCentroid());
    }

    @Override
    @SimpleProperty
    public double EastLongitude() {
        return this.east;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="float")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The east edge of the rectangle, in decimal degrees east of the prime meridian.")
    public void EastLongitude(double d) {
        this.east = d;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapRectangle)this);
    }

    @Override
    @SimpleProperty
    public double NorthLatitude() {
        return this.north;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="float")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The north edge of the rectangle, in decimal degrees north of the equator.")
    public void NorthLatitude(double d) {
        this.north = d;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapRectangle)this);
    }

    @Override
    @SimpleFunction(description="Moves the Rectangle so that it is centered on the given latitude and longitude while attempting to maintain the width and height of the Rectangle as measured from the center to the edges.")
    public void SetCenter(double d, double d2) {
        if (!(d < -90.0) && !(d > 90.0)) {
            if (!(d2 < -180.0) && !(d2 > 180.0)) {
                GeoPoint geoPoint = this.getCentroid();
                GeoPoint geoPoint2 = new GeoPoint(this.north, geoPoint.getLongitude());
                GeoPoint geoPoint3 = new GeoPoint(this.south, geoPoint.getLongitude());
                GeoPoint geoPoint4 = new GeoPoint(geoPoint.getLatitude(), this.east);
                GeoPoint geoPoint5 = new GeoPoint(geoPoint.getLatitude(), this.west);
                double d3 = GeometryUtil.distanceBetween((IGeoPoint)geoPoint2, (IGeoPoint)geoPoint3) / 2.0;
                double d4 = GeometryUtil.distanceBetween((IGeoPoint)geoPoint4, (IGeoPoint)geoPoint5) / 2.0;
                geoPoint.setCoords(d, d2);
                this.north = geoPoint.destinationPoint(d3, 0.0f).getLatitude();
                this.south = geoPoint.destinationPoint(d3, 180.0f).getLatitude();
                this.east = geoPoint.destinationPoint(d4, 90.0f).getLongitude();
                this.west = geoPoint.destinationPoint(d4, 270.0f).getLongitude();
                this.clearGeometry();
                this.map.getController().updateFeaturePosition((MapFactory.MapRectangle)this);
                return;
            }
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "SetCenter", 3405, d, d2);
            return;
        }
        this.container.$form().dispatchErrorOccurredEvent((Component)this, "SetCenter", 3405, d, d2);
    }

    @Override
    @SimpleProperty
    public double SouthLatitude() {
        return this.south;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="float")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The south edge of the rectangle, in decimal degrees north of the equator.")
    public void SouthLatitude(double d) {
        this.south = d;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapRectangle)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the type of the feature. For rectangles, this returns MapFeature.Rectangle (\"Rectangle\").")
    public String Type() {
        return this.TypeAbstract().toUnderlyingValue();
    }

    public MapFeature TypeAbstract() {
        return MapFeature.Rectangle;
    }

    @Override
    @SimpleProperty
    public double WestLongitude() {
        return this.west;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="float")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The west edge of the rectangle, in decimal degrees east of the equator.")
    public void WestLongitude(double d) {
        this.west = d;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapRectangle)this);
    }

    @Override
    public <T> T accept(MapFactory.MapFeatureVisitor<T> mapFeatureVisitor, Object ... objectArray) {
        return (T)mapFeatureVisitor.visit((MapFactory.MapRectangle)this, objectArray);
    }

    @Override
    protected Geometry computeGeometry() {
        return GeometryUtil.createGeometry((double)this.north, (double)this.east, (double)this.south, (double)this.west);
    }

    @Override
    public void updateBounds(double d, double d2, double d3, double d4) {
        this.north = d;
        this.west = d2;
        this.south = d3;
        this.east = d4;
        this.clearGeometry();
    }
}

