/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.common.NxtMailbox
 *  com.google.appinventor.components.common.NxtMotorMode
 *  com.google.appinventor.components.common.NxtMotorPort
 *  com.google.appinventor.components.common.NxtRegulationMode
 *  com.google.appinventor.components.common.NxtRunState
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorPort
 *  com.google.appinventor.components.common.NxtSensorType
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtMailbox;
import com.google.appinventor.components.common.NxtMotorMode;
import com.google.appinventor.components.common.NxtMotorPort;
import com.google.appinventor.components.common.NxtRegulationMode;
import com.google.appinventor.components.common.NxtRunState;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorPort;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.LegoMindstormsNxtBase;
import com.google.appinventor.components.runtime.util.YailList;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a low-level interface to a LEGO MINDSTORMS NXT robot, with functions to send NXT Direct Commands.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=2)
@SimpleObject
public class NxtDirectCommands
extends LegoMindstormsNxtBase {
    public NxtDirectCommands(ComponentContainer componentContainer) {
        super(componentContainer, "NxtDirectCommands");
    }

    private void closeHandle(String string, int n) {
        byte[] byArray = new byte[3];
        byArray[0] = 1;
        byArray[1] = -124;
        this.copyUBYTEValueToBytes(n, byArray, 2);
        this.evaluateStatus(string, this.sendCommandAndReceiveReturnPackage(string, byArray), byArray[1]);
    }

    private byte[] getOutputState(String string, NxtMotorPort object2) {
        Object object3 = new byte[3];
        object3[0] = 0;
        object3[1] = 6;
        this.copyUBYTEValueToBytes(object2.toInt(), (byte[])object3, 2);
        object2 = this.sendCommandAndReceiveReturnPackage(string, (byte[])object3);
        if (this.evaluateStatus(string, (byte[])object2, object3[1])) {
            if (((NxtMotorPort)object2).length == 25) {
                return object2;
            }
            object3 = this.logTag;
            int n = ((NxtMotorPort)object2).length;
            Log.w((String)object3, (String)(string + ": unexpected return package length " + n + " (expected 25)"));
        }
        return null;
    }

    private Integer openWrite(String string, String object2, long l) {
        Object object3 = new byte[26];
        object3[0] = 1;
        object3[1] = -127;
        this.copyStringValueToBytes((String)object2, (byte[])object3, 2, 19);
        this.copyULONGValueToBytes(l, (byte[])object3, 22);
        object2 = this.sendCommandAndReceiveReturnPackage(string, (byte[])object3);
        if (this.evaluateStatus(string, (byte[])object2, object3[1])) {
            if (((Object)object2).length == 4) {
                return this.getUBYTEValueFromBytes((byte[])object2, 3);
            }
            object3 = this.logTag;
            int n = ((Object)object2).length;
            Log.w((String)object3, (String)(string + ": unexpected return package length " + n + " (expected 4)"));
        }
        return null;
    }

    private Integer openWriteLinear(String string, String object2, long l) {
        Object object3 = new byte[26];
        object3[0] = 1;
        object3[1] = -119;
        this.copyStringValueToBytes((String)object2, (byte[])object3, 2, 19);
        this.copyULONGValueToBytes(l, (byte[])object3, 22);
        object2 = this.sendCommandAndReceiveReturnPackage(string, (byte[])object3);
        if (this.evaluateStatus(string, (byte[])object2, object3[1])) {
            if (((Object)object2).length == 4) {
                return this.getUBYTEValueFromBytes((byte[])object2, 3);
            }
            object3 = this.logTag;
            int n = ((Object)object2).length;
            Log.w((String)object3, (String)(string + ": unexpected return package length " + n + " (expected 4)"));
        }
        return null;
    }

    private int writeChunk(String string, int n, byte[] byArray, int n2) throws IOException {
        if (n2 <= 32) {
            Object object2 = new byte[n2 + 3];
            object2[0] = 1;
            object2[1] = -125;
            this.copyUBYTEValueToBytes(n, (byte[])object2, 2);
            System.arraycopy((Object)byArray, (int)0, (Object)object2, (int)3, (int)n2);
            byArray = this.sendCommandAndReceiveReturnPackage(string, (byte[])object2);
            if (this.evaluateStatus(string, byArray, object2[1])) {
                if (byArray.length == 6) {
                    n = this.getUWORDValueFromBytes(byArray, 4);
                    if (n == n2) {
                        return n;
                    }
                    Log.e((String)this.logTag, (String)(string + ": only " + n + " bytes were written (expected " + n2 + ")"));
                    throw new IOException("Unable to write file on robot");
                }
                object2 = this.logTag;
                n = byArray.length;
                Log.w((String)object2, (String)(string + ": unexpected return package length " + n + " (expected 6)"));
            }
            return 0;
        }
        throw new IllegalArgumentException("length must be <= 32");
    }

    @SimpleFunction(description="Delete a file on the robot.")
    public void DeleteFile(String string) {
        if (!this.checkBluetooth("DeleteFile")) {
            return;
        }
        if (string.length() == 0) {
            this.form.dispatchErrorOccurredEvent((Component)this, "DeleteFile", 406, new Object[0]);
            return;
        }
        byte[] byArray = new byte[22];
        byArray[0] = 1;
        byArray[1] = -123;
        this.copyStringValueToBytes(string, byArray, 2, 19);
        this.evaluateStatus("DeleteFile", this.sendCommandAndReceiveReturnPackage("DeleteFile", byArray), byArray[1]);
    }

    /*
     * Exception decompiling
     */
    @SimpleFunction(description="Download a file to the robot.")
    public void DownloadFile(String var1, String var2_5) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 3 blocks at once
         *     at kb.j.j1(SourceFile:66)
         *     at kb.j.X0(SourceFile:54)
         *     at kb.i.Z0(SourceFile:40)
         *     at ib.f.d(SourceFile:217)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1133)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:607)
         *     at java.lang.Thread.run(Thread.java:760)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @SimpleFunction(description="Get the battery level for the robot. Returns the voltage in millivolts.")
    public int GetBatteryLevel() {
        if (!this.checkBluetooth("GetBatteryLevel")) {
            return 0;
        }
        Object object2 = new byte[]{0, 11};
        byte[] byArray = this.sendCommandAndReceiveReturnPackage("GetBatteryLevel", (byte[])object2);
        if (this.evaluateStatus("GetBatteryLevel", byArray, object2[1])) {
            if (byArray.length == 5) {
                return this.getUWORDValueFromBytes(byArray, 3);
            }
            object2 = this.logTag;
            int n = byArray.length;
            Log.w((String)object2, (String)("GetBatteryLevel: unexpected return package length " + n + " (expected 5)"));
        }
        return 0;
    }

    @SimpleFunction(description="Get the brick name of the robot.")
    public String GetBrickName() {
        if (!this.checkBluetooth("GetBrickName")) {
            return "";
        }
        byte[] byArray = new byte[]{1, -101};
        byte[] byArray2 = this.sendCommandAndReceiveReturnPackage("GetBrickName", byArray);
        if (this.evaluateStatus("GetBrickName", byArray2, byArray[1])) {
            return this.getStringValueFromBytes(byArray2, 3);
        }
        return "";
    }

    @SimpleFunction(description="Get the name of currently running program on the robot.")
    public String GetCurrentProgramName() {
        if (!this.checkBluetooth("GetCurrentProgramName")) {
            return "";
        }
        byte[] byArray = new byte[]{0, 17};
        byte[] byArray2 = this.sendCommandAndReceiveReturnPackage("GetCurrentProgramName", byArray);
        int n = this.getStatus("GetCurrentProgramName", byArray2, byArray[1]);
        if (n == 0) {
            return this.getStringValueFromBytes(byArray2, 3);
        }
        if (n == 236) {
            return "";
        }
        this.evaluateStatus("GetCurrentProgramName", byArray2, byArray[1]);
        return "";
    }

    @SimpleFunction(description="Get the firmware and protocol version numbers for the robot as a list where the first element is the firmware version number and the second element is the protocol version number.")
    public List<String> GetFirmwareVersion() {
        if (!this.checkBluetooth("GetFirmwareVersion")) {
            return new ArrayList();
        }
        Object object2 = new byte[]{1, -120};
        byte[] byArray = this.sendCommandAndReceiveReturnPackage("GetFirmwareVersion", (byte[])object2);
        if (this.evaluateStatus("GetFirmwareVersion", byArray, object2[1])) {
            object2 = new ArrayList();
            byte by = byArray[6];
            byte by2 = byArray[5];
            object2.add((Object)(by + "." + by2));
            by = byArray[4];
            by2 = byArray[3];
            object2.add((Object)(by + "." + by2));
            return object2;
        }
        return new ArrayList();
    }

    @SimpleFunction(description="Reads the values of an input sensor on the robot. Assumes sensor type has been configured via SetInputMode.")
    public List<Object> GetInputValues(@Options(value=NxtSensorPort.class) String object2) {
        if (!this.checkBluetooth("GetInputValues")) {
            return new ArrayList();
        }
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)object2);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "GetInputValues", 408, object2);
            return new ArrayList();
        }
        object2 = this.getInputValues("GetInputValues", nxtSensorPort);
        if (object2 != null) {
            nxtSensorPort = new ArrayList();
            nxtSensorPort.add((Object)this.getBooleanValueFromBytes((byte[])object2, 4));
            nxtSensorPort.add((Object)this.getBooleanValueFromBytes((byte[])object2, 5));
            nxtSensorPort.add((Object)this.getUBYTEValueFromBytes((byte[])object2, 6));
            nxtSensorPort.add((Object)this.getUBYTEValueFromBytes((byte[])object2, 7));
            nxtSensorPort.add((Object)this.getUWORDValueFromBytes((byte[])object2, 8));
            nxtSensorPort.add((Object)this.getUWORDValueFromBytes((byte[])object2, 10));
            nxtSensorPort.add((Object)this.getSWORDValueFromBytes((byte[])object2, 12));
            nxtSensorPort.add((Object)this.getSWORDValueFromBytes((byte[])object2, 14));
            return nxtSensorPort;
        }
        return new ArrayList();
    }

    @SimpleFunction(description="Reads the output state of a motor on the robot.")
    public List<Number> GetOutputState(@Options(value=NxtMotorPort.class) String string) {
        if (!this.checkBluetooth("GetOutputState")) {
            return new ArrayList();
        }
        Object object2 = NxtMotorPort.fromUnderlyingValue((String)string);
        if (object2 == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "GetOutputState", 407, string);
            return new ArrayList();
        }
        if ((object2 = (Object)super.getOutputState("GetOutputState", (NxtMotorPort)object2)) != null) {
            string = new ArrayList();
            string.add((Object)this.getSBYTEValueFromBytes((byte[])object2, 4));
            string.add((Object)this.getUBYTEValueFromBytes((byte[])object2, 5));
            string.add((Object)this.getUBYTEValueFromBytes((byte[])object2, 6));
            string.add((Object)this.getSBYTEValueFromBytes((byte[])object2, 7));
            string.add((Object)this.getUBYTEValueFromBytes((byte[])object2, 8));
            string.add((Object)this.getULONGValueFromBytes((byte[])object2, 9));
            string.add((Object)this.getSLONGValueFromBytes((byte[])object2, 13));
            string.add((Object)this.getSLONGValueFromBytes((byte[])object2, 17));
            string.add((Object)this.getSLONGValueFromBytes((byte[])object2, 21));
            return string;
        }
        return new ArrayList();
    }

    @SimpleFunction(description="Keep Alive. Returns the current sleep time limit in milliseconds.")
    public long KeepAlive() {
        if (!this.checkBluetooth("KeepAlive")) {
            return 0L;
        }
        Object object2 = new byte[]{0, 13};
        byte[] byArray = this.sendCommandAndReceiveReturnPackage("KeepAlive", (byte[])object2);
        if (this.evaluateStatus("KeepAlive", byArray, object2[1])) {
            if (byArray.length == 7) {
                return this.getULONGValueFromBytes(byArray, 3);
            }
            object2 = this.logTag;
            int n = byArray.length;
            Log.w((String)object2, (String)("KeepAlive: unexpected return package length " + n + " (expected 7)"));
        }
        return 0L;
    }

    @SimpleFunction(description="Returns a list containing the names of matching files found on the robot.")
    public List<String> ListFiles(String object2) {
        if (!this.checkBluetooth("ListFiles")) {
            return new ArrayList();
        }
        ArrayList arrayList = new ArrayList();
        Object object3 = object2;
        if (object2.length() == 0) {
            object3 = "*.*";
        }
        byte[] byArray = new byte[22];
        byArray[0] = 1;
        byArray[1] = -122;
        this.copyStringValueToBytes((String)object3, byArray, 2, 19);
        object2 = this.sendCommandAndReceiveReturnPackage("ListFiles", byArray);
        int n = this.getStatus("ListFiles", (byte[])object2, byArray[1]);
        while (n == 0) {
            n = this.getUBYTEValueFromBytes((byte[])object2, 3);
            arrayList.add((Object)this.getStringValueFromBytes((byte[])object2, 4));
            object3 = new byte[3];
            object3[0] = true;
            object3[1] = -121;
            this.copyUBYTEValueToBytes(n, (byte[])object3, 2);
            object2 = this.sendCommandAndReceiveReturnPackage("ListFiles", (byte[])object3);
            n = this.getStatus("ListFiles", (byte[])object2, (byte)object3[1]);
        }
        return arrayList;
    }

    @SimpleFunction(description="Returns the count of available bytes to read.")
    public int LsGetStatus(@Options(value=NxtSensorPort.class) String string) {
        if (!this.checkBluetooth("LsGetStatus")) {
            return 0;
        }
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)string);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LsGetStatus", 408, string);
            return 0;
        }
        return this.lsGetStatus("LsGetStatus", nxtSensorPort);
    }

    @SimpleFunction(description="Reads unsigned low speed data from an input sensor on the robot. Assumes sensor type has been configured via SetInputMode.")
    public List<Integer> LsRead(@Options(value=NxtSensorPort.class) String string) {
        if (!this.checkBluetooth("LsRead")) {
            return new ArrayList();
        }
        Object object2 = NxtSensorPort.fromUnderlyingValue((String)string);
        if (object2 == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LsRead", 408, string);
            return new ArrayList();
        }
        if ((object2 = (Object)this.lsRead("LsRead", (NxtSensorPort)object2)) != null) {
            string = new ArrayList();
            int n = this.getUBYTEValueFromBytes((byte[])object2, 3);
            for (int i = 0; i < n; ++i) {
                string.add((Object)(object2[i + 4] & 0xFF));
            }
            return string;
        }
        return new ArrayList();
    }

    @SimpleFunction(description="Writes low speed data to an input sensor on the robot. Assumes sensor type has been configured via SetInputMode.")
    public void LsWrite(@Options(value=NxtSensorPort.class) String string, YailList object2, int n) {
        if (!this.checkBluetooth("LsWrite")) {
            return;
        }
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)string);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LsWrite", 408, string);
            return;
        }
        if (object2.size() > 16) {
            this.form.dispatchErrorOccurredEvent((Component)this, "LsWrite", 411, new Object[0]);
            return;
        }
        Object[] objectArray = object2.toArray();
        object2 = new byte[objectArray.length];
        for (int i = 0; i < objectArray.length; ++i) {
            int n2;
            string = objectArray[i].toString();
            try {
                n2 = Integer.decode((String)string);
            }
            catch (NumberFormatException numberFormatException) {
                this.form.dispatchErrorOccurredEvent((Component)this, "LsWrite", 412, i + 1);
                return;
            }
            object2[i] = (YailList)((byte)(n2 & 0xFF));
            if ((n2 >>= 8) == 0 || n2 == -1) continue;
            this.form.dispatchErrorOccurredEvent((Component)this, "LsWrite", 413, i + 1);
            return;
        }
        this.lsWrite("LsWrite", nxtSensorPort, (byte[])object2, n);
    }

    @SimpleFunction(description="Read a message from a mailbox (1-10) on the robot.")
    public String MessageRead(@Options(value=NxtMailbox.class) int n) {
        NxtMailbox nxtMailbox = NxtMailbox.fromUnderlyingValue((Integer)n);
        if (nxtMailbox == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "MessageRead", 409, n);
            return "";
        }
        return this.MessageReadAbstract(nxtMailbox);
    }

    public String MessageReadAbstract(NxtMailbox object2) {
        int n = object2.toInt();
        if (!this.checkBluetooth("MessageRead")) {
            return "";
        }
        Object object3 = new byte[5];
        object3[0] = 0;
        object3[1] = 19;
        this.copyUBYTEValueToBytes(0, (byte[])object3, 2);
        this.copyUBYTEValueToBytes(n, (byte[])object3, 3);
        this.copyBooleanValueToBytes(true, (byte[])object3, 4);
        object2 = this.sendCommandAndReceiveReturnPackage("MessageRead", (byte[])object3);
        if (this.evaluateStatus("MessageRead", (byte[])object2, object3[1])) {
            if (((NxtMailbox)object2).length == 64) {
                int n2 = this.getUBYTEValueFromBytes((byte[])object2, 3);
                if (n2 != n) {
                    Log.w((String)this.logTag, (String)("MessageRead: unexpected return mailbox: Box" + n2 + " (expected " + n + ")"));
                }
                return this.getStringValueFromBytes((byte[])object2, 5, this.getUBYTEValueFromBytes((byte[])object2, 4) - 1);
            }
            object3 = this.logTag;
            n = ((NxtMailbox)object2).length;
            Log.w((String)object3, (String)("MessageRead: unexpected return package length " + n + " (expected 64)"));
        }
        return "";
    }

    @SimpleFunction(description="Write a message to a mailbox (1-10) on the robot.")
    public void MessageWrite(@Options(value=NxtMailbox.class) int n, String string) {
        NxtMailbox nxtMailbox = NxtMailbox.fromUnderlyingValue((Integer)n);
        if (nxtMailbox == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "MessageWrite", 409, n);
            return;
        }
        this.MessageWriteAbstract(nxtMailbox, string);
    }

    public void MessageWriteAbstract(NxtMailbox nxtMailbox, String string) {
        if (!this.checkBluetooth("MessageWrite")) {
            return;
        }
        int n = string.length();
        if (n > 58) {
            this.form.dispatchErrorOccurredEvent((Component)this, "MessageWrite", 410, new Object[0]);
            return;
        }
        byte[] byArray = new byte[n + 4 + 1];
        byArray[0] = -128;
        byArray[1] = 9;
        this.copyUBYTEValueToBytes(nxtMailbox.toInt(), byArray, 2);
        this.copyUBYTEValueToBytes(n + 1, byArray, 3);
        this.copyStringValueToBytes(string, byArray, 4, n);
        this.sendCommand("MessageWrite", byArray);
    }

    @SimpleFunction(description="Play a sound file on the robot.")
    public void PlaySoundFile(String object2) {
        if (!this.checkBluetooth("PlaySoundFile")) {
            return;
        }
        if (object2.length() == 0) {
            this.form.dispatchErrorOccurredEvent((Component)this, "PlaySoundFile", 406, new Object[0]);
            return;
        }
        String string = object2;
        if (object2.indexOf(".") == -1) {
            string = (String)object2 + ".rso";
        }
        object2 = new byte[23];
        object2[0] = -128;
        object2[1] = 2;
        this.copyBooleanValueToBytes(false, (byte[])object2, 2);
        this.copyStringValueToBytes(string, (byte[])object2, 3, 19);
        this.sendCommand("PlaySoundFile", (byte[])object2);
    }

    @SimpleFunction(description="Make the robot play a tone.")
    public void PlayTone(int n, int n2) {
        if (!this.checkBluetooth("PlayTone")) {
            return;
        }
        int n3 = n;
        if (n < 200) {
            Log.w((String)this.logTag, (String)("frequencyHz " + n + " is invalid, using 200."));
            n3 = 200;
        }
        n = n3;
        if (n3 > 14000) {
            Log.w((String)this.logTag, (String)("frequencyHz " + n3 + " is invalid, using 14000."));
            n = 14000;
        }
        byte[] byArray = new byte[6];
        byArray[0] = -128;
        byArray[1] = 3;
        this.copyUWORDValueToBytes(n, byArray, 2);
        this.copyUWORDValueToBytes(n2, byArray, 4);
        this.sendCommand("PlayTone", byArray);
    }

    @SimpleFunction(description="Reset the scaled value of an input sensor on the robot.")
    public void ResetInputScaledValue(@Options(value=NxtSensorPort.class) String object2) {
        if (!this.checkBluetooth("ResetInputScaledValue")) {
            return;
        }
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)object2);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "ResetInputScaledValue", 408, object2);
            return;
        }
        this.resetInputScaledValue("ResetInputScaledValue", nxtSensorPort);
        object2 = new byte[3];
        object2[0] = -128;
        object2[1] = 8;
        this.copyUBYTEValueToBytes(nxtSensorPort.toInt(), (byte[])object2, 2);
        this.sendCommand("ResetInputScaledValue", (byte[])object2);
    }

    @SimpleFunction(description="Reset motor position.")
    public void ResetMotorPosition(@Options(value=NxtMotorPort.class) String object2, boolean bl) {
        if (!this.checkBluetooth("ResetMotorPosition")) {
            return;
        }
        NxtMotorPort nxtMotorPort = NxtMotorPort.fromUnderlyingValue((String)object2);
        if (nxtMotorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "ResetMotorPosition", 407, object2);
            return;
        }
        object2 = new byte[4];
        object2[0] = -128;
        object2[1] = 10;
        this.copyUBYTEValueToBytes(nxtMotorPort.toInt(), (byte[])object2, 2);
        this.copyBooleanValueToBytes(bl, (byte[])object2, 3);
        this.sendCommand("ResetMotorPosition", (byte[])object2);
    }

    @SimpleFunction(description="Set the brick name of the robot.")
    public void SetBrickName(String string) {
        if (!this.checkBluetooth("SetBrickName")) {
            return;
        }
        byte[] byArray = new byte[18];
        byArray[0] = 1;
        byArray[1] = -104;
        this.copyStringValueToBytes(string, byArray, 2, 15);
        this.evaluateStatus("SetBrickName", this.sendCommandAndReceiveReturnPackage("SetBrickName", byArray), byArray[1]);
    }

    @SimpleFunction(description="Configure an input sensor on the robot.")
    public void SetInputMode(@Options(value=NxtSensorPort.class) String string, @Options(value=NxtSensorType.class) int n, @Options(value=NxtSensorMode.class) int n2) {
        if (!this.checkBluetooth("SetInputMode")) {
            return;
        }
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)string);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "SetInputMode", 408, string);
            return;
        }
        string = NxtSensorType.fromUnderlyingValue((Integer)n);
        if (string == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "SetInputMode", 422, string);
            return;
        }
        NxtSensorMode nxtSensorMode = NxtSensorMode.fromUnderlyingValue((Integer)n2);
        if (nxtSensorMode == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "SetInputMode", 423, nxtSensorMode);
            return;
        }
        this.setInputMode("SetInputMode", nxtSensorPort, (NxtSensorType)string, nxtSensorMode);
    }

    @SimpleFunction(description="Sets the output state of a motor on the robot.")
    public void SetOutputState(@Options(value=NxtMotorPort.class) String string, int n, @Options(value=NxtMotorMode.class) int n2, @Options(value=NxtRegulationMode.class) int n3, int n4, @Options(value=NxtRunState.class) int n5, long l) {
        if (!this.checkBluetooth("SetOutputState")) {
            return;
        }
        NxtMotorPort nxtMotorPort = NxtMotorPort.fromUnderlyingValue((String)string);
        if (nxtMotorPort == null) {
            this.form.dispatchErrorOccurredEvent(this, "SetOutputState", 407, string);
            return;
        }
        NxtMotorMode nxtMotorMode = NxtMotorMode.fromUnderlyingValue((Integer)n2);
        if (nxtMotorMode == null) {
            this.form.dispatchErrorOccurredEvent(this, "SetOutputState", 420, n2);
            return;
        }
        string = NxtRegulationMode.fromUnderlyingValue((Integer)n3);
        if (string == null) {
            this.form.dispatchErrorOccurredEvent(this, "SetOutputState", 421, string);
            return;
        }
        this.setOutputState("SetOutputState", nxtMotorPort, n, nxtMotorMode, (NxtRegulationMode)string, n4, NxtRunState.fromUnderlyingValue((Integer)n5), l);
    }

    @SimpleFunction(description="Start execution of a previously downloaded program on the robot.")
    public void StartProgram(String object2) {
        if (!this.checkBluetooth("StartProgram")) {
            return;
        }
        if (object2.length() == 0) {
            this.form.dispatchErrorOccurredEvent((Component)this, "StartProgram", 405, new Object[0]);
            return;
        }
        String string = object2;
        if (object2.indexOf(".") == -1) {
            string = (String)object2 + ".rxe";
        }
        object2 = new byte[22];
        object2[0] = -128;
        object2[1] = false;
        this.copyStringValueToBytes(string, (byte[])object2, 2, 19);
        this.sendCommand("StartProgram", (byte[])object2);
    }

    @SimpleFunction(description="Stop execution of the currently running program on the robot.")
    public void StopProgram() {
        if (!this.checkBluetooth("StopProgram")) {
            return;
        }
        this.sendCommand("StopProgram", new byte[]{-128, 1});
    }

    @SimpleFunction(description="Stop sound playback.")
    public void StopSoundPlayback() {
        if (!this.checkBluetooth("StopSoundPlayback")) {
            return;
        }
        this.sendCommand("StopSoundPlayback", new byte[]{-128, 12});
    }
}

