/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.bluetooth.BluetoothServerSocket
 *  android.bluetooth.BluetoothSocket
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  com.google.appinventor.components.runtime.BluetoothServer$1
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.SUtil
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicReference
 */
package com.google.appinventor.components.runtime;

import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.BluetoothConnectionBase;
import com.google.appinventor.components.runtime.BluetoothServer;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.SUtil;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.CONNECTIVITY, description="Bluetooth server component", iconName="images/bluetooth.png", nonVisible=true, version=5)
@SimpleObject
@UsesPermissions(value={"android.permission.BLUETOOTH", "android.permission.BLUETOOTH_ADMIN", "android.permission.BLUETOOTH_ADVERTISE"})
public final class BluetoothServer
extends BluetoothConnectionBase {
    private static final String SPP_UUID = "00001101-0000-1000-8000-00805F9B34FB";
    private final Handler androidUIHandler = new Handler(Looper.getMainLooper());
    private final AtomicReference<BluetoothServerSocket> arBluetoothServerSocket = new AtomicReference();

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgetandroidUIHandler(BluetoothServer bluetoothServer) {
        return bluetoothServer.androidUIHandler;
    }

    static /* bridge */ /* synthetic */ AtomicReference -$$Nest$fgetarBluetoothServerSocket(BluetoothServer bluetoothServer) {
        return bluetoothServer.arBluetoothServerSocket;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$maccept(BluetoothServer bluetoothServer, String string, String string2, String string3) {
        bluetoothServer.accept(string, string2, string3);
    }

    public BluetoothServer(ComponentContainer componentContainer) {
        super(componentContainer, "BluetoothServer");
    }

    private void accept(String string, String string2, String string3) {
        UUID uUID;
        if (SUtil.requestPermissionsForAdvertising((Form)this.form, (BluetoothServer)this, (String)string, (PermissionResultHandler)new 1((BluetoothServer)this, string, string2, string3))) {
            return;
        }
        if (this.adapter == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 501, new Object[0]);
            return;
        }
        if (!this.adapter.isEnabled()) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 502, new Object[0]);
            return;
        }
        try {
            uUID = UUID.fromString((String)string3);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 506, string3);
            return;
        }
        try {
            string2 = !this.secure && Build.VERSION.SDK_INT >= 10 ? this.adapter.listenUsingInsecureRfcommWithServiceRecord(string2, uUID) : this.adapter.listenUsingRfcommWithServiceRecord(string2, uUID);
            this.arBluetoothServerSocket.set((Object)string2);
        }
        catch (IOException iOException) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 508, new Object[0]);
            return;
        }
        AsynchUtil.runAsynchronously((Runnable)new Runnable((BluetoothServer)this, string){
            final BluetoothServer this$0;
            final String val$functionName;
            {
                this.this$0 = bluetoothServer;
                this.val$functionName = string;
            }

            /*
             * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
             * Loose catch block
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                BluetoothSocket bluetoothSocket;
                block7: {
                    bluetoothSocket = null;
                    Object object2 = (BluetoothServerSocket)BluetoothServer.-$$Nest$fgetarBluetoothServerSocket(this.this$0).get();
                    if (object2 != null) {
                        Throwable throwable2222222;
                        block6: {
                            bluetoothSocket = object2.accept();
                            {
                                catch (Throwable throwable2222222) {
                                    break block6;
                                }
                                catch (IOException iOException) {}
                                {
                                    Handler handler = BluetoothServer.-$$Nest$fgetandroidUIHandler(this.this$0);
                                    object2 = new Runnable(this){
                                        final 2 this$1;
                                        {
                                            this.this$1 = var1;
                                        }

                                        public void run() {
                                            this.this$1.this$0.form.dispatchErrorOccurredEvent((Component)((Object)this.this$1.this$0), this.this$1.val$functionName, 509, new Object[0]);
                                        }
                                    };
                                    handler.post((Runnable)object2);
                                }
                                this.this$0.StopAccepting();
                                return;
                            }
                            this.this$0.StopAccepting();
                            break block7;
                        }
                        this.this$0.StopAccepting();
                        throw throwable2222222;
                    }
                }
                if (bluetoothSocket != null) {
                    BluetoothServer.-$$Nest$fgetandroidUIHandler(this.this$0).post(new Runnable(this, bluetoothSocket){
                        final 2 this$1;
                        final BluetoothSocket val$bluetoothSocket;
                        {
                            this.this$1 = var1;
                            this.val$bluetoothSocket = bluetoothSocket;
                        }

                        public void run() {
                            try {
                                this.this$1.this$0.setConnection(this.val$bluetoothSocket);
                            }
                            catch (IOException iOException) {
                                this.this$1.this$0.Disconnect();
                                this.this$1.this$0.form.dispatchErrorOccurredEvent((Component)((Object)this.this$1.this$0), this.this$1.val$functionName, 509, new Object[0]);
                                return;
                            }
                            this.this$1.this$0.ConnectionAccepted();
                        }
                    });
                }
            }
        });
    }

    @SimpleFunction(description="Accept an incoming connection with the Serial Port Profile (SPP).")
    public void AcceptConnection(String string) {
        super.accept("AcceptConnection", string, SPP_UUID);
    }

    @SimpleFunction(description="Accept an incoming connection with a specific UUID.")
    public void AcceptConnectionWithUUID(String string, String string2) {
        super.accept("AcceptConnectionWithUUID", string, string2);
    }

    @SimpleEvent(description="Indicates that a bluetooth connection has been accepted.")
    public void ConnectionAccepted() {
        Log.i((String)this.logTag, (String)"Successfullly accepted bluetooth connection.");
        EventDispatcher.dispatchEvent((Component)((Object)this), "ConnectionAccepted", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public final boolean IsAccepting() {
        boolean bl = this.arBluetoothServerSocket.get() != null;
        return bl;
    }

    @SimpleFunction(description="Stop accepting an incoming connection.")
    public void StopAccepting() {
        Object object2 = (BluetoothServerSocket)this.arBluetoothServerSocket.getAndSet(null);
        if (object2 != null) {
            try {
                object2.close();
            }
            catch (IOException iOException) {
                object2 = this.logTag;
                String string = iOException.getMessage();
                Log.w((String)object2, (String)("Error while closing bluetooth server socket: " + string));
            }
        }
    }
}

