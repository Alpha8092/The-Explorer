/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Log
 *  com.google.appinventor.components.common.MapFeature
 *  com.google.appinventor.components.runtime.Polygon$1
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.locationtech.jts.geom.Geometry
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import android.text.TextUtils;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.MapFeature;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Polygon;
import com.google.appinventor.components.runtime.PolygonBase;
import com.google.appinventor.components.runtime.errors.DispatchableError;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.locationtech.jts.geom.Geometry;
import org.osmdroid.util.GeoPoint;

@DesignerComponent(category=ComponentCategory.MAPS, description="Polygon encloses an arbitrary 2-dimensional area on a Map. Polygons can be used for drawing a perimeter, such as a campus, city, or country. Polygons begin as basic triangles. New vertices can be created by dragging the midpoint of a polygon away from the edge. Clicking on a vertex will remove the vertex, but a minimum of 3 vertices must exist at all times.", iconName="images/polygon.png", version=2)
@SimpleObject
public class Polygon
extends PolygonBase
implements MapFactory.MapPolygon {
    private static final String TAG = Polygon.class.getSimpleName();
    private static final MapFactory.MapFeatureVisitor<Double> distanceComputation = new 1();
    private List<List<List<GeoPoint>>> holePoints;
    private boolean initialized = false;
    private boolean multipolygon = false;
    private List<List<GeoPoint>> points = new ArrayList();

    public Polygon(MapFactory.MapFeatureContainer mapFeatureContainer) {
        super(mapFeatureContainer, distanceComputation);
        this.holePoints = new ArrayList();
        mapFeatureContainer.addFeature((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleFunction(description="Returns the centroid of the Polygon as a (latitude, longitude) pair.")
    public YailList Centroid() {
        return super.Centroid();
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Gets or sets the sequence of points used to draw holes in the polygon.")
    public YailList HolePoints() {
        if (this.holePoints.isEmpty()) {
            return YailList.makeEmptyList();
        }
        if (this.multipolygon) {
            LinkedList linkedList = new LinkedList();
            Iterator iterator = this.holePoints.iterator();
            while (iterator.hasNext()) {
                linkedList.add((Object)GeometryUtil.multiPolygonToYailList((List)((List)iterator.next())));
            }
            return YailList.makeList((List)linkedList);
        }
        return GeometryUtil.multiPolygonToYailList((List)((List)this.holePoints.get(0)));
    }

    @Override
    @SimpleProperty
    public void HolePoints(YailList object) {
        block4: {
            try {
                block8: {
                    block6: {
                        block7: {
                            block5: {
                                if (object.size() != 0) break block5;
                                this.holePoints = object = new ArrayList();
                                break block6;
                            }
                            if (!this.multipolygon) break block7;
                            this.holePoints = GeometryUtil.multiPolygonHolesFromYailList((YailList)object);
                            break block6;
                        }
                        if (!GeometryUtil.isMultiPolygon((YailList)object)) break block8;
                        ArrayList arrayList = new ArrayList();
                        arrayList.add((Object)GeometryUtil.multiPolygonFromYailList((YailList)object));
                        this.holePoints = arrayList;
                    }
                    if (this.initialized) {
                        this.clearGeometry();
                        this.map.getController().updateFeatureHoles((MapFactory.MapPolygon)this);
                    }
                    break block4;
                }
                object = new DispatchableError(3404, "Unable to determine the structure of the points argument.");
                throw object;
            }
            catch (DispatchableError dispatchableError) {
                this.container.$form().dispatchErrorOccurredEvent((Component)this, "HolePoints", dispatchableError.getErrorCode(), dispatchableError.getArguments());
            }
        }
    }

    @DesignerProperty(editorType="textArea")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Constructs holes in a polygon from a given list of coordinates per hole.")
    public void HolePointsFromString(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            this.holePoints = new ArrayList();
            this.map.getController().updateFeatureHoles((MapFactory.MapPolygon)this);
            return;
        }
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                string2 = new ArrayList();
                this.holePoints = string2;
                this.map.getController().updateFeatureHoles((MapFactory.MapPolygon)this);
                return;
            }
            this.holePoints = GeometryUtil.multiPolygonHolesToList((JSONArray)jSONArray);
            if (this.initialized) {
                this.clearGeometry();
                this.map.getController().updateFeatureHoles((MapFactory.MapPolygon)this);
            }
            string2 = TAG;
            List<List<GeoPoint>> list = this.points;
            jSONArray = new StringBuilder();
            Log.d((String)string2, (String)jSONArray.append("Points: ").append(list).toString());
        }
        catch (JSONException jSONException) {
            Log.e((String)TAG, (String)"Unable to parse point string", (Throwable)jSONException);
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "HolePointsFromString", 3404, jSONException.getMessage());
        }
    }

    public void Initialize() {
        this.initialized = true;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapPolygon)this);
        this.map.getController().updateFeatureHoles((MapFactory.MapPolygon)this);
        this.map.getController().updateFeatureText((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Gets or sets the sequence of points used to draw the polygon.")
    public YailList Points() {
        if (this.points.isEmpty()) {
            return YailList.makeEmptyList();
        }
        if (this.multipolygon) {
            LinkedList linkedList = new LinkedList();
            Iterator iterator = this.points.iterator();
            while (iterator.hasNext()) {
                linkedList.add((Object)GeometryUtil.pointsListToYailList((List)((List)iterator.next())));
            }
            return YailList.makeList((List)linkedList);
        }
        return GeometryUtil.pointsListToYailList((List)((List)this.points.get(0)));
    }

    @Override
    @SimpleProperty
    public void Points(YailList object) {
        block4: {
            try {
                block7: {
                    block6: {
                        block5: {
                            if (!GeometryUtil.isPolygon((YailList)object)) break block5;
                            this.multipolygon = false;
                            this.points.clear();
                            this.points.add((Object)GeometryUtil.pointsFromYailList((YailList)object));
                            break block6;
                        }
                        if (!GeometryUtil.isMultiPolygon((YailList)object)) break block7;
                        this.multipolygon = true;
                        this.points = GeometryUtil.multiPolygonFromYailList((YailList)object);
                    }
                    if (this.initialized) {
                        this.clearGeometry();
                        this.map.getController().updateFeaturePosition((MapFactory.MapPolygon)this);
                    }
                    break block4;
                }
                object = new DispatchableError(3404, "Unable to determine the structure of the points argument.");
                throw object;
            }
            catch (DispatchableError dispatchableError) {
                this.container.$form().dispatchErrorOccurredEvent((Component)this, "Points", dispatchableError.getErrorCode(), dispatchableError.getArguments());
            }
        }
    }

    @DesignerProperty(editorType="textArea")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Constructs a polygon from the given list of coordinates.")
    public void PointsFromString(String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            this.points = new ArrayList();
            this.map.getController().updateFeaturePosition((MapFactory.MapPolygon)this);
            return;
        }
        JSONArray jSONArray = new JSONArray(string2);
        if (jSONArray.length() == 0) {
            string2 = new ArrayList();
            this.points = string2;
            this.multipolygon = false;
            this.map.getController().updateFeaturePosition((MapFactory.MapPolygon)this);
            return;
        }
        string2 = GeometryUtil.multiPolygonToList((JSONArray)jSONArray);
        this.points = string2;
        boolean bl = string2.size() > 1;
        try {
            this.multipolygon = bl;
            if (this.initialized) {
                this.clearGeometry();
                this.map.getController().updateFeaturePosition((MapFactory.MapPolygon)this);
            }
        }
        catch (DispatchableError dispatchableError) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "PointsFromString", dispatchableError.getErrorCode(), dispatchableError.getArguments());
        }
        catch (JSONException jSONException) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "PointsFromString", 3404, jSONException.getMessage());
        }
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the type of the feature. For polygons, this returns MapFeature.Polygon (\"Polygon\").")
    public String Type() {
        return this.TypeAbstract().toUnderlyingValue();
    }

    public MapFeature TypeAbstract() {
        return MapFeature.Polygon;
    }

    @Override
    public <T> T accept(MapFactory.MapFeatureVisitor<T> mapFeatureVisitor, Object ... objectArray) {
        return (T)mapFeatureVisitor.visit((MapFactory.MapPolygon)this, objectArray);
    }

    @Override
    protected Geometry computeGeometry() {
        return GeometryUtil.createGeometry(this.points, this.holePoints);
    }

    @Override
    public List<List<List<GeoPoint>>> getHolePoints() {
        return this.holePoints;
    }

    @Override
    public List<List<GeoPoint>> getPoints() {
        return this.points;
    }

    boolean isInitialized() {
        return this.initialized;
    }

    @Override
    public void updateHolePoints(List<List<List<GeoPoint>>> list) {
        this.holePoints.clear();
        this.holePoints.addAll(list);
        this.clearGeometry();
    }

    @Override
    public void updatePoints(List<List<GeoPoint>> list) {
        this.points.clear();
        this.points.addAll(list);
        this.clearGeometry();
    }
}

