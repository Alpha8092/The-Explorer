/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.annotations;

public final class PropertyCategory
extends Enum<PropertyCategory> {
    private static final PropertyCategory[] $VALUES;
    public static final /* enum */ PropertyCategory ADVANCED;
    public static final /* enum */ PropertyCategory APPEARANCE;
    public static final /* enum */ PropertyCategory APPLICATION;
    public static final /* enum */ PropertyCategory BEHAVIOR;
    public static final /* enum */ PropertyCategory DEPRECATED;
    public static final /* enum */ PropertyCategory GENERAL;
    public static final /* enum */ PropertyCategory PUBLISHING;
    public static final /* enum */ PropertyCategory THEMING;
    public static final /* enum */ PropertyCategory UNSET;
    private final String name;

    static {
        PropertyCategory propertyCategory;
        PropertyCategory propertyCategory2;
        PropertyCategory propertyCategory3;
        PropertyCategory propertyCategory4;
        PropertyCategory propertyCategory5;
        PropertyCategory propertyCategory6;
        PropertyCategory propertyCategory7;
        PropertyCategory propertyCategory8;
        PropertyCategory propertyCategory9;
        BEHAVIOR = propertyCategory9 = new PropertyCategory("Behavior");
        APPEARANCE = propertyCategory8 = new PropertyCategory("Appearance");
        DEPRECATED = propertyCategory7 = new PropertyCategory("Deprecated");
        UNSET = propertyCategory6 = new PropertyCategory("Unspecified");
        APPLICATION = propertyCategory5 = new PropertyCategory("Application");
        ADVANCED = propertyCategory4 = new PropertyCategory("Advanced");
        GENERAL = propertyCategory3 = new PropertyCategory("General");
        THEMING = propertyCategory2 = new PropertyCategory("Theming");
        PUBLISHING = propertyCategory = new PropertyCategory("Publishing");
        $VALUES = new PropertyCategory[]{propertyCategory9, propertyCategory8, propertyCategory7, propertyCategory6, propertyCategory5, propertyCategory4, propertyCategory3, propertyCategory2, propertyCategory};
    }

    private PropertyCategory(String string2) {
        this.name = string2;
    }

    public static PropertyCategory valueOf(String string) {
        return (PropertyCategory)Enum.valueOf(PropertyCategory.class, (String)string);
    }

    public static PropertyCategory[] values() {
        return (PropertyCategory[])$VALUES.clone();
    }

    public String getName() {
        return this.name;
    }
}

