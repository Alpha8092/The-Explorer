/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorPort
 *  com.google.appinventor.components.common.NxtSensorType
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorPort;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsNxtSensor;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to a light sensor on a LEGO MINDSTORMS NXT robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtLightSensor
extends LegoMindstormsNxtSensor
implements Deleteable {
    private static final int DEFAULT_BOTTOM_OF_RANGE = 256;
    private static final String DEFAULT_SENSOR_PORT = "3";
    private static final int DEFAULT_TOP_OF_RANGE = 767;
    private boolean aboveRangeEventEnabled;
    private boolean belowRangeEventEnabled;
    private int bottomOfRange;
    private boolean generateLight;
    private Handler handler = new Handler();
    private State previousState = State.UNKNOWN;
    private final Runnable sensorReader;
    private int topOfRange;
    private boolean withinRangeEventEnabled;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetaboveRangeEventEnabled(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.aboveRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetbelowRangeEventEnabled(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.belowRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetbottomOfRange(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.bottomOfRange;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.handler;
    }

    static /* bridge */ /* synthetic */ State -$$Nest$fgetpreviousState(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.previousState;
    }

    static /* bridge */ /* synthetic */ Runnable -$$Nest$fgetsensorReader(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.sensorReader;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgettopOfRange(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.topOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetwithinRangeEventEnabled(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.withinRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousState(NxtLightSensor nxtLightSensor, State state) {
        nxtLightSensor.previousState = state;
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetLightValue(NxtLightSensor nxtLightSensor, String string2) {
        return nxtLightSensor.getLightValue(string2);
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$misHandlerNeeded(NxtLightSensor nxtLightSensor) {
        return nxtLightSensor.isHandlerNeeded();
    }

    public NxtLightSensor(ComponentContainer componentContainer) {
        super(componentContainer, "NxtLightSensor");
        this.sensorReader = new Runnable((NxtLightSensor)this){
            final NxtLightSensor this$0;
            {
                this.this$0 = nxtLightSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    Object object = NxtLightSensor.-$$Nest$mgetLightValue(this.this$0, "");
                    if (object.valid) {
                        object = (Integer)object.value < NxtLightSensor.-$$Nest$fgetbottomOfRange(this.this$0) ? State.BELOW_RANGE : ((Integer)object.value > NxtLightSensor.-$$Nest$fgettopOfRange(this.this$0) ? State.ABOVE_RANGE : State.WITHIN_RANGE);
                        if (object != NxtLightSensor.-$$Nest$fgetpreviousState(this.this$0)) {
                            if (object == State.BELOW_RANGE && NxtLightSensor.-$$Nest$fgetbelowRangeEventEnabled(this.this$0)) {
                                this.this$0.BelowRange();
                            }
                            if (object == State.WITHIN_RANGE && NxtLightSensor.-$$Nest$fgetwithinRangeEventEnabled(this.this$0)) {
                                this.this$0.WithinRange();
                            }
                            if (object == State.ABOVE_RANGE && NxtLightSensor.-$$Nest$fgetaboveRangeEventEnabled(this.this$0)) {
                                this.this$0.AboveRange();
                            }
                        }
                        NxtLightSensor.-$$Nest$fputpreviousState(this.this$0, (Object)object);
                    }
                }
                if (NxtLightSensor.-$$Nest$misHandlerNeeded(this.this$0)) {
                    NxtLightSensor.-$$Nest$fgethandler(this.this$0).post(NxtLightSensor.-$$Nest$fgetsensorReader(this.this$0));
                }
            }
        };
        this.SensorPort(DEFAULT_SENSOR_PORT);
        this.BottomOfRange(256);
        this.TopOfRange(767);
        this.BelowRangeEventEnabled(false);
        this.WithinRangeEventEnabled(false);
        this.AboveRangeEventEnabled(false);
        this.GenerateLight(false);
    }

    private LegoMindstormsNxtSensor.SensorValue<Integer> getLightValue(String object) {
        if ((object = (Object)this.getInputValues((String)object, this.port)) != null && this.getBooleanValueFromBytes((byte[])object, 4)) {
            return new Object(true, this.getUWORDValueFromBytes((byte[])object, 10)){
                final boolean valid;
                final T value;
                {
                    this.valid = bl;
                    this.value = t;
                }
            };
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private boolean isHandlerNeeded() {
        boolean bl = this.belowRangeEventEnabled || this.withinRangeEventEnabled || this.aboveRangeEventEnabled;
        return bl;
    }

    @SimpleEvent(description="Light level has gone above the range.")
    public void AboveRange() {
        EventDispatcher.dispatchEvent(this, "AboveRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void AboveRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.aboveRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the AboveRange event should fire when the light level goes above the TopOfRange.")
    public boolean AboveRangeEventEnabled() {
        return this.aboveRangeEventEnabled;
    }

    @SimpleEvent(description="Light level has gone below the range.")
    public void BelowRange() {
        EventDispatcher.dispatchEvent(this, "BelowRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BelowRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.belowRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the BelowRange event should fire when the light level goes below the BottomOfRange.")
    public boolean BelowRangeEventEnabled() {
        return this.belowRangeEventEnabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The bottom of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int BottomOfRange() {
        return this.bottomOfRange;
    }

    @DesignerProperty(defaultValue="256", editorType="non_negative_integer")
    @SimpleProperty
    public void BottomOfRange(int n) {
        this.bottomOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void GenerateLight(boolean bl) {
        this.generateLight = bl;
        if (this.bluetooth != null && this.bluetooth.IsConnected()) {
            this.initializeSensor("GenerateLight");
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the light sensor should generate light.")
    public boolean GenerateLight() {
        return this.generateLight;
    }

    @SimpleFunction(description="Returns the current light level as a value between 0 and 1023, or -1 if the light level can not be read.")
    public int GetLightLevel() {
        if (!this.checkBluetooth("GetLightLevel")) {
            return -1;
        }
        LegoMindstormsNxtSensor.SensorValue<Integer> sensorValue = this.getLightValue("GetLightLevel");
        if (sensorValue.valid) {
            return (Integer)sensorValue.value;
        }
        return -1;
    }

    @Override
    @DesignerProperty(defaultValue="3", editorType="lego_nxt_sensor_port")
    @SimpleProperty(userVisible=false)
    public void SensorPort(String string2) {
        this.setSensorPort(string2);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The top of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int TopOfRange() {
        return this.topOfRange;
    }

    @DesignerProperty(defaultValue="767", editorType="non_negative_integer")
    @SimpleProperty
    public void TopOfRange(int n) {
        this.topOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleEvent(description="Light level has gone within the range.")
    public void WithinRange() {
        EventDispatcher.dispatchEvent(this, "WithinRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WithinRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.withinRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the WithinRange event should fire when the light level goes between the BottomOfRange and the TopOfRange.")
    public boolean WithinRangeEventEnabled() {
        return this.withinRangeEventEnabled;
    }

    @Override
    protected void initializeSensor(String string2) {
        NxtSensorPort nxtSensorPort = this.port;
        NxtSensorType nxtSensorType = this.generateLight ? NxtSensorType.LightOn : NxtSensorType.LightOff;
        this.setInputMode(string2, nxtSensorPort, nxtSensorType, NxtSensorMode.Percentage);
    }

    @Override
    public void onDelete() {
        this.handler.removeCallbacks(this.sensorReader);
        super.onDelete();
    }
}

