/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.errors;

import com.google.appinventor.components.runtime.errors.RuntimeError;

public class YailRuntimeError
extends RuntimeError {
    private String errorType;

    public YailRuntimeError(String string, String string2) {
        super(string);
        this.errorType = string2;
    }

    public String getErrorType() {
        return this.errorType;
    }
}

