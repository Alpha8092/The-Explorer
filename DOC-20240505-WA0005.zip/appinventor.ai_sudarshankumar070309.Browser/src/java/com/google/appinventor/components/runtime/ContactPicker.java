/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.database.Cursor
 *  android.net.Uri
 *  android.provider.Contacts$ContactMethods
 *  android.provider.Contacts$People
 *  android.provider.Contacts$Phones
 *  android.util.Log
 *  com.google.appinventor.components.runtime.ContactPicker$1
 *  com.google.appinventor.components.runtime.util.HoneycombMR1Util
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.ContactPicker;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.Picker;
import com.google.appinventor.components.runtime.util.HoneycombMR1Util;
import com.google.appinventor.components.runtime.util.SdkLevel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.SOCIAL, description="A button that, when clicked on, displays a list of the contacts to choose among. After the user has made a selection, the following properties will be set to information about the chosen contact: <ul>\n<li> <code>ContactName</code>: the contact's name </li>\n <li> <code>EmailAddress</code>: the contact's primary email address </li>\n <li> <code>ContactUri</code>: the contact's URI on the device </li>\n<li> <code>EmailAddressList</code>: a list of the contact's email addresses </li>\n <li> <code>PhoneNumber</code>: the contact's primary phone number (on Later Android Verisons)</li>\n <li> <code>PhoneNumberList</code>: a list of the contact's phone numbers (on Later Android Versions)</li>\n <li> <code>Picture</code>: the name of the file containing the contact's image, which can be used as a <code>Picture</code> property value for the <code>Image</code> or <code>ImageSprite</code> component.</li></ul>\n</p><p>Other properties affect the appearance of the button (<code>TextAlignment</code>, <code>BackgroundColor</code>, etc.) and whether it can be clicked on (<code>Enabled</code>).\n</p><p>The ContactPicker component might not work on all phones. For example, on Android systems before system 3.0, it cannot pick phone numbers, and the list of email addresses will contain only one email.", iconName="images/contactPicker.png", version=6)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.READ_CONTACTS")
public class ContactPicker
extends Picker
implements ActivityResultListener {
    private static String[] CONTACT_PROJECTION;
    private static String[] DATA_PROJECTION;
    private static final int EMAIL_INDEX = 1;
    private static final int NAME_INDEX = 0;
    private static final int PHONE_INDEX = 2;
    private static final String[] PROJECTION;
    protected final Activity activityContext;
    protected String contactName;
    protected String contactPictureUri;
    protected String contactUri;
    protected String emailAddress;
    protected List emailAddressList;
    private boolean havePermission;
    private final Uri intentUri;
    protected String phoneNumber;
    protected List phoneNumberList;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(ContactPicker contactPicker, boolean bl) {
        contactPicker.havePermission = bl;
    }

    static {
        PROJECTION = new String[]{"name", "primary_email"};
    }

    public ContactPicker(ComponentContainer componentContainer) {
        super(componentContainer, Contacts.People.CONTENT_URI);
    }

    protected ContactPicker(ComponentContainer componentContainer, Uri uri) {
        super(componentContainer);
        this.havePermission = false;
        this.activityContext = componentContainer.$context();
        this.intentUri = SdkLevel.getLevel() >= 12 && uri.equals((Object)Contacts.People.CONTENT_URI) ? HoneycombMR1Util.getContentUri() : (SdkLevel.getLevel() >= 12 && uri.equals((Object)Contacts.Phones.CONTENT_URI) ? HoneycombMR1Util.getPhoneContentUri() : uri);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String ContactName() {
        return this.ensureNotNull(this.contactName);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="URI that specifies the location of the contact on the device.")
    public String ContactUri() {
        return this.ensureNotNull(this.contactUri);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String EmailAddress() {
        return this.ensureNotNull(this.emailAddress);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public List EmailAddressList() {
        return this.ensureNotNull(this.emailAddressList);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String PhoneNumber() {
        return this.ensureNotNull(this.phoneNumber);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public List PhoneNumberList() {
        return this.ensureNotNull(this.phoneNumberList);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String Picture() {
        return this.ensureNotNull(this.contactPictureUri);
    }

    @SimpleFunction(description="view a contact via its URI")
    public void ViewContact(String string2) {
        if (this.contactUri != null && (string2 = new Intent("android.intent.action.VIEW", Uri.parse((String)string2))).resolveActivity(this.activityContext.getPackageManager()) != null) {
            this.activityContext.startActivity((Intent)string2);
        }
    }

    protected boolean checkContactUri(Uri uri, String string2) {
        Log.i((String)"ContactPicker", (String)("contactUri is " + uri));
        if (uri != null && "content".equals((Object)uri.getScheme())) {
            if (!uri.getSchemeSpecificPart().startsWith(string2)) {
                Log.i((String)"ContactPicker", (String)"checkContactUri failed: C");
                Log.i((String)"ContactPicker", (String)uri.getPath());
                this.puntContactSelection(1107);
                return false;
            }
            return true;
        }
        Log.i((String)"ContactPicker", (String)"checkContactUri failed: A");
        this.puntContactSelection(1107);
        return false;
    }

    @Override
    public void click() {
        if (!this.havePermission) {
            this.container.$form().askPermission("android.permission.READ_CONTACTS", (PermissionResultHandler)new 1(this));
            return;
        }
        super.click();
    }

    protected String ensureNotNull(String string2) {
        if (string2 == null) {
            return "";
        }
        return string2;
    }

    protected List ensureNotNull(List list) {
        if (list == null) {
            return new ArrayList();
        }
        return list;
    }

    protected String getEmailAddress(String string2) {
        int n;
        try {
            n = Integer.parseInt((String)string2);
            string2 = "";
        }
        catch (NumberFormatException numberFormatException) {
            return "";
        }
        String string3 = "contact_methods._id = " + n;
        string3 = this.activityContext.getContentResolver().query(Contacts.ContactMethods.CONTENT_EMAIL_URI, new String[]{"data"}, string3, null, null);
        try {
            if (string3.moveToFirst()) {
                string2 = this.guardCursorGetString((Cursor)string3, 0);
            }
            return this.ensureNotNull(string2);
        }
        finally {
            string3.close();
        }
    }

    @Override
    protected Intent getIntent() {
        return new Intent("android.intent.action.PICK", this.intentUri);
    }

    protected String guardCursorGetString(Cursor object, int n) {
        try {
            object = object.getString(n);
        }
        catch (Exception exception) {
            object = "";
        }
        return this.ensureNotNull((String)object);
    }

    public void postHoneycombGetContactEmailAndPhone(Cursor cursor) {
        this.phoneNumber = "";
        this.emailAddress = "";
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (cursor.moveToFirst()) {
            int n = HoneycombMR1Util.getPhoneIndex((Cursor)cursor);
            int n2 = HoneycombMR1Util.getEmailIndex((Cursor)cursor);
            int n3 = HoneycombMR1Util.getMimeIndex((Cursor)cursor);
            String string2 = HoneycombMR1Util.getPhoneType();
            String string3 = HoneycombMR1Util.getEmailType();
            while (!cursor.isAfterLast()) {
                String string4 = this.guardCursorGetString(cursor, n3);
                if (string4.contains((CharSequence)string2)) {
                    arrayList.add((Object)this.guardCursorGetString(cursor, n));
                } else if (string4.contains((CharSequence)string3)) {
                    arrayList2.add((Object)this.guardCursorGetString(cursor, n2));
                } else {
                    Log.i((String)"ContactPicker", (String)("Type mismatch: " + string4 + " not " + string2 + " or " + string3));
                }
                cursor.moveToNext();
            }
        }
        if (!arrayList.isEmpty()) {
            this.phoneNumber = (String)arrayList.get(0);
        }
        if (!arrayList2.isEmpty()) {
            this.emailAddress = (String)arrayList2.get(0);
        }
        this.phoneNumberList = arrayList;
        this.emailAddressList = arrayList2;
    }

    public String postHoneycombGetContactNameAndPicture(Cursor object) {
        String string2 = "";
        if (object.moveToFirst()) {
            int n = HoneycombMR1Util.getIdIndex((Cursor)object);
            int n2 = HoneycombMR1Util.getNameIndex((Cursor)object);
            int n3 = HoneycombMR1Util.getThumbnailIndex((Cursor)object);
            int n4 = HoneycombMR1Util.getPhotoIndex((Cursor)object);
            string2 = this.guardCursorGetString((Cursor)object, n);
            this.contactName = this.guardCursorGetString((Cursor)object, n2);
            this.contactPictureUri = this.guardCursorGetString((Cursor)object, n3);
            object = this.guardCursorGetString((Cursor)object, n4);
            Log.i((String)"ContactPicker", (String)("photo_uri=" + (String)object));
        }
        return string2;
    }

    public void preHoneycombGetContactInfo(Cursor object, Uri uri) {
        if (object.moveToFirst()) {
            this.contactName = this.guardCursorGetString((Cursor)object, 0);
            this.emailAddress = this.getEmailAddress(this.guardCursorGetString((Cursor)object, 1));
            this.contactUri = uri.toString();
            this.contactPictureUri = uri.toString();
            object = this.emailAddress.equals((Object)"") ? new ArrayList() : Arrays.asList((Object[])new String[]{this.emailAddress});
            this.emailAddressList = object;
        }
    }

    protected void puntContactSelection(int n) {
        this.contactName = "";
        this.emailAddress = "";
        this.contactPictureUri = "";
        this.container.$form().dispatchErrorOccurredEvent((Component)this, "", n, new Object[0]);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void resultReturned(int n, int n2, Intent object) {
        block15: {
            block13: {
                Throwable throwable2222222;
                String string2;
                block11: {
                    String string3;
                    block14: {
                        String string4;
                        block10: {
                            if (n != this.requestCode || n2 != -1) break block15;
                            Log.i((String)"ContactPicker", (String)("received intent is " + object));
                            Object object2 = object.getData();
                            object = SdkLevel.getLevel() >= 12 ? "//com.android.contacts/contact" : "//contacts/people";
                            if (!this.checkContactUri((Uri)object2, (String)object)) break block13;
                            Cursor cursor = null;
                            String[] stringArray = null;
                            string4 = null;
                            String string5 = null;
                            String string6 = null;
                            object = stringArray;
                            string2 = string4;
                            Cursor cursor2 = cursor;
                            string3 = string5;
                            if (SdkLevel.getLevel() >= 12) {
                                object = stringArray;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                CONTACT_PROJECTION = HoneycombMR1Util.getContactProjection();
                                object = stringArray;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                cursor = this.activityContext.getContentResolver().query(object2, CONTACT_PROJECTION, null, null, null);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                string6 = this.postHoneycombGetContactNameAndPicture(cursor);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                stringArray = HoneycombMR1Util.getDataProjection();
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                DATA_PROJECTION = stringArray;
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                string4 = HoneycombMR1Util.getDataCursor((String)string6, (Activity)this.activityContext, (String[])stringArray);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string4;
                                this.postHoneycombGetContactEmailAndPhone((Cursor)string4);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string4;
                                this.contactUri = object2.toString();
                            } else {
                                object = stringArray;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                cursor = this.activityContext.getContentResolver().query(object2, PROJECTION, null, null, null);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                this.preHoneycombGetContactInfo(cursor, (Uri)object2);
                                string4 = string6;
                            }
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            String string7 = this.contactName;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            string5 = this.emailAddress;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            stringArray = this.contactUri;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            string6 = this.phoneNumber;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            object2 = this.contactPictureUri;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            StringBuilder stringBuilder = new StringBuilder();
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            Log.i((String)"ContactPicker", (String)stringBuilder.append("Contact name = ").append(string7).append(", email address = ").append(string5).append(",contact Uri = ").append((String)stringArray).append(", phone number = ").append(string6).append(", contactPhotoUri = ").append((String)object2).toString());
                            if (cursor == null) break block10;
                            {
                                block12: {
                                    catch (Throwable throwable2222222) {
                                        break block11;
                                    }
                                    catch (Exception exception) {}
                                    object = cursor2;
                                    string2 = string3;
                                    {
                                        Log.i((String)"ContactPicker", (String)"checkContactUri failed: D");
                                        object = cursor2;
                                        string2 = string3;
                                        this.puntContactSelection(1107);
                                        if (cursor2 == null) break block12;
                                    }
                                    cursor2.close();
                                }
                                if (string3 == null) break block13;
                                break block14;
                            }
                            cursor.close();
                        }
                        if (string4 == null) break block13;
                        string3 = string4;
                    }
                    string3.close();
                    break block13;
                }
                if (object != null) {
                    object.close();
                }
                if (string2 != null) {
                    string2.close();
                }
                throw throwable2222222;
            }
            this.AfterPicking();
        }
    }
}

