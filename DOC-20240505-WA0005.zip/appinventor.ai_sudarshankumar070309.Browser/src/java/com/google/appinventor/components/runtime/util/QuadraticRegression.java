/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.util.OlsTrendLine;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class QuadraticRegression
extends OlsTrendLine {
    @Override
    public Map<String, Object> compute(List<Double> arrayList, List<Double> list) {
        list = super.compute((List<Double>)arrayList, list);
        list.put((Object)"Yintercept", list.remove((Object)"intercept"));
        double d = (Double)list.get((Object)"x^2");
        double d2 = (Double)list.get((Object)"slope");
        double d3 = d2 * d2 - 4.0 * d * (Double)list.get((Object)"Yintercept");
        if (d3 > 0.0) {
            arrayList = new ArrayList();
            d3 = Math.sqrt((double)d3);
            arrayList.add((Object)((-d2 + d3) / (d * 2.0)));
            arrayList.add((Object)((-d2 - d3) / (2.0 * d)));
            list.put((Object)"Xintercepts", (Object)arrayList);
        } else if (d3 == 0.0) {
            list.put((Object)"Xintercepts", (Object)(-d2 / (2.0 * d)));
        } else {
            list.put((Object)"Xintercepts", (Object)Double.NaN);
        }
        return list;
    }

    @Override
    public float[] computePoints(Map<String, Object> object2, float f, float f2, int n, int n2) {
        if (!object2.containsKey((Object)"x^2")) {
            return new float[0];
        }
        double d = (Double)object2.get((Object)"x^2");
        double d2 = (Double)object2.get((Object)"slope");
        double d3 = (Double)object2.get((Object)"Yintercept");
        object2 = new float[n2 * 4];
        float f3 = Float.NEGATIVE_INFINITY;
        float f4 = Float.NEGATIVE_INFINITY;
        boolean bl = true;
        for (n = 0; n < n2; ++n) {
            double d4;
            double d5;
            if (bl) {
                f3 = f + (float)n * (f2 - f) / (float)n2;
                d5 = f3;
                Double.isNaN((double)d5);
                d4 = f3;
                Double.isNaN((double)d4);
                f4 = (float)((d5 * d + d2) * d4 + d3);
                bl = false;
            }
            object2[n * 4] = (Map<String, Object>)f3;
            object2[n * 4 + 1] = (Map<String, Object>)f4;
            f3 = f + (float)(n + 1) * (f2 - f) / (float)n2;
            d4 = f3;
            Double.isNaN((double)d4);
            d5 = f3;
            Double.isNaN((double)d5);
            f4 = (float)((d4 * d + d2) * d5 + d3);
            object2[n * 4 + 2] = (Map<String, Object>)f3;
            object2[n * 4 + 3] = (Map<String, Object>)f4;
        }
        return object2;
    }

    @Override
    protected boolean logY() {
        return false;
    }

    @Override
    protected int size() {
        return 3;
    }

    @Override
    protected double[] xVector(double d) {
        return new double[]{1.0, d, d * d};
    }
}

