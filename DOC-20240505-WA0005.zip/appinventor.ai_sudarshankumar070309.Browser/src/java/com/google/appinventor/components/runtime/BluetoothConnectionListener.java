/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.runtime.BluetoothConnectionBase;

interface BluetoothConnectionListener {
    public void afterConnect(BluetoothConnectionBase var1);

    public void beforeDisconnect(BluetoothConnectionBase var1);
}

