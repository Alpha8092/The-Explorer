/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.media.SoundPool
 *  android.media.SoundPool$OnLoadCompleteListener
 *  android.os.Handler
 *  android.os.Vibrator
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Sound$1
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.TiramisuUtil
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.runtime;

import android.media.SoundPool;
import android.os.Handler;
import android.os.Vibrator;
import android.util.Log;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.Sound;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.TiramisuUtil;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="<p>A multimedia component that plays sound files and optionally vibrates for the number of milliseconds (thousandths of a second) specified in the Blocks Editor.  The name of the sound file to play can be specified either in the Designer or in the Blocks Editor.</p> <p>For supported sound file formats, see <a href=\"http://developer.android.com/guide/appendix/media-formats.html\" target=\"_blank\">Android Supported Media Formats</a>.</p><p>This <code>Sound</code> component is best for short sound files, such as sound effects, while the <code>Player</code> component is more efficient for longer sounds, such as songs.</p><p>You might get an error if you attempt to play a sound immeditely after setting the source.</p>", iconName="images/soundEffect.png", nonVisible=true, version=4)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.VIBRATE, android.permission.INTERNET")
public class Sound
extends AndroidNonvisibleComponent
implements Component,
OnResumeListener,
OnStopListener,
OnDestroyListener,
Deleteable {
    private static final int LOOP_MODE_NO_LOOP = 0;
    private static final int MAX_PLAY_DELAY_RETRIES = 10;
    private static final int MAX_STREAMS = 10;
    private static final float PLAYBACK_RATE_NORMAL = 1.0f;
    private static final int PLAY_DELAY_LENGTH = 50;
    private static final float VOLUME_FULL = 1.0f;
    private int delayRetries;
    private boolean loadComplete;
    private int minimumInterval;
    private final Handler playWaitHandler;
    private int soundId;
    private final Map<String, Integer> soundMap;
    private SoundPool soundPool;
    private String sourcePath;
    private int streamId;
    private final Component thisComponent;
    private long timeLastPlayed;
    private final Vibrator vibe;
    private final boolean waitForLoadToComplete;

    static /* bridge */ /* synthetic */ int -$$Nest$fgetdelayRetries(Sound sound) {
        return sound.delayRetries;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetloadComplete(Sound sound) {
        return sound.loadComplete;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetsourcePath(Sound sound) {
        return sound.sourcePath;
    }

    static /* bridge */ /* synthetic */ Component -$$Nest$fgetthisComponent(Sound sound) {
        return sound.thisComponent;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputdelayRetries(Sound sound, int n) {
        sound.delayRetries = n;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mplayAndCheckResult(Sound sound) {
        sound.playAndCheckResult();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mplayWhenLoadComplete(Sound sound) {
        sound.playWhenLoadComplete();
    }

    public Sound(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        boolean bl = SdkLevel.getLevel() >= 8;
        this.waitForLoadToComplete = bl;
        this.playWaitHandler = new Handler();
        this.thisComponent = this;
        this.soundPool = new SoundPool(10, 3, 0);
        this.soundMap = new HashMap();
        this.vibe = (Vibrator)this.form.getSystemService("vibrator");
        this.sourcePath = "";
        this.loadComplete = true;
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.form.registerForOnDestroy((OnDestroyListener)this);
        this.form.setVolumeControlStream(3);
        this.MinimumInterval(500);
        if (bl) {
            new Object((Sound)this, null){
                final Sound this$0;
                {
                    this.this$0 = sound;
                }

                public void setOnloadCompleteListener(SoundPool soundPool) {
                    soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener(this){
                        final OnLoadHelper this$1;
                        {
                            this.this$1 = onLoadHelper;
                        }

                        public void onLoadComplete(SoundPool soundPool, int n, int n2) {
                            this.this$1.this$0.loadComplete = true;
                        }
                    });
                }
            }.setOnloadCompleteListener(this.soundPool);
        }
    }

    private void playAndCheckResult() {
        int n;
        this.streamId = n = this.soundPool.play(this.soundId, 1.0f, 1.0f, 0, 0, 1.0f);
        Log.i((String)"Sound", (String)("SoundPool.play returned stream id " + n));
        if (this.streamId == 0) {
            this.form.dispatchErrorOccurredEvent(this, "Play", 703, this.sourcePath);
        }
    }

    private void playWhenLoadComplete() {
        if (!this.loadComplete && this.waitForLoadToComplete) {
            int n = this.delayRetries;
            Log.i((String)"Sound", (String)("Sound not ready:  retrying.  Remaining retries = " + n));
            this.playWaitHandler.postDelayed(new Runnable(this){
                final Sound this$0;
                {
                    this.this$0 = sound;
                }

                public void run() {
                    if (Sound.-$$Nest$fgetloadComplete(this.this$0)) {
                        Sound.-$$Nest$mplayAndCheckResult(this.this$0);
                    } else if (Sound.-$$Nest$fgetdelayRetries(this.this$0) > 0) {
                        Sound sound = this.this$0;
                        Sound.-$$Nest$fputdelayRetries(sound, Sound.-$$Nest$fgetdelayRetries(sound) - 1);
                        Sound.-$$Nest$mplayWhenLoadComplete(this.this$0);
                    } else {
                        this.this$0.form.dispatchErrorOccurredEvent(Sound.-$$Nest$fgetthisComponent(this.this$0), "Play", 710, Sound.-$$Nest$fgetsourcePath(this.this$0));
                    }
                }
            }, 50L);
        } else {
            this.playAndCheckResult();
        }
    }

    private void prepareToDie() {
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.stop(n);
            this.soundPool.unload(this.streamId);
        }
        this.soundPool.release();
        this.vibe.cancel();
        this.soundPool = null;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The minimum interval, in milliseconds, between sounds.  If you play a sound, all further Play() calls will be ignored until the interval has elapsed.")
    public int MinimumInterval() {
        return this.minimumInterval;
    }

    @DesignerProperty(defaultValue="500", editorType="non_negative_integer")
    @SimpleProperty
    public void MinimumInterval(int n) {
        this.minimumInterval = n;
    }

    @SimpleFunction(description="Pauses playing the sound if it is being played.")
    public void Pause() {
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.pause(n);
        } else {
            Log.i((String)"Sound", (String)"Unable to pause. Did you remember to call the Play function?");
        }
    }

    @SimpleFunction(description="Plays the sound specified by the Source property.")
    public void Play() {
        if (this.soundId != 0) {
            long l = System.currentTimeMillis();
            long l2 = this.timeLastPlayed;
            if (l2 != 0L && l < l2 + (long)this.minimumInterval) {
                Log.i((String)"Sound", (String)"Unable to play because MinimumInterval has not elapsed since last play.");
            } else {
                this.timeLastPlayed = l;
                this.delayRetries = 10;
                this.playWhenLoadComplete();
            }
        } else {
            Log.i((String)"Sound", (String)"Sound Id was 0. Did you remember to set the Source property?");
            this.form.dispatchErrorOccurredEvent(this, "Play", 703, this.sourcePath);
        }
    }

    @SimpleFunction(description="Resumes playing the sound after a pause.")
    public void Resume() {
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.resume(n);
        } else {
            Log.i((String)"Sound", (String)"Unable to resume. Did you remember to call the Play function?");
        }
    }

    @SimpleEvent(description="The SoundError event is no longer used. Please use the Screen.ErrorOccurred event instead.", userVisible=false)
    public void SoundError(String string) {
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The name of the sound file.  Only certain formats are supported.  See http://developer.android.com/guide/appendix/media-formats.html.")
    public String Source() {
        return this.sourcePath;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty
    public void Source(@Asset String string) {
        String string2 = string == null ? "" : string;
        if (TiramisuUtil.requestAudioPermissions((Form)this.form, (String)string, (PermissionResultHandler)new 1((Sound)this, string2))) {
            return;
        }
        this.sourcePath = string2;
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.stop(n);
            this.streamId = 0;
        }
        this.soundId = 0;
        if (this.sourcePath.length() == 0) return;
        string = (Integer)this.soundMap.get((Object)this.sourcePath);
        if (string != null) {
            this.soundId = string.intValue();
            return;
        }
        string = this.sourcePath;
        Log.i((String)"Sound", (String)("No existing sound with path " + string + "."));
        try {
            n = MediaUtil.loadSoundPool((SoundPool)this.soundPool, (Form)this.form, (String)this.sourcePath);
            if (n != 0) {
                this.soundMap.put((Object)this.sourcePath, (Object)n);
                string = new StringBuilder();
                Log.i((String)"Sound", (String)string.append("Successfully began loading sound: setting soundId to ").append(n).append(".").toString());
                this.soundId = n;
                this.loadComplete = false;
                return;
            }
            this.form.dispatchErrorOccurredEvent((Component)this, "Source", 701, this.sourcePath);
            return;
        }
        catch (IOException iOException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "Source", 701, this.sourcePath);
            return;
        }
        catch (PermissionException permissionException) {
            this.form.dispatchPermissionDeniedEvent((Component)this, "Source", permissionException);
        }
    }

    @SimpleFunction(description="Stops playing the sound if it is being played.")
    public void Stop() {
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.stop(n);
            this.streamId = 0;
        } else {
            Log.i((String)"Sound", (String)"Unable to stop. Did you remember to call the Play function?");
        }
    }

    @SimpleFunction(description="Vibrates for the specified number of milliseconds.")
    public void Vibrate(int n) {
        this.vibe.vibrate((long)n);
    }

    @Override
    public void onDelete() {
        this.prepareToDie();
    }

    @Override
    public void onDestroy() {
        this.prepareToDie();
    }

    @Override
    public void onResume() {
        Log.i((String)"Sound", (String)"Got onResume");
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.resume(n);
        }
    }

    @Override
    public void onStop() {
        Log.i((String)"Sound", (String)"Got onStop");
        int n = this.streamId;
        if (n != 0) {
            this.soundPool.pause(n);
        }
    }
}

