/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.MapFeature
 *  com.google.appinventor.components.runtime.Circle$1
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  org.locationtech.jts.geom.Geometry
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.MapFeature;
import com.google.appinventor.components.runtime.Circle;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.PolygonBase;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import org.locationtech.jts.geom.Geometry;
import org.osmdroid.util.GeoPoint;

@DesignerComponent(category=ComponentCategory.MAPS, description="Circle", iconName="images/circle.png", version=2)
@SimpleObject
public class Circle
extends PolygonBase
implements MapFactory.MapCircle {
    private static final MapFactory.MapFeatureVisitor<Double> distanceComputation = new 1();
    private GeoPoint center = new GeoPoint(0.0, 0.0);
    private double latitude;
    private double longitude;
    private double radius;

    public Circle(MapFactory.MapFeatureContainer mapFeatureContainer) {
        super(mapFeatureContainer, distanceComputation);
        mapFeatureContainer.addFeature((MapFactory.MapFeature)this);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The latitude of the center of the circle.")
    public double Latitude() {
        return this.latitude;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="latitude")
    @SimpleProperty
    public void Latitude(double d) {
        if (GeometryUtil.isValidLatitude((double)d)) {
            this.latitude = d;
            this.center.setLatitude(d);
            this.clearGeometry();
            this.map.getController().updateFeaturePosition((MapFactory.MapCircle)this);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "Latitude", 3413, d);
        }
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The longitude of the center of the circle.")
    public double Longitude() {
        return this.longitude;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="longitude")
    @SimpleProperty
    public void Longitude(double d) {
        if (GeometryUtil.isValidLongitude((double)d)) {
            this.longitude = d;
            this.center.setLongitude(d);
            this.clearGeometry();
            this.map.getController().updateFeaturePosition((MapFactory.MapCircle)this);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "Longitude", 3414, d);
        }
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The radius of the circle in meters.")
    public double Radius() {
        return this.radius;
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="non_negative_float")
    @SimpleProperty
    public void Radius(double d) {
        this.radius = d;
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapCircle)this);
    }

    @Override
    @SimpleFunction(description="Set the center of the Circle.")
    public void SetLocation(double d, double d2) {
        if (!GeometryUtil.isValidLatitude((double)d)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetLocation", 3413, d);
        } else if (!GeometryUtil.isValidLongitude((double)d2)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetLocation", 3414, d2);
        } else {
            this.latitude = d;
            this.longitude = d2;
            this.center.setLatitude(d);
            this.center.setLongitude(d2);
            this.clearGeometry();
            this.map.getController().updateFeaturePosition((MapFactory.MapCircle)this);
        }
    }

    @Override
    @SimpleProperty(description="Returns the type of the feature. For Circles, this returns MapFeature.Circle (\"Circle\").")
    public String Type() {
        return this.TypeAbstract().toUnderlyingValue();
    }

    public MapFeature TypeAbstract() {
        return MapFeature.Circle;
    }

    @Override
    public <T> T accept(MapFactory.MapFeatureVisitor<T> mapFeatureVisitor, Object ... objectArray) {
        return (T)mapFeatureVisitor.visit((MapFactory.MapCircle)this, objectArray);
    }

    @Override
    protected Geometry computeGeometry() {
        return GeometryUtil.createGeometry((GeoPoint)this.center);
    }

    @Override
    public void updateCenter(double d, double d2) {
        this.latitude = d;
        this.longitude = d2;
        this.clearGeometry();
    }
}

