/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.Kim
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.StringBuffer
 *  java.util.HashMap
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.Kim;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.Keep;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem;
import java.util.HashMap;

class MapKeep
extends Keep {
    private Object[] list;
    private HashMap map;

    public MapKeep(int n) {
        super(n);
        this.list = new Object[this.capacity];
        this.map = new HashMap(this.capacity);
    }

    private void compact() {
        int n = 0;
        for (int i = 0; i < this.capacity; ++i) {
            Object object2 = this.list[i];
            long l = MapKeep.age(this.uses[i]);
            if (l > 0L) {
                this.uses[n] = l;
                this.list[n] = object2;
                this.map.put(object2, (Object)new Integer(n));
                ++n;
                continue;
            }
            this.map.remove(object2);
        }
        if (n < this.capacity) {
            this.length = n;
        } else {
            this.map.clear();
            this.length = 0;
        }
        this.power = 0;
    }

    public int find(Object object2) {
        int n = (object2 = this.map.get(object2)) instanceof Integer ? (Integer)object2 : -1;
        return n;
    }

    public boolean postMortem(PostMortem object2) {
        MapKeep mapKeep = (MapKeep)object2;
        if (this.length != mapKeep.length) {
            JSONzip.log(new StringBuffer().append(this.length).append(" <> ").append(mapKeep.length).toString());
            return false;
        }
        for (int i = 0; i < this.length; ++i) {
            boolean bl;
            Object object3 = this.list;
            object2 = object3[i];
            if (object2 instanceof Kim) {
                bl = ((Kim)object2).equals(mapKeep.list[i]);
            } else {
                object3 = object3[i];
                Object object4 = mapKeep.list[i];
                object2 = object3;
                if (object3 instanceof Number) {
                    object2 = object3.toString();
                }
                object3 = object4;
                if (object4 instanceof Number) {
                    object3 = object4.toString();
                }
                bl = object2.equals(object3);
            }
            if (bl) continue;
            JSONzip.log(new StringBuffer().append("\n[").append(i).append("]\n ").append(this.list[i]).append("\n ").append(mapKeep.list[i]).append("\n ").append(this.uses[i]).append("\n ").append(mapKeep.uses[i]).toString());
            return false;
        }
        return true;
    }

    public void register(Object object2) {
        if (this.length >= this.capacity) {
            super.compact();
        }
        this.list[this.length] = object2;
        this.map.put(object2, (Object)new Integer(this.length));
        this.uses[this.length] = 1L;
        ++this.length;
    }

    @Override
    public Object value(int n) {
        return this.list[n];
    }
}

