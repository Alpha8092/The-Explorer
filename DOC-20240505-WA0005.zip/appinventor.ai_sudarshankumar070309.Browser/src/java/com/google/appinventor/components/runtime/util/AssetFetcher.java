package com.google.appinventor.components.runtime.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.ReplForm;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public class AssetFetcher {
    private static Context context = ReplForm.getActiveForm();
    private static HashDatabase db = new HashDatabase(context);
    private static final String LOG_TAG = AssetFetcher.class.getSimpleName();
    private static ExecutorService background = Executors.newSingleThreadExecutor();
    private static volatile boolean inError = false;
    private static final Object semaphore = new Object();

    private AssetFetcher() {
    }

    public static void fetchAssets(final String cookieValue, final String projectId, final String uri, final String asset) {
        background.submit(new Runnable() { // from class: com.google.appinventor.components.runtime.util.AssetFetcher.1
            @Override // java.lang.Runnable
            public void run() {
                String fileName = uri + "/ode/download/file/" + projectId + "/" + asset;
                if (AssetFetcher.getFile(fileName, cookieValue, asset, 0) != null) {
                    RetValManager.assetTransferred(asset);
                }
            }
        });
    }

    public static void upgradeCompanion(final String cookieValue, final String inputUri) {
        background.submit(new Runnable() { // from class: com.google.appinventor.components.runtime.util.AssetFetcher.2
            @Override // java.lang.Runnable
            public void run() {
                String[] parts = inputUri.split("/", 0);
                String asset = parts[parts.length - 1];
                File assetFile = AssetFetcher.getFile(inputUri, cookieValue, asset, 0);
                if (assetFile != null) {
                    try {
                        Form form = Form.getActiveForm();
                        Intent intent = new Intent("android.intent.action.VIEW");
                        Uri packageuri = NougatUtil.getPackageUri(form, assetFile);
                        intent.setDataAndType(packageuri, "application/vnd.android.package-archive");
                        intent.setFlags(1);
                        form.startActivity(intent);
                    } catch (Exception e) {
                        Log.e(AssetFetcher.LOG_TAG, "ERROR_UNABLE_TO_GET", e);
                        RetValManager.sendError("Unable to Install new Companion Package.");
                    }
                }
            }
        });
    }

    public static void loadExtensions(String jsonString) {
        String str = LOG_TAG;
        Log.d(str, "loadExtensions called jsonString = " + jsonString);
        try {
            ReplForm form = (ReplForm) Form.getActiveForm();
            JSONArray array = new JSONArray(jsonString);
            List<String> extensionsToLoad = new ArrayList<>();
            if (array.length() == 0) {
                Log.d(str, "loadExtensions: No Extensions");
                RetValManager.extensionsLoaded();
                return;
            }
            for (int i = 0; i < array.length(); i++) {
                String extensionName = array.optString(i);
                if (extensionName != null) {
                    Log.d(LOG_TAG, "loadExtensions, extensionName = " + extensionName);
                    extensionsToLoad.add(extensionName);
                } else {
                    Log.e(LOG_TAG, "extensionName was null");
                    return;
                }
            }
            try {
                form.loadComponents(extensionsToLoad);
                RetValManager.extensionsLoaded();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Error in form.loadComponents", e);
            }
        } catch (JSONException e2) {
            Log.e(LOG_TAG, "JSON Exception parsing extension string", e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Not initialized variable reg: 16, insn: 0x0147: MOVE  (r7 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = (r16 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('responseCode' int)]), block:B:64:0x0147 */
    public static File getFile(final String fileName, String cookieValue, String asset, int depth) {
        int responseCode;
        Form form = Form.getActiveForm();
        if (depth > 1) {
            synchronized (semaphore) {
                if (inError) {
                    return null;
                }
                inError = true;
                form.runOnUiThread(new Runnable() { // from class: com.google.appinventor.components.runtime.util.AssetFetcher.3
                    @Override // java.lang.Runnable
                    public void run() {
                        RuntimeErrorAlert.alert(Form.getActiveForm(), "Unable to load file: " + fileName, "Error!", "End Application");
                    }
                });
                return null;
            }
        }
        int responseCode2 = 0;
        File outFile = new File(QUtil.getReplAssetPath(form, true), asset.substring("assets/".length()));
        String str = LOG_TAG;
        Log.d(str, "target file = " + outFile);
        String fileHash = null;
        boolean error = false;
        try {
            URL url = new URL(fileName);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            if (connection != null) {
                connection.addRequestProperty("Cookie", "AppInventor = " + cookieValue);
                HashFile hashFile = db.getHashFile(asset);
                if (hashFile != null) {
                    try {
                        connection.addRequestProperty("If-None-Match", hashFile.getHash());
                    } catch (Exception e) {
                        e = e;
                        Log.e(LOG_TAG, "Exception while fetching " + fileName, e);
                        return getFile(fileName, cookieValue, asset, depth + 1);
                    }
                }
                connection.setRequestMethod("GET");
                int responseCode3 = connection.getResponseCode();
                try {
                    Log.d(str, "asset = " + asset + " responseCode = " + responseCode3);
                    File parentOutFile = outFile.getParentFile();
                    fileHash = connection.getHeaderField("ETag");
                    if (responseCode3 == 304) {
                        return outFile;
                    }
                    if (!parentOutFile.exists() && !parentOutFile.mkdirs()) {
                        throw new IOException("Unable to create assets directory " + parentOutFile);
                    }
                    BufferedInputStream in = new BufferedInputStream(connection.getInputStream(), 4096);
                    try {
                        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile), 4096);
                        while (true) {
                            try {
                                try {
                                    int b = in.read();
                                    if (b == -1) {
                                        break;
                                    }
                                    out.write(b);
                                } catch (Exception e2) {
                                    e = e2;
                                    Log.e(LOG_TAG, "Exception while fetching " + fileName, e);
                                    return getFile(fileName, cookieValue, asset, depth + 1);
                                }
                            } catch (IOException e3) {
                                try {
                                    responseCode = responseCode3;
                                    try {
                                        Log.e(LOG_TAG, "copying assets", e3);
                                        error = true;
                                        out.close();
                                    } catch (Throwable th) {
                                        th = th;
                                        out.close();
                                        throw th;
                                    }
                                } catch (Throwable th2) {
                                    th = th2;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                out.close();
                                throw th;
                            }
                        }
                        out.flush();
                        try {
                            out.close();
                            responseCode = responseCode3;
                            connection.disconnect();
                            responseCode2 = responseCode;
                        } catch (Exception e4) {
                            e = e4;
                            Log.e(LOG_TAG, "Exception while fetching " + fileName, e);
                            return getFile(fileName, cookieValue, asset, depth + 1);
                        }
                    } catch (Exception e5) {
                        e = e5;
                    }
                } catch (Exception e6) {
                    e = e6;
                }
            } else {
                error = true;
            }
            if (error) {
                return getFile(fileName, cookieValue, asset, depth + 1);
            }
            if (responseCode2 == 200) {
                Date timeStamp = new Date();
                HashFile file = new HashFile(asset, fileHash, timeStamp);
                if (db.getHashFile(asset) == null) {
                    db.insertHashFile(file);
                } else {
                    db.updateHashFile(file);
                }
                return outFile;
            }
            return null;
        } catch (Exception e7) {
            e = e7;
        }
    }

    private static String byteArray2Hex(byte[] hash) {
        Formatter formatter = new Formatter();
        for (byte b : hash) {
            formatter.format("%02x", Byte.valueOf(b));
        }
        return formatter.toString();
    }
}
