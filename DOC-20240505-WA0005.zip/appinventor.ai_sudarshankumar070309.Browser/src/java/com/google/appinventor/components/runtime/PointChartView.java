/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  com.github.mikephil.charting.charts.BarLineChartBase
 *  com.github.mikephil.charting.data.BarLineScatterCandleBubbleData
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.interfaces.datasets.IBarLineScatterCandleBubbleDataSet
 *  com.google.appinventor.components.runtime.AxisChartView
 *  com.google.appinventor.components.runtime.Chart
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.view.View;
import android.view.ViewGroup;
import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.data.BarLineScatterCandleBubbleData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.interfaces.datasets.IBarLineScatterCandleBubbleDataSet;
import com.google.appinventor.components.runtime.AxisChartView;
import com.google.appinventor.components.runtime.Chart;

public abstract class PointChartView<E extends Entry, T extends IBarLineScatterCandleBubbleDataSet<E>, D extends BarLineScatterCandleBubbleData<T>, C extends BarLineChartBase<D>, V extends PointChartView<E, T, D, C, V>>
extends AxisChartView<E, T, D, C, V> {
    protected PointChartView(Chart chart) {
        super(chart);
    }

    public View getView() {
        return this.chart;
    }

    protected void initializeDefaultSettings() {
        super.initializeDefaultSettings();
        ((BarLineChartBase)this.chart).setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
    }
}

