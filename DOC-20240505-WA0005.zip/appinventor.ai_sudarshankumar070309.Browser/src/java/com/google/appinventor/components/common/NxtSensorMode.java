package com.google.appinventor.components.common;

import com.google.appinventor.components.runtime.util.FullScreenVideoUtil;
import gnu.math.DateTime;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public enum NxtSensorMode implements OptionList<Integer> {
    Raw(0),
    Boolean(32),
    TransitionCount(96),
    PeriodCount(96),
    Percentage(DateTime.TIMEZONE_MASK),
    RcxCelsius(ComponentConstants.TEXTBOX_PREFERRED_WIDTH),
    RcxFahrenheit(FullScreenVideoUtil.FULLSCREEN_VIDEO_ACTION_PAUSE),
    RcxAngleSteps(224);
    
    private static final Map<Integer, NxtSensorMode> lookup = new HashMap();
    private final int value;

    static {
        NxtSensorMode[] values;
        for (NxtSensorMode mode : values()) {
            lookup.put(mode.toUnderlyingValue(), mode);
        }
    }

    NxtSensorMode(int mode) {
        this.value = mode;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.google.appinventor.components.common.OptionList
    public Integer toUnderlyingValue() {
        return Integer.valueOf(this.value);
    }

    public static NxtSensorMode fromUnderlyingValue(Integer mode) {
        return lookup.get(mode);
    }
}
