/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.Form
 *  java.lang.Object
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import java.util.List;

public interface ComponentContainer {
    public void $add(AndroidViewComponent var1);

    public Activity $context();

    public Form $form();

    public int Height();

    public int Width();

    public List<? extends Component> getChildren();

    public void setChildHeight(AndroidViewComponent var1, int var2);

    public void setChildWidth(AndroidViewComponent var1, int var2);
}

