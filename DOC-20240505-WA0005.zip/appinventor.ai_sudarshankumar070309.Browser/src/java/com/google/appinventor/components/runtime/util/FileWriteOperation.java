/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.net.Uri
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.FileAccessMode
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  com.google.appinventor.components.runtime.util.ScopedFile
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.net.URI
 */
package com.google.appinventor.components.runtime.util;

import android.content.ContentResolver;
import android.net.Uri;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.FileAccessMode;
import com.google.appinventor.components.runtime.util.FileStreamOperation;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.ScopedFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;

public class FileWriteOperation
extends FileStreamOperation<OutputStream> {
    public FileWriteOperation(Form form, Component component, String string2, ScopedFile scopedFile, boolean bl, boolean bl2) {
        FileAccessMode fileAccessMode = bl ? FileAccessMode.APPEND : FileAccessMode.WRITE;
        super(form, component, string2, scopedFile, fileAccessMode, bl2);
        if (scopedFile.getScope() != FileScope.Asset) {
            return;
        }
        throw new IllegalArgumentException("Cannot perform a write operation on an asset");
    }

    public FileWriteOperation(Form form, Component component, String string2, String string3, FileScope fileScope, boolean bl, boolean bl2) {
        FileAccessMode fileAccessMode = bl ? FileAccessMode.APPEND : FileAccessMode.WRITE;
        super(form, component, string2, string3, fileScope, fileAccessMode, bl2);
        if (!string3.startsWith("//")) {
            return;
        }
        throw new IllegalArgumentException("Cannot perform a write operation on an asset");
    }

    @Override
    protected OutputStream openFile() throws IOException {
        String string2;
        if (this.fileName.startsWith("content:")) {
            ContentResolver contentResolver = this.form.getContentResolver();
            Uri uri = Uri.parse((String)this.fileName);
            String string3 = this.accessMode == FileAccessMode.WRITE ? "wt" : "wa";
            return contentResolver.openOutputStream(uri, string3);
        }
        String string4 = FileUtil.resolveFileName((Form)this.form, (String)this.fileName, (FileScope)this.scope);
        if (string4.startsWith("file://")) {
            string2 = URI.create((String)string4).getPath();
        } else {
            string2 = string4;
            if (string4.startsWith("file:")) {
                string2 = URI.create((String)string4).getPath();
            }
        }
        string2 = new File(string2);
        IOUtils.mkdirs((File)string2);
        return new FileOutputStream((File)string2, FileAccessMode.APPEND.equals((Object)this.accessMode));
    }

    @Override
    protected boolean process(OutputStream outputStream) throws IOException {
        return true;
    }
}

