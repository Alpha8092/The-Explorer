/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.runtime.SpeechListener;

public abstract class SpeechRecognizerController {
    SpeechListener speechListener;

    void addListener(SpeechListener speechListener) {
        this.speechListener = speechListener;
    }

    void start() {
    }

    void stop() {
    }
}

