/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.content.Intent;

public interface OnNewIntentListener {
    public void onNewIntent(Intent var1);
}

