/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.SensorComponent
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 */
package com.google.appinventor.components.runtime;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.SensorComponent;

@DesignerComponent(category=ComponentCategory.SENSORS, description="<p>Non-visible component that measures the ambient geomagnetic field for all three physical axes (x, y, z) in Tesla https://en.wikipedia.org/wiki/Tesla_(unit).</p>", iconName="images/magneticSensor.png", nonVisible=true, version=1)
@SimpleObject
public class MagneticFieldSensor
extends AndroidNonvisibleComponent
implements SensorEventListener,
Deleteable,
OnPauseListener,
OnResumeListener,
OnStopListener,
SensorComponent {
    private double absoluteStrength;
    private boolean enabled = true;
    private boolean listening;
    private Sensor magneticSensor;
    private final SensorManager sensorManager;
    private float xStrength;
    private float yStrength;
    private float zStrength;

    public MagneticFieldSensor(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        componentContainer = (SensorManager)componentContainer.$context().getSystemService("sensor");
        this.sensorManager = componentContainer;
        this.magneticSensor = componentContainer.getDefaultSensor(2);
        super.startListening();
    }

    private Sensor getMagneticSensor() {
        Sensor sensor = this.sensorManager.getDefaultSensor(2);
        if (sensor == null) {
            sensor = this.sensorManager.getDefaultSensor(2);
        }
        return sensor;
    }

    private void startListening() {
        Sensor sensor;
        SensorManager sensorManager;
        if (!this.listening && (sensorManager = this.sensorManager) != null && (sensor = this.magneticSensor) != null) {
            sensorManager.registerListener((SensorEventListener)this, sensor, 3);
            this.listening = true;
        }
    }

    private void stopListening() {
        SensorManager sensorManager;
        if (this.listening && (sensorManager = this.sensorManager) != null) {
            sensorManager.unregisterListener((SensorEventListener)this);
            this.listening = false;
            this.xStrength = 0.0f;
            this.yStrength = 0.0f;
            this.zStrength = 0.0f;
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates the absolute strength of the field.")
    public double AbsoluteStrength() {
        return this.absoluteStrength;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates that there is a magnetic field sensor in the device and it is available.")
    public boolean Available() {
        boolean bl = this.sensorManager.getSensorList(2).size() > 0;
        return bl;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void Enabled(boolean bl) {
        if (this.enabled != bl) {
            this.enabled = bl;
        }
        if (this.enabled) {
            super.startListening();
        } else {
            super.stopListening();
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates whether or not the magnetic field sensor is enabled and working.")
    public boolean Enabled() {
        return this.enabled;
    }

    @SimpleEvent(description="Triggers when magnetic field has changed, setting the new values in parameters.")
    public void MagneticChanged(float f, float f2, float f3, double d) {
        EventDispatcher.dispatchEvent((Component)this, "MagneticChanged", Float.valueOf((float)f), Float.valueOf((float)f2), Float.valueOf((float)f3), d);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates the maximum range the magnetic sensor can reach.")
    public float MaximumRange() {
        return this.magneticSensor.getMaximumRange();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates the field's strength in the X-axis.")
    public float XStrength() {
        return this.xStrength;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates the field's strength in the Y-axis.")
    public float YStrength() {
        return this.yStrength;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Indicates the field's strength in the Z-axis.")
    public float ZStrength() {
        return this.zStrength;
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    @Override
    public void onDelete() {
        if (this.enabled) {
            this.stopListening();
        }
    }

    @Override
    public void onPause() {
        this.stopListening();
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.startListening();
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.enabled && sensorEvent.sensor.getType() == 2) {
            double d;
            float f;
            float[] fArray = (float[])sensorEvent.values.clone();
            this.xStrength = sensorEvent.values[0];
            this.yStrength = sensorEvent.values[1];
            this.zStrength = f = sensorEvent.values[2];
            float f2 = this.xStrength;
            float f3 = this.yStrength;
            this.absoluteStrength = d = Math.sqrt((double)(f2 * f2 + f3 * f3 + f * f));
            this.MagneticChanged(this.xStrength, this.yStrength, this.zStrength, d);
        }
    }

    @Override
    public void onStop() {
        if (this.enabled) {
            this.stopListening();
        }
    }
}

