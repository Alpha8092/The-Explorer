/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.BiggerFuture
 *  gnu.expr.Language
 *  gnu.text.Path
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.Socket
 *  kawa.Shell
 *  kawa.Telnet
 */
package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.runtime.util.BiggerFuture;
import gnu.expr.Language;
import gnu.mapping.Environment;
import gnu.mapping.InPort;
import gnu.mapping.OutPort;
import gnu.mapping.Procedure;
import gnu.mapping.Procedure0;
import gnu.mapping.TtyInPort;
import gnu.mapping.Values;
import gnu.text.FilePath;
import gnu.text.Path;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import kawa.Shell;
import kawa.Telnet;

public class TelnetRepl
extends Procedure0 {
    private static final int REPL_STACK_SIZE = 262144;
    Language language;
    Socket socket;

    public TelnetRepl(Language language, Socket socket) {
        this.language = language;
        this.socket = socket;
    }

    public static Thread serve(Language language, Socket socket) throws IOException {
        Object object = new Telnet(socket, true);
        Object object2 = object.getOutputStream();
        object = object.getInputStream();
        object2 = new OutPort((OutputStream)object2, (Path)FilePath.valueOf("/dev/stdout"));
        object = new TtyInPort((InputStream)object, (Path)FilePath.valueOf("/dev/stdin"), (OutPort)((Object)object2));
        language = new BiggerFuture((Procedure)new TelnetRepl(language, socket), (InPort)((Object)object), (OutPort)((Object)object2), (OutPort)((Object)object2), "Telnet Repl Thread", 262144L);
        language.start();
        return language;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object apply0() {
        Throwable throwable2222222;
        block9: {
            Object object = Thread.currentThread();
            if (object.getContextClassLoader() == null) {
                object.setContextClassLoader(Telnet.class.getClassLoader());
            }
            Shell.run((Language)this.language, (Environment)Environment.getCurrent());
            object = Values.empty;
            {
                catch (Throwable throwable2222222) {
                    break block9;
                }
                catch (RuntimeException runtimeException) {}
                {
                    String string2 = runtimeException.getMessage();
                    object = new StringBuilder();
                    Log.d((String)"TelnetRepl", (String)object.append("Repl is exiting with error ").append(string2).toString());
                    runtimeException.printStackTrace();
                    throw runtimeException;
                }
            }
            try {
                this.socket.close();
                return object;
            }
            catch (IOException iOException) {
                // empty catch block
            }
            return object;
        }
        try {
            this.socket.close();
            throw throwable2222222;
        }
        catch (IOException iOException) {
            // empty catch block
        }
        throw throwable2222222;
    }
}

