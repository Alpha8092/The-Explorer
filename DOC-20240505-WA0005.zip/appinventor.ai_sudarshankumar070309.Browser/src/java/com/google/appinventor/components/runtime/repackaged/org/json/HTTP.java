/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.HTTPTokener
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.Iterator
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.HTTPTokener;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import java.util.Iterator;

public class HTTP {
    public static final String CRLF = "\r\n";

    public static JSONObject toJSONObject(String string) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        String string2 = (string = new HTTPTokener(string)).nextToken();
        if (string2.toUpperCase().startsWith("HTTP")) {
            jSONObject.put("HTTP-Version", (Object)string2);
            jSONObject.put("Status-Code", (Object)string.nextToken());
            jSONObject.put("Reason-Phrase", (Object)string.nextTo('\u0000'));
            string.next();
        } else {
            jSONObject.put("Method", (Object)string2);
            jSONObject.put("Request-URI", (Object)string.nextToken());
            jSONObject.put("HTTP-Version", (Object)string.nextToken());
        }
        while (string.more()) {
            string2 = string.nextTo(':');
            string.next(':');
            jSONObject.put(string2, (Object)string.nextTo('\u0000'));
            string.next();
        }
        return jSONObject;
    }

    public static String toString(JSONObject object) throws JSONException {
        block5: {
            StringBuffer stringBuffer;
            Iterator iterator;
            block4: {
                block3: {
                    iterator = object.keys();
                    stringBuffer = new StringBuffer();
                    if (!object.has("Status-Code") || !object.has("Reason-Phrase")) break block3;
                    stringBuffer.append(object.getString("HTTP-Version"));
                    stringBuffer.append(' ');
                    stringBuffer.append(object.getString("Status-Code"));
                    stringBuffer.append(' ');
                    stringBuffer.append(object.getString("Reason-Phrase"));
                    break block4;
                }
                if (!object.has("Method") || !object.has("Request-URI")) break block5;
                stringBuffer.append(object.getString("Method"));
                stringBuffer.append(' ');
                stringBuffer.append('\"');
                stringBuffer.append(object.getString("Request-URI"));
                stringBuffer.append('\"');
                stringBuffer.append(' ');
                stringBuffer.append(object.getString("HTTP-Version"));
            }
            stringBuffer.append(CRLF);
            while (iterator.hasNext()) {
                String string = iterator.next().toString();
                if ("HTTP-Version".equals((Object)string) || "Status-Code".equals((Object)string) || "Reason-Phrase".equals((Object)string) || "Method".equals((Object)string) || "Request-URI".equals((Object)string) || object.isNull(string)) continue;
                stringBuffer.append(string);
                stringBuffer.append(": ");
                stringBuffer.append(object.getString(string));
                stringBuffer.append(CRLF);
            }
            stringBuffer.append(CRLF);
            return stringBuffer.toString();
        }
        object = new JSONException("Not enough material for an HTTP header.");
        throw object;
    }
}

