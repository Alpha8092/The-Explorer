/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.imagebot.ImageBotToken$token
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.Descriptors$Descriptor
 *  com.google.protobuf.Descriptors$FileDescriptor
 *  com.google.protobuf.Descriptors$FileDescriptor$InternalDescriptorAssigner
 *  com.google.protobuf.ExtensionRegistry
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageV3$FieldAccessorTable
 *  com.google.protobuf.MessageOrBuilder
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.imagebot;

import com.google.appinventor.components.runtime.imagebot.ImageBotToken;
import com.google.protobuf.ByteString;
import com.google.protobuf.Descriptors;
import com.google.protobuf.ExtensionRegistry;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.MessageOrBuilder;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ImageBotToken {
    private static Descriptors.FileDescriptor descriptor;
    private static final Descriptors.Descriptor internal_static_request_descriptor;
    private static final GeneratedMessageV3.FieldAccessorTable internal_static_request_fieldAccessorTable;
    private static final Descriptors.Descriptor internal_static_response_descriptor;
    private static final GeneratedMessageV3.FieldAccessorTable internal_static_response_fieldAccessorTable;
    private static final Descriptors.Descriptor internal_static_token_descriptor;
    private static final GeneratedMessageV3.FieldAccessorTable internal_static_token_fieldAccessorTable;
    private static final Descriptors.Descriptor internal_static_unsigned_descriptor;
    private static final GeneratedMessageV3.FieldAccessorTable internal_static_unsigned_fieldAccessorTable;

    static /* bridge */ /* synthetic */ Descriptors.Descriptor -$$Nest$sfgetinternal_static_request_descriptor() {
        return internal_static_request_descriptor;
    }

    static /* bridge */ /* synthetic */ GeneratedMessageV3.FieldAccessorTable -$$Nest$sfgetinternal_static_request_fieldAccessorTable() {
        return internal_static_request_fieldAccessorTable;
    }

    static /* bridge */ /* synthetic */ Descriptors.Descriptor -$$Nest$sfgetinternal_static_response_descriptor() {
        return internal_static_response_descriptor;
    }

    static /* bridge */ /* synthetic */ GeneratedMessageV3.FieldAccessorTable -$$Nest$sfgetinternal_static_response_fieldAccessorTable() {
        return internal_static_response_fieldAccessorTable;
    }

    static /* bridge */ /* synthetic */ Descriptors.Descriptor -$$Nest$sfgetinternal_static_token_descriptor() {
        return internal_static_token_descriptor;
    }

    static /* bridge */ /* synthetic */ GeneratedMessageV3.FieldAccessorTable -$$Nest$sfgetinternal_static_token_fieldAccessorTable() {
        return internal_static_token_fieldAccessorTable;
    }

    static /* bridge */ /* synthetic */ Descriptors.Descriptor -$$Nest$sfgetinternal_static_unsigned_descriptor() {
        return internal_static_unsigned_descriptor;
    }

    static /* bridge */ /* synthetic */ GeneratedMessageV3.FieldAccessorTable -$$Nest$sfgetinternal_static_unsigned_fieldAccessorTable() {
        return internal_static_unsigned_fieldAccessorTable;
    }

    static {
        Descriptors.FileDescriptor.InternalDescriptorAssigner internalDescriptorAssigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner(){

            public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor fileDescriptor) {
                descriptor = fileDescriptor;
                return null;
            }
        };
        Descriptors.FileDescriptor.internalBuildGeneratedFileFrom((String[])new String[]{"\n\u000bimage.proto\"D\n\bunsigned\u0012\r\n\u0005huuid\u0018\u0001 \u0001(\t\u0012\u0012\n\u0007version\u0018\u0002 \u0001(\u0004:\u00010\u0012\u0015\n\ngeneration\u0018\u0003 \u0001(\u0004:\u00010\"i\n\u0005token\u0012\u0012\n\u0007version\u0018\u0001 \u0001(\u0004:\u00011\u0012\u0010\n\u0005keyid\u0018\u0002 \u0001(\u0004:\u00011\u0012\u0015\n\ngeneration\u0018\u0003 \u0001(\u0004:\u00010\u0012\u0010\n\bunsigned\u0018\u0004 \u0001(\f\u0012\u0011\n\tsignature\u0018\u0005 \u0001(\f\"\u00d2\u0001\n\u0007request\u0012\u0012\n\u0007version\u0018\u0001 \u0001(\u0004:\u00011\u0012)\n\toperation\u0018\u0002 \u0002(\u000e2\u0016.request.OperationType\u0012\u0015\n\u0005token\u0018\u0003 \u0001(\u000b2\u0006.token\u0012\u000e\n\u0006prompt\u0018\u0004 \u0001(\t\u0012\u000e\n\u0006source\u0018\u0005 \u0001(\f\u0012\f\n\u0004mask\u0018\u0006 \u0001(\f\u0012\u000e\n\u0006apikey\u0018\u0007 \u0001(\t\u0012\f\n\u0004size\u0018\b \u0001(\t\"%\n\rOperationType\u0012\n\n\u0006CREATE\u0010\u0000\u0012\b\n\u0004EDI", "T\u0010\u0001\"@\n\bresponse\u0012\u0012\n\u0007version\u0018\u0001 \u0001(\u0004:\u00011\u0012\u0011\n\u0006status\u0018\u0002 \u0001(\u0004:\u00010\u0012\r\n\u0005image\u0018\u0003 \u0001(\fBC\n2com.google.appinventor.components.runtime.imagebotB\rImageBotToken"}, (Descriptors.FileDescriptor[])new Descriptors.FileDescriptor[0], (Descriptors.FileDescriptor.InternalDescriptorAssigner)internalDescriptorAssigner);
        internalDescriptorAssigner = (Descriptors.Descriptor)ImageBotToken.getDescriptor().getMessageTypes().get(0);
        internal_static_unsigned_descriptor = internalDescriptorAssigner;
        internal_static_unsigned_fieldAccessorTable = new GeneratedMessageV3.FieldAccessorTable((Descriptors.Descriptor)internalDescriptorAssigner, new String[]{"Huuid", "Version", "Generation"});
        internalDescriptorAssigner = (Descriptors.Descriptor)ImageBotToken.getDescriptor().getMessageTypes().get(1);
        internal_static_token_descriptor = internalDescriptorAssigner;
        internal_static_token_fieldAccessorTable = new GeneratedMessageV3.FieldAccessorTable((Descriptors.Descriptor)internalDescriptorAssigner, new String[]{"Version", "Keyid", "Generation", "Unsigned", "Signature"});
        internalDescriptorAssigner = (Descriptors.Descriptor)ImageBotToken.getDescriptor().getMessageTypes().get(2);
        internal_static_request_descriptor = internalDescriptorAssigner;
        internal_static_request_fieldAccessorTable = new GeneratedMessageV3.FieldAccessorTable((Descriptors.Descriptor)internalDescriptorAssigner, new String[]{"Version", "Operation", "Token", "Prompt", "Source", "Mask", "Apikey", "Size"});
        internalDescriptorAssigner = (Descriptors.Descriptor)ImageBotToken.getDescriptor().getMessageTypes().get(3);
        internal_static_response_descriptor = internalDescriptorAssigner;
        internal_static_response_fieldAccessorTable = new GeneratedMessageV3.FieldAccessorTable((Descriptors.Descriptor)internalDescriptorAssigner, new String[]{"Version", "Status", "Image"});
    }

    private ImageBotToken() {
    }

    public static Descriptors.FileDescriptor getDescriptor() {
        return descriptor;
    }

    public static void registerAllExtensions(ExtensionRegistry extensionRegistry) {
        ImageBotToken.registerAllExtensions((ExtensionRegistryLite)extensionRegistry);
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }

    public static interface requestOrBuilder
    extends MessageOrBuilder {
        public String getApikey();

        public ByteString getApikeyBytes();

        public ByteString getMask();

        public OperationType getOperation();

        public String getPrompt();

        public ByteString getPromptBytes();

        public String getSize();

        public ByteString getSizeBytes();

        public ByteString getSource();

        public token getToken();

        public tokenOrBuilder getTokenOrBuilder();

        public long getVersion();

        public boolean hasApikey();

        public boolean hasMask();

        public boolean hasOperation();

        public boolean hasPrompt();

        public boolean hasSize();

        public boolean hasSource();

        public boolean hasToken();

        public boolean hasVersion();
    }

    public static interface responseOrBuilder
    extends MessageOrBuilder {
        public ByteString getImage();

        public long getStatus();

        public long getVersion();

        public boolean hasImage();

        public boolean hasStatus();

        public boolean hasVersion();
    }

    public static interface tokenOrBuilder
    extends MessageOrBuilder {
        public long getGeneration();

        public long getKeyid();

        public ByteString getSignature();

        public ByteString getUnsigned();

        public long getVersion();

        public boolean hasGeneration();

        public boolean hasKeyid();

        public boolean hasSignature();

        public boolean hasUnsigned();

        public boolean hasVersion();
    }

    public static interface unsignedOrBuilder
    extends MessageOrBuilder {
        public long getGeneration();

        public String getHuuid();

        public ByteString getHuuidBytes();

        public long getVersion();

        public boolean hasGeneration();

        public boolean hasHuuid();

        public boolean hasVersion();
    }
}

