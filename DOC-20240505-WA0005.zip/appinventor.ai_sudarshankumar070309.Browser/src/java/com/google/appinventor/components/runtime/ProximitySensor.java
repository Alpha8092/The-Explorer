/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  com.google.appinventor.components.runtime.SensorComponent
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import com.google.appinventor.components.runtime.SensorComponent;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@DesignerComponent(category=ComponentCategory.SENSORS, description="<p>Non-visible component that can measures the proximity of an object in cm relative to the view screen of a device. This sensor is typically used to determine whether a handset is being held up to a persons ear; i.e. lets you determine how far away an object is from a device. Many devices return the absolute distance, in cm, but some return only near and far values. In this case, the sensor usually reports its maximum range value in the far state and a lesser value in the near state.</p>", iconName="images/proximitysensor.png", nonVisible=true, version=1)
@SimpleObject
public class ProximitySensor
extends AndroidNonvisibleComponent
implements OnStopListener,
OnResumeListener,
SensorComponent,
OnPauseListener,
SensorEventListener,
Deleteable,
RealTimeDataSource<String, Float> {
    private final Set<DataSourceChangeListener> dataSourceObservers = new HashSet();
    private float distance = 0.0f;
    private boolean enabled;
    private boolean keepRunningWhenOnPause;
    private final Sensor proximitySensor;
    private final SensorManager sensorManager;

    public ProximitySensor(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        this.enabled = true;
        componentContainer = (SensorManager)componentContainer.$context().getSystemService("sensor");
        this.sensorManager = componentContainer;
        this.proximitySensor = componentContainer.getDefaultSensor(8);
        super.startListening();
    }

    private void startListening() {
        this.sensorManager.registerListener((SensorEventListener)this, this.proximitySensor, 3);
    }

    private void stopListening() {
        this.sensorManager.unregisterListener((SensorEventListener)this);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Reports whether or not the device has a proximity sensor.")
    public boolean Available() {
        boolean bl = this.sensorManager.getSensorList(8).size() > 0;
        return bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the distance from the object to the device")
    public float Distance() {
        return this.distance;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(description="If enabled, then device will listen for changes in proximity.")
    public void Enabled(boolean bl) {
        if (this.enabled == bl) {
            return;
        }
        this.enabled = bl;
        if (bl) {
            super.startListening();
        } else {
            super.stopListening();
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Enabled() {
        return this.enabled;
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(description="If set to true, it will keep sensing for proximity changes even when the app is not visible")
    public void KeepRunningWhenOnPause(boolean bl) {
        this.keepRunningWhenOnPause = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean KeepRunningWhenOnPause() {
        return this.keepRunningWhenOnPause;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Reports the Maximum Range of the device's ProximitySensor")
    public float MaximumRange() {
        return this.proximitySensor.getMaximumRange();
    }

    @SimpleEvent(description="Triggered when distance (in cm) of the object to the device changes.")
    public void ProximityChanged(float f) {
        this.distance = f;
        this.notifyDataObservers("distance", (Object)Float.valueOf((float)f));
        EventDispatcher.dispatchEvent((Component)this, "ProximityChanged", Float.valueOf((float)this.distance));
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    public Float getDataValue(String string) {
        if (string.equals((Object)"distance")) {
            return Float.valueOf((float)this.distance);
        }
        return Float.valueOf((float)0.0f);
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    @Override
    public void onDelete() {
        if (this.enabled) {
            this.stopListening();
        }
    }

    @Override
    public void onPause() {
        if (this.enabled && !this.keepRunningWhenOnPause) {
            this.stopListening();
        }
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.startListening();
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.enabled) {
            float f;
            this.distance = f = ((float[])sensorEvent.values.clone())[0];
            this.ProximityChanged(f);
        }
    }

    @Override
    public void onStop() {
        if (this.enabled) {
            this.stopListening();
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }
}

