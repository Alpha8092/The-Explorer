/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Handler
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.GameClient$15
 *  com.google.appinventor.components.runtime.GameClient$17
 *  com.google.appinventor.components.runtime.GameClient$19
 *  com.google.appinventor.components.runtime.GameClient$21
 *  com.google.appinventor.components.runtime.GameClient$23
 *  com.google.appinventor.components.runtime.GameClient$25
 *  com.google.appinventor.components.runtime.GameClient$27
 *  com.google.appinventor.components.runtime.GameClient$29
 *  com.google.appinventor.components.runtime.GameClient$31
 *  com.google.appinventor.components.runtime.GameClient$32
 *  com.google.appinventor.components.runtime.util.AsyncCallbackPair
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.GameInstance
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.PlayerListDelta
 *  com.google.appinventor.components.runtime.util.WebServiceUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.apache.http.NameValuePair
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.os.Handler;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.GameClient;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.AsyncCallbackPair;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.GameInstance;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.PlayerListDelta;
import com.google.appinventor.components.runtime.util.WebServiceUtil;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.INTERNAL, description="Provides a way for applications to communicate with online game servers", iconName="images/gameClient.png", nonVisible=true, version=1)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.INTERNET, com.google.android.googleapps.permission.GOOGLE_AUTH")
public class GameClient
extends AndroidNonvisibleComponent
implements Component,
OnResumeListener,
OnStopListener {
    private static final String COMMAND_ARGUMENTS_KEY = "args";
    private static final String COMMAND_TYPE_KEY = "command";
    private static final String COUNT_KEY = "count";
    private static final String ERROR_RESPONSE_KEY = "e";
    private static final String GAME_ID_KEY = "gid";
    private static final String GET_INSTANCE_LISTS_COMMAND = "getinstancelists";
    private static final String GET_MESSAGES_COMMAND = "messages";
    private static final String INSTANCE_ID_KEY = "iid";
    private static final String INSTANCE_PUBLIC_KEY = "makepublic";
    private static final String INVITED_LIST_KEY = "invited";
    private static final String INVITEE_KEY = "inv";
    private static final String INVITE_COMMAND = "invite";
    private static final String JOINED_LIST_KEY = "joined";
    private static final String JOIN_INSTANCE_COMMAND = "joininstance";
    private static final String LEADER_KEY = "leader";
    private static final String LEAVE_INSTANCE_COMMAND = "leaveinstance";
    private static final String LOG_TAG = "GameClient";
    private static final String MESSAGES_LIST_KEY = "messages";
    private static final String MESSAGE_CONTENT_KEY = "contents";
    private static final String MESSAGE_RECIPIENTS_KEY = "mrec";
    private static final String MESSAGE_SENDER_KEY = "msender";
    private static final String MESSAGE_TIME_KEY = "mtime";
    private static final String NEW_INSTANCE_COMMAND = "newinstance";
    private static final String NEW_MESSAGE_COMMAND = "newmessage";
    private static final String PLAYERS_LIST_KEY = "players";
    private static final String PLAYER_ID_KEY = "pid";
    private static final String PUBLIC_LIST_KEY = "public";
    private static final String SERVER_COMMAND = "servercommand";
    private static final String SERVER_RETURN_VALUE_KEY = "response";
    private static final String SET_LEADER_COMMAND = "setleader";
    private static final String TYPE_KEY = "type";
    private Activity activityContext;
    private Handler androidUIHandler = new Handler();
    private String gameId;
    private GameInstance instance;
    private List<String> invitedInstances;
    private List<String> joinedInstances;
    private List<String> publicInstances;
    private String serviceUrl;
    private String userEmailAddress = "";

    static /* bridge */ /* synthetic */ GameInstance -$$Nest$fgetinstance(GameClient gameClient) {
        return gameClient.instance;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputinstance(GameClient gameClient, GameInstance gameInstance) {
        gameClient.instance = gameInstance;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostGetInstanceLists(GameClient gameClient) {
        gameClient.postGetInstanceLists();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostGetMessages(GameClient gameClient, String string, int n) {
        gameClient.postGetMessages(string, n);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostInvite(GameClient gameClient, String string) {
        gameClient.postInvite(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostLeaveInstance(GameClient gameClient) {
        gameClient.postLeaveInstance();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostMakeNewInstance(GameClient gameClient, String string, Boolean bl) {
        gameClient.postMakeNewInstance(string, bl);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostNewMessage(GameClient gameClient, String string, YailList yailList, YailList yailList2) {
        gameClient.postNewMessage(string, yailList, yailList2);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostServerCommand(GameClient gameClient, String string, YailList yailList) {
        gameClient.postServerCommand(string, yailList);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostSetInstance(GameClient gameClient, String string) {
        gameClient.postSetInstance(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostSetLeader(GameClient gameClient, String string) {
        gameClient.postSetLeader(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mprocessInstanceLists(GameClient gameClient, JSONObject jSONObject) {
        gameClient.processInstanceLists(jSONObject);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mupdateInstanceInfo(GameClient gameClient, JSONObject jSONObject) {
        gameClient.updateInstanceInfo(jSONObject);
    }

    public GameClient(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.activityContext = componentContainer.$context();
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnStop((OnStopListener)this);
        this.gameId = "";
        this.instance = new GameInstance("");
        this.joinedInstances = Lists.newArrayList();
        this.invitedInstances = Lists.newArrayList();
        this.publicInstances = Lists.newArrayList();
        this.serviceUrl = "http://appinvgameserver.appspot.com";
    }

    private void postCommandToGameServer(String string, List<NameValuePair> list, AsyncCallbackPair<JSONObject> asyncCallbackPair) {
        super.postCommandToGameServer(string, list, asyncCallbackPair, false);
    }

    private void postCommandToGameServer(String string, List<NameValuePair> list, AsyncCallbackPair<JSONObject> var3_3, boolean bl) {
        var3_3 = new 32((GameClient)this, string, var3_3, bl, list);
        WebServiceUtil.getInstance().postCommandReturningObject(this.ServiceUrl(), string, list, (AsyncCallbackPair)var3_3);
    }

    private void postGetInstanceLists() {
        15 var1_1 = new 15(this);
        this.postCommandToGameServer(GET_INSTANCE_LISTS_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress())), (AsyncCallbackPair<JSONObject>)var1_1);
    }

    private void postGetMessages(String string, int n) {
        17 var3_3 = new 17((GameClient)this, string);
        if (this.InstanceId().equals((Object)"")) {
            this.Info("You must join an instance before attempting to fetch messages.");
            return;
        }
        super.postCommandToGameServer("messages", (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(COUNT_KEY, Integer.toString((int)n)), new BasicNameValuePair(MESSAGE_TIME_KEY, this.instance.getMessageTime(string)), new BasicNameValuePair(TYPE_KEY, string)), (AsyncCallbackPair<JSONObject>)var3_3);
    }

    private void postInvite(String string) {
        19 var2_2 = new 19((GameClient)this);
        if (this.InstanceId().equals((Object)"")) {
            this.Info("You must have joined an instance before you can invite new players.");
            return;
        }
        super.postCommandToGameServer(INVITE_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(INVITEE_KEY, string)), (AsyncCallbackPair<JSONObject>)var2_2);
    }

    private void postLeaveInstance() {
        21 var1_1 = new 21(this);
        this.postCommandToGameServer(LEAVE_INSTANCE_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress())), (AsyncCallbackPair<JSONObject>)var1_1);
    }

    private void postMakeNewInstance(String string, Boolean bl) {
        23 var3_3 = new 23((GameClient)this);
        super.postCommandToGameServer(NEW_INSTANCE_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, string), new BasicNameValuePair(INSTANCE_PUBLIC_KEY, bl.toString())), (AsyncCallbackPair<JSONObject>)var3_3, true);
    }

    private void postNewMessage(String string, YailList yailList, YailList yailList2) {
        25 var4_4 = new 25((GameClient)this);
        if (this.InstanceId().equals((Object)"")) {
            this.Info("You must have joined an instance before you can send messages.");
            return;
        }
        super.postCommandToGameServer(NEW_MESSAGE_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(TYPE_KEY, string), new BasicNameValuePair(MESSAGE_RECIPIENTS_KEY, yailList.toJSONString()), new BasicNameValuePair(MESSAGE_CONTENT_KEY, yailList2.toJSONString()), new BasicNameValuePair(MESSAGE_TIME_KEY, this.instance.getMessageTime(string))), (AsyncCallbackPair<JSONObject>)var4_4);
    }

    private void postServerCommand(String string, YailList yailList) {
        27 var3_3 = new 27((GameClient)this, string, yailList);
        Log.d((String)LOG_TAG, (String)("Going to post " + string + " with args " + yailList));
        super.postCommandToGameServer(SERVER_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(COMMAND_TYPE_KEY, string), new BasicNameValuePair(COMMAND_ARGUMENTS_KEY, yailList.toJSONString())), (AsyncCallbackPair<JSONObject>)var3_3);
    }

    private void postSetInstance(String string) {
        29 var2_2 = new 29((GameClient)this);
        super.postCommandToGameServer(JOIN_INSTANCE_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, string), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress())), (AsyncCallbackPair<JSONObject>)var2_2, true);
    }

    private void postSetLeader(String string) {
        31 var2_2 = new 31((GameClient)this);
        if (this.InstanceId().equals((Object)"")) {
            this.Info("You must join an instance before attempting to set a leader.");
            return;
        }
        super.postCommandToGameServer(SET_LEADER_COMMAND, (List<NameValuePair>)Lists.newArrayList(new BasicNameValuePair(GAME_ID_KEY, this.GameId()), new BasicNameValuePair(INSTANCE_ID_KEY, this.InstanceId()), new BasicNameValuePair(PLAYER_ID_KEY, this.UserEmailAddress()), new BasicNameValuePair(LEADER_KEY, string)), (AsyncCallbackPair<JSONObject>)var2_2);
    }

    private void processInstanceLists(JSONObject jSONObject) {
        try {
            this.joinedInstances = JsonUtil.getStringListFromJsonArray((JSONArray)jSONObject.getJSONArray(JOINED_LIST_KEY));
            this.publicInstances = JsonUtil.getStringListFromJsonArray((JSONArray)jSONObject.getJSONArray(PUBLIC_LIST_KEY));
            jSONObject = JsonUtil.getStringListFromJsonArray((JSONArray)jSONObject.getJSONArray(INVITED_LIST_KEY));
            if (!jSONObject.equals(this.InvitedInstances())) {
                List<String> list = this.invitedInstances;
                this.invitedInstances = jSONObject;
                ArrayList arrayList = new ArrayList((Collection)jSONObject);
                arrayList.removeAll(list);
                jSONObject = arrayList.iterator();
                while (jSONObject.hasNext()) {
                    this.Invited((String)jSONObject.next());
                }
            }
        }
        catch (JSONException jSONException) {
            Log.w((String)LOG_TAG, (Throwable)jSONException);
            this.Info("Instance lists failed to parse.");
        }
    }

    private void updateInstanceInfo(JSONObject jSONObject) throws JSONException {
        boolean bl = false;
        String string = jSONObject.getString(LEADER_KEY);
        jSONObject = JsonUtil.getStringListFromJsonArray((JSONArray)jSONObject.getJSONArray(PLAYERS_LIST_KEY));
        if (!this.Leader().equals((Object)string)) {
            this.instance.setLeader(string);
            bl = true;
        }
        if ((jSONObject = this.instance.setPlayers((List)jSONObject)) != PlayerListDelta.NO_CHANGE) {
            string = jSONObject.getPlayersRemoved().iterator();
            while (string.hasNext()) {
                this.PlayerLeft((String)string.next());
            }
            jSONObject = jSONObject.getPlayersAdded().iterator();
            while (jSONObject.hasNext()) {
                this.PlayerJoined((String)jSONObject.next());
            }
        }
        if (bl) {
            this.NewLeader(this.Leader());
        }
    }

    @SimpleEvent(description="Indicates that a function call completed.")
    public void FunctionCompleted(String string) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$functionName;
            {
                this.this$0 = gameClient;
                this.val$functionName = string;
            }

            public void run() {
                String string = this.val$functionName;
                Log.d((String)"GameClient", (String)("Request completed: " + string));
                EventDispatcher.dispatchEvent(this.this$0, "FunctionCompleted", this.val$functionName);
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The game name for this application. The same game ID can have one or more game instances.")
    public String GameId() {
        return this.gameId;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    public void GameId(String string) {
        this.gameId = string;
    }

    @SimpleFunction(description="Updates the InstancesJoined and InstancesInvited lists. This procedure can be called before setting the InstanceId.")
    public void GetInstanceLists() {
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
            final GameClient this$0;
            {
                this.this$0 = gameClient;
            }

            public void run() {
                GameClient.-$$Nest$mpostGetInstanceLists(this.this$0);
            }
        });
    }

    @SimpleFunction(description="Retrieves messages of the specified type.")
    public void GetMessages(String string, int n) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string, n){
            final GameClient this$0;
            final int val$count;
            final String val$type;
            {
                this.this$0 = gameClient;
                this.val$type = string;
                this.val$count = n;
            }

            public void run() {
                GameClient.-$$Nest$mpostGetMessages(this.this$0, this.val$type, this.val$count);
            }
        });
    }

    @SimpleEvent(description="Indicates that a new message has been received.")
    public void GotMessage(String string, String string2, List<Object> list) {
        Log.d((String)LOG_TAG, (String)("Got message of type " + string));
        this.androidUIHandler.post(new Runnable((GameClient)this, string, string2, list){
            final GameClient this$0;
            final List val$contents;
            final String val$sender;
            final String val$type;
            {
                this.this$0 = gameClient;
                this.val$type = string;
                this.val$sender = string2;
                this.val$contents = list;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "GotMessage", this.val$type, this.val$sender, this.val$contents);
            }
        });
    }

    @SimpleEvent(description="Indicates that something has occurred which the player should know about.")
    public void Info(String string) {
        Log.d((String)LOG_TAG, (String)("Info: " + string));
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$message;
            {
                this.this$0 = gameClient;
                this.val$message = string;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "Info", this.val$message);
            }
        });
    }

    public void Initialize() {
        Log.d((String)LOG_TAG, (String)"Initialize");
        if (!this.gameId.equals((Object)"")) {
            return;
        }
        throw new YailRuntimeError("Game Id must not be empty.", "GameClient Configuration Error.");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The game instance id.  Taken together,the game ID and the instance ID uniquely identify the game.")
    public String InstanceId() {
        return this.instance.getInstanceId();
    }

    @SimpleEvent(description="Indicates that the InstanceId property has changed as a result of calling MakeNewInstance or SetInstance.")
    public void InstanceIdChanged(String string) {
        Log.d((String)LOG_TAG, (String)("Instance id changed to " + string));
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$instanceId;
            {
                this.this$0 = gameClient;
                this.val$instanceId = string;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "InstanceIdChanged", this.val$instanceId);
            }
        });
    }

    @SimpleFunction(description="Invites a player to this game instance.")
    public void Invite(String string) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$playerEmail;
            {
                this.this$0 = gameClient;
                this.val$playerEmail = string;
            }

            public void run() {
                GameClient.-$$Nest$mpostInvite(this.this$0, this.val$playerEmail);
            }
        });
    }

    @SimpleEvent(description="Indicates that a user has been invited to this game instance.")
    public void Invited(String string) {
        Log.d((String)LOG_TAG, (String)("Player invited to " + string));
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$instanceId;
            {
                this.this$0 = gameClient;
                this.val$instanceId = string;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "Invited", this.val$instanceId);
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The set of game instances to which this player has been invited but has not yet joined.  To ensure current values are returned, first invoke GetInstanceLists.")
    public List<String> InvitedInstances() {
        return this.invitedInstances;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The set of game instances in which this player is participating.  To ensure current values are returned, first invoke GetInstanceLists.")
    public List<String> JoinedInstances() {
        return this.joinedInstances;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The game's leader. At any time, each game instance has only one leader, but the leader may change with time.  Initially, the leader is the game instance creator. Application writers determine special properties of the leader. The leader value is updated each time a successful communication is made with the server.")
    public String Leader() {
        return this.instance.getLeader();
    }

    @SimpleFunction(description="Leaves the current instance.")
    public void LeaveInstance() {
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
            final GameClient this$0;
            {
                this.this$0 = gameClient;
            }

            public void run() {
                GameClient.-$$Nest$mpostLeaveInstance(this.this$0);
            }
        });
    }

    @SimpleFunction(description="Asks the server to create a new instance of this game.")
    public void MakeNewInstance(String string, boolean bl) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string, bl){
            final GameClient this$0;
            final String val$instanceId;
            final boolean val$makePublic;
            {
                this.this$0 = gameClient;
                this.val$instanceId = string;
                this.val$makePublic = bl;
            }

            public void run() {
                GameClient.-$$Nest$mpostMakeNewInstance(this.this$0, this.val$instanceId, this.val$makePublic);
            }
        });
    }

    @SimpleEvent(description="Indicates that a new instance was successfully created after calling MakeNewInstance.")
    public void NewInstanceMade(String string) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$instanceId;
            {
                this.this$0 = gameClient;
                this.val$instanceId = string;
            }

            public void run() {
                String string = this.val$instanceId;
                Log.d((String)"GameClient", (String)("New instance made: " + string));
                EventDispatcher.dispatchEvent(this.this$0, "NewInstanceMade", this.val$instanceId);
            }
        });
    }

    @SimpleEvent(description="Indicates that this game has a new leader as specified through SetLeader")
    public void NewLeader(String string) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$playerId;
            {
                this.this$0 = gameClient;
                this.val$playerId = string;
            }

            public void run() {
                String string = this.val$playerId;
                Log.d((String)"GameClient", (String)("Leader change to " + string));
                EventDispatcher.dispatchEvent(this.this$0, "NewLeader", this.val$playerId);
            }
        });
    }

    @SimpleEvent(description="Indicates that a new player has joined this game instance.")
    public void PlayerJoined(String string) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$playerId;
            {
                this.this$0 = gameClient;
                this.val$playerId = string;
            }

            public void run() {
                if (!this.val$playerId.equals((Object)this.this$0.UserEmailAddress())) {
                    String string = this.val$playerId;
                    Log.d((String)"GameClient", (String)("Player joined: " + string));
                    EventDispatcher.dispatchEvent(this.this$0, "PlayerJoined", this.val$playerId);
                }
            }
        });
    }

    @SimpleEvent(description="Indicates that a player has left this game instance.")
    public void PlayerLeft(String string) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$playerId;
            {
                this.this$0 = gameClient;
                this.val$playerId = string;
            }

            public void run() {
                String string = this.val$playerId;
                Log.d((String)"GameClient", (String)("Player left: " + string));
                EventDispatcher.dispatchEvent(this.this$0, "PlayerLeft", this.val$playerId);
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The current set of players for this game instance. Each player is designated by an email address, which is a string. The list of players is updated each time a successful communication is made with the game server.")
    public List<String> Players() {
        return this.instance.getPlayers();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The set of game instances that have been marked public. To ensure current values are returned, first invoke {@link #GetInstanceLists}. ")
    public List<String> PublicInstances() {
        return this.publicInstances;
    }

    @SimpleFunction(description="Sends a keyed message to all recipients in the recipients list. The message will consist of the contents list.")
    public void SendMessage(String string, YailList yailList, YailList yailList2) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string, yailList, yailList2){
            final GameClient this$0;
            final YailList val$contents;
            final YailList val$recipients;
            final String val$type;
            {
                this.this$0 = gameClient;
                this.val$type = string;
                this.val$recipients = yailList;
                this.val$contents = yailList2;
            }

            public void run() {
                GameClient.-$$Nest$mpostNewMessage(this.this$0, this.val$type, this.val$recipients, this.val$contents);
            }
        });
    }

    @SimpleFunction(description="Sends the specified command to the game server.")
    public void ServerCommand(String string, YailList yailList) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string, yailList){
            final GameClient this$0;
            final YailList val$arguments;
            final String val$command;
            {
                this.this$0 = gameClient;
                this.val$command = string;
                this.val$arguments = yailList;
            }

            public void run() {
                GameClient.-$$Nest$mpostServerCommand(this.this$0, this.val$command, this.val$arguments);
            }
        });
    }

    @SimpleEvent(description="Indicates that a server command failed.")
    public void ServerCommandFailure(String string, YailList yailList) {
        this.androidUIHandler.post(new Runnable((GameClient)this, string, yailList){
            final GameClient this$0;
            final YailList val$arguments;
            final String val$command;
            {
                this.this$0 = gameClient;
                this.val$command = string;
                this.val$arguments = yailList;
            }

            public void run() {
                String string = this.val$command;
                Log.d((String)"GameClient", (String)("Server command failed: " + string));
                EventDispatcher.dispatchEvent(this.this$0, "ServerCommandFailure", this.val$command, this.val$arguments);
            }
        });
    }

    @SimpleEvent(description="Indicates that a server command returned successfully.")
    public void ServerCommandSuccess(String string, List<Object> list) {
        Log.d((String)LOG_TAG, (String)(string + " server command returned."));
        this.androidUIHandler.post(new Runnable((GameClient)this, string, list){
            final GameClient this$0;
            final String val$command;
            final List val$response;
            {
                this.this$0 = gameClient;
                this.val$command = string;
                this.val$response = list;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "ServerCommandSuccess", this.val$command, this.val$response);
            }
        });
    }

    @DesignerProperty(defaultValue="http://appinvgameserver.appspot.com", editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, userVisible=false)
    public void ServiceURL(String string) {
        this.serviceUrl = string.endsWith("/") ? string.substring(0, string.length() - 1) : string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The URL of the game server.")
    public String ServiceUrl() {
        return this.serviceUrl;
    }

    @SimpleFunction(description="Sets InstanceId and joins the specified instance.")
    public void SetInstance(String string) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$instanceId;
            {
                this.this$0 = gameClient;
                this.val$instanceId = string;
            }

            public void run() {
                if (this.val$instanceId.equals((Object)"")) {
                    Log.d((String)"GameClient", (String)"Instance id set to empty string.");
                    if (!this.this$0.InstanceId().equals((Object)"")) {
                        GameClient.-$$Nest$fputinstance(this.this$0, new GameInstance(""));
                        this.this$0.InstanceIdChanged("");
                        this.this$0.FunctionCompleted("SetInstance");
                    }
                } else {
                    GameClient.-$$Nest$mpostSetInstance(this.this$0, this.val$instanceId);
                }
            }
        });
    }

    @SimpleFunction(description="Tells the server to set the leader to playerId. Only the current leader may successfully set a new leader.")
    public void SetLeader(String string) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$playerEmail;
            {
                this.this$0 = gameClient;
                this.val$playerEmail = string;
            }

            public void run() {
                GameClient.-$$Nest$mpostSetLeader(this.this$0, this.val$playerEmail);
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The email address that is being used as the player id for this game client.   At present, users must set this manually in oder to join a game.  But this property will change in the future so that is set automatically, and users will not be able to change it.")
    public String UserEmailAddress() {
        if (this.userEmailAddress.equals((Object)"")) {
            this.Info("User email address is empty.");
        }
        return this.userEmailAddress;
    }

    @SimpleProperty
    public void UserEmailAddress(String string) {
        this.userEmailAddress = string;
        this.UserEmailAddressSet(string);
    }

    @SimpleEvent(description="Indicates that the user email address has been set.")
    public void UserEmailAddressSet(String string) {
        Log.d((String)LOG_TAG, (String)"Email address set.");
        this.androidUIHandler.post(new Runnable((GameClient)this, string){
            final GameClient this$0;
            final String val$emailAddress;
            {
                this.this$0 = gameClient;
                this.val$emailAddress = string;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "UserEmailAddressSet", this.val$emailAddress);
            }
        });
    }

    @SimpleEvent(description="Indicates that an error occurred while communicating with the web server.")
    public void WebServiceError(String string, String string2) {
        Log.e((String)LOG_TAG, (String)("WebServiceError: " + string2));
        this.androidUIHandler.post(new Runnable((GameClient)this, string, string2){
            final GameClient this$0;
            final String val$functionName;
            final String val$message;
            {
                this.this$0 = gameClient;
                this.val$functionName = string;
                this.val$message = string2;
            }

            public void run() {
                EventDispatcher.dispatchEvent(this.this$0, "WebServiceError", this.val$functionName, this.val$message);
            }
        });
    }

    @Override
    public void onResume() {
        Log.d((String)LOG_TAG, (String)"Activity Resumed.");
    }

    @Override
    public void onStop() {
        Log.d((String)LOG_TAG, (String)"Activity Stopped.");
    }
}

