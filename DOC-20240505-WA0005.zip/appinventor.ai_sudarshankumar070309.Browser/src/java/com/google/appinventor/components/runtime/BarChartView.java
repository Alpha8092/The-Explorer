/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  com.github.mikephil.charting.charts.BarChart
 *  com.github.mikephil.charting.data.BarData
 *  com.github.mikephil.charting.data.BarDataSet
 *  com.github.mikephil.charting.data.BarEntry
 *  com.github.mikephil.charting.data.ChartData
 *  com.github.mikephil.charting.interfaces.datasets.IBarDataSet
 *  com.google.appinventor.components.runtime.AxisChartView
 *  com.google.appinventor.components.runtime.BarChartDataModel
 *  com.google.appinventor.components.runtime.Chart
 *  com.google.appinventor.components.runtime.ChartDataModel
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.google.appinventor.components.runtime.AxisChartView;
import com.google.appinventor.components.runtime.BarChartDataModel;
import com.google.appinventor.components.runtime.Chart;
import com.google.appinventor.components.runtime.ChartDataModel;
import java.util.Iterator;
import java.util.List;

public class BarChartView
extends AxisChartView<BarEntry, IBarDataSet, BarData, BarChart, BarChartView> {
    private static final float GROUP_SPACE = 0.08f;
    private static final float START_X_VALUE = 0.0f;
    private float barSpace = 0.0f;
    private float barWidth = 0.3f;

    public BarChartView(Chart chart) {
        super(chart);
        this.chart = new BarChart((Context)this.form);
        this.data = new BarData();
        ((BarChart)this.chart).setData((ChartData)((BarData)this.data));
        this.initializeDefaultSettings();
    }

    private void recalculateBarSpaceAndWidth() {
        int n = ((BarData)((BarChart)this.chart).getData()).getDataSetCount();
        if (n > 1) {
            float f = 0.92f / (float)n;
            this.barSpace = 0.1f * f;
            this.barWidth = 0.9f * f;
            ((BarData)((BarChart)this.chart).getData()).setBarWidth(this.barWidth);
        }
        if (n == 2) {
            ((BarChart)this.chart).getXAxis().setCenterAxisLabels(true);
        }
    }

    private void regroupBars() {
        if (((BarData)((BarChart)this.chart).getData()).getDataSetCount() > 1) {
            ((BarChart)this.chart).groupBars(0.0f, 0.08f, this.barSpace);
            int n = 0;
            Iterator iterator = ((BarData)((BarChart)this.chart).getData()).getDataSets().iterator();
            while (iterator.hasNext()) {
                n = Math.max((int)n, (int)((IBarDataSet)iterator.next()).getEntryCount());
            }
            ((BarChart)this.chart).getXAxis().setAxisMinimum(0.0f);
            ((BarChart)this.chart).getXAxis().setAxisMaximum(((BarData)((BarChart)this.chart).getData()).getGroupWidth(0.08f, this.barSpace) * (float)n + 0.0f);
        }
    }

    public ChartDataModel<BarEntry, IBarDataSet, BarData, BarChart, BarChartView> createChartModel() {
        BarChartDataModel barChartDataModel = new BarChartDataModel((BarData)this.data, this);
        this.recalculateBarSpaceAndWidth();
        return barChartDataModel;
    }

    public View getView() {
        return this.chart;
    }

    protected void initializeDefaultSettings() {
        super.initializeDefaultSettings();
        ((BarChart)this.chart).setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        ((BarChart)this.chart).getXAxis().setGranularity(1.0f);
    }

    protected void refresh(ChartDataModel<BarEntry, IBarDataSet, BarData, BarChart, BarChartView> iBarDataSet, List<BarEntry> list) {
        if ((iBarDataSet = (IBarDataSet)iBarDataSet.getDataset()) instanceof BarDataSet) {
            ((BarDataSet)iBarDataSet).setValues(list);
        }
        super.regroupBars();
        ((BarData)((BarChart)this.chart).getData()).notifyDataChanged();
        ((BarChart)this.chart).notifyDataSetChanged();
        ((BarChart)this.chart).invalidate();
    }
}

