/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.YailConstants
 *  com.google.appinventor.components.runtime.util.YailNumberToString
 *  com.google.appinventor.components.runtime.util.YailObject
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  java.util.Set
 *  org.json.JSONException
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.YailConstants;
import com.google.appinventor.components.runtime.util.YailNumberToString;
import com.google.appinventor.components.runtime.util.YailObject;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.math.IntNum;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.json.JSONException;

public class YailList
extends Pair
implements YailObject {
    public YailList() {
        super(YailConstants.YAIL_HEADER, LList.Empty);
    }

    private YailList(Object object) {
        super(YailConstants.YAIL_HEADER, object);
    }

    public static String YailListElementToString(Object object) {
        if (object instanceof IntNum) {
            return ((IntNum)((Object)object)).toString(10);
        }
        if (object instanceof Long) {
            return Long.toString((long)((Long)object));
        }
        if (Number.class.isInstance(object)) {
            return YailNumberToString.format((double)((Number)object).doubleValue());
        }
        return String.valueOf((Object)object);
    }

    public static YailList makeEmptyList() {
        return new YailList();
    }

    public static YailList makeList(Collection collection) {
        return new YailList(Pair.makeList((List)new ArrayList(collection)));
    }

    public static YailList makeList(List list) {
        return new YailList(Pair.makeList(list));
    }

    public static YailList makeList(Set set) {
        return new YailList(Pair.makeList((List)new ArrayList((Collection)set)));
    }

    public static YailList makeList(Object[] objectArray) {
        return new YailList(Pair.makeList(objectArray, 0));
    }

    public Object getObject(int n) {
        return this.get(n + 1);
    }

    public String getString(int n) {
        return this.get(n + 1).toString();
    }

    @Override
    public int size() {
        return super.size() - 1;
    }

    @Override
    public Object[] toArray() {
        if (this.cdr instanceof Pair) {
            return ((Pair)this.cdr).toArray();
        }
        if (this.cdr instanceof LList) {
            return ((LList)this.cdr).toArray();
        }
        throw new YailRuntimeError("YailList cannot be represented as an array", "YailList Error.");
    }

    public String toJSONString() {
        StringBuilder stringBuilder = new StringBuilder();
        String string2 = "";
        stringBuilder.append('[');
        int n = this.size();
        for (int i = 1; i <= n; ++i) {
            Object object = this.get(i);
            stringBuilder.append(string2).append(JsonUtil.getJsonRepresentation((Object)object));
            string2 = ",";
            continue;
        }
        try {
            stringBuilder.append(']');
            string2 = stringBuilder.toString();
            return string2;
        }
        catch (JSONException jSONException) {
            YailRuntimeError yailRuntimeError = new YailRuntimeError("List failed to convert to JSON.", "JSON Creation Error.");
            throw yailRuntimeError;
        }
    }

    @Override
    public String toString() {
        if (this.cdr instanceof Pair) {
            return ((Pair)this.cdr).toString();
        }
        if (this.cdr instanceof LList) {
            return ((LList)this.cdr).toString();
        }
        throw new RuntimeException("YailList cannot be represented as a String");
    }

    public String[] toStringArray() {
        int n = this.size();
        String[] stringArray = new String[n];
        for (int i = 1; i <= n; ++i) {
            stringArray[i - 1] = YailList.YailListElementToString(this.get(i));
        }
        return stringArray;
    }
}

