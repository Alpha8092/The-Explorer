/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.net.wifi.WifiManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Notifier
 *  com.google.appinventor.components.runtime.util.EclairUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.WebRTCNativeMgr
 *  java.lang.Appendable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 *  java.lang.Throwable
 *  java.security.MessageDigest
 *  java.util.Formatter
 *  org.acra.util.Installation
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesNativeLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.ReplForm;
import com.google.appinventor.components.runtime.util.AppInvHTTPD;
import com.google.appinventor.components.runtime.util.EclairUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.WebRTCNativeMgr;
import java.security.MessageDigest;
import java.util.Formatter;
import org.acra.util.Installation;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.INTERNAL, description="Component that returns information about the phone.", iconName="images/phoneip.png", nonVisible=true, version=1)
@SimpleObject
@UsesLibraries(libraries="webrtc.jar,google-http-client.jar,google-http-client-android2-beta.jar,google-http-client-android3-beta.jar")
@UsesNativeLibraries(v7aLibraries="libjingle_peerconnection_so.so", v8aLibraries="libjingle_peerconnection_so.so", x86_64Libraries="libjingle_peerconnection_so.so")
@UsesPermissions(value={"android.permission.ACCESS_NETWORK_STATE", "android.permission.ACCESS_WIFI_STATE"})
public class PhoneStatus
extends AndroidNonvisibleComponent
implements Component {
    private static final String LOG_TAG = "PhoneStatus";
    private static Activity activity;
    private static PhoneStatus mainInstance;
    private static String popup;
    private static boolean useWebRTC;
    private String firstHmacSeed = null;
    private String firstSeed = null;
    private final Form form;

    static /* bridge */ /* synthetic */ Form -$$Nest$fgetform(PhoneStatus phoneStatus) {
        return phoneStatus.form;
    }

    static {
        mainInstance = null;
        useWebRTC = false;
        popup = "No Page Provided!";
    }

    public PhoneStatus(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.form = componentContainer.$form();
        activity = componentContainer.$context();
        if (mainInstance == null) {
            mainInstance = this;
        }
    }

    @SimpleFunction(description="Returns the IP address of the phone in the form of a String")
    public static String GetWifiIpAddress() {
        int n = ((WifiManager)PhoneStatus.activity.getSystemService((String)"wifi")).getDhcpInfo().ipAddress;
        String string = PhoneStatus.isConnected() ? PhoneStatus.intToIp(n) : "Error: No Wifi Connection";
        return string;
    }

    @SimpleFunction(description="Causes an Exception, used to debug exception processing.")
    public static void doFault() throws Exception {
        throw new Exception("doFault called!");
    }

    static void doSettings() {
        Log.d((String)LOG_TAG, (String)"doSettings called.");
        PhoneStatus phoneStatus = mainInstance;
        if (phoneStatus != null) {
            phoneStatus.OnSettings();
        } else {
            Log.d((String)LOG_TAG, (String)"mainStance is null on doSettings");
        }
    }

    public static String getPopup() {
        return popup;
    }

    public static boolean getUseWebRTC() {
        return useWebRTC;
    }

    public static String intToIp(int n) {
        return (n & 0xFF) + "." + (n >> 8 & 0xFF) + "." + (n >> 16 & 0xFF) + "." + (n >> 24 & 0xFF);
    }

    @SimpleFunction(description="Returns TRUE if the phone is on Wifi, FALSE otherwise")
    public static boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager)activity.getSystemService("connectivity");
        NetworkInfo networkInfo = null;
        if (connectivityManager != null) {
            networkInfo = connectivityManager.getNetworkInfo(1);
        }
        boolean bl = networkInfo == null ? false : networkInfo.isConnected();
        return bl;
    }

    @SimpleFunction(description="Return the app that installed us")
    public String GetInstaller() {
        if (SdkLevel.getLevel() >= 5) {
            String string = EclairUtil.getInstallerPackageName((String)"edu.mit.appinventor.aicompanion3", (Activity)this.form);
            if (string == null) {
                return "sideloaded";
            }
            return string;
        }
        return "unknown";
    }

    @SimpleFunction(description="Return the our VersionName property")
    public String GetVersionName() {
        try {
            String string = this.form.getPackageName();
            string = this.form.getPackageManager().getPackageInfo((String)string, (int)0).versionName;
            return string;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            Log.e((String)LOG_TAG, (String)"Unable to get VersionName", (Throwable)nameNotFoundException);
            return "UNKNOWN";
        }
    }

    @SimpleFunction(description="Return the ACRA Installation ID")
    public String InstallationId() {
        return Installation.id((Context)this.form);
    }

    @SimpleEvent
    public void OnSettings() {
        EventDispatcher.dispatchEvent(this, "OnSettings", new Object[0]);
    }

    @SimpleFunction(description="Get the current Android SDK Level")
    public int SdkLevel() {
        return SdkLevel.getLevel();
    }

    @SimpleFunction(description="Set the content of the Pop-Up page used for the new legacy connection")
    public void SetPopup(String string) {
        popup = string;
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WebRTC(boolean bl) {
        useWebRTC = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If True we are using WebRTC to talk to the server.")
    public boolean WebRTC() {
        return useWebRTC;
    }

    @SimpleFunction(description="Downloads the URL and installs it as an Android Package via the installed browser")
    public void installURL(String string) {
        try {
            Class clazz = Class.forName((String)"edu.mit.appinventor.companionextras.CompanionExtras");
            Object object2 = clazz.getConstructor(new Class[]{Form.class}).newInstance(new Object[]{this.form});
            clazz.getMethod("Extra1", new Class[]{String.class}).invoke(object2, new Object[]{string});
        }
        catch (Exception exception) {
            string = Uri.parse((String)(string + "?store=1"));
            string = new Intent("android.intent.action.VIEW").setData((Uri)string);
            this.form.startActivity((Intent)string);
        }
    }

    @SimpleFunction(description="Returns true if we are running in the emulator or USB Connection")
    public boolean isDirect() {
        Object object2 = Build.VERSION.RELEASE;
        Log.d((String)LOG_TAG, (String)("android.os.Build.VERSION.RELEASE = " + (String)object2));
        object2 = Build.PRODUCT;
        Log.d((String)LOG_TAG, (String)("android.os.Build.PRODUCT = " + (String)object2));
        if (ReplForm.isEmulator()) {
            return true;
        }
        object2 = this.form;
        if (object2 instanceof ReplForm) {
            return ((ReplForm)object2).isDirect();
        }
        return false;
    }

    @SimpleFunction(description="Declare that we have loaded our initial assets and other assets should come from the sdcard")
    public void setAssetsLoaded() {
        Form form = this.form;
        if (form instanceof ReplForm) {
            ((ReplForm)form).setAssetsLoaded();
        }
    }

    @SimpleFunction(description="Establish the secret seed for HOTP generation. Return the SHA1 of the provided seed, this will be used to contact the rendezvous server. Note: This code also starts the connection negotiation process if we are using WebRTC. This is a bit of a kludge...")
    public String setHmacSeedReturnCode(String string, String string2) {
        if (string.equals((Object)"")) {
            return "";
        }
        string2 = this.firstSeed;
        if (string2 != null) {
            if (!string2.equals((Object)string)) {
                Notifier.oneButtonAlert((Activity)this.form, (String)"You cannot use two codes with one start up of the Companion. You should restart the Companion and try again.", (String)"Warning", (String)"OK", (Runnable)new Runnable((PhoneStatus)this){
                    final PhoneStatus this$0;
                    {
                        this.this$0 = phoneStatus;
                    }

                    public void run() {
                        PhoneStatus.-$$Nest$fgetform(this.this$0).finish();
                        System.exit((int)0);
                    }
                });
            }
            return this.firstHmacSeed;
        }
        this.firstSeed = string;
        if (!useWebRTC) {
            AppInvHTTPD.setHmacKey(string);
        }
        try {
            string2 = MessageDigest.getInstance((String)"SHA1");
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)"Exception getting SHA1 Instance", (Throwable)exception);
            return "";
        }
        string2.update(string.getBytes());
        byte[] byArray = string2.digest();
        string2 = new StringBuffer(byArray.length * 2);
        Formatter formatter = new Formatter((Appendable)string2);
        int n = byArray.length;
        for (int i = 0; i < n; ++i) {
            formatter.format("%02x", new Object[]{byArray[i]});
        }
        Log.d((String)LOG_TAG, (String)("Seed = " + string));
        string = string2.toString();
        Log.d((String)LOG_TAG, (String)("Code = " + string));
        this.firstHmacSeed = string = string2.toString();
        return string;
    }

    @SimpleFunction(description="Really Exit the Application")
    public void shutdown() {
        this.form.finish();
        System.exit((int)0);
    }

    @SimpleFunction(description="Start the internal AppInvHTTPD to listen for incoming forms. FOR REPL USE ONLY!")
    public void startHTTPD(boolean bl) {
        if (this.form.isRepl()) {
            ((ReplForm)this.form).startHTTPD(bl);
        }
    }

    @SimpleFunction(description="Start the WebRTC engine")
    public void startWebRTC(String string, String string2) {
        if (!useWebRTC) {
            return;
        }
        string = new WebRTCNativeMgr(string, string2);
        string.initiate((ReplForm)this.form, (Context)activity, this.firstSeed);
        ((ReplForm)this.form).setWebRTCMgr((WebRTCNativeMgr)string);
    }
}

