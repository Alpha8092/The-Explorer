/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.nfc.NfcAdapter
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.util.GingerbreadUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnNewIntentListener;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.util.GingerbreadUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;

@DesignerComponent(category=ComponentCategory.SENSORS, description="<p>Non-visible component to provide NFC capabilities.  For now this component supports the reading and writing of text tags only (if supported by the device)</p><p>In order to read and write text tags, the component must have its <code>ReadMode</code> property set to True or False respectively.</p><p><strong>Note:</strong> This component will only work on Screen1 of any App Inventor app.</p>", iconName="images/nearfield.png", nonVisible=true, version=1)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.NFC")
public class NearField
extends AndroidNonvisibleComponent
implements OnStopListener,
OnResumeListener,
OnPauseListener,
OnNewIntentListener,
Deleteable {
    private static final String TAG = "nearfield";
    private Activity activity;
    private NfcAdapter nfcAdapter;
    private boolean readMode = true;
    protected int requestCode;
    private String tagContent = "";
    private String textToWrite = "";
    private int writeType;

    public NearField(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.activity = componentContainer.$context();
        this.writeType = 1;
        componentContainer = SdkLevel.getLevel() >= 9 ? GingerbreadUtil.newNfcAdapter((Context)this.activity) : null;
        this.nfcAdapter = componentContainer;
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnNewIntent((OnNewIntentListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        Log.d((String)TAG, (String)"Nearfield component created");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String LastMessage() {
        Log.d((String)TAG, (String)"String message method stared");
        return this.tagContent;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Specifies whether the NFC hardware should operate in read or write mode.")
    public void ReadMode(boolean bl) {
        Log.d((String)TAG, (String)("Read mode set to" + bl));
        this.readMode = bl;
        if (!bl && SdkLevel.getLevel() >= 9) {
            GingerbreadUtil.enableNFCWriteMode((Activity)this.activity, (NfcAdapter)this.nfcAdapter, (String)this.textToWrite);
        }
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean ReadMode() {
        Log.d((String)TAG, (String)"boolean method stared");
        return this.readMode;
    }

    @SimpleEvent
    public void TagRead(String string) {
        Log.d((String)TAG, (String)("Tag read: got message " + string));
        this.tagContent = string;
        EventDispatcher.dispatchEvent((Component)this, "TagRead", string);
    }

    @SimpleEvent
    public void TagWritten() {
        String string = this.textToWrite;
        Log.d((String)TAG, (String)("Tag written: " + string));
        EventDispatcher.dispatchEvent((Component)((Object)this), "TagWritten", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String TextToWrite() {
        Log.d((String)TAG, (String)"String message method stared");
        return this.textToWrite;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Specifies the content that will be written to the tag when in write mode. This method has no effect if ReadMode is true.")
    public void TextToWrite(String string) {
        Log.d((String)TAG, (String)("Text to write set to" + string));
        this.textToWrite = string;
        if (!this.readMode && this.writeType == 1 && SdkLevel.getLevel() >= 9) {
            GingerbreadUtil.enableNFCWriteMode((Activity)this.activity, (NfcAdapter)this.nfcAdapter, (String)this.textToWrite);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public int WriteType() {
        return this.writeType;
    }

    @Override
    public void onDelete() {
    }

    @Override
    public void onNewIntent(Intent intent) {
        Log.d((String)TAG, (String)("Nearfield on onNewIntent.  Intent is: " + intent));
        this.resolveIntent(intent);
    }

    @Override
    public void onPause() {
        Log.d((String)TAG, (String)"OnPause method started.");
        NfcAdapter nfcAdapter = this.nfcAdapter;
        if (nfcAdapter != null) {
            GingerbreadUtil.disableNFCAdapter((Activity)this.activity, (NfcAdapter)nfcAdapter);
        }
    }

    @Override
    public void onResume() {
        Intent intent = this.activity.getIntent();
        Log.d((String)TAG, (String)("Nearfield on onResume.  Intent is: " + intent));
    }

    @Override
    public void onStop() {
    }

    void resolveIntent(Intent intent) {
        Log.d((String)TAG, (String)("resolve intent. Intent is: " + intent));
        if (SdkLevel.getLevel() >= 9) {
            GingerbreadUtil.resolveNFCIntent((Intent)intent, (NearField)this);
        }
    }
}

