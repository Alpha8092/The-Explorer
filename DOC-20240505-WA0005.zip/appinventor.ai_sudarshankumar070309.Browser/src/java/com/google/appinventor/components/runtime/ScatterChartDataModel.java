/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.charts.ScatterChart
 *  com.github.mikephil.charting.charts.ScatterChart$ScatterShape
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.data.ScatterData
 *  com.github.mikephil.charting.data.ScatterDataSet
 *  com.github.mikephil.charting.interfaces.datasets.IDataSet
 *  com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
 *  com.github.mikephil.charting.utils.EntryXComparator
 *  com.google.appinventor.components.common.PointStyle
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.ScatterData;
import com.github.mikephil.charting.data.ScatterDataSet;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.interfaces.datasets.IScatterDataSet;
import com.github.mikephil.charting.utils.EntryXComparator;
import com.google.appinventor.components.common.PointStyle;
import com.google.appinventor.components.runtime.PointChartDataModel;
import com.google.appinventor.components.runtime.ScatterChartDataModel;
import com.google.appinventor.components.runtime.ScatterChartView;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ScatterChartDataModel
extends PointChartDataModel<Entry, IScatterDataSet, ScatterData, ScatterChart, ScatterChartView> {
    public ScatterChartDataModel(ScatterData scatterData, ScatterChartView scatterChartView) {
        super(scatterData, scatterChartView, (IScatterDataSet)new ScatterDataSet((List)new ArrayList(), ""));
    }

    protected ScatterChartDataModel(ScatterData scatterData, ScatterChartView scatterChartView, IScatterDataSet iScatterDataSet) {
        super(scatterData, scatterChartView);
        this.dataset = iScatterDataSet;
        ((ScatterData)this.data).addDataSet((IDataSet)iScatterDataSet);
        this.setDefaultStylingProperties();
    }

    public void addEntryFromTuple(YailList yailList) {
        if ((yailList = this.getEntryFromTuple(yailList)) != null) {
            int n = Collections.binarySearch((List)this.entries, (Object)yailList, (Comparator)new EntryXComparator());
            if (n < 0) {
                n = -n - 1;
            } else {
                int n2 = this.entries.size();
                while (n < n2 && ((Entry)this.entries.get(n)).getX() == yailList.getX()) {
                    ++n;
                }
            }
            this.entries.add(n, (Object)yailList);
        }
    }

    protected void setDefaultStylingProperties() {
        if (this.dataset instanceof ScatterDataSet) {
            ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.CIRCLE);
        }
    }

    public void setPointShape(PointStyle pointStyle) {
        if (!(this.dataset instanceof ScatterDataSet)) {
            return;
        }
        switch (1.$SwitchMap$com$google$appinventor$components$common$PointStyle[pointStyle.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown shape type: " + pointStyle);
            }
            case 5: {
                ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.X);
                break;
            }
            case 4: {
                ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.CROSS);
                break;
            }
            case 3: {
                ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.TRIANGLE);
                break;
            }
            case 2: {
                ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.SQUARE);
                break;
            }
            case 1: {
                ((ScatterDataSet)this.dataset).setScatterShape(ScatterChart.ScatterShape.CIRCLE);
            }
        }
    }
}

