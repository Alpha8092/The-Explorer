/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.util.OlsTrendLine;
import java.util.List;
import java.util.Map;

public class LogarithmicRegression
extends OlsTrendLine {
    @Override
    public Map<String, Object> compute(List<Double> list, List<Double> list2) {
        list = super.compute(list, list2);
        list.remove((Object)"x^2");
        double d = (Double)list.remove((Object)"slope");
        list.put((Object)"a", (Object)((Double)list.remove((Object)"intercept")));
        list.put((Object)"b", (Object)d);
        return list;
    }

    @Override
    public float[] computePoints(Map<String, Object> object2, float f, float f2, int n, int n2) {
        if (!object2.containsKey((Object)"b")) {
            return new float[0];
        }
        if (f2 <= 0.0f) {
            return new float[0];
        }
        float f3 = f <= 0.0f ? Math.min((float)1.0E-4f, (float)(f2 / (float)(n2 + 1))) : f;
        double d = (Double)object2.get((Object)"b");
        double d2 = (Double)object2.get((Object)"a");
        object2 = new float[n2 * 4];
        float f4 = Float.NEGATIVE_INFINITY;
        f = Float.NEGATIVE_INFINITY;
        boolean bl = true;
        for (n = 0; n < n2; ++n) {
            boolean bl2 = bl;
            if (bl) {
                bl2 = false;
                f4 = f3 + (float)n * (f2 - f3) / (float)n2;
                f = (float)(Math.log((double)f4) * d + d2);
            }
            object2[n * 4] = (Map<String, Object>)f4;
            object2[n * 4 + 1] = (Map<String, Object>)f;
            f4 = (float)(n + 1) * (f2 - f3) / (float)n2 + f3;
            f = (float)(Math.log((double)f4) * d + d2);
            object2[n * 4 + 2] = (Map<String, Object>)f4;
            object2[n * 4 + 3] = (Map<String, Object>)f;
            bl = bl2;
        }
        return object2;
    }

    @Override
    protected boolean logY() {
        return false;
    }

    @Override
    protected int size() {
        return 2;
    }

    @Override
    protected double[] xVector(double d) {
        return new double[]{1.0, Math.log((double)d)};
    }
}

