/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.SensorEvent
 *  java.lang.Object
 *  java.lang.Override
 */
package com.google.appinventor.components.runtime;

import android.hardware.SensorEvent;
import com.google.appinventor.components.runtime.BufferedSingleValueSensor;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.SingleValueSensor;

public abstract class BufferedSingleValueSensor
extends SingleValueSensor {
    private AveragingBuffer buffer;

    public BufferedSingleValueSensor(ComponentContainer componentContainer, int n, int n2) {
        super(componentContainer.$form(), n);
        this.buffer = new AveragingBuffer((BufferedSingleValueSensor)this, n2, null);
    }

    protected float getAverageValue() {
        return this.buffer.getAverage();
    }

    /*
     * Exception decompiling
     */
    @Override
    public void onSensorChanged(SensorEvent var1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.ClassCastException: uc.s cannot be cast to uc.m
         *     at oc.w.b(SourceFile:4)
         *     at oc.e.r(SourceFile:8)
         *     at kb.g.Q1(SourceFile:7)
         *     at kb.g.P1(SourceFile:70)
         *     at ib.f.d(SourceFile:59)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1133)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:607)
         *     at java.lang.Thread.run(Thread.java:760)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}

