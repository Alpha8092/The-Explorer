/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.github.mikephil.charting.charts.ScatterChart
 *  com.github.mikephil.charting.data.ChartData
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.data.ScatterData
 *  com.github.mikephil.charting.interfaces.datasets.IScatterDataSet
 *  com.github.mikephil.charting.renderer.DataRenderer
 *  com.google.appinventor.components.runtime.Chart
 *  com.google.appinventor.components.runtime.ChartDataModel
 *  com.google.appinventor.components.runtime.ScatterChartDataModel
 *  com.google.appinventor.components.runtime.util.ScatterWithTrendlineRenderer
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import com.github.mikephil.charting.charts.ScatterChart;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.ScatterData;
import com.github.mikephil.charting.interfaces.datasets.IScatterDataSet;
import com.github.mikephil.charting.renderer.DataRenderer;
import com.google.appinventor.components.runtime.Chart;
import com.google.appinventor.components.runtime.ChartDataModel;
import com.google.appinventor.components.runtime.PointChartView;
import com.google.appinventor.components.runtime.ScatterChartDataModel;
import com.google.appinventor.components.runtime.util.ScatterWithTrendlineRenderer;

public class ScatterChartView
extends PointChartView<Entry, IScatterDataSet, ScatterData, ScatterChart, ScatterChartView> {
    public ScatterChartView(Chart chart) {
        super(chart);
        this.chart = new ScatterChart((Context)this.form);
        ((ScatterChart)this.chart).setRenderer((DataRenderer)new ScatterWithTrendlineRenderer((ScatterChart)this.chart, ((ScatterChart)this.chart).getAnimator(), ((ScatterChart)this.chart).getViewPortHandler()));
        this.data = new ScatterData();
        ((ScatterChart)this.chart).setData((ChartData)((ScatterData)this.data));
        this.initializeDefaultSettings();
    }

    public ChartDataModel<Entry, IScatterDataSet, ScatterData, ScatterChart, ScatterChartView> createChartModel() {
        return new ScatterChartDataModel((ScatterData)this.data, this);
    }
}

