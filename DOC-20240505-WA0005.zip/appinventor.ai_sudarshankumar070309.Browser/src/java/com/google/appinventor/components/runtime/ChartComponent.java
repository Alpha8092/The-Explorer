package com.google.appinventor.components.runtime;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface ChartComponent extends Component {
    void initChartData();
}
