/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.provider.MediaStore$Images$Media
 *  android.util.Log
 *  android.webkit.MimeTypeMap
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.ImagePicker$1
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.QUtil
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Comparator
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.webkit.MimeTypeMap;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.ImagePicker;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.Picker;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.QUtil;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="A special-purpose button. When the user taps an image picker, the device's image gallery appears, and the user can choose an image. After an image is picked, it is saved, and the <code>Selected</code> property will be the name of the file where the image is stored. In order to not fill up storage, a maximum of 10 images will be stored.  Picking more images will delete previous images, in order from oldest to newest.", version=5)
@SimpleObject
public class ImagePicker
extends Picker
implements ActivityResultListener {
    private static final String FILE_PREFIX = "picked_image";
    private static final String LOG_TAG = "ImagePicker";
    private static final String imagePickerDirectoryName = "/Pictures/_app_inventor_image_picker";
    private static final int maxSavedFiles = 10;
    private boolean havePermission = false;
    private String selectionSavedImage = "";
    private String selectionURI;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(ImagePicker imagePicker, boolean bl) {
        imagePicker.havePermission = bl;
    }

    public ImagePicker(ComponentContainer componentContainer) {
        super(componentContainer);
    }

    private void copyToExternalStorageAndDeleteSource(File file, String string2) {
        String string3 = null;
        String string4 = QUtil.getExternalStoragePath((Context)this.container.$form());
        File file2 = new File(string4 + imagePickerDirectoryName);
        string4 = string3;
        file2.mkdirs();
        string4 = string3;
        string4 = string2 = File.createTempFile((String)FILE_PREFIX, (String)string2, (File)file2);
        string3 = string2.getPath();
        string4 = string2;
        this.selectionSavedImage = string3;
        string4 = string2;
        string4 = string2;
        Object object = new StringBuilder();
        string4 = string2;
        Log.i((String)LOG_TAG, (String)object.append("saved file path is: ").append(string3).toString());
        string4 = string2;
        FileUtil.copyFile((String)file.getAbsolutePath(), (String)string2.getAbsolutePath());
        string4 = string2;
        object = this.selectionSavedImage;
        string4 = string2;
        string4 = string2;
        string3 = new StringBuilder();
        string4 = string2;
        try {
            Log.i((String)LOG_TAG, (String)string3.append("Image was copied to ").append((String)object).toString());
        }
        catch (IOException iOException) {
            string2 = this.selectionSavedImage;
            String string5 = iOException.getMessage();
            string2 = "destination is " + string2 + ": error is " + string5;
            Log.i((String)LOG_TAG, (String)("copyFile failed. " + string2));
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "SaveImage", 1601, string2);
            this.selectionSavedImage = "";
            string4.delete();
        }
        file.delete();
        super.trimDirectory(10, file2);
    }

    private void saveSelectedImageToExternalStorage(String string2) {
        File file;
        this.selectionSavedImage = "";
        try {
            file = MediaUtil.copyMediaToTempFile((Form)this.container.$form(), (String)this.selectionURI);
        }
        catch (IOException iOException) {
            string2 = iOException.getMessage();
            Log.i((String)LOG_TAG, (String)("copyMediaToTempFile failed: " + string2));
            this.container.$form().dispatchErrorOccurredEvent((Component)this, LOG_TAG, 1602, iOException.getMessage());
            return;
        }
        String string3 = file.getPath();
        Log.i((String)LOG_TAG, (String)("temp file path is: " + string3));
        super.copyToExternalStorageAndDeleteSource(file, string2);
    }

    private void trimDirectory(int n, File objectArray) {
        objectArray = objectArray.listFiles();
        Arrays.sort((Object[])objectArray, (Comparator)new Comparator<File>((ImagePicker)this){
            final ImagePicker this$0;
            {
                this.this$0 = imagePicker;
            }

            public int compare(File file, File file2) {
                return Long.valueOf((long)file.lastModified()).compareTo(Long.valueOf((long)file2.lastModified()));
            }
        });
        int n2 = objectArray.length;
        for (int i = 0; i < n2 - n; ++i) {
            objectArray[i].delete();
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Path to the file containing the image that was selected.")
    public String Selection() {
        return this.selectionSavedImage;
    }

    @Override
    public void click() {
        if (!this.havePermission && FileUtil.needsWritePermission((FileScope)this.container.$form().DefaultFileScope())) {
            this.container.$form().askPermission("android.permission.WRITE_EXTERNAL_STORAGE", (PermissionResultHandler)new 1(this));
            return;
        }
        super.click();
    }

    @Override
    protected Intent getIntent() {
        return new Intent("android.intent.action.PICK", MediaStore.Images.Media.INTERNAL_CONTENT_URI);
    }

    @Override
    public void resultReturned(int n, int n2, Intent object) {
        if (n == this.requestCode && n2 == -1) {
            String string2;
            object = object.getData();
            this.selectionURI = string2 = object.toString();
            Log.i((String)LOG_TAG, (String)("selectionURI = " + string2));
            string2 = this.container.$context().getContentResolver();
            object = MimeTypeMap.getSingleton().getExtensionFromMimeType(string2.getType((Uri)object));
            object = "." + (String)object;
            Log.i((String)LOG_TAG, (String)("extension = " + (String)object));
            super.saveSelectedImageToExternalStorage((String)object);
            this.AfterPicking();
        }
    }
}

