/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorType
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsNxtSensor;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to a touch sensor on a LEGO MINDSTORMS NXT robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtTouchSensor
extends LegoMindstormsNxtSensor
implements Deleteable {
    private static final String DEFAULT_SENSOR_PORT = "1";
    private Handler handler = new Handler();
    private boolean pressedEventEnabled;
    private State previousState = State.UNKNOWN;
    private boolean releasedEventEnabled;
    private final Runnable sensorReader;

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.handler;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetpressedEventEnabled(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.pressedEventEnabled;
    }

    static /* bridge */ /* synthetic */ State -$$Nest$fgetpreviousState(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.previousState;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetreleasedEventEnabled(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.releasedEventEnabled;
    }

    static /* bridge */ /* synthetic */ Runnable -$$Nest$fgetsensorReader(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.sensorReader;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousState(NxtTouchSensor nxtTouchSensor, State state) {
        nxtTouchSensor.previousState = state;
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetPressedValue(NxtTouchSensor nxtTouchSensor, String string2) {
        return nxtTouchSensor.getPressedValue(string2);
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$misHandlerNeeded(NxtTouchSensor nxtTouchSensor) {
        return nxtTouchSensor.isHandlerNeeded();
    }

    public NxtTouchSensor(ComponentContainer componentContainer) {
        super(componentContainer, "NxtTouchSensor");
        this.sensorReader = new Runnable((NxtTouchSensor)this){
            final NxtTouchSensor this$0;
            {
                this.this$0 = nxtTouchSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    Object object = NxtTouchSensor.-$$Nest$mgetPressedValue(this.this$0, "");
                    if (object.valid) {
                        object = (Boolean)object.value != false ? State.PRESSED : State.RELEASED;
                        if (object != NxtTouchSensor.-$$Nest$fgetpreviousState(this.this$0)) {
                            if (object == State.PRESSED && NxtTouchSensor.-$$Nest$fgetpressedEventEnabled(this.this$0)) {
                                this.this$0.Pressed();
                            }
                            if (object == State.RELEASED && NxtTouchSensor.-$$Nest$fgetreleasedEventEnabled(this.this$0)) {
                                this.this$0.Released();
                            }
                        }
                        NxtTouchSensor.-$$Nest$fputpreviousState(this.this$0, (Object)object);
                    }
                }
                if (NxtTouchSensor.-$$Nest$misHandlerNeeded(this.this$0)) {
                    NxtTouchSensor.-$$Nest$fgethandler(this.this$0).post(NxtTouchSensor.-$$Nest$fgetsensorReader(this.this$0));
                }
            }
        };
        this.SensorPort(DEFAULT_SENSOR_PORT);
        this.PressedEventEnabled(false);
        this.ReleasedEventEnabled(false);
    }

    private LegoMindstormsNxtSensor.SensorValue<Boolean> getPressedValue(String object) {
        object = this.getInputValues((String)object, this.port);
        boolean bl = false;
        if (object != null && this.getBooleanValueFromBytes((byte[])object, 4)) {
            if (this.getSWORDValueFromBytes((byte[])object, 12) != 0) {
                bl = true;
            }
            return new Object(true, bl){
                final boolean valid;
                final T value;
                {
                    this.valid = bl;
                    this.value = t;
                }
            };
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private boolean isHandlerNeeded() {
        boolean bl = this.pressedEventEnabled || this.releasedEventEnabled;
        return bl;
    }

    @SimpleFunction(description="Returns true if the touch sensor is pressed.")
    public boolean IsPressed() {
        if (!this.checkBluetooth("IsPressed")) {
            return false;
        }
        LegoMindstormsNxtSensor.SensorValue<Boolean> sensorValue = this.getPressedValue("IsPressed");
        if (sensorValue.valid) {
            return (Boolean)sensorValue.value;
        }
        return false;
    }

    @SimpleEvent(description="Touch sensor has been pressed.")
    public void Pressed() {
        EventDispatcher.dispatchEvent(this, "Pressed", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void PressedEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.pressedEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the Pressed event should fire when the touch sensor is pressed.")
    public boolean PressedEventEnabled() {
        return this.pressedEventEnabled;
    }

    @SimpleEvent(description="Touch sensor has been released.")
    public void Released() {
        EventDispatcher.dispatchEvent(this, "Released", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void ReleasedEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.releasedEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the Released event should fire when the touch sensor is released.")
    public boolean ReleasedEventEnabled() {
        return this.releasedEventEnabled;
    }

    @Override
    @DesignerProperty(defaultValue="1", editorType="lego_nxt_sensor_port")
    @SimpleProperty(userVisible=false)
    public void SensorPort(String string2) {
        this.setSensorPort(string2);
    }

    @Override
    protected void initializeSensor(String string2) {
        this.setInputMode(string2, this.port, NxtSensorType.Touch, NxtSensorMode.Boolean);
    }

    @Override
    public void onDelete() {
        this.handler.removeCallbacks(this.sensorReader);
        super.onDelete();
    }
}

