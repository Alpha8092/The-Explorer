/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.TimePickerDialog
 *  android.app.TimePickerDialog$OnTimeSetListener
 *  android.content.Context
 *  android.os.Handler
 *  android.text.format.DateFormat
 *  android.widget.TimePicker
 *  com.google.appinventor.components.runtime.ButtonBase
 *  com.google.appinventor.components.runtime.util.Dates
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.Calendar
 */
package com.google.appinventor.components.runtime;

import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Handler;
import android.text.format.DateFormat;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ButtonBase;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.TimePicker;
import com.google.appinventor.components.runtime.util.Dates;
import java.util.Calendar;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="<p>A button that, when clicked on, launches  a popup dialog to allow the user to select a time.</p>", iconName="images/timePicker.png", version=4)
@SimpleObject
public class TimePicker
extends ButtonBase {
    private Handler androidUIHandler;
    private boolean customTime = false;
    private Form form;
    private int hour = 0;
    private Calendar instant;
    private int minute = 0;
    private TimePickerDialog time;
    private TimePickerDialog.OnTimeSetListener timePickerListener;

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgetandroidUIHandler(TimePicker timePicker) {
        return timePicker.androidUIHandler;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgethour(TimePicker timePicker) {
        return timePicker.hour;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetminute(TimePicker timePicker) {
        return timePicker.minute;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputhour(TimePicker timePicker, int n) {
        timePicker.hour = n;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputinstant(TimePicker timePicker, Calendar calendar) {
        timePicker.instant = calendar;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputminute(TimePicker timePicker, int n) {
        timePicker.minute = n;
    }

    public TimePicker(ComponentContainer componentContainer) {
        super(componentContainer);
        this.timePickerListener = new TimePickerDialog.OnTimeSetListener((TimePicker)this){
            final TimePicker this$0;
            {
                this.this$0 = timePicker;
            }

            public void onTimeSet(android.widget.TimePicker object, int n, int n2) {
                if (object.isShown()) {
                    TimePicker.-$$Nest$fputhour(this.this$0, n);
                    TimePicker.-$$Nest$fputminute(this.this$0, n2);
                    object = this.this$0;
                    TimePicker.-$$Nest$fputinstant((TimePicker)((Object)object), Dates.TimeInstant((int)TimePicker.-$$Nest$fgethour((TimePicker)((Object)object)), (int)TimePicker.-$$Nest$fgetminute(this.this$0)));
                    TimePicker.-$$Nest$fgetandroidUIHandler(this.this$0).post(new Runnable(this){
                        final 1 this$1;
                        {
                            this.this$1 = var1;
                        }

                        public void run() {
                            this.this$1.this$0.AfterTimeSet();
                        }
                    });
                }
            }
        };
        this.form = componentContainer.$form();
        componentContainer = Calendar.getInstance();
        this.hour = componentContainer.get(11);
        this.minute = componentContainer.get(12);
        this.time = new TimePickerDialog((Context)this.container.$context(), this.timePickerListener, this.hour, this.minute, DateFormat.is24HourFormat((Context)this.container.$context()));
        this.instant = Dates.TimeInstant((int)this.hour, (int)this.minute);
        this.androidUIHandler = new Handler();
    }

    @SimpleEvent(description="This event is run when a user has set the time in the popup dialog.")
    public void AfterTimeSet() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "AfterTimeSet", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The hour of the last time set using the time picker. The hour is in a 24 hour format. If the last time set was 11:53 pm, this property will return 23.")
    public int Hour() {
        return this.hour;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The instant of the last time set using the time picker")
    public Calendar Instant() {
        return this.instant;
    }

    @SimpleFunction(description="Launches the TimePicker dialog.")
    public void LaunchPicker() {
        this.click();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The minute of the last time set using the time picker")
    public int Minute() {
        return this.minute;
    }

    @SimpleFunction(description="Set the time to be shown in the Time Picker popup. Current time is shown by default.")
    public void SetTimeToDisplay(int n, int n2) {
        if (n >= 0 && n <= 23) {
            if (n2 >= 0 && n2 <= 59) {
                this.time.updateTime(n, n2);
                this.instant = Dates.TimeInstant((int)n, (int)n2);
                this.customTime = true;
            } else {
                this.form.dispatchErrorOccurredEvent((Component)this, "SetTimeToDisplay", 2302, new Object[0]);
            }
        } else {
            this.form.dispatchErrorOccurredEvent((Component)this, "SetTimeToDisplay", 2301, new Object[0]);
        }
    }

    @SimpleFunction(description="Set the time from the instant to be shown in the Time Picker dialog. Current time is shown by default.")
    public void SetTimeToDisplayFromInstant(Calendar calendar) {
        int n = Dates.Hour((Calendar)calendar);
        int n2 = Dates.Minute((Calendar)calendar);
        this.time.updateTime(n, n2);
        Dates.TimeInstant((int)n, (int)n2);
        this.customTime = true;
    }

    public void click() {
        if (!this.customTime) {
            Calendar calendar = Calendar.getInstance();
            int n = calendar.get(11);
            int n2 = calendar.get(12);
            this.time.updateTime(n, n2);
            this.instant = Dates.TimeInstant((int)this.hour, (int)this.minute);
        } else {
            this.customTime = false;
        }
        this.time.show();
    }
}

