/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.ColorMatrix
 *  android.graphics.ColorMatrixColorFilter
 *  android.graphics.Paint
 *  android.graphics.drawable.BitmapDrawable
 *  android.net.Uri
 *  android.os.Handler
 *  android.util.Log
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Canvas
 *  com.google.appinventor.components.runtime.Image
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.Base58Util
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.protobuf.ByteString
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.nio.charset.StandardCharsets
 *  java.security.KeyStore
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateFactory
 *  java.security.cert.X509Certificate
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 */
package com.google.appinventor.components.runtime;

import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.errors.StopBlocksExecution;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.imagebot.ImageBotToken;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.Base58Util;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.protobuf.ByteString;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(androidMinSdk=9, category=ComponentCategory.EXPERIMENTAL, iconName="images/paintpalette.png", nonVisible=true, version=2)
@SimpleObject
@UsesLibraries(libraries="protobuf-java-3.0.0.jar")
@UsesPermissions(permissionNames="android.permission.INTERNET")
public class ImageBot
extends AndroidNonvisibleComponent {
    private static final String COMODO_ROOT = "-----BEGIN CERTIFICATE-----\nMIIENjCCAx6gAwIBAgIBATANBgkqhkiG9w0BAQUFADBvMQswCQYDVQQGEwJTRTEU\nMBIGA1UEChMLQWRkVHJ1c3QgQUIxJjAkBgNVBAsTHUFkZFRydXN0IEV4dGVybmFs\nIFRUUCBOZXR3b3JrMSIwIAYDVQQDExlBZGRUcnVzdCBFeHRlcm5hbCBDQSBSb290\nMB4XDTAwMDUzMDEwNDgzOFoXDTIwMDUzMDEwNDgzOFowbzELMAkGA1UEBhMCU0Ux\nFDASBgNVBAoTC0FkZFRydXN0IEFCMSYwJAYDVQQLEx1BZGRUcnVzdCBFeHRlcm5h\nbCBUVFAgTmV0d29yazEiMCAGA1UEAxMZQWRkVHJ1c3QgRXh0ZXJuYWwgQ0EgUm9v\ndDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALf3GjPm8gAELTngTlvt\nH7xsD821+iO2zt6bETOXpClMfZOfvUq8k+0DGuOPz+VtUFrWlymUWoCwSXrbLpX9\nuMq/NzgtHj6RQa1wVsfwTz/oMp50ysiQVOnGXw94nZpAPA6sYapeFI+eh6FqUNzX\nmk6vBbOmcZSccbNQYArHE504B4YCqOmoaSYYkKtMsE8jqzpPhNjfzp/haW+710LX\na0Tkx63ubUFfclpxCDezeWWkWaCUN/cALw3CknLa0Dhy2xSoRcRdKn23tNbE7qzN\nE0S3ySvdQwAl+mG5aWpYIxG3pzOPVnVZ9c0p10a3CitlttNCbxWyuHv77+ldU9U0\nWicCAwEAAaOB3DCB2TAdBgNVHQ4EFgQUrb2YejS0Jvf6xCZU7wO94CTLVBowCwYD\nVR0PBAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wgZkGA1UdIwSBkTCBjoAUrb2YejS0\nJvf6xCZU7wO94CTLVBqhc6RxMG8xCzAJBgNVBAYTAlNFMRQwEgYDVQQKEwtBZGRU\ncnVzdCBBQjEmMCQGA1UECxMdQWRkVHJ1c3QgRXh0ZXJuYWwgVFRQIE5ldHdvcmsx\nIjAgBgNVBAMTGUFkZFRydXN0IEV4dGVybmFsIENBIFJvb3SCAQEwDQYJKoZIhvcN\nAQEFBQADggEBALCb4IUlwtYj4g+WBpKdQZic2YR5gdkeWxQHIzZlj7DYd7usQWxH\nYINRsPkyPef89iYTx4AWpb9a/IfPeHmJIZriTAcKhjW88t5RxNKWt9x+Tu5w/Rw5\n6wwCURQtjr0W4MHfRnXnJK3s9EK0hZNwEGe6nQY1ShjTK3rMUUKhemPR5ruhxSvC\nNr4TDea9Y355e6cJDUCrat2PisP29owaQgVR1EX1n6diIWgVIEM8med8vSTYqZEX\nc4g/VhsxOBi0cQ+azcgOno4uG+GMmIPLHzHxREzGBHNJdmAPx/i9F4BrLunMTA5a\nmnkPIAou1Z5jJh5VkpTYghdae9C8x49OhgQ=\n-----END CERTIFICATE-----\n";
    private static final String COMODO_USRTRUST = "-----BEGIN CERTIFICATE-----\nMIIFdzCCBF+gAwIBAgIQE+oocFv07O0MNmMJgGFDNjANBgkqhkiG9w0BAQwFADBv\nMQswCQYDVQQGEwJTRTEUMBIGA1UEChMLQWRkVHJ1c3QgQUIxJjAkBgNVBAsTHUFk\nZFRydXN0IEV4dGVybmFsIFRUUCBOZXR3b3JrMSIwIAYDVQQDExlBZGRUcnVzdCBF\neHRlcm5hbCBDQSBSb290MB4XDTAwMDUzMDEwNDgzOFoXDTIwMDUzMDEwNDgzOFow\ngYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtK\nZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYD\nVQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MIICIjAN\nBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAgBJlFzYOw9sIs9CsVw127c0n00yt\nUINh4qogTQktZAnczomfzD2p7PbPwdzx07HWezcoEStH2jnGvDoZtF+mvX2do2NC\ntnbyqTsrkfjib9DsFiCQCT7i6HTJGLSR1GJk23+jBvGIGGqQIjy8/hPwhxR79uQf\njtTkUcYRZ0YIUcuGFFQ/vDP+fmyc/xadGL1RjjWmp2bIcmfbIWax1Jt4A8BQOujM\n8Ny8nkz+rwWWNR9XWrf/zvk9tyy29lTdyOcSOk2uTIq3XJq0tyA9yn8iNK5+O2hm\nAUTnAU5GU5szYPeUvlM3kHND8zLDU+/bqv50TmnHa4xgk97Exwzf4TKuzJM7UXiV\nZ4vuPVb+DNBpDxsP8yUmazNt925H+nND5X4OpWaxKXwyhGNVicQNwZNUMBkTrNN9\nN6frXTpsNVzbQdcS2qlJC9/YgIoJk2KOtWbPJYjNhLixP6Q5D9kCnusSTJV882sF\nqV4Wg8y4Z+LoE53MW4LTTLPtW//e5XOsIzstAL81VXQJSdhJWBp/kjbmUZIO8yZ9\nHE0XvMnsQybQv0FfQKlERPSZ51eHnlAfV1SoPv10Yy+xUGUJ5lhCLkMaTLTwJUdZ\n+gQek9QmRkpQgbLevni3/GcV4clXhB4PY9bpYrrWX1Uu6lzGKAgEJTm4Diup8kyX\nHAc/DVL17e8vgg8CAwEAAaOB9DCB8TAfBgNVHSMEGDAWgBStvZh6NLQm9/rEJlTv\nA73gJMtUGjAdBgNVHQ4EFgQUU3m/WqorSs9UgOHYm8Cd8rIDZsswDgYDVR0PAQH/\nBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wEQYDVR0gBAowCDAGBgRVHSAAMEQGA1Ud\nHwQ9MDswOaA3oDWGM2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9BZGRUcnVzdEV4\ndGVybmFsQ0FSb290LmNybDA1BggrBgEFBQcBAQQpMCcwJQYIKwYBBQUHMAGGGWh0\ndHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcNAQEMBQADggEBAJNl9jeD\nlQ9ew4IcH9Z35zyKwKoJ8OkLJvHgwmp1ocd5yblSYMgpEg7wrQPWCcR23+WmgZWn\nRtqCV6mVksW2jwMibDN3wXsyF24HzloUQToFJBv2FAY7qCUkDrvMKnXduXBBP3zQ\nYzYhBx9G/2CkkeFnvN4ffhkUyWNnkepnB2u0j4vAbkN9w6GAbLIevFOFfdyQoaS8\nLe9Gclc1Bb+7RrtubTeZtv8jkpHGbkD4jylW6l/VXxRTrPBPYer3IsynVgviuDQf\nJtl7GQVoP7o81DgGotPmjw7jtHFtQELFhLRAlSv0ZaBIefYdgWOWnU914Ph85I6p\n0fKtirOMxyHNwu8=\n-----END CERTIFICATE-----\n";
    private static final boolean DEBUG = false;
    private static final String IMAGEBOT_SERVICE_URL = "https://chatbot.appinventor.mit.edu/image/v1";
    private static final String ISRG_ROOT_X1 = "-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw\nTzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\ncmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4\nWhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu\nZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY\nMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc\nh77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+\n0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U\nA5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW\nT8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH\nB5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC\nB5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv\nKBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn\nOlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn\njh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw\nqHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI\nrU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV\nHRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq\nhkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL\nubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ\n3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK\nNFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5\nORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur\nTkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC\njNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc\noyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq\n4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA\nmRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d\nemyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=\n-----END CERTIFICATE-----\n";
    public static final String LOG_TAG = ImageBot.class.getSimpleName();
    private static final String MIT_CA = "-----BEGIN CERTIFICATE-----\nMIIFXjCCBEagAwIBAgIJAMLfrRWIaHLbMA0GCSqGSIb3DQEBCwUAMIHPMQswCQYD\nVQQGEwJVUzELMAkGA1UECBMCTUExEjAQBgNVBAcTCUNhbWJyaWRnZTEuMCwGA1UE\nChMlTWFzc2FjaHVzZXR0cyBJbnN0aXR1dGUgb2YgVGVjaG5vbG9neTEZMBcGA1UE\nCxMQTUlUIEFwcCBJbnZlbnRvcjEmMCQGA1UEAxMdQ2xvdWREQiBDZXJ0aWZpY2F0\nZSBBdXRob3JpdHkxEDAOBgNVBCkTB0Vhc3lSU0ExGjAYBgkqhkiG9w0BCQEWC2pp\nc0BtaXQuZWR1MB4XDTE3MTIyMjIyMzkyOVoXDTI3MTIyMDIyMzkyOVowgc8xCzAJ\nBgNVBAYTAlVTMQswCQYDVQQIEwJNQTESMBAGA1UEBxMJQ2FtYnJpZGdlMS4wLAYD\nVQQKEyVNYXNzYWNodXNldHRzIEluc3RpdHV0ZSBvZiBUZWNobm9sb2d5MRkwFwYD\nVQQLExBNSVQgQXBwIEludmVudG9yMSYwJAYDVQQDEx1DbG91ZERCIENlcnRpZmlj\nYXRlIEF1dGhvcml0eTEQMA4GA1UEKRMHRWFzeVJTQTEaMBgGCSqGSIb3DQEJARYL\namlzQG1pdC5lZHUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHzI3D\nFobNDv2HTWlDdedmbxZIJYSqWlzdRJC3oVJgCubdAs46WJRqUxDRWft9UpYGMKkw\nmYN8mdPby2m5OJagdVIZgnguB71zIQkC8yMzd94FC3gldX5m7R014D/0fkpzvsSt\n6fsNectJT0k7gPELOH6t4u6AUbvIsEX0nNyRWsmA/ucXCsDBwXyBJxfOKIQ9tDI4\n/WfcKk9JDpeMF7RP0CIOtlAPotKIaPoY1W3eMIi/0riOt5vTFsB8pxhxAVy0cfGX\niHukdrAkAJixTgkyS7wzk22xOeXVnRIzAMGK5xHMDw/HRQGTrUGfIXHENV3u+3Ae\nL5/ZoQwyZTixmQNzAgMBAAGjggE5MIIBNTAdBgNVHQ4EFgQUZfMKQXqtC5UJGFrZ\ngZE1nmlx+t8wggEEBgNVHSMEgfwwgfmAFGXzCkF6rQuVCRha2YGRNZ5pcfrfoYHV\npIHSMIHPMQswCQYDVQQGEwJVUzELMAkGA1UECBMCTUExEjAQBgNVBAcTCUNhbWJy\naWRnZTEuMCwGA1UEChMlTWFzc2FjaHVzZXR0cyBJbnN0aXR1dGUgb2YgVGVjaG5v\nbG9neTEZMBcGA1UECxMQTUlUIEFwcCBJbnZlbnRvcjEmMCQGA1UEAxMdQ2xvdWRE\nQiBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkxEDAOBgNVBCkTB0Vhc3lSU0ExGjAYBgkq\nhkiG9w0BCQEWC2ppc0BtaXQuZWR1ggkAwt+tFYhoctswDAYDVR0TBAUwAwEB/zAN\nBgkqhkiG9w0BAQsFAAOCAQEAIkKr3eIvwZO6a1Jsh3qXwveVnrqwxYvLw2IhTwNT\n/P6C5jbRnzUuDuzg5sEIpbBo/Bp3qIp7G5cdVOkIrqO7uCp6Kyc7d9lPsEe/cbF4\naNwNmdWroRN1y0tuMU6+z7frd5pOeAZP9E/DM/0Uaz4yVzwnlvZUttaLymyMhH54\nisGQKbAqHDFtKZvb6DxsHzrO2YgeaBAtjeVhPWiv8BhzbOo9+hhZvYHYtoM2W+Ze\nDHuvv0v+qouphftDKVBp16N8Pk5WgabTXzV6VcNee92iwbWYDEv06+S3AF/q2TBe\nxxXtAa5ywbp6IRF37QuQChcYnOx7zIylYI1PIENfQFC2BA==\n-----END CERTIFICATE-----\n";
    private String apiKey = "";
    private boolean invert = true;
    private int size = 256;
    private SSLSocketFactory sslSockFactory;
    private String token;

    static /* bridge */ /* synthetic */ void -$$Nest$mdoCreateImage(ImageBot imageBot, String string) {
        imageBot.doCreateImage(string);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mdoEditImage(ImageBot imageBot, Bitmap bitmap, Bitmap bitmap2, String string) {
        imageBot.doEditImage(bitmap, bitmap2, string);
    }

    public ImageBot(ComponentContainer componentContainer) {
        super(componentContainer.$form());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void doCreateImage(String object2) {
        try {
            Object object3 = this.token;
            object3 = object3 != null && !object3.equals((Object)"") && this.token.charAt(0) == '%' ? this.token.substring(1) : this.token;
            object3 = ImageBotToken.token.parseFrom(Base58Util.decode((String)object3));
            Runnable runnable = ImageBotToken.request.newBuilder().setToken((ImageBotToken.token)object3);
            int n = this.size;
            object3 = new StringBuilder();
            object3 = runnable.setSize(object3.append(n).toString()).setOperation(ImageBotToken.OperationType.CREATE).setPrompt((String)object2);
            runnable = this.apiKey;
            object2 = object3;
            if (runnable != null) {
                object2 = object3;
                if (!runnable.isEmpty()) {
                    object2 = ((ImageBotToken.Builder)object3).setApikey(this.apiKey);
                }
            }
            object2 = object2.build();
            try {
                object3 = super.sendRequest(object2);
                runnable = this.form;
                object2 = new Runnable((ImageBot)this, (String)object3){
                    final ImageBot this$0;
                    final String val$response;
                    {
                        this.this$0 = imageBot;
                        this.val$response = string;
                    }

                    public void run() {
                        this.this$0.ImageCreated(this.val$response);
                    }
                };
                runnable.runOnUiThread(object2);
                return;
            }
            catch (ImageException imageException) {
                Log.e((String)LOG_TAG, (String)"Unable to create image", (Throwable)imageException);
                object3 = this.form;
                runnable = new Runnable((ImageBot)this, imageException){
                    final ImageBot this$0;
                    final ImageException val$e;
                    {
                        this.this$0 = imageBot;
                        this.val$e = imageException;
                    }

                    public void run() {
                        this.this$0.ErrorOccurred(ImageException.-$$Nest$mgetResponseCode(this.val$e), ImageException.-$$Nest$mgetResponseMessage(this.val$e));
                    }
                };
                object3.runOnUiThread(runnable);
                return;
            }
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)"Unable to create image", (Throwable)exception);
            this.form.runOnUiThread(new Runnable((ImageBot)this, exception){
                final ImageBot this$0;
                final Exception val$e;
                {
                    this.this$0 = imageBot;
                    this.val$e = exception;
                }

                public void run() {
                    this.this$0.ErrorOccurred(404, this.val$e.toString());
                }
            });
        }
    }

    private void doEditImage(Bitmap object2, Bitmap object3, String runnable) {
        Object object4 = new ByteArrayOutputStream();
        object2.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)object4);
        object4 = ByteString.copyFrom((byte[])object4.toByteArray());
        object2 = null;
        if (object3 != null) {
            object2 = new ByteArrayOutputStream();
            object3.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)object2);
            object2 = ByteString.copyFrom((byte[])object2.toByteArray());
        }
        object3 = (object3 = this.token) != null && !object3.equals((Object)"") && this.token.charAt(0) == '%' ? this.token.substring(1) : this.token;
        try {
            object3 = ImageBotToken.token.parseFrom(Base58Util.decode((String)object3));
        }
        catch (IOException iOException) {
            this.form.runOnUiThread(new Runnable((ImageBot)this){
                final ImageBot this$0;
                {
                    this.this$0 = imageBot;
                }

                public void run() {
                    this.this$0.ErrorOccurred(403, "Invalid Token");
                }
            });
            return;
        }
        object3 = ImageBotToken.request.newBuilder().setToken((ImageBotToken.token)object3).setSource((ByteString)object4).setOperation(ImageBotToken.OperationType.EDIT);
        int n = this.size;
        runnable = ((ImageBotToken.Builder)object3).setSize("" + n).setPrompt((String)runnable);
        object4 = this.apiKey;
        object3 = runnable;
        if (object4 != null) {
            object3 = runnable;
            if (!object4.isEmpty()) {
                object3 = runnable.setApikey(this.apiKey);
            }
        }
        if (object2 != null) {
            ((ImageBotToken.Builder)object3).setMask((ByteString)object2);
        }
        object2 = ((ImageBotToken.Builder)object3).build();
        try {
            object2 = super.sendRequest(object2);
            object3 = this.form;
            runnable = new Runnable((ImageBot)this, (String)object2){
                final ImageBot this$0;
                final String val$response;
                {
                    this.this$0 = imageBot;
                    this.val$response = string;
                }

                public void run() {
                    this.this$0.ImageEdited(this.val$response);
                }
            };
            object3.runOnUiThread(runnable);
        }
        catch (ImageException imageException) {
            Log.e((String)LOG_TAG, (String)"Unable to edit image", (Throwable)imageException);
            this.form.runOnUiThread(new Runnable((ImageBot)this, imageException){
                final ImageBot this$0;
                final ImageException val$e;
                {
                    this.this$0 = imageBot;
                    this.val$e = imageException;
                }

                public void run() {
                    this.this$0.ErrorOccurred(ImageException.-$$Nest$mgetResponseCode(this.val$e), ImageException.-$$Nest$mgetResponseMessage(this.val$e));
                }
            });
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void ensureSslSockFactory() {
        ImageBot imageBot = this;
        synchronized (imageBot) {
            int n;
            X509Certificate[] x509CertificateArray;
            int n2;
            ByteArrayInputStream byteArrayInputStream;
            ByteArrayInputStream byteArrayInputStream2;
            ByteArrayInputStream byteArrayInputStream3;
            ByteArrayInputStream byteArrayInputStream4;
            CertificateFactory certificateFactory;
            Object object2 = this.sslSockFactory;
            if (object2 != null) return;
            try {
                certificateFactory = CertificateFactory.getInstance((String)"X.509");
                byteArrayInputStream4 = new ByteArrayInputStream(COMODO_ROOT.getBytes(StandardCharsets.UTF_8));
                object2 = certificateFactory.generateCertificate((InputStream)byteArrayInputStream4);
                byteArrayInputStream4.close();
                byteArrayInputStream3 = new ByteArrayInputStream(COMODO_USRTRUST.getBytes(StandardCharsets.UTF_8));
                byteArrayInputStream4 = certificateFactory.generateCertificate((InputStream)byteArrayInputStream3);
                byteArrayInputStream3.close();
                byteArrayInputStream2 = new ByteArrayInputStream(MIT_CA.getBytes(StandardCharsets.UTF_8));
                byteArrayInputStream3 = certificateFactory.generateCertificate((InputStream)byteArrayInputStream2);
                byteArrayInputStream2.close();
                byteArrayInputStream = new ByteArrayInputStream(ISRG_ROOT_X1.getBytes(StandardCharsets.UTF_8));
                byteArrayInputStream2 = certificateFactory.generateCertificate((InputStream)byteArrayInputStream);
                byteArrayInputStream.close();
                certificateFactory = KeyStore.getInstance((String)KeyStore.getDefaultType());
                certificateFactory.load(null, null);
                n2 = 1;
                x509CertificateArray = this.getSystemCertificates();
                n = x509CertificateArray.length;
            }
            catch (Exception exception) {
                Log.e((String)LOG_TAG, (String)"Could not setup SSL Trust Store for ImageBot", (Throwable)exception);
                object2 = new YailRuntimeError("Could Not setup SSL Trust Store for ImageBot: ", exception.getMessage());
                throw object2;
            }
            for (int i = 0; i < n; ++n2, ++i) {
                X509Certificate x509Certificate = x509CertificateArray[i];
                {
                    byteArrayInputStream = new StringBuilder();
                    certificateFactory.setCertificateEntry(byteArrayInputStream.append("root").append(n2).toString(), (Certificate)x509Certificate);
                    continue;
                }
            }
            {
                certificateFactory.setCertificateEntry("comodo", (Certificate)object2);
                certificateFactory.setCertificateEntry("inter", (Certificate)byteArrayInputStream4);
                certificateFactory.setCertificateEntry("mitca", (Certificate)byteArrayInputStream3);
                certificateFactory.setCertificateEntry("isrg", (Certificate)byteArrayInputStream2);
                object2 = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
                object2.init((KeyStore)certificateFactory);
                byteArrayInputStream4 = SSLContext.getInstance((String)"TLS");
                byteArrayInputStream4.init(null, object2.getTrustManagers(), null);
                this.sslSockFactory = byteArrayInputStream4.getSocketFactory();
            }
            return;
        }
    }

    private File getOutputFile() throws IOException {
        String string;
        String string2 = FileUtil.resolveFileName((Form)this.form, (String)"", (FileScope)this.form.DefaultFileScope());
        if (string2.startsWith("file://")) {
            string = string2.substring(7);
        } else {
            string = string2;
            if (string2.startsWith("file:")) {
                string = string2.substring(5);
            }
        }
        string2 = LOG_TAG;
        Log.d((String)string2, (String)("tempdir = " + string));
        string = File.createTempFile((String)"ImageBot", (String)".png", (File)new File(string));
        Log.d((String)string2, (String)("outfile = " + string));
        return string;
    }

    private X509Certificate[] getSystemCertificates() {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
            X509Certificate[] x509CertificateArray = null;
            trustManagerFactory.init(null);
            x509CertificateArray = ((X509TrustManager)trustManagerFactory.getTrustManagers()[0]).getAcceptedIssuers();
            return x509CertificateArray;
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)"Getting System Certificates", (Throwable)exception);
            return new X509Certificate[0];
        }
    }

    private Bitmap loadImage(Object object2) throws IOException {
        Log.d((String)LOG_TAG, (String)("loadImage source = " + object2));
        if (object2 instanceof Canvas) {
            object2 = ((Canvas)object2).getBitmap();
        } else if (object2 instanceof Image) {
            object2 = ((BitmapDrawable)((Image)object2).getView().getBackground()).getBitmap();
        } else {
            object2 = object2.toString();
            object2 = MediaUtil.getBitmapDrawable((Form)this.form, (String)object2).getBitmap();
        }
        Object object3 = object2;
        if (object2 != null) {
            if (object2.getWidth() == this.size && object2.getHeight() == this.size) {
                return object2;
            }
            int n = this.size;
            object3 = Bitmap.createScaledBitmap((Bitmap)object2, (int)n, (int)n, (boolean)false);
        }
        return object3;
    }

    private Bitmap loadMask(Object object2) throws IOException {
        Bitmap bitmap = super.loadImage(object2);
        object2 = bitmap;
        if (this.invert) {
            object2 = new ColorMatrixColorFilter(new ColorMatrix(new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, -1.0f, 255.0f}));
            Paint paint = new Paint();
            paint.setColorFilter((ColorFilter)object2);
            int n = this.size;
            object2 = Bitmap.createBitmap((int)n, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            new android.graphics.Canvas((Bitmap)object2).drawBitmap(bitmap, 0.0f, 0.0f, paint);
        }
        return object2;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private String sendRequest(ImageBotToken.request var1) throws ImageException {
        block11: {
            block10: {
                var7_3 /* !! */  = null;
                var6_5 = null;
                super.ensureSslSockFactory();
                var3_7 = -1;
                var4_8 = var6_5;
                var5_9 = var7_3 /* !! */ ;
                var2_10 = var3_7;
                var4_8 = var6_5;
                var5_9 = var7_3 /* !! */ ;
                var2_10 = var3_7;
                var8_11 = new URL("https://chatbot.appinventor.mit.edu/image/v1");
                var4_8 = var6_5;
                var5_9 = var7_3 /* !! */ ;
                var2_10 = var3_7;
                var6_5 = (HttpsURLConnection)var8_11.openConnection();
                if (var6_5 == null) ** GOTO lbl95
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var6_5.setSSLSocketFactory(this.sslSockFactory);
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var6_5.setRequestMethod("POST");
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var6_5.setDoOutput(true);
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */ .writeTo(var6_5.getOutputStream());
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var3_7 = var6_5.getResponseCode();
                if (var3_7 != 200) ** GOTO lbl80
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var7_3 /* !! */  = (HttpsURLConnection)ImageBotToken.response.parseFrom(var6_5.getInputStream()).getImage().toByteArray();
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var8_11 = super.getOutputFile();
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */  = new FileOutputStream((File)var8_11);
                var1 /* !! */ .write((byte[])var7_3 /* !! */ );
                var1 /* !! */ .flush();
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */ .close();
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */  = Uri.fromFile((File)var8_11).toString();
                if (var6_5 == null) break block10;
                var6_5.disconnect();
            }
            return var1 /* !! */ ;
            catch (Throwable var7_4) {
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */ .close();
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                throw var7_4;
lbl80:
                // 1 sources

                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var7_3 /* !! */  = IOUtils.readStreamAsString((InputStream)var6_5.getErrorStream());
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                var1 /* !! */  = new Exception(var3_7, (String)var7_3 /* !! */ , null, null){
                    private final int code;
                    private final String description;

                    static /* bridge */ /* synthetic */ int -$$Nest$mgetResponseCode(ImageException imageException) {
                        return imageException.getResponseCode();
                    }

                    static /* bridge */ /* synthetic */ String -$$Nest$mgetResponseMessage(ImageException imageException) {
                        return imageException.getResponseMessage();
                    }
                    {
                        this.code = n;
                        this.description = string;
                    }

                    private int getResponseCode() {
                        return this.code;
                    }

                    private String getResponseMessage() {
                        return this.description;
                    }
                };
                var4_8 = var6_5;
                var5_9 = var6_5;
                var2_10 = var3_7;
                throw var1 /* !! */ ;
lbl95:
                // 1 sources

                if (var6_5 != null) {
                    var6_5.disconnect();
                }
                throw new /* invalid duplicate definition of identical inner class */;
                {
                    catch (Throwable var1_1) {
                        break block11;
                    }
                    catch (IOException var6_6) {}
                    var4_8 = var5_9;
                    {
                        Log.e((String)ImageBot.LOG_TAG, (String)"Got an IOException", (Throwable)var6_6);
                        var4_8 = var5_9;
                        var4_8 = var5_9;
                        var1 /* !! */  = new /* invalid duplicate definition of identical inner class */;
                        var4_8 = var5_9;
                        throw var1 /* !! */ ;
                    }
                }
            }
        }
        if (var4_8 != null) {
            var4_8.disconnect();
        }
        throw var1_1;
    }

    @DesignerProperty(editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void ApiKey(String string) {
        this.apiKey = string;
    }

    @SimpleFunction
    public void CreateImage(String string) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((ImageBot)this, string){
            final ImageBot this$0;
            final String val$description;
            {
                this.this$0 = imageBot;
                this.val$description = string;
            }

            public void run() {
                ImageBot.-$$Nest$mdoCreateImage(this.this$0, this.val$description);
            }
        });
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SimpleFunction
    public void EditImage(Object object2, String runnable) {
        try {
            Runnable runnable2;
            void var0_5;
            Bitmap bitmap = super.loadImage(object2);
            if (bitmap != null) {
                Runnable runnable3 = new Runnable((ImageBot)var0_5, bitmap, (String)runnable2){
                    final ImageBot this$0;
                    final Bitmap val$bitmap;
                    final String val$description;
                    {
                        this.this$0 = imageBot;
                        this.val$bitmap = bitmap;
                        this.val$description = string;
                    }

                    public void run() {
                        ImageBot.-$$Nest$mdoEditImage(this.this$0, this.val$bitmap, null, this.val$description);
                    }
                };
                AsynchUtil.runAsynchronously((Runnable)runnable3);
                return;
            }
            Handler handler = var0_5.form.androidUIHandler;
            runnable2 = new Runnable((ImageBot)var0_5){
                final ImageBot this$0;
                {
                    this.this$0 = imageBot;
                }

                public void run() {
                    this.this$0.ErrorOccurred(-1, "Invalid input to EditImage");
                }
            };
            handler.postDelayed(runnable2, 0L);
            StopBlocksExecution stopBlocksExecution = new StopBlocksExecution();
            throw stopBlocksExecution;
        }
        catch (IOException iOException) {
            Log.e((String)LOG_TAG, (String)"Unable to read source image", (Throwable)iOException);
        }
    }

    @SimpleFunction
    public void EditImageWithMask(Object object2, Object runnable, String string) {
        Bitmap bitmap;
        block4: {
            object2 = super.loadImage(object2);
            bitmap = super.loadMask(runnable);
            if (object2 == null) {
                return;
            }
            if (bitmap != null) break block4;
            return;
        }
        try {
            runnable = new Runnable((ImageBot)this, (Bitmap)object2, bitmap, string){
                final ImageBot this$0;
                final Bitmap val$bitmap;
                final Bitmap val$mask;
                final String val$prompt;
                {
                    this.this$0 = imageBot;
                    this.val$bitmap = bitmap;
                    this.val$mask = bitmap2;
                    this.val$prompt = string;
                }

                public void run() {
                    ImageBot.-$$Nest$mdoEditImage(this.this$0, this.val$bitmap, this.val$mask, this.val$prompt);
                }
            };
            AsynchUtil.runAsynchronously((Runnable)runnable);
        }
        catch (IOException iOException) {
            Log.e((String)LOG_TAG, (String)"Unable to read source image", (Throwable)iOException);
        }
    }

    @SimpleEvent
    public void ErrorOccurred(int n, String string) {
        if (!EventDispatcher.dispatchEvent((Component)this, "ErrorOccurred", n, string)) {
            this.form.dispatchErrorOccurredEvent((Component)this, "ErrorOccurred", 4300, n, string);
        }
    }

    @SimpleEvent
    public void ImageCreated(String string) {
        EventDispatcher.dispatchEvent((Component)this, "ImageCreated", string);
    }

    @SimpleEvent
    public void ImageEdited(String string) {
        EventDispatcher.dispatchEvent((Component)this, "ImageEdited", string);
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void InvertMask(boolean bl) {
        this.invert = bl;
    }

    @SimpleProperty
    public boolean InvertMask() {
        return this.invert;
    }

    @SimpleProperty
    public int Size() {
        return this.size;
    }

    @DesignerProperty(defaultValue="256", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void Size(int n) {
        this.size = n;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.ADVANCED, description="The MIT Access token to use. MIT App Inventor will automatically fill this value in. You should not need to change it.", userVisible=true)
    public void Token(String string) {
        this.token = string;
    }
}

