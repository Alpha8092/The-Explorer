/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.text.TextUtils
 *  android.util.Log
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.ObservableDataSource
 *  com.google.appinventor.components.runtime.Web$7
 *  com.google.appinventor.components.runtime.repackaged.org.json.XML
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.BulkPermissionRequest
 *  com.google.appinventor.components.runtime.util.ChartDataSourceUtil
 *  com.google.appinventor.components.runtime.util.CsvUtil
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.GingerbreadUtil
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.XmlParser
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.io.BufferedInputStream
 *  java.io.BufferedOutputStream
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.Reader
 *  java.io.StringReader
 *  java.io.UnsupportedEncodingException
 *  java.lang.CharSequence
 *  java.lang.ClassCastException
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.net.CookieHandler
 *  java.net.HttpURLConnection
 *  java.net.MalformedURLException
 *  java.net.ProtocolException
 *  java.net.SocketTimeoutException
 *  java.net.URISyntaxException
 *  java.net.URL
 *  java.net.URLDecoder
 *  java.net.URLEncoder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.Future
 *  java.util.concurrent.FutureTask
 *  javax.xml.parsers.SAXParser
 *  javax.xml.parsers.SAXParserFactory
 *  org.json.JSONException
 *  org.xml.sax.InputSource
 *  org.xml.sax.helpers.DefaultHandler
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.common.HtmlEntities;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSource;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.ObservableDataSource;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.errors.DispatchableError;
import com.google.appinventor.components.runtime.errors.IllegalArgumentError;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.RequestTimeoutException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.XML;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import com.google.appinventor.components.runtime.util.ChartDataSourceUtil;
import com.google.appinventor.components.runtime.util.CsvUtil;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.GingerbreadUtil;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.XmlParser;
import com.google.appinventor.components.runtime.util.YailDictionary;
import com.google.appinventor.components.runtime.util.YailList;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.DefaultHandler;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.CONNECTIVITY, description="Non-visible component that provides functions for HTTP GET, POST, PUT, and DELETE requests.", iconName="images/web.png", nonVisible=true, version=9)
@SimpleObject
@UsesLibraries(libraries="json.jar")
@UsesPermissions(value={"android.permission.INTERNET"})
public class Web
extends AndroidNonvisibleComponent
implements Component,
ObservableDataSource<YailList, Future<YailList>> {
    private static final String LOG_TAG = "Web";
    private static final Map<String, String> mimeTypeToExtension;
    private final Activity activity;
    private boolean allowCookies;
    private YailList columns;
    private final CookieHandler cookieHandler;
    private HashSet<DataSourceChangeListener> dataSourceObservers;
    private boolean haveReadPermission;
    private boolean haveWritePermission;
    private FutureTask<Void> lastTask;
    private YailList requestHeaders;
    private String responseFileName;
    private String responseTextEncoding;
    private boolean saveResponse;
    private int timeout;
    private String urlString;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhaveReadPermission(Web web, boolean bl) {
        web.haveReadPermission = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputhaveWritePermission(Web web, boolean bl) {
        web.haveWritePermission = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mperformRequest(Web web, CapturedProperties capturedProperties, byte[] byArray, String string, String string2, String string3) {
        web.performRequest(capturedProperties, byArray, string, string2, string3);
    }

    static {
        HashMap hashMap = Maps.newHashMap();
        mimeTypeToExtension = hashMap;
        hashMap.put((Object)"application/pdf", (Object)"pdf");
        hashMap.put((Object)"application/zip", (Object)"zip");
        hashMap.put((Object)"audio/mpeg", (Object)"mpeg");
        hashMap.put((Object)"audio/mp3", (Object)"mp3");
        hashMap.put((Object)"audio/mp4", (Object)"mp4");
        hashMap.put((Object)"image/gif", (Object)"gif");
        hashMap.put((Object)"image/jpeg", (Object)"jpg");
        hashMap.put((Object)"image/png", (Object)"png");
        hashMap.put((Object)"image/tiff", (Object)"tiff");
        hashMap.put((Object)"text/plain", (Object)"txt");
        hashMap.put((Object)"text/html", (Object)"html");
        hashMap.put((Object)"text/xml", (Object)"xml");
    }

    protected Web() {
        super(null);
        this.urlString = "";
        this.requestHeaders = new YailList();
        this.responseFileName = "";
        this.timeout = 0;
        this.haveReadPermission = false;
        this.haveWritePermission = false;
        this.lastTask = null;
        this.columns = new YailList();
        this.dataSourceObservers = new HashSet();
        this.responseTextEncoding = "UTF-8";
        this.activity = null;
        this.cookieHandler = null;
    }

    public Web(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.urlString = "";
        this.requestHeaders = new YailList();
        this.responseFileName = "";
        this.timeout = 0;
        this.haveReadPermission = false;
        this.haveWritePermission = false;
        Object var2_2 = null;
        this.lastTask = null;
        this.columns = new YailList();
        this.dataSourceObservers = new HashSet();
        this.responseTextEncoding = "UTF-8";
        this.activity = componentContainer.$context();
        componentContainer = SdkLevel.getLevel() >= 9 ? GingerbreadUtil.newCookieManager() : var2_2;
        this.cookieHandler = componentContainer;
    }

    private CapturedProperties capturePropertyValues(String string) {
        try {
            Object object2 = new Object((Web)this){
                final boolean allowCookies;
                final Map<String, List<String>> cookies;
                final Map<String, List<String>> requestHeaders;
                final String responseFileName;
                final boolean saveResponse;
                final int timeout;
                final URL url;
                final String urlString;
                {
                    Object object2;
                    block5: {
                        Map map;
                        boolean bl;
                        URL uRL;
                        object2 = web.urlString;
                        this.urlString = object2;
                        this.url = uRL = new URL((String)object2);
                        this.allowCookies = bl = web.allowCookies;
                        this.saveResponse = web.saveResponse;
                        this.responseFileName = web.responseFileName;
                        this.timeout = web.timeout;
                        this.requestHeaders = map = Web.processRequestHeaders(web.requestHeaders);
                        Object var4_8 = null;
                        Object var3_9 = null;
                        object2 = var4_8;
                        if (bl) {
                            object2 = var4_8;
                            if (web.cookieHandler != null) {
                                try {
                                    web = web.cookieHandler.get(uRL.toURI(), map);
                                }
                                catch (IOException iOException) {
                                    object2 = var4_8;
                                    break block5;
                                }
                                catch (URISyntaxException uRISyntaxException) {
                                    web = var3_9;
                                }
                                object2 = web;
                            }
                        }
                    }
                    this.cookies = object2;
                }
            };
            return object2;
        }
        catch (InvalidRequestHeadersException invalidRequestHeadersException) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, invalidRequestHeadersException.errorNumber, invalidRequestHeadersException.index);
        }
        catch (MalformedURLException malformedURLException) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 1109, this.urlString);
        }
        return null;
    }

    private File createFile(String string, String string2) throws IOException, FileUtil.FileException {
        if (!TextUtils.isEmpty((CharSequence)string)) {
            return FileUtil.getExternalFile((Form)this.form, (String)string);
        }
        int n = string2.indexOf(59);
        string = string2;
        if (n != -1) {
            string = string2.substring(0, n);
        }
        string = string2 = (String)mimeTypeToExtension.get((Object)string);
        if (string2 == null) {
            string = "tmp";
        }
        return FileUtil.getDownloadFile((Form)this.form, (String)string);
    }

    @Deprecated
    static Object decodeJsonText(String string) throws IllegalArgumentException {
        return Web.decodeJsonText(string, false);
    }

    static Object decodeJsonText(String object2, boolean bl) throws IllegalArgumentException {
        try {
            object2 = JsonUtil.getObjectFromJson((String)object2, (boolean)bl);
            return object2;
        }
        catch (org.json.JSONException jSONException) {
            throw new IllegalArgumentException("jsonText is not a legal JSON value");
        }
    }

    private static InputStream getConnectionStream(HttpURLConnection httpURLConnection) throws SocketTimeoutException {
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            return inputStream;
        }
        catch (IOException iOException) {
            return httpURLConnection.getErrorStream();
        }
        catch (SocketTimeoutException socketTimeoutException) {
            throw socketTimeoutException;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String getResponseContent(HttpURLConnection object2, String string) throws IOException {
        String string2 = object2.getContentEncoding();
        Object object3 = string2;
        if (string2 == null) {
            object3 = string != null && !string.isEmpty() ? string : "UTF-8";
        }
        string = new InputStreamReader(Web.getConnectionStream(object2), (String)object3);
        try {
            int n = object2.getContentLength();
            object2 = n != -1 ? new StringBuilder(n) : new StringBuilder();
            object3 = new char[1024];
            while ((n = string.read((char[])object3)) != -1) {
                object2.append((char[])object3, 0, n);
            }
            object2 = object2.toString();
            return object2;
        }
        finally {
            string.close();
        }
    }

    private static String getResponseType(HttpURLConnection object2) {
        if ((object2 = object2.getContentType()) == null) {
            object2 = "";
        }
        return object2;
    }

    private static HttpURLConnection openConnection(CapturedProperties capturedProperties, String string) throws IOException, ClassCastException, ProtocolException {
        HttpURLConnection httpURLConnection = (HttpURLConnection)capturedProperties.url.openConnection();
        httpURLConnection.setConnectTimeout(capturedProperties.timeout);
        httpURLConnection.setReadTimeout(capturedProperties.timeout);
        if (string.equals((Object)"PUT") || string.equals((Object)"PATCH") || string.equals((Object)"DELETE")) {
            httpURLConnection.setRequestMethod(string);
        }
        for (Map.Entry entry : capturedProperties.requestHeaders.entrySet()) {
            String string2 = (String)entry.getKey();
            entry = ((List)entry.getValue()).iterator();
            while (entry.hasNext()) {
                httpURLConnection.addRequestProperty(string2, (String)entry.next());
            }
        }
        if (capturedProperties.cookies != null) {
            for (String string2 : capturedProperties.cookies.entrySet()) {
                string = (String)string2.getKey();
                string2 = ((List)string2.getValue()).iterator();
                while (string2.hasNext()) {
                    httpURLConnection.addRequestProperty(string, (String)string2.next());
                }
            }
        }
        return httpURLConnection;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void performRequest(CapturedProperties var1_10, byte[] var2_14, String var3_2, String var4_3, String var5_1) {
        block36: {
            block45: {
                block44: {
                    block43: {
                        block42: {
                            block41: {
                                block38: {
                                    block39: {
                                        block40: {
                                            block37: {
                                                var7_17 /* !! */  = new ArrayList();
                                                if (var3_2 /* !! */  != null && FileUtil.needsReadPermission((Form)this.form, (String)var3_2 /* !! */ ) && !this.haveReadPermission) {
                                                    var7_17 /* !! */ .add((Object)"android.permission.READ_EXTERNAL_STORAGE");
                                                }
                                                if (this.saveResponse && FileUtil.needsWritePermission((Form)this.form, (String)(var8_18 /* !! */  = FileUtil.resolveFileName((Form)this.form, (String)var1_10.responseFileName, (FileScope)this.form.DefaultFileScope()))) && !this.haveWritePermission) {
                                                    var7_17 /* !! */ .add((Object)"android.permission.WRITE_EXTERNAL_STORAGE");
                                                }
                                                if (var7_17 /* !! */ .size() > 0 && !this.haveReadPermission) {
                                                    this.form.askPermission((BulkPermissionRequest)new 7(this, (Component)this, var5_1, (String[])var7_17 /* !! */ .toArray((Object[])new String[0]), (List)var7_17 /* !! */ , this, var1_10, var2_14 /* !! */ , var3_2 /* !! */ , (String)var4_3, var5_1));
                                                    return;
                                                }
                                                var8_18 /* !! */  = Web.openConnection(var1_10, (String)var4_3);
                                                if (var8_18 /* !! */  == null) break block36;
                                                if (var2_14 /* !! */  == null) break block37;
                                                try {
                                                    Web.writeRequestData(var8_18 /* !! */ , var2_14 /* !! */ );
                                                    ** GOTO lbl28
                                                }
                                                catch (Throwable var4_4) {
                                                    var7_17 /* !! */  = this;
                                                    break block38;
                                                }
                                                catch (SocketTimeoutException var4_5) {
                                                    var4_3 = this;
                                                    break block39;
                                                }
                                            }
                                            if (var3_2 /* !! */  == null) ** GOTO lbl28
                                            this.writeRequestFile(var8_18 /* !! */ , var3_2 /* !! */ );
lbl28:
                                            // 3 sources

                                            var6_19 = var8_18 /* !! */ .getResponseCode();
                                            var7_17 /* !! */  = Web.getResponseType(var8_18 /* !! */ );
                                            this.processResponseCookies(var8_18 /* !! */ );
                                            if (this.saveResponse) {
                                                var9_20 = this.saveResponseContent(var8_18 /* !! */ , var1_10.responseFileName, (String)var7_17 /* !! */ );
                                                var10_22 = this.activity;
                                                var4_3 = new Runnable(this, var1_10, var6_19, (String)var7_17 /* !! */ , var9_20){
                                                    final Web this$0;
                                                    final String val$path;
                                                    final int val$responseCode;
                                                    final String val$responseType;
                                                    final CapturedProperties val$webProps;
                                                    {
                                                        this.this$0 = web;
                                                        this.val$webProps = capturedProperties;
                                                        this.val$responseCode = n;
                                                        this.val$responseType = string;
                                                        this.val$path = string2;
                                                    }

                                                    public void run() {
                                                        this.this$0.GotFile(this.val$webProps.urlString, this.val$responseCode, this.val$responseType, this.val$path);
                                                    }
                                                };
                                                var10_22.runOnUiThread((Runnable)var4_3);
                                                break block40;
                                            }
                                            var9_21 = Web.getResponseContent(var8_18 /* !! */ , this.responseTextEncoding);
                                            var11_24 = this.activity;
                                            var4_3 = this;
                                            var10_23 = new Runnable(this, var1_10, var6_19, (String)var7_17 /* !! */ , (String)var9_21){
                                                final Web this$0;
                                                final int val$responseCode;
                                                final String val$responseContent;
                                                final String val$responseType;
                                                final CapturedProperties val$webProps;
                                                {
                                                    this.this$0 = web;
                                                    this.val$webProps = capturedProperties;
                                                    this.val$responseCode = n;
                                                    this.val$responseType = string;
                                                    this.val$responseContent = string2;
                                                }

                                                public void run() {
                                                    this.this$0.GotText(this.val$webProps.urlString, this.val$responseCode, this.val$responseType, this.val$responseContent);
                                                }
                                            };
                                            var11_24.runOnUiThread(var10_23);
                                            super.updateColumns((String)var9_21, (String)var7_17 /* !! */ );
                                            var4_3.notifyDataObservers(null, null);
                                        }
                                        var4_3 = this;
                                        var8_18 /* !! */ .disconnect();
                                        break block36;
                                        catch (SocketTimeoutException var4_6) {
                                            break block39;
                                        }
                                        catch (Throwable var4_7) {
                                            var7_17 /* !! */  = this;
                                            break block38;
                                        }
                                        catch (SocketTimeoutException var4_8) {
                                            var4_3 = this;
                                        }
                                    }
                                    var4_3 = this;
                                    try {
                                        var7_17 /* !! */  = var4_3.activity;
                                        var9_21 = new Runnable((Web)var4_3, var1_10){
                                            final Web this$0;
                                            final CapturedProperties val$webProps;
                                            {
                                                this.this$0 = web;
                                                this.val$webProps = capturedProperties;
                                            }

                                            public void run() {
                                                this.this$0.TimedOut(this.val$webProps.urlString);
                                            }
                                        };
                                        var7_17 /* !! */ .runOnUiThread(var9_21);
                                        var4_3 = new RequestTimeoutException();
                                        throw var4_3;
                                    }
                                    catch (Throwable v0) {
                                        var4_3 = this;
                                        var4_3 = v0;
                                    }
                                }
                                var7_17 /* !! */  = this;
                                try {
                                    var8_18 /* !! */ .disconnect();
                                    throw var4_3;
                                }
                                catch (Exception v1) {
                                    var4_3 = this;
                                    var4_3 = v1;
                                    break block41;
                                }
                                catch (RequestTimeoutException v2) {
                                    var2_14 /* !! */  = (byte[])this;
                                    var2_14 /* !! */  = (byte[])v2;
                                    break block42;
                                }
                                catch (DispatchableError v3) {
                                    var1_10 = this;
                                    var1_10 = v3;
                                    break block43;
                                }
                                catch (FileUtil.FileException v4) {
                                    var1_10 = this;
                                    var1_10 = v4;
                                    break block44;
                                }
                                catch (PermissionException v5) {
                                    var1_10 = this;
                                    var1_10 = v5;
                                    break block45;
                                }
                                catch (Exception var4_9) {
                                    var7_17 /* !! */  = this;
                                }
                            }
                            var7_17 /* !! */  = this;
                            if (var5_1.equals((Object)"Get")) {
                                var6_19 = 1101;
                                var2_14 /* !! */  = (byte[])new String[1];
                                var2_14 /* !! */ [0] = (byte)var1_10.urlString;
                                var1_10 = (String[])var2_14 /* !! */ ;
                            } else if (var5_1.equals((Object)"Delete")) {
                                var6_19 = 1114;
                                var2_14 /* !! */  = (byte[])new String[1];
                                var2_14 /* !! */ [0] = (byte)var1_10.urlString;
                                var1_10 = (String[])var2_14 /* !! */ ;
                            } else if (!(var5_1.equals((Object)"PostFile") || var5_1.equals((Object)"PutFile") || var5_1.equals((Object)"PatchFile"))) {
                                var4_3 = "";
                                var3_2 /* !! */  = var4_3;
                                if (var2_14 /* !! */  != null) {
                                    try {
                                        var3_2 /* !! */  = new String(var2_14 /* !! */ , "UTF-8");
                                    }
                                    catch (UnsupportedEncodingException var2_15) {
                                        Log.e((String)"Web", (String)"UTF-8 is the default charset for Android but not available???");
                                        var3_2 /* !! */  = var4_3;
                                    }
                                }
                                var1_10 = new String[]{var3_2 /* !! */ , var1_10.urlString};
                                var6_19 = 1103;
                            } else {
                                var6_19 = 1104;
                                var2_14 /* !! */  = (byte[])new String[2];
                                var2_14 /* !! */ [0] = (byte)var3_2 /* !! */ ;
                                var2_14 /* !! */ [1] = (byte)var1_10.urlString;
                                var1_10 = (String[])var2_14 /* !! */ ;
                            }
                            var7_17 /* !! */ .form.dispatchErrorOccurredEvent((Component)var7_17 /* !! */ , var5_1, var6_19, var1_10);
                            break block36;
                            catch (RequestTimeoutException var2_16) {
                                var2_14 /* !! */  = (byte[])this;
                            }
                        }
                        var2_14 /* !! */  = (byte[])this;
                        var2_14 /* !! */ .form.dispatchErrorOccurredEvent((Component)var2_14 /* !! */ , var5_1, 1117, new Object[]{var1_10.urlString});
                        break block36;
                        catch (DispatchableError var1_11) {
                            var2_14 /* !! */  = (byte[])this;
                        }
                    }
                    var2_14 /* !! */  = (byte[])this;
                    var2_14 /* !! */ .form.dispatchErrorOccurredEvent((Component)var2_14 /* !! */ , var5_1, var1_10.getErrorCode(), var1_10.getArguments());
                    break block36;
                    catch (FileUtil.FileException var1_12) {
                        var2_14 /* !! */  = (byte[])this;
                    }
                }
                var2_14 /* !! */  = (byte[])this;
                var2_14 /* !! */ .form.dispatchErrorOccurredEvent((Component)var2_14 /* !! */ , var5_1, var1_10.getErrorMessageNumber(), new Object[0]);
                break block36;
                catch (PermissionException var1_13) {
                    var2_14 /* !! */  = (byte[])this;
                }
            }
            var2_14 /* !! */  = (byte[])this;
            var2_14 /* !! */ .form.dispatchPermissionDeniedEvent((Component)var2_14 /* !! */ , var5_1, (PermissionException)var1_10);
        }
    }

    private static Map<String, List<String>> processRequestHeaders(YailList yailList) throws InvalidRequestHeadersException {
        HashMap hashMap = Maps.newHashMap();
        for (int i = 0; i < yailList.size(); ++i) {
            Object object2 = yailList.getObject(i);
            if (object2 instanceof YailList) {
                ArrayList arrayList = (ArrayList)object2;
                if (arrayList.size() == 2) {
                    object2 = arrayList.getObject(0).toString();
                    Object object3 = arrayList.getObject(1);
                    arrayList = Lists.newArrayList();
                    if (object3 instanceof YailList) {
                        object3 = (YailList)object3;
                        for (int j = 0; j < object3.size(); ++j) {
                            arrayList.add((Object)object3.getObject(j).toString());
                        }
                    } else {
                        arrayList.add((Object)object3.toString());
                    }
                    hashMap.put(object2, arrayList);
                    continue;
                }
                throw new Exception(1111, i + 1){
                    final int errorNumber;
                    final int index;
                    {
                        this.errorNumber = n;
                        this.index = n2;
                    }
                };
            }
            throw new /* invalid duplicate definition of identical inner class */;
        }
        return hashMap;
    }

    private void processResponseCookies(HttpURLConnection httpURLConnection) {
        if (this.allowCookies && this.cookieHandler != null) {
            try {
                Map map = httpURLConnection.getHeaderFields();
                this.cookieHandler.put(httpURLConnection.getURL().toURI(), map);
            }
            catch (IOException iOException) {
            }
            catch (URISyntaxException uRISyntaxException) {
                // empty catch block
            }
        }
    }

    private void requestTextImpl(String string, String string2, String string3, String string4) {
        CapturedProperties capturedProperties = super.capturePropertyValues(string3);
        if (capturedProperties == null) {
            return;
        }
        string = new FutureTask(new Runnable((Web)this, string2, string, string3, capturedProperties, string4){
            final Web this$0;
            final String val$encoding;
            final String val$functionName;
            final String val$httpVerb;
            final String val$text;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$encoding = string;
                this.val$text = string2;
                this.val$functionName = string3;
                this.val$webProps = capturedProperties;
                this.val$httpVerb = string4;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                Object object2;
                try {
                    object2 = this.val$encoding;
                    object2 = object2 != null && object2.length() != 0 ? (Object)this.val$text.getBytes(this.val$encoding) : (Object)this.val$text.getBytes("UTF-8");
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, this.val$functionName, 1102, this.val$encoding);
                    return;
                }
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, (byte[])object2, null, this.val$httpVerb, this.val$functionName);
            }
        }, null);
        this.lastTask = string;
        AsynchUtil.runAsynchronously((Runnable)string);
    }

    /*
     * Loose catch block
     */
    private String saveResponseContent(HttpURLConnection httpURLConnection, String string, String string2) throws IOException {
        int n;
        if (!(string2 = (string = super.createFile(string, string2)).getParentFile()).exists() && !string2.mkdirs()) {
            throw new DispatchableError(2108, string2.getAbsolutePath());
        }
        httpURLConnection = new BufferedInputStream(Web.getConnectionStream(httpURLConnection), 4096);
        FileOutputStream fileOutputStream = new FileOutputStream((File)string);
        string2 = new BufferedOutputStream((OutputStream)fileOutputStream, 4096);
        while (true) {
            n = httpURLConnection.read();
            if (n != -1) break block10;
            break;
        }
        catch (Throwable throwable) {
            try {
                string2.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                httpURLConnection.close();
                throw throwable2;
            }
        }
        {
            block10: {
                string2.flush();
                string2.close();
                httpURLConnection.close();
                return string.getAbsolutePath();
            }
            string2.write(n);
            continue;
        }
    }

    private void updateColumns(String string, String string2) {
        if (string2.contains((CharSequence)"json")) {
            try {
                this.columns = JsonUtil.getColumnsFromJson((String)string);
            }
            catch (org.json.JSONException jSONException) {}
        } else if (string2.contains((CharSequence)"csv") || string2.startsWith("text/")) {
            try {
                string = CsvUtil.fromCsvTable((String)string);
                this.columns = string;
                this.columns = ChartDataSourceUtil.getTranspose((YailList)string);
            }
            catch (Exception exception) {
                this.columns = new YailList();
            }
        }
    }

    private static void writeRequestData(HttpURLConnection httpURLConnection, byte[] byArray) throws IOException {
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setFixedLengthStreamingMode(byArray.length);
        httpURLConnection = new BufferedOutputStream(httpURLConnection.getOutputStream());
        try {
            httpURLConnection.write(byArray, 0, byArray.length);
            httpURLConnection.flush();
            return;
        }
        finally {
            httpURLConnection.close();
        }
    }

    /*
     * Loose catch block
     */
    private void writeRequestFile(HttpURLConnection httpURLConnection, String string) throws IOException {
        int n;
        string = new BufferedInputStream(MediaUtil.openMedia((Form)this.form, (String)string));
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setChunkedStreamingMode(0);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
        while (true) {
            n = string.read();
            if (n != -1) break block9;
            break;
        }
        catch (Throwable throwable) {
            try {
                bufferedOutputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                string.close();
                throw throwable2;
            }
        }
        {
            block9: {
                bufferedOutputStream.flush();
                bufferedOutputStream.close();
                string.close();
                return;
            }
            bufferedOutputStream.write(n);
            continue;
        }
    }

    @DesignerProperty(defaultValue="false", editorType="boolean")
    @SimpleProperty
    public void AllowCookies(boolean bl) {
        this.allowCookies = bl;
        if (bl && this.cookieHandler == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "AllowCookies", 4, new Object[0]);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the cookies from a response should be saved and used in subsequent requests. Cookies are only supported on Android version 2.3 or greater.")
    public boolean AllowCookies() {
        return this.allowCookies;
    }

    @SimpleFunction
    public String BuildRequestData(YailList object2) {
        try {
            object2 = this.buildRequestData((YailList)object2);
            return object2;
        }
        catch (BuildRequestDataException buildRequestDataException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "BuildRequestData", buildRequestDataException.errorNumber, buildRequestDataException.index);
            return "";
        }
    }

    @SimpleFunction(description="Clears all cookies for this Web component.")
    public void ClearCookies() {
        CookieHandler cookieHandler = this.cookieHandler;
        if (cookieHandler != null) {
            GingerbreadUtil.clearCookies((CookieHandler)cookieHandler);
        } else {
            this.form.dispatchErrorOccurredEvent(this, "ClearCookies", 4, new Object[0]);
        }
    }

    @SimpleFunction
    public void Delete() {
        CapturedProperties capturedProperties = this.capturePropertyValues("Delete");
        if (capturedProperties == null) {
            return;
        }
        capturedProperties = new FutureTask(new Runnable(this, capturedProperties){
            final Web this$0;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$webProps = capturedProperties;
            }

            public void run() {
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, null, null, "DELETE", "Delete");
            }
        }, null);
        this.lastTask = capturedProperties;
        AsynchUtil.runAsynchronously((Runnable)capturedProperties);
    }

    @SimpleFunction
    public void Get() {
        CapturedProperties capturedProperties = this.capturePropertyValues("Get");
        if (capturedProperties == null) {
            return;
        }
        capturedProperties = new FutureTask(new Runnable(this, capturedProperties){
            final Web this$0;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$webProps = capturedProperties;
            }

            public void run() {
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, null, null, "GET", "Get");
            }
        }, null);
        this.lastTask = capturedProperties;
        AsynchUtil.runAsynchronously((Runnable)capturedProperties);
    }

    @SimpleEvent
    public void GotFile(String string, int n, String string2, String string3) {
        EventDispatcher.dispatchEvent((Component)this, "GotFile", string, n, string2, string3);
    }

    @SimpleEvent
    public void GotText(String string, int n, String string2, String string3) {
        EventDispatcher.dispatchEvent((Component)this, "GotText", string, n, string2, string3);
    }

    @SimpleFunction(description="Decodes the given HTML text value. HTML character entities such as `&`, `<`, `>`, `'`, and `\"` are changed to &, <, >, ', and \". Entities such as &#xhhhh, and &#nnnn are changed to the appropriate characters.")
    public String HtmlTextDecode(String string) {
        try {
            String string2 = HtmlEntities.decodeHtmlText(string);
            return string2;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "HtmlTextDecode", 1106, string);
            return "";
        }
    }

    @SimpleFunction
    public String JsonObjectEncode(Object object2) {
        try {
            String string = JsonUtil.encodeJsonObject((Object)object2);
            return string;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "JsonObjectEncode", 1118, object2);
            return "";
        }
    }

    @SimpleFunction
    public Object JsonTextDecode(String string) {
        try {
            Object object2 = Web.decodeJsonText(string, false);
            return object2;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "JsonTextDecode", 1105, string);
            return "";
        }
    }

    @SimpleFunction
    public Object JsonTextDecodeWithDictionaries(String string) {
        try {
            Object object2 = Web.decodeJsonText(string, true);
            return object2;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "JsonTextDecodeWithDictionaries", 1105, string);
            return "";
        }
    }

    @SimpleFunction(description="Performs an HTTP PATCH request using the Url property and data from the specified file.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PatchFile(String string) {
        CapturedProperties capturedProperties = super.capturePropertyValues("PatchFile");
        if (capturedProperties == null) {
            return;
        }
        AsynchUtil.runAsynchronously((Runnable)new Runnable((Web)this, capturedProperties, string){
            final Web this$0;
            final String val$path;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$webProps = capturedProperties;
                this.val$path = string;
            }

            public void run() {
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, null, this.val$path, "PATCH", "PatchFile");
            }
        });
    }

    @SimpleFunction(description="Performs an HTTP PATCH request using the Url property and the specified text.<br>The characters of the text are encoded using UTF-8 encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The responseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PatchText(String string) {
        super.requestTextImpl(string, "UTF-8", "PatchText", "PATCH");
    }

    @SimpleFunction(description="Performs an HTTP PATCH request using the Url property and the specified text.<br>The characters of the text are encoded using the given encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PatchTextWithEncoding(String string, String string2) {
        super.requestTextImpl(string, string2, "PatchTextWithEncoding", "PATCH");
    }

    @SimpleFunction(description="Performs an HTTP POST request using the Url property and data from the specified file.\nIf the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.\nIf the SaveResponse property is false, the GotText event will be triggered.")
    public void PostFile(String string) {
        CapturedProperties capturedProperties = super.capturePropertyValues("PostFile");
        if (capturedProperties == null) {
            return;
        }
        string = new FutureTask(new Runnable((Web)this, capturedProperties, string){
            final Web this$0;
            final String val$path;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$webProps = capturedProperties;
                this.val$path = string;
            }

            public void run() {
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, null, this.val$path, "POST", "PostFile");
            }
        }, null);
        this.lastTask = string;
        AsynchUtil.runAsynchronously((Runnable)string);
    }

    @SimpleFunction(description="Performs an HTTP POST request using the Url property and the specified text.\nThe characters of the text are encoded using UTF-8 encoding.\nIf the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The responseFileName property can be used to specify the name of the file.\nIf the SaveResponse property is false, the GotText event will be triggered.")
    public void PostText(String string) {
        super.requestTextImpl(string, "UTF-8", "PostText", "POST");
    }

    @SimpleFunction(description="Performs an HTTP POST request using the Url property and the specified text.\nThe characters of the text are encoded using the given encoding.\nIf the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.\nIf the SaveResponse property is false, the GotText event will be triggered.")
    public void PostTextWithEncoding(String string, String string2) {
        super.requestTextImpl(string, string2, "PostTextWithEncoding", "POST");
    }

    @SimpleFunction(description="Performs an HTTP PUT request using the Url property and data from the specified file.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutFile(String string) {
        CapturedProperties capturedProperties = super.capturePropertyValues("PutFile");
        if (capturedProperties == null) {
            return;
        }
        string = new FutureTask(new Runnable((Web)this, capturedProperties, string){
            final Web this$0;
            final String val$path;
            final CapturedProperties val$webProps;
            {
                this.this$0 = web;
                this.val$webProps = capturedProperties;
                this.val$path = string;
            }

            public void run() {
                Web.-$$Nest$mperformRequest(this.this$0, this.val$webProps, null, this.val$path, "PUT", "PutFile");
            }
        }, null);
        this.lastTask = string;
        AsynchUtil.runAsynchronously((Runnable)string);
    }

    @SimpleFunction(description="Performs an HTTP PUT request using the Url property and the specified text.<br>The characters of the text are encoded using UTF-8 encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The responseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutText(String string) {
        super.requestTextImpl(string, "UTF-8", "PutText", "PUT");
    }

    @SimpleFunction(description="Performs an HTTP PUT request using the Url property and the specified text.<br>The characters of the text are encoded using the given encoding.<br>If the SaveResponse property is true, the response will be saved in a file and the GotFile event will be triggered. The ResponseFileName property can be used to specify the name of the file.<br>If the SaveResponse property is false, the GotText event will be triggered.")
    public void PutTextWithEncoding(String string, String string2) {
        super.requestTextImpl(string, string2, "PutTextWithEncoding", "PUT");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The request headers, as a list of two-element sublists. The first element of each sublist represents the request header field name. The second element of each sublist represents the request header field values, either a single value or a list containing multiple values.")
    public YailList RequestHeaders() {
        return this.requestHeaders;
    }

    @SimpleProperty
    public void RequestHeaders(YailList yailList) {
        try {
            Web.processRequestHeaders(yailList);
            this.requestHeaders = yailList;
        }
        catch (InvalidRequestHeadersException invalidRequestHeadersException) {
            this.form.dispatchErrorOccurredEvent((Component)this, "RequestHeaders", invalidRequestHeadersException.errorNumber, invalidRequestHeadersException.index);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The name of the file where the response should be saved. If SaveResponse is true and ResponseFileName is empty, then a new file name will be generated.")
    public String ResponseFileName() {
        return this.responseFileName;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty
    public void ResponseFileName(String string) {
        this.responseFileName = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="User-specified character encoding for web response.")
    public String ResponseTextEncoding() {
        return this.responseTextEncoding;
    }

    @DesignerProperty(defaultValue="UTF-8", editorType="string")
    @SimpleProperty
    public void ResponseTextEncoding(String string) {
        this.responseTextEncoding = string;
    }

    @DesignerProperty(defaultValue="false", editorType="boolean")
    @SimpleProperty
    public void SaveResponse(boolean bl) {
        this.saveResponse = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the response should be saved in a file.")
    public boolean SaveResponse() {
        return this.saveResponse;
    }

    @SimpleEvent
    public void TimedOut(String string) {
        EventDispatcher.dispatchEvent((Component)this, "TimedOut", string);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The number of milliseconds that a web request will wait for a response before giving up. If set to 0, then there is no time limit on how long the request will wait.")
    public int Timeout() {
        return this.timeout;
    }

    @DesignerProperty(defaultValue="0", editorType="non_negative_integer")
    @SimpleProperty
    public void Timeout(int n) {
        if (n >= 0) {
            this.timeout = n;
            return;
        }
        throw new IllegalArgumentError("Web Timeout must be a non-negative integer.");
    }

    @SimpleFunction
    public String UriDecode(String string) {
        try {
            string = URLDecoder.decode((String)string, (String)"UTF-8");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            Log.e((String)LOG_TAG, (String)"UTF-8 is unsupported?", (Throwable)unsupportedEncodingException);
            return "";
        }
    }

    @SimpleFunction
    public String UriEncode(String string) {
        try {
            string = URLEncoder.encode((String)string, (String)"UTF-8");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            Log.e((String)LOG_TAG, (String)"UTF-8 is unsupported?", (Throwable)unsupportedEncodingException);
            return "";
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The URL for the web request.")
    public String Url() {
        return this.urlString;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty
    public void Url(String string) {
        this.urlString = string;
    }

    @SimpleFunction(description="Decodes the given XML string to produce a dictionary structure. See the App Inventor documentation on \"Other topics, notes, and details\" for information.")
    public Object XMLTextDecode(String object2) {
        try {
            object2 = this.JsonTextDecode(XML.toJSONObject((String)object2).toString());
            return object2;
        }
        catch (JSONException jSONException) {
            Log.e((String)LOG_TAG, (String)jSONException.getMessage());
            this.form.dispatchErrorOccurredEvent((Component)this, "XMLTextDecode", 1105, jSONException.getMessage());
            return YailList.makeEmptyList();
        }
    }

    @SimpleFunction(description="Decodes the given XML into a set of nested dictionaries that capture the structure and data contained in the XML. See the help for more details.")
    public Object XMLTextDecodeAsDictionary(String object2) {
        try {
            XmlParser xmlParser = new XmlParser();
            SAXParser sAXParser = SAXParserFactory.newInstance().newSAXParser();
            StringReader stringReader = new StringReader(object2);
            InputSource inputSource = new InputSource((Reader)stringReader);
            inputSource.setEncoding("UTF-8");
            sAXParser.parse(inputSource, (DefaultHandler)xmlParser);
            object2 = xmlParser.getRoot();
            return object2;
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)exception.getMessage());
            this.form.dispatchErrorOccurredEvent((Component)this, "XMLTextDecodeAsDictionary", 1105, exception.getMessage());
            return new YailDictionary();
        }
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    String buildRequestData(YailList yailList) throws BuildRequestDataException {
        StringBuilder stringBuilder = new StringBuilder();
        String string = "";
        for (int i = 0; i < yailList.size(); ++i) {
            Object object2 = yailList.getObject(i);
            if (object2 instanceof YailList) {
                Object object3 = (YailList)object2;
                if (object3.size() == 2) {
                    object2 = object3.getObject(0).toString();
                    object3 = object3.getObject(1).toString();
                    stringBuilder.append(string).append(this.UriEncode((String)object2)).append('=').append(this.UriEncode((String)object3));
                    string = "&";
                    continue;
                }
                throw new Exception(1113, i + 1){
                    final int errorNumber;
                    final int index;
                    {
                        this.errorNumber = n;
                        this.index = n2;
                    }
                };
            }
            throw new /* invalid duplicate definition of identical inner class */;
        }
        return stringBuilder.toString();
    }

    public YailList getColumn(String string) {
        for (int i = 0; i < this.columns.size(); ++i) {
            YailList yailList = (YailList)this.columns.getObject(i);
            if (yailList.isEmpty() || !yailList.getString(0).equals((Object)string)) continue;
            return yailList;
        }
        return new YailList();
    }

    public YailList getColumns(YailList yailList) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < yailList.size(); ++i) {
            arrayList.add((Object)this.getColumn(yailList.getString(i)));
        }
        return YailList.makeList((List)arrayList);
    }

    public Future<YailList> getDataValue(YailList yailList) {
        yailList = new FutureTask((Callable)new Callable<YailList>((Web)this, this.lastTask, yailList){
            final Web this$0;
            final FutureTask val$currentTask;
            final YailList val$key;
            {
                this.this$0 = web;
                this.val$currentTask = futureTask;
                this.val$key = yailList;
            }

            public YailList call() throws Exception {
                FutureTask futureTask = this.val$currentTask;
                if (futureTask != null && !futureTask.isDone() && !this.val$currentTask.isCancelled()) {
                    try {
                        this.val$currentTask.get();
                    }
                    catch (ExecutionException executionException) {
                        executionException.printStackTrace();
                    }
                    catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                }
                return this.this$0.getColumns(this.val$key);
            }
        });
        AsynchUtil.runAsynchronously((Runnable)yailList);
        return yailList;
    }

    public void notifyDataObservers(YailList yailList, Object object2) {
        yailList = this.dataSourceObservers.iterator();
        while (yailList.hasNext()) {
            ((DataSourceChangeListener)yailList.next()).onDataSourceValueChange((DataSource<?, ?>)this, null, this.columns);
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }
}

