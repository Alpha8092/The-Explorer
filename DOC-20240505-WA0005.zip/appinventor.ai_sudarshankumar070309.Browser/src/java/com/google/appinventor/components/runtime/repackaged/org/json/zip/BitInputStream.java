/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader;
import java.io.IOException;
import java.io.InputStream;

public class BitInputStream
implements BitReader {
    static final int[] mask = new int[]{0, 1, 3, 7, 15, 31, 63, 127, 255};
    private int available = 0;
    private InputStream in;
    private long nrBits = 0L;
    private int unread = 0;

    public BitInputStream(InputStream inputStream) {
        this.in = inputStream;
    }

    public BitInputStream(InputStream inputStream, int n) {
        this.in = inputStream;
        this.unread = n;
        this.available = 8;
    }

    public boolean bit() throws IOException {
        boolean bl = true;
        if (this.read(1) == 0) {
            bl = false;
        }
        return bl;
    }

    public long nrBits() {
        return this.nrBits;
    }

    public boolean pad(int n) throws IOException {
        int n2 = (int)(this.nrBits % (long)n);
        boolean bl = true;
        for (int i = 0; i < n - n2; ++i) {
            if (!this.bit()) continue;
            bl = false;
        }
        return bl;
    }

    public int read(int n) throws IOException {
        if (n == 0) {
            return 0;
        }
        if (n >= 0 && n <= 32) {
            int n2 = 0;
            while (n > 0) {
                int n3;
                if (this.available == 0) {
                    this.unread = n3 = this.in.read();
                    if (n3 >= 0) {
                        this.available = 8;
                    } else {
                        throw new IOException("Attempt to read past end.");
                    }
                }
                int n4 = n;
                int n5 = this.available;
                n3 = n4;
                if (n4 > n5) {
                    n3 = this.available;
                }
                n2 |= (this.unread >>> n5 - n3 & mask[n3]) << n - n3;
                this.nrBits += (long)n3;
                this.available = n5 - n3;
                n -= n3;
            }
            return n2;
        }
        IOException iOException = new IOException("Bad read width.");
        throw iOException;
    }
}

