/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.BlendMode
 *  android.graphics.BlendModeColorFilter
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.widget.ProgressBar
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.widget.ProgressBar;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;

@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="A visible component that indicates the progress of an operation using an animated linear bar.", iconName="images/linearProgress.png", version=1)
@SimpleObject
public final class LinearProgress
extends AndroidViewComponent {
    private static final String LOG_TAG = "LinearProgress";
    private Context context;
    private int indeterminateColor = -16776961;
    private ProgressBar progressBar;
    private int progressColor = -16776961;

    public LinearProgress(ComponentContainer componentContainer) {
        super(componentContainer);
        this.context = componentContainer.$context();
        this.progressBar = new ProgressBar(this.context, null, 16842872);
        componentContainer.$add((AndroidViewComponent)this);
        this.Minimum(0);
        this.Maximum(100);
        this.ProgressColor(-16776961);
        this.IndeterminateColor(-16776961);
        this.Indeterminate(true);
        this.Width(-2);
        Log.d((String)LOG_TAG, (String)"Linear Progress created");
    }

    public int Height() {
        return this.getView().getHeight();
    }

    public void Height(int n) {
        this.container.setChildHeight((AndroidViewComponent)this, n);
    }

    public void HeightPercent(int n) {
    }

    @SimpleFunction(description="Increase the progress bar's progress by the specified amount.")
    public void IncrementProgressBy(int n) {
        this.progressBar.incrementProgressBy(n);
        this.ProgressChanged(this.progressBar.getProgress());
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Change the indeterminate mode for this progress bar. In indeterminate mode, the progress is ignored and the progress bar shows an infinite animation instead.")
    public void Indeterminate(boolean bl) {
        this.progressBar.setIndeterminate(bl);
        Log.i((String)LOG_TAG, (String)("Indeterminate is: " + bl));
    }

    @SimpleProperty(description="Indicate whether this progress bar is in indeterminate mode.")
    public boolean Indeterminate() {
        return this.progressBar.isIndeterminate();
    }

    @SimpleProperty
    public int IndeterminateColor() {
        return this.indeterminateColor;
    }

    @DesignerProperty(defaultValue="&HFF0000FF", editorType="color")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Change the indeterminate color of the progress bar.")
    public void IndeterminateColor(int n) {
        this.indeterminateColor = n;
        Drawable drawable = this.progressBar.getProgressDrawable();
        if (Build.VERSION.SDK_INT >= 29) {
            drawable.setColorFilter((ColorFilter)new BlendModeColorFilter(n, BlendMode.SRC_IN));
        } else {
            drawable.setColorFilter(n, PorterDuff.Mode.SRC_IN);
        }
        Log.i((String)LOG_TAG, (String)("Indeterminate Color = " + n));
    }

    @SimpleProperty
    public int Maximum() {
        return this.progressBar.getMax();
    }

    @DesignerProperty(defaultValue="100", editorType="integer")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Set the upper range of the progress bar max.")
    public void Maximum(int n) {
        this.progressBar.setMax(n);
        Log.i((String)LOG_TAG, (String)("setMax = " + n));
    }

    @SimpleProperty
    public int Minimum() {
        int n = Build.VERSION.SDK_INT >= 26 ? this.progressBar.getMin() : 0;
        return n;
    }

    @DesignerProperty(defaultValue="0", editorType="integer")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Set the lower range of the progress bar to min. This function works only for devices with API >= 26")
    public void Minimum(int n) {
        if (Build.VERSION.SDK_INT >= 26) {
            this.progressBar.setMin(n);
            Log.i((String)LOG_TAG, (String)("setMin = " + n));
        } else {
            n = Build.VERSION.SDK_INT;
            Log.i((String)LOG_TAG, (String)("setMin of progress bar is not possible. API is " + n));
        }
    }

    @SimpleProperty(description="Get the progress bar's current level of progress.")
    public int Progress() {
        return this.progressBar.getProgress();
    }

    @SimpleProperty(description="Sets the current progress to the specified value. Does not do anything if the progress bar is in indeterminate mode.")
    public void Progress(int n) {
        if (Build.VERSION.SDK_INT >= 24) {
            this.progressBar.setProgress(n, true);
        } else {
            this.progressBar.setProgress(n);
        }
        this.ProgressChanged(this.progressBar.getProgress());
    }

    @SimpleEvent(description="Event that indicates that the progress of the progress bar has been changed. Returns the current progress value. If \"Indeterminate\" is set to true, then it returns \"0\".")
    public void ProgressChanged(int n) {
        EventDispatcher.dispatchEvent((Component)this, "ProgressChanged", n);
    }

    @SimpleProperty
    public int ProgressColor() {
        return this.progressColor;
    }

    @DesignerProperty(defaultValue="&HFF0000FF", editorType="color")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Change the progress color of the progress bar.")
    public void ProgressColor(int n) {
        this.progressColor = n;
        Drawable drawable = this.progressBar.getProgressDrawable();
        if (Build.VERSION.SDK_INT >= 29) {
            drawable.setColorFilter((ColorFilter)new BlendModeColorFilter(n, BlendMode.SRC_IN));
        } else {
            drawable.setColorFilter(n, PorterDuff.Mode.SRC_IN);
        }
        Log.i((String)LOG_TAG, (String)("Progress Color = " + n));
    }

    public ProgressBar getView() {
        return this.progressBar;
    }
}

