/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.AsyncTask
 *  android.os.Handler
 *  android.os.Looper
 *  android.view.View
 *  com.github.mikephil.charting.charts.Chart
 *  com.github.mikephil.charting.components.Legend$LegendHorizontalAlignment
 *  com.github.mikephil.charting.data.ChartData
 *  com.github.mikephil.charting.data.DataSet
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.interfaces.datasets.IDataSet
 *  com.google.appinventor.components.runtime.Chart
 *  com.google.appinventor.components.runtime.ChartDataModel
 *  com.google.appinventor.components.runtime.Form
 *  java.lang.Object
 *  java.lang.SafeVarargs
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.google.appinventor.components.runtime.Chart;
import com.google.appinventor.components.runtime.ChartDataModel;
import com.google.appinventor.components.runtime.Form;
import java.util.ArrayList;
import java.util.List;

public abstract class ChartView<E extends Entry, T extends IDataSet<E>, D extends ChartData<T>, C extends com.github.mikephil.charting.charts.Chart<D>, V extends ChartView<E, T, D, C, V>> {
    protected C chart;
    protected Chart chartComponent;
    protected D data;
    protected Form form;
    protected Handler uiHandler = new Handler(Looper.myLooper());

    protected ChartView(Chart chart) {
        this.chartComponent = chart;
        this.form = chart.$form();
    }

    public abstract ChartDataModel<E, T, D, C, V> createChartModel();

    public Form getForm() {
        return this.form;
    }

    public abstract View getView();

    protected void initializeDefaultSettings() {
        this.chart.getLegend().setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        this.chart.getLegend().setWordWrapEnabled(true);
    }

    public void refresh() {
        this.chart.notifyDataSetChanged();
        this.chart.invalidate();
    }

    public void refresh(ChartDataModel<E, T, D, C, V> chartDataModel) {
        new RefreshTask((ChartView)this, chartDataModel.getEntries()).execute(new ChartDataModel[]{chartDataModel});
    }

    protected void refresh(ChartDataModel<E, T, D, C, V> iDataSet, List<E> list) {
        if ((iDataSet = iDataSet.getDataset()) instanceof DataSet) {
            ((DataSet)iDataSet).setValues(list);
        }
        this.chart.getData().notifyDataChanged();
        this.chart.notifyDataSetChanged();
        this.chart.invalidate();
    }

    public void setBackgroundColor(int n) {
        this.chart.setBackgroundColor(n);
    }

    public void setDescription(String string) {
        this.chart.getDescription().setText(string);
    }

    public void setLegendEnabled(boolean bl) {
        this.chart.getLegend().setEnabled(bl);
    }

    private class RefreshTask
    extends AsyncTask<ChartDataModel<E, T, D, C, V>, Void, ChartDataModel<E, T, D, C, V>> {
        private final List<E> entries;
        final ChartView this$0;

        public RefreshTask(ChartView chartView, List<E> list) {
            this.this$0 = chartView;
            this.entries = new ArrayList(list);
        }

        @SafeVarargs
        protected final ChartDataModel<E, T, D, C, V> doInBackground(ChartDataModel<E, T, D, C, V> ... chartDataModelArray) {
            return chartDataModelArray[0];
        }

        protected void onPostExecute(ChartDataModel<E, T, D, C, V> chartDataModel) {
            this.this$0.refresh(chartDataModel, this.entries);
        }
    }
}

