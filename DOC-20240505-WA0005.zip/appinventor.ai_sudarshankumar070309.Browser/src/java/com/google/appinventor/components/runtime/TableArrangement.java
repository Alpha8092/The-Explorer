/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.View
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.TableLayout
 *  com.google.appinventor.components.runtime.util.ViewUtil
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.TableLayout;
import com.google.appinventor.components.runtime.util.ViewUtil;
import java.util.ArrayList;
import java.util.List;

@DesignerComponent(category=ComponentCategory.LAYOUT, description="<p>A formatting element in which to place components that should be displayed in tabular form.</p>", iconName="images/table.png", version=1)
@SimpleObject
public class TableArrangement
extends AndroidViewComponent
implements Component,
ComponentContainer {
    private List<Component> allChildren = new ArrayList();
    private final Activity context;
    private final TableLayout viewLayout;

    public TableArrangement(ComponentContainer componentContainer) {
        super(componentContainer);
        Activity activity;
        this.context = activity = componentContainer.$context();
        this.viewLayout = new TableLayout((Context)activity, 2, 2);
        componentContainer.$add((AndroidViewComponent)this);
    }

    @Override
    public void $add(AndroidViewComponent androidViewComponent) {
        this.viewLayout.add(androidViewComponent);
        this.allChildren.add((Object)androidViewComponent);
    }

    @Override
    public Activity $context() {
        return this.context;
    }

    @Override
    public Form $form() {
        return this.container.$form();
    }

    @SimpleProperty(userVisible=false)
    public int Columns() {
        return this.viewLayout.getNumColumns();
    }

    @DesignerProperty(defaultValue="2", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public void Columns(int n) {
        this.viewLayout.setNumColumns(n);
    }

    @SimpleProperty(userVisible=false)
    public int Rows() {
        return this.viewLayout.getNumRows();
    }

    @DesignerProperty(defaultValue="2", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public void Rows(int n) {
        this.viewLayout.setNumRows(n);
    }

    @Override
    public List<? extends Component> getChildren() {
        return this.allChildren;
    }

    public View getView() {
        return this.viewLayout.getLayoutManager();
    }

    @Override
    public void setChildHeight(AndroidViewComponent androidViewComponent, int n) {
        int n2 = n;
        if (n <= -1000) {
            n2 = this.container.$form().Height();
            n2 = n2 > -1000 && n2 <= 0 ? -1 : -(n + 1000) * n2 / 100;
        }
        androidViewComponent.setLastHeight(n2);
        ViewUtil.setChildHeightForTableLayout((View)androidViewComponent.getView(), (int)n2);
    }

    @Override
    public void setChildWidth(AndroidViewComponent androidViewComponent, int n) {
        System.err.println("TableArrangment.setChildWidth: width = " + n + " component = " + androidViewComponent);
        int n2 = n;
        if (n <= -1000) {
            n2 = this.container.$form().Width();
            if (n2 > -1000 && n2 <= 0) {
                n2 = -1;
            } else {
                System.err.println("%%TableArrangement.setChildWidth(): width = " + n + " parent Width = " + n2 + " child = " + androidViewComponent);
                n2 = -(n + 1000) * n2 / 100;
            }
        }
        androidViewComponent.setLastWidth(n2);
        ViewUtil.setChildWidthForTableLayout((View)androidViewComponent.getView(), (int)n2);
    }
}

