/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.Kim
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader
 *  java.io.UnsupportedEncodingException
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONArray;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.Kim;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitReader;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.Keep;
import java.io.UnsupportedEncodingException;

public class Decompressor
extends JSONzip {
    BitReader bitreader;

    public Decompressor(BitReader bitReader) {
        this.bitreader = bitReader;
    }

    private boolean bit() throws JSONException {
        try {
            boolean bl = this.bitreader.bit();
            return bl;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
    }

    private Object getAndTick(Keep object2, BitReader object3) throws JSONException {
        block3: {
            try {
                int n = object3.read(object2.bitsize());
                object3 = object2.value(n);
                if (n >= object2.length) break block3;
                object2.tick(n);
                return object3;
            }
            catch (Throwable throwable) {
                throw new JSONException(throwable);
            }
        }
        object2 = new JSONException("Deep error.");
        throw object2;
    }

    private int read(int n) throws JSONException {
        try {
            n = this.bitreader.read(n);
            return n;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
    }

    private JSONArray readArray(boolean bl) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        Object object2 = bl ? super.readString() : super.readValue();
        jSONArray.put(object2);
        while (true) {
            if (!super.bit()) {
                if (!super.bit()) {
                    return jSONArray;
                }
                object2 = bl ? super.readValue() : super.readString();
                jSONArray.put(object2);
                continue;
            }
            object2 = bl ? super.readString() : super.readValue();
            jSONArray.put(object2);
        }
    }

    private Object readJSON() throws JSONException {
        switch (this.read(3)) {
            default: {
                return JSONObject.NULL;
            }
            case 7: {
                return this.readArray(false);
            }
            case 6: {
                return this.readArray(true);
            }
            case 5: {
                return this.readObject();
            }
            case 3: {
                return Boolean.FALSE;
            }
            case 2: {
                return Boolean.TRUE;
            }
            case 1: {
                return new JSONArray();
            }
            case 0: 
        }
        return new JSONObject();
    }

    private String readName() throws JSONException {
        Object object2 = new byte[65536];
        int n = 0;
        if (!this.bit()) {
            while (true) {
                int n2;
                if ((n2 = this.namehuff.read(this.bitreader)) == 256) {
                    if (n == 0) {
                        return "";
                    }
                    object2 = new Kim(object2, n);
                    this.namekeep.register(object2);
                    return object2.toString();
                }
                object2[n] = (byte)n2;
                ++n;
            }
        }
        return this.getAndTick(this.namekeep, this.bitreader).toString();
    }

    private JSONObject readObject() throws JSONException {
        JSONObject jSONObject = new JSONObject();
        do {
            String string = this.readName();
            Object object2 = !this.bit() ? this.readString() : this.readValue();
            jSONObject.put(string, object2);
        } while (this.bit());
        return jSONObject;
    }

    private String readString() throws JSONException {
        int n = 0;
        int n2 = -1;
        int n3 = 0;
        if (this.bit()) {
            return this.getAndTick(this.stringkeep, this.bitreader).toString();
        }
        Object object2 = new byte[65536];
        boolean bl = this.bit();
        this.substringkeep.reserve();
        block0: while (true) {
            int n4;
            if (bl) {
                n4 = ((Kim)this.getAndTick(this.substringkeep, this.bitreader)).copy(object2, n);
                if (n2 != -1) {
                    this.substringkeep.registerOne(new Kim(object2, n2, n3 + 1));
                }
                n2 = n;
                n3 = n4;
                bl = this.bit();
                n = n4;
                continue;
            }
            while (true) {
                if ((n4 = this.substringhuff.read(this.bitreader)) == 256) {
                    if (!this.bit()) {
                        if (n == 0) {
                            return "";
                        }
                        object2 = new Kim(object2, n);
                        this.stringkeep.register(object2);
                        this.substringkeep.registerMany((Kim)object2);
                        return object2.toString();
                    }
                    bl = true;
                    continue block0;
                }
                object2[n] = (byte)n4;
                ++n;
                n4 = n2;
                if (n2 != -1) {
                    this.substringkeep.registerOne(new Kim(object2, n2, n3 + 1));
                    n4 = -1;
                }
                n2 = n4;
            }
            break;
        }
    }

    private Object readValue() throws JSONException {
        int n = this.read(2);
        int n2 = 4;
        switch (n) {
            default: {
                throw new JSONException("Impossible.");
            }
            case 3: {
                return this.readJSON();
            }
            case 2: {
                return this.getAndTick(this.values, this.bitreader);
            }
            case 1: {
                Object object2 = new byte[256];
                n2 = 0;
                while (true) {
                    if ((n = this.read(4)) == endOfNumber) {
                        try {
                            String string = new String(object2, 0, n2, "US-ASCII");
                            object2 = JSONObject.stringToValue((String)string);
                        }
                        catch (UnsupportedEncodingException unsupportedEncodingException) {
                            throw new JSONException(unsupportedEncodingException);
                        }
                        this.values.register(object2);
                        return object2;
                    }
                    object2[n2] = bcd[n];
                    ++n2;
                }
            }
            case 0: 
        }
        if (this.bit()) {
            n2 = !this.bit() ? 7 : 14;
        }
        return new Integer(this.read(n2));
    }

    public boolean pad(int n) throws JSONException {
        try {
            boolean bl = this.bitreader.pad(n);
            return bl;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
    }

    public Object unzip() throws JSONException {
        this.begin();
        return this.readJSON();
    }
}

