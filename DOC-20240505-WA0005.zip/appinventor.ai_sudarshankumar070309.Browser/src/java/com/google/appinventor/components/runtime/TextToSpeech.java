/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.TextToSpeech$1
 *  com.google.appinventor.components.runtime.util.ITextToSpeech
 *  com.google.appinventor.components.runtime.util.ITextToSpeech$TextToSpeechCallback
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Locale
 *  java.util.Map
 *  java.util.MissingResourceException
 */
package com.google.appinventor.components.runtime;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnClearListener;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.TextToSpeech;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.util.ExternalTextToSpeech;
import com.google.appinventor.components.runtime.util.ITextToSpeech;
import com.google.appinventor.components.runtime.util.InternalTextToSpeech;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="The TextToSpeech component speaks a given text aloud.  You can set the pitch and the rate of speech. <p>You can also set a language by supplying a language code.  This changes the pronunciation of words, not the actual language spoken.  For example, setting the language to French and speaking English text will sound like someone speaking English (en) with a French accent.</p> <p>You can also specify a country by supplying a country code. This can affect the pronunciation.  For example, British English (GBR) will sound different from US English (USA).  Not every country code will affect every language.</p> <p>The languages and countries available depend on the particular device, and can be listed with the AvailableLanguages and AvailableCountries properties.</p>", iconName="images/textToSpeech.png", nonVisible=true, version=6)
@SimpleObject
public class TextToSpeech
extends AndroidNonvisibleComponent
implements Component,
OnStopListener,
OnResumeListener,
OnDestroyListener,
OnClearListener {
    private static final String LOG_TAG = "TextToSpeech";
    private static final Map<String, Locale> iso3CountryToLocaleMap;
    private static final Map<String, Locale> iso3LanguageToLocaleMap;
    private YailList allCountries;
    private YailList allLanguages;
    private String country;
    private ArrayList<String> countryList;
    private boolean isTtsPrepared;
    private String iso2Country;
    private String iso2Language;
    private String language;
    private ArrayList<String> languageList;
    private float pitch = 1.0f;
    private boolean result = false;
    private float speechRate = 1.0f;
    private final ITextToSpeech tts;

    static /* bridge */ /* synthetic */ void -$$Nest$fputresult(TextToSpeech textToSpeech, boolean bl) {
        textToSpeech.result = bl;
    }

    static {
        iso3LanguageToLocaleMap = Maps.newHashMap();
        iso3CountryToLocaleMap = Maps.newHashMap();
        TextToSpeech.initLocaleMaps();
    }

    public TextToSpeech(ComponentContainer object2) {
        super(object2.$form());
        this.Language("");
        this.Country("");
        boolean bl = SdkLevel.getLevel() < 4;
        String string = bl ? "external" : "internal";
        Log.v((String)LOG_TAG, (String)("Using " + string + " TTS library."));
        string = new 1((TextToSpeech)this);
        object2 = bl ? new ExternalTextToSpeech((ComponentContainer)object2, (ITextToSpeech.TextToSpeechCallback)string) : new InternalTextToSpeech(object2.$context(), (ITextToSpeech.TextToSpeechCallback)string);
        this.tts = object2;
        this.form.registerForOnStop((OnStopListener)this);
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnDestroy((OnDestroyListener)this);
        this.form.setVolumeControlStream(3);
        this.isTtsPrepared = false;
        this.languageList = new ArrayList();
        this.countryList = new ArrayList();
        this.allLanguages = YailList.makeList(this.languageList);
        this.allCountries = YailList.makeList(this.countryList);
    }

    private void getLanguageAndCountryLists() {
        if (SdkLevel.getLevel() >= 4) {
            for (Object object2 : Locale.getAvailableLocales()) {
                if (this.tts.isLanguageAvailable(object2) == -2) continue;
                String string = object2.getLanguage();
                object2 = object2.getISO3Country();
                if (!string.equals((Object)"") && !this.languageList.contains((Object)string)) {
                    this.languageList.add((Object)string);
                }
                if (object2.equals((Object)"") || this.countryList.contains(object2)) continue;
                this.countryList.add(object2);
            }
            Collections.sort(this.languageList);
            Collections.sort(this.countryList);
            this.allLanguages = YailList.makeList(this.languageList);
            this.allCountries = YailList.makeList(this.countryList);
        }
    }

    private static void initLocaleMaps() {
        for (Locale locale : Locale.getAvailableLocales()) {
            String string;
            try {
                string = locale.getISO3Country();
                if (string.length() > 0) {
                    iso3CountryToLocaleMap.put((Object)string, (Object)locale);
                }
            }
            catch (MissingResourceException missingResourceException) {
                // empty catch block
            }
            try {
                string = locale.getISO3Language();
                if (string.length() <= 0) continue;
                iso3LanguageToLocaleMap.put((Object)string, (Object)locale);
            }
            catch (MissingResourceException missingResourceException) {
                // empty catch block
            }
        }
    }

    private static Locale iso3CountryToLocale(String string) {
        Locale locale;
        Map<String, Locale> map = iso3CountryToLocaleMap;
        Locale locale2 = locale = (Locale)map.get((Object)string);
        if (locale == null) {
            locale2 = (Locale)map.get((Object)string.toUpperCase(Locale.ENGLISH));
        }
        string = locale2 == null ? Locale.getDefault() : locale2;
        return string;
    }

    private static Locale iso3LanguageToLocale(String string) {
        Locale locale;
        block1: {
            Locale locale2;
            Map<String, Locale> map = iso3LanguageToLocaleMap;
            locale = locale2 = (Locale)map.get((Object)string);
            if (locale2 == null) {
                locale = (Locale)map.get((Object)string.toLowerCase(Locale.ENGLISH));
            }
            if (locale != null) break block1;
            locale = Locale.getDefault();
        }
        return locale;
    }

    @SimpleEvent(description="Event to raise after the message is spoken. The result will be true if the message is spoken successfully, otherwise it will be false.")
    public void AfterSpeaking(boolean bl) {
        EventDispatcher.dispatchEvent((Component)this, "AfterSpeaking", bl);
    }

    @SimpleProperty(description="List of the country codes available on this device for use with TextToSpeech.  Check the Android developer documentation under supported languages to find the meanings of these abbreviations.")
    public YailList AvailableCountries() {
        this.prepareLanguageAndCountryProperties();
        return this.allCountries;
    }

    @SimpleProperty(description="List of the languages available on this device for use with TextToSpeech.  Check the Android developer documentation under supported languages to find the meanings of these abbreviations.")
    public YailList AvailableLanguages() {
        this.prepareLanguageAndCountryProperties();
        return this.allLanguages;
    }

    @SimpleEvent
    public void BeforeSpeaking() {
        EventDispatcher.dispatchEvent(this, "BeforeSpeaking", new Object[0]);
    }

    @SimpleProperty
    public String Country() {
        return this.country;
    }

    @DesignerProperty(defaultValue="", editorType="countries")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Country code to use for speech generation.  This can affect the pronounciation.  For example, British English (GBR) will sound different from US English (USA).  Not every country code will affect every language.")
    public void Country(String string) {
        switch (string.length()) {
            default: {
                string = Locale.getDefault();
                this.country = string.getCountry();
                break;
            }
            case 3: {
                string = TextToSpeech.iso3CountryToLocale(string);
                this.country = string.getISO3Country();
                break;
            }
            case 2: {
                string = new Locale(string);
                this.country = string.getCountry();
            }
        }
        this.iso2Country = string.getCountry();
    }

    @SimpleProperty
    public String Language() {
        return this.language;
    }

    @DesignerProperty(defaultValue="", editorType="languages")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the language for TextToSpeech. This changes the way that words are pronounced, not the actual language that is spoken.  For example setting the language to and speaking English text with sound like someone speaking English with a French accent.")
    public void Language(String string) {
        switch (string.length()) {
            default: {
                string = Locale.getDefault();
                this.language = string.getLanguage();
                break;
            }
            case 3: {
                string = TextToSpeech.iso3LanguageToLocale(string);
                this.language = string.getISO3Language();
                break;
            }
            case 2: {
                string = new Locale(string);
                this.language = string.getLanguage();
            }
        }
        this.iso2Language = string.getLanguage();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns current value of Pitch")
    public float Pitch() {
        return this.pitch;
    }

    @DesignerProperty(defaultValue="1.0", editorType="float")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the Pitch for TextToSpeech The values should be between 0 and 2 where lower values lower the tone of synthesized voice and greater values raise it.")
    public void Pitch(float f) {
        if (!(f < 0.0f) && !(f > 2.0f)) {
            this.pitch = f;
            ITextToSpeech iTextToSpeech = this.tts;
            if (f == 0.0f) {
                f = 0.1f;
            }
            iTextToSpeech.setPitch(f);
            return;
        }
        Log.i((String)LOG_TAG, (String)("Pitch value should be between 0 and 2, but user specified: " + f));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public boolean Result() {
        return this.result;
    }

    @SimpleFunction
    public void Speak(String string) {
        this.BeforeSpeaking();
        Locale locale = new Locale(this.iso2Language, this.iso2Country);
        this.tts.speak(string, locale);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns current value of SpeechRate")
    public float SpeechRate() {
        return this.speechRate;
    }

    @DesignerProperty(defaultValue="1.0", editorType="float")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the SpeechRate for TextToSpeech. The values should be between 0 and 2 where lower values slow down the pitch and greater values accelerate it.")
    public void SpeechRate(float f) {
        if (!(f < 0.0f) && !(f > 2.0f)) {
            this.speechRate = f;
            ITextToSpeech iTextToSpeech = this.tts;
            if (f == 0.0f) {
                f = 0.1f;
            }
            iTextToSpeech.setSpeechRate(f);
            return;
        }
        Log.i((String)LOG_TAG, (String)("speechRate value should be between 0 and 2, but user specified: " + f));
    }

    @SimpleFunction
    public void Stop() {
        this.tts.stop();
        this.AfterSpeaking(false);
    }

    @Override
    public void onClear() {
        this.tts.onDestroy();
    }

    @Override
    public void onDestroy() {
        this.tts.onDestroy();
    }

    @Override
    public void onResume() {
        this.tts.onResume();
    }

    @Override
    public void onStop() {
        this.tts.onStop();
    }

    public void prepareLanguageAndCountryProperties() {
        if (!this.isTtsPrepared) {
            if (!this.tts.isInitialized()) {
                this.form.dispatchErrorOccurredEvent(this, LOG_TAG, 2701, new Object[0]);
                this.Speak("");
            } else {
                this.getLanguageAndCountryLists();
                this.isTtsPrepared = true;
            }
        }
    }
}

