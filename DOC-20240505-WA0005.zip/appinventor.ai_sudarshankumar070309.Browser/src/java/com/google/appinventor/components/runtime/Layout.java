/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.view.ViewGroup;
import com.google.appinventor.components.runtime.AndroidViewComponent;

public interface Layout {
    public void add(AndroidViewComponent var1);

    public ViewGroup getLayoutManager();
}

