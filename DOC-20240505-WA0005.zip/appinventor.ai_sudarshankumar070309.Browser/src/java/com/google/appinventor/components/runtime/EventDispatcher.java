/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.EventDispatcher$EventClosure-IA
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.OptionHelper;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class EventDispatcher {
    private static final boolean DEBUG = false;
    private static final Map<HandlesEventDispatching, EventRegistry> mapDispatchDelegateToEventRegistry = new HashMap();

    private EventDispatcher() {
    }

    private static boolean delegateDispatchEvent(HandlesEventDispatching handlesEventDispatching, Set<EventClosure> object2, Component component, Object ... objectArray) {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            boolean bl = false;
            for (Object object2 : object2) {
                boolean bl2 = handlesEventDispatching.dispatchEvent(component, ((EventClosure)object2).componentId, ((EventClosure)object2).eventName, objectArray);
                if (!bl2) continue;
                bl = true;
            }
            return bl;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean dispatchEvent(Component component, String string, Object ... set) {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            Set set2;
            Object[] objectArray = OptionHelper.optionListsFromValues(component, string, (Object[])set2);
            boolean bl = false;
            boolean bl2 = false;
            HandlesEventDispatching handlesEventDispatching = component.getDispatchDelegate();
            if (handlesEventDispatching.canDispatchEvent(component, string)) {
                set2 = (Set)EventDispatcher.getEventRegistry(handlesEventDispatching).eventClosuresMap.get((Object)string);
                bl = bl2;
                if (set2 != null) {
                    bl = bl2;
                    if (set2.size() > 0) {
                        bl = EventDispatcher.delegateDispatchEvent(handlesEventDispatching, (Set<EventClosure>)set2, component, objectArray);
                    }
                }
                bl2 = !bl;
                handlesEventDispatching.dispatchGenericEvent(component, string, bl2, objectArray);
            }
            // ** MonitorExit[var7_3] (shouldn't be in output)
            return bl;
        }
    }

    private static EventRegistry getEventRegistry(HandlesEventDispatching handlesEventDispatching) {
        EventRegistry eventRegistry;
        Map<HandlesEventDispatching, EventRegistry> map = mapDispatchDelegateToEventRegistry;
        EventRegistry eventRegistry2 = eventRegistry = (EventRegistry)map.get((Object)handlesEventDispatching);
        if (eventRegistry == null) {
            eventRegistry2 = new EventRegistry(handlesEventDispatching);
            map.put((Object)handlesEventDispatching, (Object)eventRegistry2);
        }
        return eventRegistry2;
    }

    public static String makeFullEventName(String string, String string2) {
        return string + "$" + string2;
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void registerEventForDelegation(HandlesEventDispatching handlesEventDispatching, String string, String string2) {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            void var2_2;
            EventRegistry eventRegistry = EventDispatcher.getEventRegistry(handlesEventDispatching);
            handlesEventDispatching = (Set)eventRegistry.eventClosuresMap.get((Object)var2_2);
            handlesEventDispatching = handlesEventDispatching == null ? new HashSet() : new HashSet((Collection)handlesEventDispatching);
            EventClosure eventClosure = new EventClosure(string, (String)var2_2, null);
            handlesEventDispatching.add(eventClosure);
            eventRegistry.eventClosuresMap.put((Object)var2_2, (Object)handlesEventDispatching);
            // ** MonitorExit[var5_3] (shouldn't be in output)
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void removeDispatchDelegate(HandlesEventDispatching object) {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            object = EventDispatcher.removeEventRegistry((HandlesEventDispatching)object);
            if (object != null) {
                ((EventRegistry)object).eventClosuresMap.clear();
            }
            // ** MonitorExit[var1_1] (shouldn't be in output)
            return;
        }
    }

    private static EventRegistry removeEventRegistry(HandlesEventDispatching handlesEventDispatching) {
        return (EventRegistry)mapDispatchDelegateToEventRegistry.remove((Object)handlesEventDispatching);
    }

    public static void unregisterAllEventsForDelegation() {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            try {
                Iterator iterator = mapDispatchDelegateToEventRegistry.values().iterator();
                while (iterator.hasNext()) {
                    ((EventRegistry)iterator.next()).eventClosuresMap.clear();
                }
                // ** MonitorExit[var1] (shouldn't be in output)
                return;
            }
            catch (Throwable throwable) {
                // ** MonitorExit[var1] (shouldn't be in output)
                throw throwable;
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void unregisterEventForDelegation(HandlesEventDispatching handlesEventDispatching, String string, String string2) {
        Class<EventDispatcher> clazz = EventDispatcher.class;
        synchronized (EventDispatcher.class) {
            EventRegistry eventRegistry = EventDispatcher.getEventRegistry(handlesEventDispatching);
            Set set = (Set)eventRegistry.eventClosuresMap.get((Object)string2);
            if (set == null) return;
            if (set.isEmpty()) return;
            handlesEventDispatching = new HashSet();
            for (EventClosure eventClosure : set) {
                if (eventClosure.componentId.equals((Object)string)) continue;
                handlesEventDispatching.add(eventClosure);
            }
            eventRegistry.eventClosuresMap.put((Object)string2, (Object)handlesEventDispatching);
            // ** MonitorExit[var6_4] (shouldn't be in output)
            return;
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private static final class EventClosure {
        private final String componentId;
        private final String eventName;

        private EventClosure(String string, String string2) {
            this.componentId = string;
            this.eventName = string2;
        }

        /* synthetic */ EventClosure(String string, String string2, EventClosure-IA eventClosure-IA) {
            super(string, string2);
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object != null && this.getClass() == object.getClass()) {
                object = (EventClosure)object;
                if (!this.componentId.equals((Object)((EventClosure)object).componentId)) {
                    return false;
                }
                return this.eventName.equals((Object)((EventClosure)object).eventName);
            }
            return false;
        }

        public int hashCode() {
            return this.eventName.hashCode() * 31 + this.componentId.hashCode();
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    private static final class EventRegistry {
        private final HandlesEventDispatching dispatchDelegate;
        private final HashMap<String, Set<EventClosure>> eventClosuresMap = new HashMap();

        EventRegistry(HandlesEventDispatching handlesEventDispatching) {
            this.dispatchDelegate = handlesEventDispatching;
        }
    }
}

