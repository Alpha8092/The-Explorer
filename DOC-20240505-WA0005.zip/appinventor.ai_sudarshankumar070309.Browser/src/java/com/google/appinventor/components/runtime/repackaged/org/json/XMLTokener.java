/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  com.google.appinventor.components.runtime.repackaged.org.json.XML
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.HashMap
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;
import com.google.appinventor.components.runtime.repackaged.org.json.XML;
import java.util.HashMap;

public class XMLTokener
extends JSONTokener {
    public static final HashMap entity;

    static {
        HashMap hashMap;
        entity = hashMap = new HashMap(8);
        hashMap.put((Object)"amp", (Object)XML.AMP);
        hashMap.put((Object)"apos", (Object)XML.APOS);
        hashMap.put((Object)"gt", (Object)XML.GT);
        hashMap.put((Object)"lt", (Object)XML.LT);
        hashMap.put((Object)"quot", (Object)XML.QUOT);
    }

    public XMLTokener(String string) {
        super(string);
    }

    public String nextCDATA() throws JSONException {
        Object object2;
        block1: {
            int n;
            object2 = new StringBuffer();
            do {
                char c = this.next();
                if (this.end()) break block1;
                object2.append(c);
            } while ((n = object2.length() - 3) < 0 || object2.charAt(n) != ']' || object2.charAt(n + 1) != ']' || object2.charAt(n + 2) != '>');
            object2.setLength(n);
            return object2.toString();
        }
        object2 = this.syntaxError("Unclosed CDATA");
        throw object2;
    }

    public Object nextContent() throws JSONException {
        char c;
        while (Character.isWhitespace((char)(c = this.next()))) {
        }
        if (c == '\u0000') {
            return null;
        }
        if (c == '<') {
            return XML.LT;
        }
        StringBuffer stringBuffer = new StringBuffer();
        while (c != '<' && c != '\u0000') {
            if (c == '&') {
                stringBuffer.append(this.nextEntity(c));
            } else {
                stringBuffer.append(c);
            }
            c = this.next();
        }
        this.back();
        return stringBuffer.toString().trim();
    }

    public Object nextEntity(char c) throws JSONException {
        Object object2 = new StringBuffer();
        while (true) {
            char c2;
            if (!Character.isLetterOrDigit((char)(c2 = this.next())) && c2 != '#') {
                if (c2 == ';') {
                    String string = object2.toString();
                    if ((object2 = entity.get((Object)string)) == null) {
                        object2 = new StringBuffer().append(c).append(string).append(";").toString();
                    }
                    return object2;
                }
                throw this.syntaxError(new StringBuffer().append("Missing ';' in XML entity: &").append(object2).toString());
            }
            object2.append(Character.toLowerCase((char)c2));
        }
    }

    public Object nextMeta() throws JSONException {
        char c;
        while (Character.isWhitespace((char)(c = this.next()))) {
        }
        switch (c) {
            default: {
                break;
            }
            case '?': {
                return XML.QUEST;
            }
            case '>': {
                return XML.GT;
            }
            case '=': {
                return XML.EQ;
            }
            case '<': {
                return XML.LT;
            }
            case '/': {
                return XML.SLASH;
            }
            case '\"': 
            case '\'': {
                char c2;
                while ((c2 = this.next()) != '\u0000') {
                    if (c2 != c) continue;
                    return Boolean.TRUE;
                }
                throw this.syntaxError("Unterminated string");
            }
            case '!': {
                return XML.BANG;
            }
            case '\u0000': {
                throw this.syntaxError("Misshaped meta tag");
            }
        }
        block15: while (true) {
            if (Character.isWhitespace((char)(c = this.next()))) {
                return Boolean.TRUE;
            }
            switch (c) {
                default: {
                    continue block15;
                }
                case '\u0000': 
                case '!': 
                case '\"': 
                case '\'': 
                case '/': 
                case '<': 
                case '=': 
                case '>': 
                case '?': 
            }
            break;
        }
        this.back();
        return Boolean.TRUE;
    }

    public Object nextToken() throws JSONException {
        StringBuffer stringBuffer;
        char c;
        while (Character.isWhitespace((char)(c = this.next()))) {
        }
        switch (c) {
            default: {
                stringBuffer = new StringBuffer();
                break;
            }
            case '?': {
                return XML.QUEST;
            }
            case '>': {
                return XML.GT;
            }
            case '=': {
                return XML.EQ;
            }
            case '<': {
                throw this.syntaxError("Misplaced '<'");
            }
            case '/': {
                return XML.SLASH;
            }
            case '\"': 
            case '\'': {
                char c2;
                StringBuffer stringBuffer2 = new StringBuffer();
                while ((c2 = this.next()) != '\u0000') {
                    if (c2 == c) {
                        return stringBuffer2.toString();
                    }
                    if (c2 == '&') {
                        stringBuffer2.append(this.nextEntity(c2));
                        continue;
                    }
                    stringBuffer2.append(c2);
                }
                throw this.syntaxError("Unterminated string");
            }
            case '!': {
                return XML.BANG;
            }
            case '\u0000': {
                throw this.syntaxError("Misshaped element");
            }
        }
        block17: while (true) {
            stringBuffer.append(c);
            c = this.next();
            if (Character.isWhitespace((char)c)) {
                return stringBuffer.toString();
            }
            switch (c) {
                default: {
                    continue block17;
                }
                case '\"': 
                case '\'': 
                case '<': {
                    throw this.syntaxError("Bad character in a name");
                }
                case '!': 
                case '/': 
                case '=': 
                case '>': 
                case '?': 
                case '[': 
                case ']': {
                    this.back();
                    return stringBuffer.toString();
                }
                case '\u0000': 
            }
            break;
        }
        return stringBuffer.toString();
    }

    public boolean skipPast(String string) throws JSONException {
        char c;
        int n;
        int n2 = 0;
        int n3 = string.length();
        char[] cArray = new char[n3];
        int n4 = 0;
        while (true) {
            n = n2;
            if (n4 >= n3) break;
            c = this.next();
            if (c == '\u0000') {
                return false;
            }
            cArray[n4] = c;
            ++n4;
        }
        while (true) {
            int n5;
            n4 = n;
            int n6 = 1;
            n2 = 0;
            while (true) {
                n5 = n6;
                if (n2 >= n3) break;
                if (cArray[n4] != string.charAt(n2)) {
                    n5 = 0;
                    break;
                }
                n4 = n5 = n4 + 1;
                if (n5 >= n3) {
                    n4 = n5 - n3;
                }
                ++n2;
            }
            if (n5 != 0) {
                return true;
            }
            c = this.next();
            if (c == '\u0000') {
                return false;
            }
            cArray[n] = c;
            if (++n < n3) continue;
            n -= n3;
        }
    }
}

