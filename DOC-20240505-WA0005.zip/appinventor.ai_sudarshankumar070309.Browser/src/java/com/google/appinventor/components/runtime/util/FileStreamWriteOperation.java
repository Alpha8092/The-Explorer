/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.FileWriteOperation;
import com.google.appinventor.components.runtime.util.IOUtils;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public abstract class FileStreamWriteOperation
extends FileWriteOperation {
    private static final String LOG_TAG = FileStreamWriteOperation.class.getSimpleName();

    public FileStreamWriteOperation(Form form, Component component, String string2, String string3, FileScope fileScope, boolean bl, boolean bl2) {
        super(form, component, string2, string3, fileScope, bl, bl2);
    }

    @Override
    protected final boolean process(OutputStream outputStream) throws IOException {
        boolean bl;
        block5: {
            OutputStream outputStream2;
            OutputStream outputStream3 = outputStream2 = null;
            outputStream3 = outputStream2;
            try {
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
                outputStream3 = outputStream = outputStreamWriter;
            }
            catch (Throwable throwable) {
                if (true) {
                    IOUtils.closeQuietly((String)LOG_TAG, outputStream3);
                }
                throw throwable;
            }
            bl = this.process((OutputStreamWriter)outputStream);
            if (!bl) break block5;
            IOUtils.closeQuietly((String)LOG_TAG, (Closeable)outputStream);
        }
        return bl;
    }

    @Override
    protected abstract boolean process(OutputStreamWriter var1) throws IOException;
}

