package com.google.appinventor.components.runtime.util.theme;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface ThemeHelper {
    boolean hasActionBar();

    void requestActionBar();

    void setActionBarAnimation(boolean z);

    boolean setActionBarVisible(boolean z);

    void setTitle(String str);

    void setTitle(String str, boolean z);
}
