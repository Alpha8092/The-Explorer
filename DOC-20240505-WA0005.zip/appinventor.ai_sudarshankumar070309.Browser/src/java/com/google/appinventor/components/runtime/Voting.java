/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Handler
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.Voting$2
 *  com.google.appinventor.components.runtime.Voting$4
 *  com.google.appinventor.components.runtime.util.AsyncCallbackPair
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.WebServiceUtil
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.message.BasicNameValuePair
 *  org.json.JSONArray
 *  org.json.JSONException
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Voting;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.util.AsyncCallbackPair;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.WebServiceUtil;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.INTERNAL, designerHelpDescription="<p>The Voting component enables users to vote on a question by communicating with a Web service to retrieve a ballot and later sending back users' votes.</p>", iconName="images/voting.png", nonVisible=true, version=1)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.INTERNET")
public class Voting
extends AndroidNonvisibleComponent
implements Component {
    private static final String BALLOT_OPTIONS_PARAMETER = "options";
    private static final String BALLOT_QUESTION_PARAMETER = "question";
    private static final String ID_REQUESTED_PARAMETER = "idRequested";
    private static final String IS_POLLING_PARAMETER = "isPolling";
    private static final String LOG_TAG = "Voting";
    private static final String REQUESTBALLOT_COMMAND = "requestballot";
    private static final String SENDBALLOT_COMMAND = "sendballot";
    private static final String USER_CHOICE_PARAMETER = "userchoice";
    private static final String USER_ID_PARAMETER = "userid";
    private Activity activityContext;
    private Handler androidUIHandler;
    private ArrayList<String> ballotOptions;
    private String ballotOptionsString;
    private String ballotQuestion;
    private Boolean idRequested;
    private Boolean isPolling;
    private String serviceURL = "http://androvote.appspot.com";
    private ComponentContainer theContainer;
    private String userChoice;
    private String userId = "";

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgetandroidUIHandler(Voting voting) {
        return voting.androidUIHandler;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetballotOptionsString(Voting voting) {
        return voting.ballotOptionsString;
    }

    static /* bridge */ /* synthetic */ Boolean -$$Nest$fgetisPolling(Voting voting) {
        return voting.isPolling;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetuserChoice(Voting voting) {
        return voting.userChoice;
    }

    static /* bridge */ /* synthetic */ String -$$Nest$fgetuserId(Voting voting) {
        return voting.userId;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputballotOptions(Voting voting, ArrayList arrayList) {
        voting.ballotOptions = arrayList;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputballotOptionsString(Voting voting, String string) {
        voting.ballotOptionsString = string;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputballotQuestion(Voting voting, String string) {
        voting.ballotQuestion = string;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputidRequested(Voting voting, Boolean bl) {
        voting.idRequested = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputisPolling(Voting voting, Boolean bl) {
        voting.isPolling = bl;
    }

    static /* bridge */ /* synthetic */ ArrayList -$$Nest$mJSONArrayToArrayList(Voting voting, JSONArray jSONArray) {
        return voting.JSONArrayToArrayList(jSONArray);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostRequestBallot(Voting voting) {
        voting.postRequestBallot();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mpostSendBallot(Voting voting, String string, String string2) {
        voting.postSendBallot(string, string2);
    }

    public Voting(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        Boolean bl;
        this.isPolling = bl = Boolean.valueOf((boolean)false);
        this.idRequested = bl;
        this.ballotQuestion = "";
        this.ballotOptions = new ArrayList();
        this.userChoice = "";
        this.androidUIHandler = new Handler();
        this.theContainer = componentContainer;
        this.activityContext = componentContainer.$context();
        this.serviceURL = "http://androvote.appspot.com";
    }

    private ArrayList<String> JSONArrayToArrayList(JSONArray jSONArray) throws JSONException {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); ++i) {
            arrayList.add((Object)jSONArray.getString(i));
        }
        return arrayList;
    }

    private void postRequestBallot() {
        2 var1_1 = new 2(this);
        WebServiceUtil.getInstance().postCommandReturningObject(this.serviceURL, REQUESTBALLOT_COMMAND, null, (AsyncCallbackPair)var1_1);
    }

    private void postSendBallot(String string, String string2) {
        4 var3_3 = new 4((Voting)this);
        WebServiceUtil.getInstance().postCommand(this.serviceURL, SENDBALLOT_COMMAND, Lists.newArrayList(new BasicNameValuePair(USER_CHOICE_PARAMETER, string), new BasicNameValuePair(USER_ID_PARAMETER, string2)), (AsyncCallbackPair)var3_3);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The list of ballot options.")
    public List<String> BallotOptions() {
        return this.ballotOptions;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The question to be voted on.")
    public String BallotQuestion() {
        return this.ballotQuestion;
    }

    @SimpleEvent(description="Event indicating that a ballot was retrieved from the Web service and that the properties <code>BallotQuestion</code> and <code>BallotOptions</code> have been set.  This is always preceded by a call to the method <code>RequestBallot</code>.")
    public void GotBallot() {
        EventDispatcher.dispatchEvent(this, "GotBallot", new Object[0]);
    }

    @SimpleEvent
    public void GotBallotConfirmation() {
        EventDispatcher.dispatchEvent(this, "GotBallotConfirmation", new Object[0]);
    }

    @SimpleEvent
    public void NoOpenPoll() {
        EventDispatcher.dispatchEvent(this, "NoOpenPoll", new Object[0]);
    }

    @SimpleFunction(description="Send a request for a ballot to the Web service specified by the property <code>ServiceURL</code>.  When the completes, one of the following events will be raised: <code>GotBallot</code>, <code>NoOpenPoll</code>, or <code>WebServiceError</code>.")
    public void RequestBallot() {
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
            final Voting this$0;
            {
                this.this$0 = voting;
            }

            public void run() {
                Voting.-$$Nest$mpostRequestBallot(this.this$0);
            }
        });
    }

    @SimpleFunction(description="Send a completed ballot to the Web service.  This should not be called until the properties <code>UserId</code> and <code>UserChoice</code> have been set by the application.")
    public void SendBallot() {
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
            final Voting this$0;
            {
                this.this$0 = voting;
            }

            public void run() {
                Voting voting = this.this$0;
                Voting.-$$Nest$mpostSendBallot(voting, Voting.-$$Nest$fgetuserChoice(voting), Voting.-$$Nest$fgetuserId(this.this$0));
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The URL of the Voting service")
    public String ServiceURL() {
        return this.serviceURL;
    }

    @DesignerProperty(defaultValue="http://androvote.appspot.com", editorType="string")
    @SimpleProperty
    public void ServiceURL(String string) {
        this.serviceURL = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The ballot choice to send to the server, which must be set before <code>SendBallot</code> is called.  This must be one of <code>BallotOptions</code>.")
    public String UserChoice() {
        return this.userChoice;
    }

    @SimpleProperty
    public void UserChoice(String string) {
        this.userChoice = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The email address associated with this device. This property has been deprecated and always returns the empty text value.")
    public String UserEmailAddress() {
        return "";
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="A text identifying the voter that is sent to the Voting server along with the vote.  This must be set before <code>SendBallot</code> is called.")
    public String UserId() {
        return this.userId;
    }

    @SimpleProperty
    public void UserId(String string) {
        this.userId = string;
    }

    @SimpleEvent
    public void WebServiceError(String string) {
        EventDispatcher.dispatchEvent((Component)this, "WebServiceError", string);
    }
}

