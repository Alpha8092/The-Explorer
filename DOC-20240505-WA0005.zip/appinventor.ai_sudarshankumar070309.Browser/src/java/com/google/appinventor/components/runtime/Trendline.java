/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.DashPathEffect
 *  android.util.Log
 *  com.github.mikephil.charting.data.Entry
 *  com.google.appinventor.components.common.BestFitModel
 *  com.google.appinventor.components.common.LOBFValues
 *  com.google.appinventor.components.common.LinearRegression
 *  com.google.appinventor.components.common.StrokeStyle
 *  com.google.appinventor.components.runtime.Chart
 *  com.google.appinventor.components.runtime.ChartComponent
 *  com.google.appinventor.components.runtime.ChartData2D
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  com.google.appinventor.components.runtime.Trendline$1
 *  com.google.appinventor.components.runtime.util.YailDictionary$KeyTransformer
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.google.appinventor.components.runtime;

import android.graphics.DashPathEffect;
import android.util.Log;
import com.github.mikephil.charting.data.Entry;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.common.BestFitModel;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.LOBFValues;
import com.google.appinventor.components.common.LinearRegression;
import com.google.appinventor.components.common.StrokeStyle;
import com.google.appinventor.components.common.TrendlineCalculator;
import com.google.appinventor.components.runtime.Chart;
import com.google.appinventor.components.runtime.ChartComponent;
import com.google.appinventor.components.runtime.ChartData2D;
import com.google.appinventor.components.runtime.ChartView;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.DataModel;
import com.google.appinventor.components.runtime.DataSource;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.PointChartView;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import com.google.appinventor.components.runtime.ScatterChartView;
import com.google.appinventor.components.runtime.Trendline;
import com.google.appinventor.components.runtime.util.ExponentialRegression;
import com.google.appinventor.components.runtime.util.LogarithmicRegression;
import com.google.appinventor.components.runtime.util.QuadraticRegression;
import com.google.appinventor.components.runtime.util.YailDictionary;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.CHARTS, description="A component that predicts a best fit model for a given data series.", iconName="images/trendline.png", version=1)
@UsesLibraries(value={"commons-math3.jar"})
public class Trendline
implements ChartComponent,
DataSourceChangeListener {
    private static final boolean DEBUG = false;
    private static final YailDictionary.KeyTransformer ENUM_KEY_TRANSFORMER;
    private static final String LOG_TAG;
    private ChartData2D chartData = null;
    private int color = 0;
    private final Chart container;
    private TrendlineCalculator currentModel;
    private final DashPathEffect dashed;
    private DataModel<?> dataModel;
    private final float density;
    private final DashPathEffect dotted;
    private final ExponentialRegression exponentialRegression;
    private boolean extend = true;
    private boolean initialized;
    private Map<String, Object> lastResults;
    private final LogarithmicRegression logarithmicRegression;
    private double maxX;
    private double minX;
    private BestFitModel model = BestFitModel.Linear;
    private final QuadraticRegression quadraticRegression;
    private final LinearRegression regression;
    private StrokeStyle strokeStyle = StrokeStyle.Solid;
    private double strokeWidth = 1.0;
    private boolean visible = true;

    static /* bridge */ /* synthetic */ ChartData2D -$$Nest$fgetchartData(Trendline trendline) {
        return trendline.chartData;
    }

    static /* bridge */ /* synthetic */ Chart -$$Nest$fgetcontainer(Trendline trendline) {
        return trendline.container;
    }

    static /* bridge */ /* synthetic */ double -$$Nest$fgetstrokeWidth(Trendline trendline) {
        return trendline.strokeWidth;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetvisible(Trendline trendline) {
        return trendline.visible;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$mgetColor(Trendline trendline) {
        return trendline.getColor();
    }

    static /* bridge */ /* synthetic */ DashPathEffect -$$Nest$mgetDashPathEffect(Trendline trendline) {
        return trendline.getDashPathEffect();
    }

    static /* bridge */ /* synthetic */ float[] -$$Nest$mgetPoints(Trendline trendline, float f, float f2, int n) {
        return trendline.getPoints(f, f2, n);
    }

    static {
        LOG_TAG = Trendline.class.getSimpleName();
        ENUM_KEY_TRANSFORMER = new 1();
    }

    public Trendline(Chart chart) {
        float f;
        LinearRegression linearRegression;
        this.regression = linearRegression = new LinearRegression();
        this.quadraticRegression = new QuadraticRegression();
        this.exponentialRegression = new ExponentialRegression();
        this.logarithmicRegression = new LogarithmicRegression();
        this.currentModel = linearRegression;
        this.lastResults = new HashMap();
        this.initialized = false;
        this.dataModel = null;
        this.minX = Double.POSITIVE_INFINITY;
        this.maxX = Double.NEGATIVE_INFINITY;
        this.density = f = chart.$form().deviceDensity();
        this.container = chart;
        chart.addDataComponent((ChartComponent)this);
        this.dashed = new DashPathEffect(new float[]{f * 10.0f, f * 10.0f}, 0.0f);
        this.dotted = new DashPathEffect(new float[]{2.0f * f, f * 10.0f}, 0.0f);
    }

    private int getColor() {
        ChartData2D chartData2D;
        int n = this.color;
        if (n == 0 && (chartData2D = this.chartData) != null) {
            n = chartData2D.Color();
            return 0xFFFFFF & n | (n >> 24 & 0xFF) / 2 << 24;
        }
        return n;
    }

    private DashPathEffect getDashPathEffect() {
        switch (3.$SwitchMap$com$google$appinventor$components$common$StrokeStyle[this.strokeStyle.ordinal()]) {
            default: {
                return null;
            }
            case 2: {
                return this.dotted;
            }
            case 1: 
        }
        return this.dashed;
    }

    private float[] getPoints(float f, float f2, int n) {
        if (this.initialized && this.chartData != null) {
            int n2;
            float f3 = f;
            float f4 = f2;
            if (!this.extend) {
                f3 = Math.max((float)f, (float)((float)this.minX));
                f4 = Math.min((float)f2, (float)((float)this.maxX));
            }
            switch (3.$SwitchMap$com$google$appinventor$components$common$StrokeStyle[this.strokeStyle.ordinal()]) {
                default: {
                    n2 = 1;
                    break;
                }
                case 2: {
                    n2 = 12;
                    break;
                }
                case 1: {
                    n2 = 20;
                }
            }
            n2 = (int)Math.ceil((double)((float)n / (this.density * (float)n2)));
            return this.currentModel.computePoints(this.lastResults, f3, f4, n, n2);
        }
        return new float[0];
    }

    private static double resultOrNan(Double d) {
        double d2 = d == null ? Double.NaN : d;
        return d2;
    }

    private static double resultOrZero(Double d) {
        double d2 = d == null ? 0.0 : d;
        return d2;
    }

    @DesignerProperty(editorType="component:com.google.appinventor.component.runtime.ChartData2D")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The data series for which to compute the line of best fit.")
    public void ChartData(ChartData2D chartData2D) {
        ChartData2D chartData2D2 = this.chartData;
        if (chartData2D2 != null) {
            chartData2D2.removeDataSourceChangeListener((DataSourceChangeListener)this);
        }
        this.chartData = chartData2D;
        if (chartData2D != null) {
            chartData2D.addDataSourceChangeListener((DataSourceChangeListener)this);
        }
    }

    @SimpleProperty
    public int Color() {
        return this.color;
    }

    @DesignerProperty(defaultValue="&H00000000", editorType="color")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The color of the line of best fit.")
    public void Color(int n) {
        this.color = n;
        if (this.initialized) {
            this.container.refresh();
        }
    }

    @SimpleProperty
    public double CorrelationCoefficient() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"correlation coefficient"));
    }

    @SimpleFunction
    public void DisconnectFromChartData() {
        ChartData2D chartData2D = this.chartData;
        if (chartData2D != null) {
            chartData2D.removeDataSourceChangeListener((DataSourceChangeListener)this);
        }
        this.lastResults.clear();
        this.container.refresh();
    }

    @SimpleProperty
    public double ExponentialBase() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"b"));
    }

    @SimpleProperty
    public double ExponentialCoefficient() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"a"));
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether to extend the line of best fit beyond the data.")
    public void Extend(boolean bl) {
        this.extend = bl;
        if (this.initialized) {
            this.container.refresh();
        }
    }

    @SimpleProperty
    public boolean Extend() {
        return this.extend;
    }

    @SimpleFunction
    public Object GetResultValue(@Options(value=LOBFValues.class) String string) {
        if (this.lastResults.containsKey((Object)string)) {
            return this.lastResults.get((Object)string);
        }
        return Double.NaN;
    }

    public void Initialize() {
        this.initialized = true;
        if (this.dataModel == null) {
            this.initChartData();
        }
    }

    @SimpleProperty
    public double LinearCoefficient() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"slope"));
    }

    @SimpleProperty
    public double LogarithmCoefficient() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"b"));
    }

    @SimpleProperty
    public double LogarithmConstant() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"a"));
    }

    @SimpleProperty
    public BestFitModel Model() {
        return this.model;
    }

    @DesignerProperty(defaultValue="Linear", editorType="best_fit_model")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The model to use for the line of best fit.")
    public void Model(BestFitModel bestFitModel) {
        this.model = bestFitModel;
        switch (3.$SwitchMap$com$google$appinventor$components$common$BestFitModel[bestFitModel.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown model: " + bestFitModel);
            }
            case 4: {
                this.currentModel = this.logarithmicRegression;
                break;
            }
            case 3: {
                this.currentModel = this.exponentialRegression;
                break;
            }
            case 2: {
                this.currentModel = this.quadraticRegression;
                break;
            }
            case 1: {
                this.currentModel = this.regression;
            }
        }
        if (this.initialized) {
            this.container.refresh();
        }
    }

    @SimpleProperty
    public List<Double> Predictions() {
        Object object2 = this.lastResults.get((Object)"predictions");
        if (object2 instanceof List) {
            return (List)object2;
        }
        return new ArrayList();
    }

    @SimpleProperty
    public double QuadraticCoefficient() {
        return Trendline.resultOrZero((Double)this.lastResults.get((Object)"x^2"));
    }

    @SimpleProperty
    public double RSquared() {
        return Trendline.resultOrNan((Double)this.lastResults.get((Object)"r^2"));
    }

    @SimpleProperty
    public YailDictionary Results() {
        return new YailDictionary(this.lastResults, ENUM_KEY_TRANSFORMER);
    }

    @SimpleProperty
    public StrokeStyle StrokeStyle() {
        return this.strokeStyle;
    }

    public void StrokeStyle(int n) {
        StrokeStyle strokeStyle = StrokeStyle.fromUnderlyingValue((Integer)n);
        if (strokeStyle != null) {
            this.StrokeStyle(strokeStyle);
        }
    }

    @DesignerProperty(defaultValue="1", editorType="stroke_style")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The style of the best fit line.")
    public void StrokeStyle(StrokeStyle strokeStyle) {
        this.strokeStyle = strokeStyle;
        if (this.initialized) {
            this.container.refresh();
        }
    }

    public void StrokeStyle(String string) {
        try {
            this.StrokeStyle(Integer.parseInt((String)string));
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
    }

    @SimpleProperty
    public double StrokeWidth() {
        return this.strokeWidth;
    }

    @DesignerProperty(defaultValue="1.0", editorType="non_negative_float")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The width of the best fit line.")
    public void StrokeWidth(double d) {
        this.strokeWidth = d;
        if (this.initialized) {
            this.container.refresh();
        }
    }

    @SimpleEvent
    public void Updated(YailDictionary yailDictionary) {
        EventDispatcher.dispatchEvent((Component)this, "Updated", new Object[]{yailDictionary});
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void Visible(boolean bl) {
        this.visible = bl;
        if (this.initialized) {
            this.container.refresh();
        }
    }

    @SimpleProperty
    public boolean Visible() {
        return this.visible;
    }

    @SimpleProperty
    public Object XIntercepts() {
        Object object2;
        block0: {
            object2 = this.lastResults.get((Object)"Xintercepts");
            if (object2 != null) break block0;
            object2 = Double.NaN;
        }
        return object2;
    }

    @SimpleProperty
    public double YIntercept() {
        if (this.lastResults.containsKey((Object)"Yintercept")) {
            return (Double)this.lastResults.get((Object)"Yintercept");
        }
        if (this.lastResults.containsKey((Object)"intercept")) {
            return (Double)this.lastResults.get((Object)"intercept");
        }
        return Double.NaN;
    }

    public HandlesEventDispatching getDispatchDelegate() {
        return this.container.getDispatchDelegate();
    }

    public void initChartData() {
        String string = LOG_TAG;
        ChartView chartView = this.container.getChartView();
        Log.d((String)string, (String)("initChartData view is " + chartView));
        if (this.container.getChartView() instanceof ScatterChartView) {
            this.dataModel = new /* Unavailable Anonymous Inner Class!! */;
        } else if (this.container.getChartView() instanceof PointChartView) {
            this.dataModel = new /* Unavailable Anonymous Inner Class!! */;
        }
    }

    @Override
    public void onDataSourceValueChange(DataSource<?, ?> object2, String string, Object object3) {
        this.lastResults.clear();
        object2 = object2.getDataValue(null);
        if (!(object2 instanceof List)) {
            return;
        }
        object3 = (List)object2;
        object2 = new ArrayList();
        string = new ArrayList();
        this.minX = Double.POSITIVE_INFINITY;
        this.maxX = Double.NEGATIVE_INFINITY;
        object3 = object3.iterator();
        while (object3.hasNext()) {
            Object object4 = object3.next();
            if (!(object4 instanceof Entry)) continue;
            double d = (object4 = (Entry)object4).getX();
            if (d < this.minX) {
                this.minX = d;
            }
            if (d > this.maxX) {
                this.maxX = d;
            }
            object2.add((Object)d);
            string.add((Object)object4.getY());
        }
        if (object2.isEmpty()) {
            Log.w((String)LOG_TAG, (String)"No entries in the data source");
            return;
        }
        if (object2.size() < 2) {
            Log.w((String)LOG_TAG, (String)"Not enough entries in the data source");
            return;
        }
        if (object2.size() != string.size()) {
            Log.w((String)LOG_TAG, (String)"Must have equal X and Y data points");
            return;
        }
        this.lastResults = this.currentModel.compute((List<Double>)object2, (List<Double>)string);
        if (this.initialized) {
            object2 = new YailDictionary(this.lastResults, ENUM_KEY_TRANSFORMER);
            this.container.$form().runOnUiThread(new Runnable((Trendline)this, (YailDictionary)((Object)object2)){
                final Trendline this$0;
                final YailDictionary val$results;
                {
                    this.this$0 = trendline;
                    this.val$results = yailDictionary;
                }

                public void run() {
                    this.this$0.Updated(this.val$results);
                    if (Trendline.-$$Nest$fgetvisible(this.this$0)) {
                        Trendline.-$$Nest$fgetcontainer(this.this$0).getChartView().getView().invalidate();
                    }
                }
            });
        }
    }

    @Override
    public void onReceiveValue(RealTimeDataSource<?, ?> realTimeDataSource, String string, Object object2) {
    }
}

