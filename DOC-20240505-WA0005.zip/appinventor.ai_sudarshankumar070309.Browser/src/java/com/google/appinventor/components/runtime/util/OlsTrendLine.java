/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  org.apache.commons.math3.linear.MatrixUtils
 *  org.apache.commons.math3.stat.regression.OLSMultipleLinearRegression
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.common.TrendlineCalculator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.stat.regression.OLSMultipleLinearRegression;

public abstract class OlsTrendLine
implements TrendlineCalculator {
    private static final boolean DEBUG = false;
    private static final double SIGNIFICANCE = 1.0E14;

    private static double round(double d) {
        d = Math.round((double)(d * 1.0E14));
        Double.isNaN((double)d);
        return d / 1.0E14;
    }

    @Override
    public Map<String, Object> compute(List<Double> hashMap, List<Double> iterator) {
        if (!hashMap.isEmpty() && !iterator.isEmpty()) {
            if (hashMap.size() == iterator.size()) {
                int n;
                Object object2 = new double[hashMap.size()][];
                for (n = 0; n < hashMap.size(); ++n) {
                    object2[n] = this.xVector((Double)hashMap.get(n));
                }
                hashMap = (HashMap)new double[iterator.size()];
                if (this.logY()) {
                    n = 0;
                    iterator = iterator.iterator();
                    while (iterator.hasNext()) {
                        hashMap[n] = (List<Double>)Math.log((double)((Double)iterator.next()));
                        ++n;
                    }
                } else {
                    n = 0;
                    iterator = iterator.iterator();
                    while (iterator.hasNext()) {
                        hashMap[n] = (List<Double>)((Double)iterator.next());
                        ++n;
                    }
                }
                iterator = new OLSMultipleLinearRegression();
                iterator.setNoIntercept(true);
                iterator.newSampleData(hashMap, (double[][])object2);
                object2 = MatrixUtils.createColumnRealMatrix((double[])iterator.estimateRegressionParameters());
                hashMap = new HashMap();
                hashMap.put((Object)"intercept", (Object)OlsTrendLine.round(object2.getEntry(0, 0)));
                hashMap.put((Object)"slope", (Object)OlsTrendLine.round(object2.getEntry(1, 0)));
                if (this.size() > 2) {
                    hashMap.put((Object)"x^2", (Object)OlsTrendLine.round(object2.getEntry(2, 0)));
                }
                hashMap.put((Object)"r^2", (Object)iterator.calculateRSquared());
                return hashMap;
            }
            throw new IllegalStateException("Must have equal X and Y data points");
        }
        hashMap = new IllegalStateException("List must have at least one element");
        throw hashMap;
    }

    protected abstract boolean logY();

    protected abstract int size();

    protected abstract double[] xVector(double var1);
}

