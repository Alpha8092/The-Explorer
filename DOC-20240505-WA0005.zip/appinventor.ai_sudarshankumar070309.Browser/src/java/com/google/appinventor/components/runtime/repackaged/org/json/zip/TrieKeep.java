/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.Kim
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.StringBuffer
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.Kim;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.Keep;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem;

class TrieKeep
extends Keep {
    private int[] froms;
    private Kim[] kims;
    private Node root;
    private int[] thrus;

    public TrieKeep(int n) {
        super(n);
        this.froms = new int[this.capacity];
        this.thrus = new int[this.capacity];
        this.kims = new Kim[this.capacity];
        this.root = new Node((TrieKeep)this);
    }

    public Kim kim(int n) {
        Kim kim;
        block3: {
            int n2;
            int n3;
            Kim kim2;
            block2: {
                kim2 = this.kims[n];
                n3 = this.froms[n];
                n2 = this.thrus[n];
                if (n3 != 0) break block2;
                kim = kim2;
                if (n2 == kim2.length) break block3;
            }
            kim = new Kim(kim2, n3, n2);
            this.froms[n] = 0;
            this.thrus[n] = kim.length;
            this.kims[n] = kim;
        }
        return kim;
    }

    public int length(int n) {
        return this.thrus[n] - this.froms[n];
    }

    public int match(Kim kim, int n, int n2) {
        Node node = this.root;
        int n3 = -1;
        for (int i = n; i < n2 && (node = node.get(kim.get(i))) != null; ++i) {
            if (node.integer != -1) {
                n3 = node.integer;
            }
            ++n;
        }
        return n3;
    }

    public boolean postMortem(PostMortem postMortem) {
        boolean bl = true;
        TrieKeep trieKeep = (TrieKeep)postMortem;
        int n = this.length;
        int n2 = trieKeep.length;
        boolean bl2 = false;
        if (n != n2) {
            JSONzip.log(new StringBuffer().append("\nLength ").append(this.length).append(" <> ").append(trieKeep.length).toString());
            return false;
        }
        if (this.capacity != trieKeep.capacity) {
            JSONzip.log(new StringBuffer().append("\nCapacity ").append(this.capacity).append(" <> ").append(trieKeep.capacity).toString());
            return false;
        }
        for (n2 = 0; n2 < this.length; ++n2) {
            Kim kim;
            postMortem = this.kim(n2);
            if (postMortem.equals((Object)(kim = trieKeep.kim(n2)))) continue;
            JSONzip.log(new StringBuffer().append("\n[").append(n2).append("] ").append((Object)postMortem).append(" <> ").append((Object)kim).toString());
            bl = false;
        }
        boolean bl3 = bl2;
        if (bl) {
            bl3 = bl2;
            if (this.root.postMortem(trieKeep.root)) {
                bl3 = true;
            }
        }
        return bl3;
    }

    public void registerMany(Kim kim) {
        int n;
        int n2 = kim.length;
        int n3 = n = this.capacity - this.length;
        if (n > 40) {
            n3 = 40;
        }
        int n4 = n3;
        for (n = 0; n < n2 - 2; ++n) {
            int n5;
            n3 = n5 = n2 - n;
            if (n5 > 10) {
                n3 = 10;
            }
            Node node = this.root;
            n5 = n4;
            for (int i = n; i < n3 + n; ++i) {
                node = node.vet(kim.get(i));
                n4 = n5;
                if (node.integer == -1) {
                    n4 = n5--;
                    if (i - n >= 2) {
                        Node.access$002(node, this.length);
                        this.uses[this.length] = 1L;
                        this.kims[this.length] = kim;
                        this.froms[this.length] = n;
                        this.thrus[this.length] = i + 1;
                        ++this.length;
                        n4 = n5;
                        if (n5 <= 0) {
                            return;
                        }
                    }
                }
                n5 = n4;
            }
            n4 = n5;
        }
    }

    public int registerOne(Kim kim, int n, int n2) {
        if (this.length < this.capacity) {
            int n3;
            Node node = this.root;
            for (n3 = n; n3 < n2; ++n3) {
                node = node.vet(kim.get(n3));
            }
            if (node.integer == -1) {
                n3 = this.length++;
                Node.access$002(node, n3);
                this.uses[n3] = 1L;
                this.kims[n3] = kim;
                this.froms[n3] = n;
                this.thrus[n3] = n2;
                return n3;
            }
        }
        return -1;
    }

    public void registerOne(Kim kim) {
        int n = this.registerOne(kim, 0, kim.length);
        if (n != -1) {
            this.kims[n] = kim;
        }
    }

    public void reserve() {
        if (this.capacity - this.length < 40) {
            int n;
            int n2 = 0;
            this.root = new Node(this);
            for (n = 0; n < this.capacity; ++n) {
                int n3 = n2;
                if (this.uses[n] > 1L) {
                    Kim kim = this.kims[n];
                    int n4 = this.thrus[n];
                    Object object2 = this.root;
                    for (n3 = this.froms[n]; n3 < n4; ++n3) {
                        object2 = ((Node)object2).vet(kim.get(n3));
                    }
                    Node.access$002((Node)object2, n2);
                    this.uses[n2] = TrieKeep.age(this.uses[n]);
                    object2 = this.froms;
                    object2[n2] = object2[n];
                    this.thrus[n2] = n4;
                    this.kims[n2] = kim;
                    n3 = n2 + 1;
                }
                n2 = n3;
            }
            n = n2;
            if (this.capacity - n2 < 40) {
                this.power = 0;
                this.root = new Node(this);
                n = 0;
            }
            this.length = n;
            while (n < this.capacity) {
                this.uses[n] = 0L;
                this.kims[n] = null;
                this.froms[n] = 0;
                this.thrus[n] = 0;
                ++n;
            }
        }
    }

    @Override
    public Object value(int n) {
        return this.kim(n);
    }

    class Node
    implements PostMortem {
        private int integer;
        private Node[] next;
        private final TrieKeep this$0;

        public Node(TrieKeep trieKeep) {
            this.this$0 = trieKeep;
            this.integer = -1;
            this.next = null;
        }

        static /* synthetic */ int access$002(Node node, int n) {
            node.integer = n;
            return n;
        }

        public Node get(byte by) {
            return this.get(by & 0xFF);
        }

        public Node get(int n) {
            Object object2 = this.next;
            object2 = object2 == null ? null : object2[n];
            return object2;
        }

        public boolean postMortem(PostMortem postMortem) {
            if ((postMortem = (Node)postMortem) == null) {
                JSONzip.log("\nMisalign");
                return false;
            }
            if (this.integer != postMortem.integer) {
                JSONzip.log(new StringBuffer().append("\nInteger ").append(this.integer).append(" <> ").append(postMortem.integer).toString());
                return false;
            }
            if (this.next == null) {
                if (postMortem.next == null) {
                    return true;
                }
                JSONzip.log(new StringBuffer().append("\nNext is null ").append(this.integer).toString());
                return false;
            }
            for (int i = 0; i < 256; ++i) {
                Node node = this.next[i];
                if (node != null) {
                    if (node.postMortem(postMortem.next[i])) continue;
                    return false;
                }
                if (postMortem.next[i] == null) continue;
                JSONzip.log(new StringBuffer().append("\nMisalign ").append(i).toString());
                return false;
            }
            return true;
        }

        public void set(byte by, Node node) {
            this.set(by & 0xFF, node);
        }

        public void set(int n, Node node) {
            if (this.next == null) {
                this.next = new Node[256];
            }
            this.next[n] = node;
        }

        public Node vet(byte by) {
            return this.vet(by & 0xFF);
        }

        public Node vet(int n) {
            Node node;
            Node node2 = node = this.get(n);
            if (node == null) {
                node2 = new Node(this.this$0);
                this.set(n, node2);
            }
            return node2;
        }
    }
}

