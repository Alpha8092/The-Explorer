/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.annotations.androidmanifest;

import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.CategoryElement;
import com.google.appinventor.components.annotations.androidmanifest.DataElement;

public @interface IntentFilterElement {
    public ActionElement[] actionElements();

    public CategoryElement[] categoryElements() default {};

    public DataElement[] dataElements() default {};

    public String icon() default "";

    public String label() default "";

    public String order() default "";

    public String priority() default "";
}

