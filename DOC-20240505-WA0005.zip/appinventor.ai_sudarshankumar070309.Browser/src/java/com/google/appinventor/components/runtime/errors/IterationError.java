/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.google.appinventor.components.runtime.errors;

import com.google.appinventor.components.runtime.errors.DispatchableError;

public class IterationError
extends DispatchableError {
    public IterationError(int n, Object[] objectArray) {
        super(n, objectArray);
    }

    public static DispatchableError fromError(int n, DispatchableError dispatchableError) {
        switch (dispatchableError.getErrorCode()) {
            default: {
                return dispatchableError;
            }
            case 3410: {
                return new IterationError(3407, IterationError.prepend(n, dispatchableError.getArguments()));
            }
            case 3409: {
                return new IterationError(3408, IterationError.prepend(n, dispatchableError.getArguments()));
            }
            case 3405: 
        }
        return new IterationError(3406, IterationError.prepend(n, dispatchableError.getArguments()));
    }

    private static Object[] prepend(int n, Object[] objectArray) {
        Object[] objectArray2 = new Object[objectArray.length + 1];
        objectArray2[0] = n;
        System.arraycopy((Object)objectArray, (int)0, (Object)objectArray2, (int)1, (int)objectArray.length);
        return objectArray2;
    }

    public String getExpected() {
        return (String)this.getArguments()[1];
    }

    public String getFound() {
        return (String)this.getArguments()[2];
    }

    public int getIndex() {
        return (Integer)this.getArguments()[0];
    }
}

