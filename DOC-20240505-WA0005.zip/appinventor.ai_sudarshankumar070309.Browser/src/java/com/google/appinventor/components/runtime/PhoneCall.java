/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.net.Uri
 *  android.telephony.TelephonyManager
 *  com.google.appinventor.components.common.EndedStatus
 *  com.google.appinventor.components.common.StartedStatus
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.PhoneCall$1
 *  com.google.appinventor.components.runtime.PhoneCall$2
 *  com.google.appinventor.components.runtime.util.BulkPermissionRequest
 *  com.google.appinventor.components.runtime.util.PhoneCallUtil
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.telephony.TelephonyManager;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.EndedStatus;
import com.google.appinventor.components.common.StartedStatus;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.PhoneCall;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import com.google.appinventor.components.runtime.util.PhoneCallUtil;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.SOCIAL, description="<p>A non-visible component that makes a phone call to the number specified in the <code>PhoneNumber</code> property, which can be set either in the Designer or Blocks Editor. The component has a <code>MakePhoneCall</code> method, enabling the program to launch a phone call.</p><p>Often, this component is used with the <code>ContactPicker</code> component, which lets the user select a contact from the ones stored on the phone and sets the <code>PhoneNumber</code> property to the contact's phone number.</p><p>To directly specify the phone number (e.g., 650-555-1212), set the <code>PhoneNumber</code> property to a Text with the specified digits (e.g., \"6505551212\").  Dashes, dots, and parentheses may be included (e.g., \"(650)-555-1212\") but will be ignored; spaces may not be included.</p>", iconName="images/phoneCall.png", nonVisible=true, version=3)
@SimpleObject
public class PhoneCall
extends AndroidNonvisibleComponent
implements Component,
OnDestroyListener,
ActivityResultListener {
    private static final int PHONECALL_REQUEST_CODE = 1346916174;
    private final CallStateReceiver callStateReceiver;
    private final Context context;
    private boolean didRegisterReceiver = false;
    private boolean havePermission = false;
    private String phoneNumber;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(PhoneCall phoneCall, boolean bl) {
        phoneCall.havePermission = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mregisterCallStateMonitor(PhoneCall phoneCall) {
        phoneCall.registerCallStateMonitor();
    }

    public PhoneCall(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.context = componentContainer.$context();
        this.form.registerForOnDestroy((OnDestroyListener)this);
        this.form.registerForActivityResult((ActivityResultListener)this, 1346916174);
        this.PhoneNumber("");
        this.callStateReceiver = new BroadcastReceiver((PhoneCall)this){
            private String number;
            private CallStatus status;
            final PhoneCall this$0;
            {
                this.this$0 = phoneCall;
                this.status = null;
                this.number = "";
            }

            public void onReceive(Context object2, Intent intent) {
                block8: {
                    block6: {
                        block9: {
                            block7: {
                                object2 = intent.getAction();
                                if (!"android.intent.action.PHONE_STATE".equals(object2)) break block6;
                                object2 = intent.getStringExtra("state");
                                if (!TelephonyManager.EXTRA_STATE_RINGING.equals(object2)) break block7;
                                this.status = CallStatus.INCOMING_WAITING;
                                object2 = intent.getStringExtra("incoming_number");
                                this.number = object2;
                                if (object2 == null) {
                                    return;
                                }
                                this.this$0.PhoneCallStartedAbstract(StartedStatus.Incoming, this.number);
                                break block8;
                            }
                            if (!TelephonyManager.EXTRA_STATE_OFFHOOK.equals(object2)) break block9;
                            if (this.status != CallStatus.INCOMING_WAITING) break block8;
                            this.status = CallStatus.INCOMING_ANSWERED;
                            this.this$0.IncomingCallAnswered(this.number);
                            break block8;
                        }
                        if (!TelephonyManager.EXTRA_STATE_IDLE.equals(object2)) break block8;
                        if (this.status == CallStatus.INCOMING_WAITING) {
                            this.this$0.PhoneCallEndedAbstract(EndedStatus.IncomingRejected, this.number);
                        } else if (this.status == CallStatus.INCOMING_ANSWERED) {
                            this.this$0.PhoneCallEndedAbstract(EndedStatus.IncomingEnded, this.number);
                        } else if (this.status == CallStatus.OUTGOING_WAITING) {
                            this.this$0.PhoneCallEndedAbstract(EndedStatus.OutgoingEnded, this.number);
                        }
                        this.status = null;
                        this.number = "";
                        break block8;
                    }
                    if (!"android.intent.action.NEW_OUTGOING_CALL".equals(object2)) break block8;
                    this.status = CallStatus.OUTGOING_WAITING;
                    this.number = intent.getStringExtra("android.intent.extra.PHONE_NUMBER");
                    this.this$0.PhoneCallStartedAbstract(StartedStatus.Outgoing, this.number);
                }
            }
        };
    }

    private void registerCallStateMonitor() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.NEW_OUTGOING_CALL");
        intentFilter.addAction("android.intent.action.PHONE_STATE");
        this.context.registerReceiver((BroadcastReceiver)this.callStateReceiver, intentFilter);
        this.didRegisterReceiver = true;
    }

    private void unregisterCallStateMonitor() {
        if (this.didRegisterReceiver) {
            this.context.unregisterReceiver((BroadcastReceiver)this.callStateReceiver);
            this.didRegisterReceiver = false;
        }
    }

    @SimpleEvent(description="Event indicating that an incoming phone call is answered. phoneNumber is the incoming call phone number.")
    @UsesPermissions(value={"android.permission.PROCESS_OUTGOING_CALLS", "android.permission.READ_CALL_LOG", "android.permission.READ_PHONE_STATE"})
    public void IncomingCallAnswered(String string) {
        EventDispatcher.dispatchEvent((Component)this, "IncomingCallAnswered", string);
    }

    public void Initialize() {
        if (this.form.doesAppDeclarePermission("android.permission.READ_CALL_LOG")) {
            this.form.askPermission((BulkPermissionRequest)new 1(this, (Component)this, "Initialize", new String[]{"android.permission.PROCESS_OUTGOING_CALLS", "android.permission.READ_PHONE_STATE", "android.permission.READ_CALL_LOG"}));
        }
    }

    @SimpleFunction(description="Launches the default dialer app set to start a phone call usingthe number in the PhoneNumber property.")
    public void MakePhoneCall() {
        Intent intent = new Intent("android.intent.action.DIAL", Uri.fromParts((String)"tel", (String)this.phoneNumber, null));
        if (intent.resolveActivity(this.form.getPackageManager()) != null) {
            this.form.startActivityForResult(intent, 1346916174);
        }
    }

    @SimpleFunction(description="Directly initiates a phone call using the number in the PhoneNumber property.")
    @UsesPermissions(value={"android.permission.CALL_PHONE"})
    public void MakePhoneCallDirect() {
        if (!this.havePermission) {
            this.form.askPermission("android.permission.CALL_PHONE", (PermissionResultHandler)new 2(this));
        } else {
            PhoneCallUtil.makePhoneCall((Context)this.context, (String)this.phoneNumber);
        }
    }

    @SimpleEvent(description="Event indicating that a phone call has ended. If status is 1, incoming call is missed or rejected; if status is 2, incoming call is answered before hanging up; if status is 3, outgoing call is hung up. phoneNumber is the ended call phone number.")
    @UsesPermissions(value={"android.permission.PROCESS_OUTGOING_CALLS", "android.permission.READ_CALL_LOG", "android.permission.READ_PHONE_STATE"})
    public void PhoneCallEnded(@Options(value=EndedStatus.class) int n, String string) {
        EndedStatus endedStatus = EndedStatus.fromUnderlyingValue((Integer)n);
        if (endedStatus != null) {
            this.PhoneCallEndedAbstract(endedStatus, string);
        }
    }

    public void PhoneCallEndedAbstract(EndedStatus endedStatus, String string) {
        EventDispatcher.dispatchEvent((Component)this, "PhoneCallEnded", endedStatus.toUnderlyingValue(), string);
    }

    @SimpleEvent(description="Event indicating that a phonecall has started. If status is 1, incoming call is ringing; if status is 2, outgoing call is dialled. phoneNumber is the incoming/outgoing phone number.")
    @UsesPermissions(value={"android.permission.PROCESS_OUTGOING_CALLS", "android.permission.READ_CALL_LOG", "android.permission.READ_PHONE_STATE"})
    public void PhoneCallStarted(@Options(value=StartedStatus.class) int n, String string) {
        StartedStatus startedStatus = StartedStatus.fromUnderlyingValue((Integer)n);
        if (startedStatus != null) {
            this.PhoneCallStartedAbstract(startedStatus, string);
        }
    }

    public void PhoneCallStartedAbstract(StartedStatus startedStatus, String string) {
        EventDispatcher.dispatchEvent((Component)this, "PhoneCallStarted", startedStatus.toUnderlyingValue(), string);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String PhoneNumber() {
        return this.phoneNumber;
    }

    @DesignerProperty(editorType="string")
    @SimpleProperty
    public void PhoneNumber(String string) {
        this.phoneNumber = string;
    }

    @Override
    public void onDestroy() {
        this.unregisterCallStateMonitor();
    }

    @Override
    public void resultReturned(int n, int n2, Intent intent) {
        if (n == 1346916174) {
            this.PhoneCallStartedAbstract(StartedStatus.Outgoing, "");
        }
    }
}

