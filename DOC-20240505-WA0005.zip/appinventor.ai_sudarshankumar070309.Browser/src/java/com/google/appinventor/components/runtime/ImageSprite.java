/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.drawable.BitmapDrawable
 *  android.util.Log
 *  com.google.appinventor.components.runtime.Sprite
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  java.io.IOException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Sprite;
import com.google.appinventor.components.runtime.util.MediaUtil;
import java.io.IOException;

@DesignerComponent(category=ComponentCategory.ANIMATION, description="<p>A 'sprite' that can be placed on a <code>Canvas</code>, where it can react to touches and drags, interact with other sprites (<code>Ball</code>s and other <code>ImageSprite</code>s) and the edge of the Canvas, and move according to its property values.  Its appearance is that of the image specified in its <code>Picture</code> property (unless its <code>Visible</code> property is <code>False</code>).</p> <p>To have an <code>ImageSprite</code> move 10 pixels to the left every 1000 milliseconds (one second), for example, you would set the <code>Speed</code> property to 10 [pixels], the <code>Interval</code> property to 1000 [milliseconds], the <code>Heading</code> property to 180 [degrees], and the <code>Enabled</code> property to <code>True</code>.  A sprite whose <code>Rotates</code> property is <code>True</code> will rotate its image as the sprite's <code>Heading</code> changes.  Checking for collisions with a rotated sprite currently checks the sprite's unrotated position so that collision checking will be inaccurate for tall narrow or short wide sprites that are rotated.  Any of the sprite properties can be changed at any time under program control.</p> ", iconName="images/imageSprite.png", version=8)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.INTERNET")
public class ImageSprite
extends Sprite {
    private BitmapDrawable drawable;
    private final Form form;
    private int heightHint = -1;
    private String picturePath = "";
    private boolean rotates;
    private int widthHint = -1;

    public ImageSprite(ComponentContainer componentContainer) {
        super(componentContainer);
        this.form = componentContainer.$form();
        this.rotates = true;
    }

    @SimpleProperty(description="The height of the ImageSprite in pixels.")
    public int Height() {
        int n = this.heightHint;
        if (n != -1 && n != -2 && n > -1000) {
            return n;
        }
        BitmapDrawable bitmapDrawable = this.drawable;
        n = bitmapDrawable == null ? 0 : (int)((float)bitmapDrawable.getBitmap().getHeight() / this.form.deviceDensity());
        return n;
    }

    @SimpleProperty
    public void Height(int n) {
        this.heightHint = n;
        this.registerChange();
    }

    public void HeightPercent(int n) {
    }

    @SimpleFunction(description="Moves the ImageSprite so that its left top corner is at the specified x and y coordinates.")
    public void MoveTo(double d, double d2) {
        super.MoveTo(d, d2);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The picture that determines the ImageSprite's appearance.")
    public String Picture() {
        return this.picturePath;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty
    public void Picture(@Asset String string) {
        if (string == null) {
            string = "";
        }
        this.picturePath = string;
        try {
            this.drawable = MediaUtil.getBitmapDrawable((Form)this.form, (String)string);
        }
        catch (IOException iOException) {
            String string2 = this.picturePath;
            Log.e((String)"ImageSprite", (String)("Unable to load " + string2));
            this.drawable = null;
        }
        this.registerChange();
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void Rotates(boolean bl) {
        this.rotates = bl;
        this.registerChange();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the image should rotate to match the ImageSprite's heading. The sprite rotates around its centerpoint.")
    public boolean Rotates() {
        return this.rotates;
    }

    @SimpleProperty(description="The width of the ImageSprite in pixels.")
    public int Width() {
        int n = this.widthHint;
        if (n != -1 && n != -2 && n > -1000) {
            return n;
        }
        BitmapDrawable bitmapDrawable = this.drawable;
        n = bitmapDrawable == null ? 0 : (int)((float)bitmapDrawable.getBitmap().getWidth() / this.form.deviceDensity());
        return n;
    }

    @SimpleProperty
    public void Width(int n) {
        this.widthHint = n;
        this.registerChange();
    }

    public void WidthPercent(int n) {
    }

    @SimpleProperty(description="The horizontal coordinate of the left edge of the ImageSprite, increasing as the ImageSprite moves right.")
    public double X() {
        return super.X();
    }

    @SimpleProperty(description="The vertical coordinate of the top edge of the ImageSprite, increasing as the ImageSprite moves down.")
    public double Y() {
        return super.Y();
    }

    public void onDraw(Canvas canvas) {
        if (this.drawable != null && this.visible) {
            int n = (int)((float)Math.round((double)this.xLeft) * this.form.deviceDensity());
            int n2 = (int)((float)Math.round((double)this.yTop) * this.form.deviceDensity());
            int n3 = (int)((float)this.Width() * this.form.deviceDensity());
            int n4 = (int)((float)this.Height() * this.form.deviceDensity());
            this.drawable.setBounds(n, n2, n + n3, n2 + n4);
            if (!this.rotates) {
                this.drawable.draw(canvas);
            } else {
                canvas.save();
                canvas.rotate((float)(-this.Heading()), (float)(n3 / 2 + n), (float)(n4 / 2 + n2));
                this.drawable.draw(canvas);
                canvas.restore();
            }
        }
    }
}

