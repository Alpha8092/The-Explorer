/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

public interface PermissionResultHandler {
    public void HandlePermissionResponse(String var1, boolean var2);
}

