/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.accounts.AccountManager
 *  android.accounts.AuthenticatorException
 *  android.accounts.OperationCanceledException
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Looper
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.AccountChooser
 *  com.google.appinventor.components.runtime.util.IClientLoginHelper
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Thread
 *  org.apache.http.Header
 *  org.apache.http.HttpResponse
 *  org.apache.http.client.ClientProtocolException
 *  org.apache.http.client.HttpClient
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.DefaultHttpClient
 */
package com.google.appinventor.components.runtime.util;

import android.accounts.AccountManager;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import com.google.appinventor.components.runtime.util.AccountChooser;
import com.google.appinventor.components.runtime.util.IClientLoginHelper;
import java.io.IOException;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;

public class ClientLoginHelper
implements IClientLoginHelper {
    private static final String ACCOUNT_TYPE = "com.google";
    private static final String AUTHORIZATION_HEADER_PREFIX = "GoogleLogin auth=";
    private static final String LOG_TAG = "ClientLoginHelper";
    private AccountChooser accountChooser;
    private AccountManager accountManager;
    private Activity activity;
    private String authToken;
    private HttpClient client;
    private boolean initialized = false;
    private String service;

    public ClientLoginHelper(Activity activity, String string, String string2, HttpClient httpClient) {
        this.service = string;
        if (httpClient == null) {
            httpClient = new DefaultHttpClient();
        }
        this.client = httpClient;
        this.activity = activity;
        this.accountManager = AccountManager.get((Context)activity);
        this.accountChooser = new AccountChooser(activity, string, string2, string);
    }

    private static void addGoogleAuthHeader(HttpUriRequest httpUriRequest, String string) {
        if (string != null) {
            Log.i((String)LOG_TAG, (String)("adding auth token token: " + string));
            httpUriRequest.addHeader("Authorization", AUTHORIZATION_HEADER_PREFIX + string);
        }
    }

    private void initialize() throws ClientProtocolException {
        if (!this.initialized) {
            Log.i((String)LOG_TAG, (String)"initializing");
            if (!this.isUiThread()) {
                this.authToken = this.getAuthToken();
                this.initialized = true;
            } else {
                throw new IllegalArgumentException("Can't initialize login helper from UI thread");
            }
        }
    }

    private boolean isUiThread() {
        return Looper.getMainLooper().getThread().equals((Object)Thread.currentThread());
    }

    private static void removeGoogleAuthHeaders(HttpUriRequest httpUriRequest) {
        for (Header header : httpUriRequest.getAllHeaders()) {
            if (!header.getName().equalsIgnoreCase("Authorization") || !header.getValue().startsWith(AUTHORIZATION_HEADER_PREFIX)) continue;
            Log.i((String)LOG_TAG, (String)("Removing header:" + header));
            httpUriRequest.removeHeader(header);
        }
    }

    public HttpResponse execute(HttpUriRequest httpUriRequest) throws ClientProtocolException, IOException {
        HttpResponse httpResponse;
        super.initialize();
        ClientLoginHelper.addGoogleAuthHeader(httpUriRequest, this.authToken);
        Object object2 = httpResponse = this.client.execute(httpUriRequest);
        if (httpResponse.getStatusLine().getStatusCode() == 401) {
            object2 = this.authToken;
            Log.i((String)LOG_TAG, (String)("Invalid token: " + (String)object2));
            this.accountManager.invalidateAuthToken(ACCOUNT_TYPE, this.authToken);
            this.authToken = this.getAuthToken();
            ClientLoginHelper.removeGoogleAuthHeaders(httpUriRequest);
            ClientLoginHelper.addGoogleAuthHeader(httpUriRequest, this.authToken);
            object2 = this.authToken;
            Log.i((String)LOG_TAG, (String)("new token: " + (String)object2));
            object2 = this.client.execute(httpUriRequest);
        }
        return object2;
    }

    public void forgetAccountName() {
        this.accountChooser.forgetAccountName();
    }

    public String getAuthToken() throws ClientProtocolException {
        Object object2 = this.accountChooser.findAccount();
        if (object2 != null) {
            object2 = this.accountManager.getAuthToken(object2, this.service, null, this.activity, null, null);
            Log.i((String)LOG_TAG, (String)("Have account, auth token: " + object2));
            try {
                object2 = ((Bundle)object2.getResult()).getString("authtoken");
                return object2;
            }
            catch (OperationCanceledException operationCanceledException) {
                operationCanceledException.printStackTrace();
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
            catch (AuthenticatorException authenticatorException) {
                authenticatorException.printStackTrace();
            }
        }
        throw new ClientProtocolException("Can't get valid authentication token");
    }
}

