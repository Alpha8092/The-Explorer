package com.google.appinventor.components.common;

import java.util.HashMap;
import java.util.Map;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public enum BestFitModel implements OptionList<String> {
    Linear("Linear"),
    Quadratic("Quadratic"),
    Exponential("Exponential"),
    Logarithmic("Logarithmic");
    
    private static final Map<String, BestFitModel> lookup = new HashMap();
    private final String value;

    static {
        BestFitModel[] values;
        for (BestFitModel model : values()) {
            lookup.put(model.toUnderlyingValue(), model);
        }
    }

    BestFitModel(String value) {
        this.value = value;
    }

    @Override // com.google.appinventor.components.common.OptionList
    public String toUnderlyingValue() {
        return this.value;
    }

    public static BestFitModel fromUnderlyingValue(String model) {
        return lookup.get(model);
    }
}
