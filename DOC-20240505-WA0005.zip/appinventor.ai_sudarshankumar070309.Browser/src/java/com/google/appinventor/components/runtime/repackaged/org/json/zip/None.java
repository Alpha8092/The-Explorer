package com.google.appinventor.components.runtime.repackaged.org.json.zip;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface None {
    public static final int none = -1;
}
