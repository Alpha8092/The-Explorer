/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.data.Entry
 *  com.google.appinventor.components.runtime.ChartData2D
 *  com.google.appinventor.components.runtime.CloudDB
 *  com.google.appinventor.components.runtime.DataCollection
 *  com.google.appinventor.components.runtime.DataFile
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.Entry;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ChartData2D;
import com.google.appinventor.components.runtime.CloudDB;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataCollection;
import com.google.appinventor.components.runtime.DataFile;
import com.google.appinventor.components.runtime.DataModel;
import com.google.appinventor.components.runtime.DataSource;
import com.google.appinventor.components.runtime.Spreadsheet;
import com.google.appinventor.components.runtime.TinyDB;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.util.YailList;
import gnu.lists.LList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@DesignerComponent(category=ComponentCategory.DATASCIENCE, description="A component that contains anomaly detection models", iconName="images/anomaly.png", nonVisible=true, version=2)
@SimpleObject
public final class AnomalyDetection
extends DataCollection<ComponentContainer, DataModel<?>> {
    public AnomalyDetection(ComponentContainer componentContainer) {
        super(componentContainer);
    }

    public static double getAnomalyIndex(YailList yailList) {
        if (!yailList.isEmpty()) {
            return (Double)AnomalyDetection.castToDouble((List)((LList)yailList.getCdr())).get(0);
        }
        throw new IllegalStateException("Must have equal X and Y data points");
    }

    public <K, V> void ChangeDataSource(DataSource<K, V> dataSource, String string) {
    }

    @SimpleFunction(description="Given a single anomaly and the x and y values of your data. This block will return the x and y value pairs of your data without the anomaly")
    public List<List<?>> CleanData(YailList yailList, YailList yailList2, YailList yailList3) {
        yailList2 = AnomalyDetection.castToDouble((List)((LList)yailList2.getCdr()));
        yailList3 = AnomalyDetection.castToDouble((List)((LList)yailList3.getCdr()));
        if (yailList2.size() == yailList3.size()) {
            if (yailList2.size() != 0 && yailList3.size() != 0) {
                int n = (int)AnomalyDetection.getAnomalyIndex(yailList);
                yailList2.remove(n - 1);
                yailList3.remove(n - 1);
                yailList = new ArrayList();
                if (yailList2.size() == yailList3.size()) {
                    for (n = 0; n < yailList2.size(); ++n) {
                        yailList.add((Object)YailList.makeList((List)Arrays.asList((Object[])new Double[]{(Double)yailList2.get(n), (Double)yailList3.get(n)})));
                    }
                }
                return yailList;
            }
            throw new IllegalStateException("List must have at least one element");
        }
        yailList = new IllegalStateException("Must have equal X and Y data points");
        throw yailList;
    }

    public void Clear() {
    }

    public void DataFileXColumn(String string) {
    }

    public void DataFileYColumn(String string) {
    }

    public void DataSourceKey(String string) {
    }

    @SimpleFunction(description="Z-Score Anomaly Detection: checks each data point's Z-scoreagainst the given threshold if a data point's Z-score is greater than the threshold, the data point is labeled as anomaly and returned in a list of pairs (anomaly index, anomaly value)")
    public List<List<?>> DetectAnomalies(YailList yailList, double d) {
        int n;
        ArrayList arrayList = new ArrayList();
        yailList = AnomalyDetection.castToDouble((List)((LList)yailList.getCdr()));
        double d2 = 0.0;
        for (n = 0; n < yailList.size(); ++n) {
            d2 += ((Double)yailList.get(n)).doubleValue();
        }
        double d3 = yailList.size();
        Double.isNaN((double)d3);
        d3 = d2 / d3;
        d2 = 0.0;
        for (n = 0; n < yailList.size(); ++n) {
            d2 += Math.pow((double)((Double)yailList.get(n) - d3), (double)2.0);
        }
        double d4 = yailList.size();
        Double.isNaN((double)d4);
        d2 = Math.sqrt((double)(d2 / d4));
        for (n = 0; n < yailList.size(); ++n) {
            if (!(Math.abs((double)(((Double)yailList.get(n) - d3) / d2)) > d)) continue;
            arrayList.add((Object)Arrays.asList((Object[])new Number[]{n + 1, (Number)yailList.get(n)}));
        }
        return arrayList;
    }

    @SimpleFunction
    public List<List<?>> DetectAnomaliesInChartData(ChartData2D chartData2D, double d) {
        double d2;
        double d3;
        List list = chartData2D.getDataValue(null);
        double d4 = 0.0;
        chartData2D = list.iterator();
        while (chartData2D.hasNext()) {
            d3 = ((Entry)chartData2D.next()).getY();
            Double.isNaN((double)d3);
            d4 += d3;
        }
        d3 = list.size();
        Double.isNaN((double)d3);
        d3 = d4 / d3;
        d4 = 0.0;
        chartData2D = list.iterator();
        while (chartData2D.hasNext()) {
            d2 = ((Entry)chartData2D.next()).getY();
            Double.isNaN((double)d2);
            d4 += Math.pow((double)(d2 - d3), (double)2.0);
        }
        d2 = list.size();
        Double.isNaN((double)d2);
        d4 = Math.sqrt((double)(d4 / d2));
        chartData2D = new ArrayList();
        for (Entry entry : list) {
            d2 = entry.getY();
            Double.isNaN((double)d2);
            if (!(Math.abs((double)((d2 - d3) / d4)) > d)) continue;
            chartData2D.add((Object)Arrays.asList((Object[])new Float[]{Float.valueOf((float)entry.getX()), Float.valueOf((float)entry.getY())}));
        }
        return chartData2D;
    }

    public void ElementsFromPairs(String string) {
    }

    public YailList GetAllEntries() {
        return YailList.makeEmptyList();
    }

    public YailList GetEntriesWithXValue(String string) {
        return YailList.makeEmptyList();
    }

    public YailList GetEntriesWithYValue(String string) {
        return YailList.makeEmptyList();
    }

    public void ImportFromCloudDB(CloudDB cloudDB, String string) {
    }

    public void ImportFromDataFile(DataFile dataFile, String string, String string2) {
    }

    public void ImportFromList(YailList yailList) {
    }

    public void ImportFromSpreadsheet(Spreadsheet spreadsheet, String string, String string2, boolean bl) {
    }

    public void ImportFromTinyDB(TinyDB tinyDB, String string) {
    }

    public void ImportFromWeb(Web web, String string, String string2) {
    }

    public void RemoveDataSource() {
    }

    public <K, V> void Source(DataSource<K, V> dataSource) {
    }

    public void SpreadsheetUseHeaders(boolean bl) {
    }

    public void SpreadsheetXColumn(String string) {
    }

    public void SpreadsheetYColumn(String string) {
    }

    public void WebXColumn(String string) {
    }

    public void WebYColumn(String string) {
    }

    public void onDataChange() {
    }
}

