/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.EditText
 *  android.widget.LinearLayout
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$LayoutParams
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.ListAdapterWithRecyclerView
 *  com.google.appinventor.components.runtime.ListView$2
 *  com.google.appinventor.components.runtime.util.ElementsUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.CharSequence
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.ListAdapterWithRecyclerView;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.util.ElementsUtil;
import com.google.appinventor.components.runtime.util.YailDictionary;
import com.google.appinventor.components.runtime.util.YailList;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="<p>This is a visible component that displays a list of text and image elements.</p> <p>Simple lists of strings may be set using the ElementsFromString property. More complex lists of elements containing multiple strings and/or images can be created using the ListData and ListViewLayout properties. </p>", iconName="images/listView.png", nonVisible=false, version=7)
@SimpleObject
@UsesLibraries(libraries="recyclerview.jar, cardview.jar, cardview.aar")
@UsesPermissions(permissionNames="android.permission.INTERNET,android.permission.READ_EXTERNAL_STORAGE")
public final class ListView
extends AndroidViewComponent
implements AdapterView.OnItemClickListener {
    private static final int DEFAULT_BACKGROUND_COLOR = -16777216;
    private static final boolean DEFAULT_ENABLED = false;
    private static final int DEFAULT_IMAGE_WIDTH = 200;
    private static final int DEFAULT_TEXT_SIZE = 22;
    private static final String LOG_TAG = "ListView";
    private int backgroundColor;
    protected final ComponentContainer container;
    private int detailTextColor;
    private List<YailDictionary> dictItems;
    private float fontSizeDetail;
    private float fontSizeMain;
    private String fontTypeDetail;
    private String fontTypeface;
    private int imageHeight;
    private int imageWidth;
    private int layout;
    private final LinearLayout linearLayout;
    private ListAdapterWithRecyclerView listAdapterWithRecyclerView;
    private int orientation;
    private String propertyValue;
    private RecyclerView recyclerView;
    private String selection;
    private int selectionColor;
    private String selectionDetailText;
    private int selectionIndex;
    private boolean showFilter = false;
    private List<String> stringItems;
    private int textColor;
    private EditText txtSearchBox;

    static /* bridge */ /* synthetic */ ListAdapterWithRecyclerView -$$Nest$fgetlistAdapterWithRecyclerView(ListView listView) {
        return listView.listAdapterWithRecyclerView;
    }

    static /* bridge */ /* synthetic */ RecyclerView -$$Nest$fgetrecyclerView(ListView listView) {
        return listView.recyclerView;
    }

    public ListView(ComponentContainer componentContainer) {
        super(componentContainer);
        LinearLayout linearLayout;
        this.container = componentContainer;
        this.stringItems = new ArrayList();
        this.dictItems = new ArrayList();
        this.linearLayout = linearLayout = new LinearLayout((Context)componentContainer.$context());
        linearLayout.setOrientation(1);
        this.orientation = 0;
        this.layout = 0;
        this.recyclerView = new RecyclerView((Context)componentContainer.$context());
        RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(-1, -1);
        this.recyclerView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        layoutParams = new EditText((Context)componentContainer.$context());
        this.txtSearchBox = layoutParams;
        layoutParams.setSingleLine(true);
        this.txtSearchBox.setWidth(-2);
        this.txtSearchBox.setPadding(10, 10, 10, 10);
        this.txtSearchBox.setHint((CharSequence)"Search list...");
        if (!AppInventorCompatActivity.isClassicMode()) {
            this.txtSearchBox.setBackgroundColor(-1);
        }
        if (componentContainer.$form().isDarkTheme()) {
            this.txtSearchBox.setTextColor(-16777216);
            this.txtSearchBox.setHintTextColor(-16777216);
        }
        this.txtSearchBox.addTextChangedListener(new TextWatcher((ListView)this){
            final ListView this$0;
            {
                this.this$0 = listView;
            }

            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }

            public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
                if (charSequence.length() > 0) {
                    if (!ListView.-$$Nest$fgetlistAdapterWithRecyclerView(this.this$0).hasVisibleItems()) {
                        this.this$0.setAdapterData();
                    }
                    ListView.-$$Nest$fgetlistAdapterWithRecyclerView(this.this$0).getFilter().filter(charSequence);
                    ListView.-$$Nest$fgetrecyclerView(this.this$0).setAdapter((RecyclerView.Adapter)ListView.-$$Nest$fgetlistAdapterWithRecyclerView(this.this$0));
                } else {
                    this.this$0.setAdapterData();
                }
            }
        });
        if (this.showFilter) {
            this.txtSearchBox.setVisibility(0);
        } else {
            this.txtSearchBox.setVisibility(8);
        }
        this.BackgroundColor(-16777216);
        this.SelectionColor(-3355444);
        this.TextColor(-1);
        this.TextColorDetail(-1);
        this.FontSize(22.0f);
        this.FontSizeDetail(14.0f);
        this.FontTypeface("0");
        this.FontTypefaceDetail("0");
        this.ImageWidth(200);
        this.ImageHeight(200);
        this.ElementsFromString("");
        this.ListData("");
        linearLayout.addView((View)this.txtSearchBox);
        linearLayout.addView((View)this.recyclerView);
        linearLayout.requestLayout();
        componentContainer.$add((AndroidViewComponent)this);
        this.Width(-2);
        this.ListViewLayout(0);
        this.SelectionIndex(0);
    }

    @SimpleEvent(description="Simple event to be raised after the an element has been chosen in the list. The selected element is available in the Selection property.")
    public void AfterPicking() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "AfterPicking", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The color of the listview background.")
    public int BackgroundColor() {
        return this.backgroundColor;
    }

    @DesignerProperty(defaultValue="&HFF000000", editorType="color")
    @SimpleProperty
    public void BackgroundColor(int n) {
        this.backgroundColor = n;
        this.recyclerView.setBackgroundColor(n);
        this.linearLayout.setBackgroundColor(this.backgroundColor);
    }

    @SimpleFunction(description="Create a ListView entry. MainText is required. DetailText and ImageName are optional.")
    public YailDictionary CreateElement(String string, String string2, String string3) {
        YailDictionary yailDictionary = new YailDictionary();
        yailDictionary.put("Text1", string);
        yailDictionary.put("Text2", string2);
        yailDictionary.put("Image", string3);
        return yailDictionary;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public YailList Elements() {
        if (this.dictItems.size() > 0) {
            return YailList.makeList(this.dictItems);
        }
        return ElementsUtil.makeYailListFromList(this.stringItems);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="List of elements to show in the ListView. Depending on the ListView, this may be a list of strings or a list of 3-element sub-lists containing Text, Description, and Image file name.")
    public void Elements(YailList yailList) {
        this.dictItems.clear();
        this.stringItems = new ArrayList();
        if (yailList.size() > 0) {
            if (yailList.getObject(0) instanceof YailDictionary) {
                for (int i = 0; i < yailList.size(); ++i) {
                    YailDictionary yailDictionary;
                    Object object2 = yailList.getObject(i);
                    if (object2 instanceof YailDictionary) {
                        yailDictionary = (YailDictionary)((Object)object2);
                        this.dictItems.add(i, (Object)yailDictionary);
                        continue;
                    }
                    yailDictionary = new YailDictionary();
                    yailDictionary.put("Text1", YailList.YailListElementToString((Object)object2));
                    this.dictItems.add(i, (Object)yailDictionary);
                }
            } else {
                this.stringItems = ElementsUtil.elementsStrings((YailList)yailList, (String)LOG_TAG);
            }
        }
        this.setAdapterData();
    }

    @DesignerProperty(defaultValue="", editorType="textArea")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The TextView elements specified as a string with the stringItems separated by commas such as: Cheese,Fruit,Bacon,Radish. Each word before the comma will be an element in the list.")
    public void ElementsFromString(String string) {
        this.stringItems = ElementsUtil.elementsListFromString((String)string);
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The text size of the listview stringItems.", userVisible=false)
    public float FontSize() {
        return this.fontSizeMain;
    }

    @SimpleProperty
    public void FontSize(float f) {
        this.fontSizeMain = !(f > 1000.0f) && !(f < 1.0f) ? f : 999.0f;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The text size of the listview stringItems.")
    public float FontSizeDetail() {
        return this.fontSizeDetail;
    }

    @DesignerProperty(defaultValue="14.0", editorType="non_negative_float")
    @SimpleProperty
    public void FontSizeDetail(float f) {
        this.fontSizeDetail = !(f > 1000.0f) && !(f < 1.0f) ? f : 999.0f;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public String FontTypeface() {
        return this.fontTypeface;
    }

    @DesignerProperty(defaultValue="0", editorType="typeface")
    @SimpleProperty(userVisible=false)
    public void FontTypeface(String string) {
        this.fontTypeface = string;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public String FontTypefaceDetail() {
        return this.fontTypeDetail;
    }

    @DesignerProperty(defaultValue="0", editorType="typeface")
    @SimpleProperty(userVisible=false)
    public void FontTypefaceDetail(String string) {
        this.fontTypeDetail = string;
        this.setAdapterData();
    }

    @SimpleFunction(description="Get the Detail Text of a ListView element.")
    public String GetDetailText(YailDictionary yailDictionary) {
        return yailDictionary.get("Text2").toString();
    }

    @SimpleFunction(description="Get the filename of the image of a ListView element that has been uploaded to Media.")
    public String GetImageName(YailDictionary yailDictionary) {
        return yailDictionary.get("Image").toString();
    }

    @SimpleFunction(description="Get the Main Text of a ListView element.")
    public String GetMainText(YailDictionary yailDictionary) {
        return yailDictionary.get("Text1").toString();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Determines the height of the list on the view.")
    public void Height(int n) {
        int n2 = n;
        if (n == -1) {
            n2 = -2;
        }
        super.Height(n2);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The image height of the listview image stringItems.")
    public int ImageHeight() {
        return this.imageHeight;
    }

    @DesignerProperty(defaultValue="200", editorType="non_negative_integer")
    @SimpleProperty
    public void ImageHeight(int n) {
        this.imageHeight = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The image width of the listview image.")
    public int ImageWidth() {
        return this.imageWidth;
    }

    @DesignerProperty(defaultValue="200", editorType="non_negative_integer")
    @SimpleProperty
    public void ImageWidth(int n) {
        this.imageWidth = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, userVisible=false)
    public String ListData() {
        return this.propertyValue;
    }

    @DesignerProperty(editorType="ListViewAddData")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, userVisible=false)
    public void ListData(String string) {
        block7: {
            this.propertyValue = string;
            this.dictItems.clear();
            if (string != null && string != "") {
                int n;
                JSONArray jSONArray;
                try {
                    jSONArray = new JSONArray(string);
                    n = 0;
                }
                catch (JSONException jSONException) {
                    Log.e((String)LOG_TAG, (String)"Malformed JSON in ListView.ListData", (Throwable)jSONException);
                    this.container.$form().dispatchErrorOccurredEvent((Component)this, "ListView.ListData", 0, jSONException.getMessage());
                }
                while (true) {
                    block8: {
                        if (n >= jSONArray.length()) break block7;
                        JSONObject jSONObject = jSONArray.getJSONObject(n);
                        YailDictionary yailDictionary = new YailDictionary();
                        if (!jSONObject.has("Text1")) break block8;
                        yailDictionary.put("Text1", jSONObject.getString("Text1"));
                        string = jSONObject.has("Text2") ? jSONObject.getString("Text2") : "";
                        yailDictionary.put("Text2", string);
                        string = jSONObject.has("Image") ? jSONObject.getString("Image") : "";
                        yailDictionary.put("Image", string);
                        this.dictItems.add((Object)yailDictionary);
                    }
                    ++n;
                }
            }
        }
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public int ListViewLayout() {
        return this.layout;
    }

    @DesignerProperty(defaultValue="0", editorType="ListViewLayout")
    @SimpleProperty(userVisible=false)
    public void ListViewLayout(int n) {
        this.layout = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public int Orientation() {
        return this.orientation;
    }

    @DesignerProperty(defaultValue="0", editorType="recyclerview_orientation")
    @SimpleProperty(description="Specifies the layout's orientation (vertical, horizontal). ")
    public void Orientation(int n) {
        this.orientation = n;
        this.setAdapterData();
    }

    @SimpleFunction(description="Reload the ListView to reflect any changes in the data.")
    public void Refresh() {
        this.setAdapterData();
    }

    @SimpleFunction(description="Removes Item from list at a given index")
    public void RemoveItemAtIndex(int n) {
        if (n >= 1 && n <= Math.max((int)this.dictItems.size(), (int)this.stringItems.size())) {
            if (this.dictItems.size() >= n) {
                this.dictItems.remove(n - 1);
            }
            if (this.stringItems.size() >= n) {
                this.stringItems.remove(n - 1);
            }
            this.setAdapterData();
            return;
        }
        this.container.$form().dispatchErrorOccurredEvent((Component)this, "RemoveItemAtIndex", 4601, n);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the text last selected in the ListView.")
    public String Selection() {
        return this.selection;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty
    public void Selection(String string) {
        this.selection = string;
        if (!this.dictItems.isEmpty()) {
            for (int i = 0; i < this.dictItems.size(); ++i) {
                YailDictionary yailDictionary = (YailDictionary)((Object)this.dictItems.get(i));
                if (yailDictionary.get("Text1").toString() == string) {
                    this.selectionIndex = i + 1;
                    this.selectionDetailText = ElementsUtil.toStringEmptyIfNull((Object)yailDictionary.get("Text2"));
                    break;
                }
                this.selectionIndex = 0;
            }
        } else {
            this.selectionIndex = ElementsUtil.setSelectedIndexFromValueInStringList((String)string, this.stringItems);
        }
        this.SelectionIndex(this.selectionIndex);
    }

    @SimpleProperty(description="The color of the item when it is selected.")
    public int SelectionColor() {
        return this.selectionColor;
    }

    @DesignerProperty(defaultValue="&HFFCCCCCC", editorType="color")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void SelectionColor(int n) {
        this.selectionColor = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the secondary text of the selected row in the ListView.")
    public String SelectionDetailText() {
        return this.selectionDetailText;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The index of the currently selected item, starting at 1.  If no item is selected, the value will be 0.  If an attempt is made to set this to a number less than 1 or greater than the number of stringItems in the ListView, SelectionIndex will be set to 0, and Selection will be set to the empty text.")
    public int SelectionIndex() {
        return this.selectionIndex;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Specifies the one-indexed position of the selected item in the ListView. This could be used to retrievethe text at the chosen position. If an attempt is made to set this to a number less than 1 or greater than the number of stringItems in the ListView, SelectionIndex will be set to 0, and Selection will be set to the empty text.")
    public void SelectionIndex(int n) {
        if (!this.dictItems.isEmpty()) {
            this.selectionIndex = n = ElementsUtil.selectionIndex((int)n, (YailList)YailList.makeList(this.dictItems));
            if (n > 0) {
                this.selection = ((YailDictionary)((Object)this.dictItems.get(n - 1))).get("Text1").toString();
                this.selectionDetailText = ElementsUtil.toStringEmptyIfNull((Object)((YailDictionary)((Object)this.dictItems.get(this.selectionIndex - 1))).get("Text2").toString());
            } else {
                this.selection = "";
                this.selectionDetailText = "";
            }
        } else {
            this.selectionIndex = ElementsUtil.selectionIndexInStringList((int)n, this.stringItems);
            this.selection = ElementsUtil.setSelectionFromIndexInStringList((int)n, this.stringItems);
            this.selectionDetailText = "";
        }
        ListAdapterWithRecyclerView listAdapterWithRecyclerView = this.listAdapterWithRecyclerView;
        if (listAdapterWithRecyclerView != null) {
            listAdapterWithRecyclerView.toggleSelection(this.selectionIndex - 1);
        }
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(description="Sets visibility of ShowFilterBar. True will show the bar, False will hide it.")
    public void ShowFilterBar(boolean bl) {
        this.showFilter = bl;
        if (bl) {
            this.txtSearchBox.setVisibility(0);
        } else {
            this.txtSearchBox.setVisibility(8);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns current state of ShowFilterBar for visibility.")
    public boolean ShowFilterBar() {
        return this.showFilter;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The text color of the listview stringItems.")
    public int TextColor() {
        return this.textColor;
    }

    @DesignerProperty(defaultValue="&HFFFFFFFF", editorType="color")
    @SimpleProperty
    public void TextColor(int n) {
        this.textColor = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The text color of DetailText of listview stringItems. ")
    public int TextColorDetail() {
        return this.detailTextColor;
    }

    @DesignerProperty(defaultValue="&HFFFFFFFF", editorType="color")
    @SimpleProperty
    public void TextColorDetail(int n) {
        this.detailTextColor = n;
        this.setAdapterData();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The text size of the listview items.")
    public int TextSize() {
        return Math.round((float)this.fontSizeMain);
    }

    @DesignerProperty(defaultValue="22", editorType="non_negative_integer")
    @SimpleProperty
    public void TextSize(int n) {
        int n2 = n;
        if (n > 1000) {
            n2 = 999;
        }
        this.FontSize(Float.valueOf((float)n2).floatValue());
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Determines the width of the list on the view.")
    public void Width(int n) {
        int n2 = n;
        if (n == -1) {
            n2 = -2;
        }
        super.Width(n2);
    }

    public View getView() {
        return this.linearLayout;
    }

    public void onItemClick(AdapterView<?> object2, View view, int n, long l) {
        object2 = (YailDictionary)((Object)object2.getAdapter().getItem(n));
        this.selection = ElementsUtil.toStringEmptyIfNull((Object)((YailDictionary)((Object)object2)).get("Text1").toString());
        this.selectionDetailText = ElementsUtil.toStringEmptyIfNull((Object)((YailDictionary)((Object)object2)).get("Text2"));
        this.selectionIndex = n + 1;
        this.AfterPicking();
    }

    public void setAdapterData() {
        LinearLayoutManager linearLayoutManager;
        if (!this.dictItems.isEmpty()) {
            this.listAdapterWithRecyclerView = new ListAdapterWithRecyclerView(this.container, this.dictItems, this.textColor, this.detailTextColor, this.fontSizeMain, this.fontSizeDetail, this.fontTypeface, this.fontTypeDetail, this.layout, this.backgroundColor, this.selectionColor, this.imageWidth, this.imageHeight, false);
            linearLayoutManager = this.orientation == 1 ? new LinearLayoutManager((Context)this.container.$context(), 0, false) : new LinearLayoutManager((Context)this.container.$context(), 1, false);
        } else {
            this.listAdapterWithRecyclerView = new ListAdapterWithRecyclerView(this.container, this.stringItems, this.textColor, this.fontSizeMain, this.fontTypeface, this.backgroundColor, this.selectionColor);
            linearLayoutManager = new LinearLayoutManager((Context)this.container.$context(), 1, false);
        }
        this.listAdapterWithRecyclerView.setOnItemClickListener((ListAdapterWithRecyclerView.ClickListener)new 2(this));
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.recyclerView.setAdapter((RecyclerView.Adapter)this.listAdapterWithRecyclerView);
    }
}

