/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.annotations;

import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.annotations.androidmanifest.ProviderElement;

public @interface UsesQueries {
    public IntentFilterElement[] intents() default {};

    public String[] packageNames() default {};

    public ProviderElement[] providers() default {};
}

