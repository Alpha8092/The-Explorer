/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.Override
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.SingleValueSensor;

@DesignerComponent(category=ComponentCategory.SENSORS, description="A sensor component that can measure the ambient (external) temperature. Most Android devices do not have this sensor.", iconName="images/thermometer.png", nonVisible=true, version=1)
@SimpleObject
public class Thermometer
extends SingleValueSensor {
    public Thermometer(ComponentContainer componentContainer) {
        super(componentContainer.$form(), 13);
    }

    @SimpleProperty(description="The temperature in degrees Celsius, if the sensor is available and enabled")
    public float Temperature() {
        return this.getValue();
    }

    @SimpleEvent(description="Called when a change is detected in the temperature (in degrees Celsius).")
    public void TemperatureChanged(float f) {
        EventDispatcher.dispatchEvent((Component)this, "TemperatureChanged", Float.valueOf((float)f));
    }

    @Override
    protected void onValueChanged(float f) {
        this.TemperatureChanged(f);
    }
}

