/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Spinner
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.util.ElementsUtil
 *  com.google.appinventor.components.runtime.util.HoneycombUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.os.Build;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.ElementsUtil;
import com.google.appinventor.components.runtime.util.HoneycombUtil;
import com.google.appinventor.components.runtime.util.YailList;

@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="<p>A spinner component that displays a pop-up with a list of elements. These elements can be set in the Designer or Blocks Editor by setting the<code>ElementsFromString</code> property to a string-separated concatenation (for example, <em>choice 1, choice 2, choice 3</em>) or by setting the <code>Elements</code> property to a List in the Blocks editor. Spinners are created with the first item already selected. So selecting  it does not generate an After Picking event. Consequently it's useful to make the  first Spinner item be a non-choice like \"Select from below...\". </p>", iconName="images/spinner.png", nonVisible=false, version=1)
@SimpleObject
public final class Spinner
extends AndroidViewComponent
implements AdapterView.OnItemSelectedListener {
    private ArrayAdapter<String> adapter;
    private YailList items = new YailList();
    private int oldAdapterCount;
    private int oldSelectionIndex;
    private final android.widget.Spinner view;

    public Spinner(ComponentContainer componentContainer) {
        super(componentContainer);
        ArrayAdapter arrayAdapter;
        this.view = Build.VERSION.SDK_INT < 11 ? new android.widget.Spinner((Context)componentContainer.$context()) : HoneycombUtil.makeSpinner((Context)componentContainer.$context());
        this.adapter = arrayAdapter = new ArrayAdapter((Context)componentContainer.$context(), 17367048);
        arrayAdapter.setDropDownViewResource(17367058);
        this.view.setAdapter(this.adapter);
        this.view.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        componentContainer.$add((AndroidViewComponent)this);
        this.Prompt("");
        this.oldSelectionIndex = this.SelectionIndex();
    }

    private void setAdapterData(String[] stringArray) {
        this.oldAdapterCount = this.adapter.getCount();
        this.adapter.clear();
        for (int i = 0; i < stringArray.length; ++i) {
            this.adapter.add((Object)stringArray[i]);
        }
    }

    @SimpleEvent(description="Event called after the user selects an item from the dropdown list.")
    public void AfterSelecting(String string) {
        EventDispatcher.dispatchEvent((Component)this, "AfterSelecting", string);
    }

    @SimpleFunction(description="Displays the dropdown list for selection, same action as when the user clicks on the spinner.")
    public void DisplayDropdown() {
        this.view.performClick();
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="returns a list of text elements to be picked from.")
    public YailList Elements() {
        return this.items;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Adds the passed text element to the Spinner list")
    public void Elements(YailList yailList) {
        if (yailList.size() == 0) {
            this.SelectionIndex(0);
        } else if (yailList.size() < this.items.size() && this.SelectionIndex() == this.items.size()) {
            this.SelectionIndex(yailList.size());
        }
        this.items = ElementsUtil.elements((YailList)yailList, (String)"Spinner");
        super.setAdapterData(yailList.toStringArray());
    }

    @DesignerProperty(defaultValue="", editorType="textArea")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the Spinner list to the elements passed in the comma-separated string")
    public void ElementsFromString(String string) {
        this.Elements(ElementsUtil.elementsFromString((String)string));
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Text with the current title for the Spinner window")
    public String Prompt() {
        return this.view.getPrompt().toString();
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Sets the Spinner window prompt to the given title")
    public void Prompt(String string) {
        this.view.setPrompt((CharSequence)string);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the current selected item in the spinner ")
    public String Selection() {
        String string = this.SelectionIndex() == 0 ? "" : (String)this.view.getItemAtPosition(this.SelectionIndex() - 1);
        return string;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Set the selected item in the spinner")
    public void Selection(String string) {
        this.SelectionIndex(ElementsUtil.setSelectedIndexFromValue((String)string, (YailList)this.items));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The index of the currently selected item, starting at 1. If no item is selected, the value will be 0.")
    public int SelectionIndex() {
        return ElementsUtil.selectionIndex((int)(this.view.getSelectedItemPosition() + 1), (YailList)this.items);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Set the spinner selection to the element at the given index.If an attempt is made to set this to a number less than 1 or greater than the number of items in the Spinner, SelectionIndex will be set to 0, and Selection will be set to empty.")
    public void SelectionIndex(int n) {
        this.oldSelectionIndex = this.SelectionIndex();
        this.view.setSelection(ElementsUtil.selectionIndex((int)n, (YailList)this.items) - 1);
    }

    public View getView() {
        return this.view;
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
        if (this.oldAdapterCount == 0 && this.adapter.getCount() > 0 && this.oldSelectionIndex == 0 || this.oldAdapterCount > this.adapter.getCount() && this.oldSelectionIndex > this.adapter.getCount()) {
            this.SelectionIndex(n + 1);
            this.oldAdapterCount = this.adapter.getCount();
        } else {
            this.SelectionIndex(n + 1);
            this.AfterSelecting(this.Selection());
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
        this.view.setSelection(0);
    }
}

