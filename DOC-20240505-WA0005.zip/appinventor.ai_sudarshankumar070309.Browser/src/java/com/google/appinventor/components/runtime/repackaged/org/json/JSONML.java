/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.XML
 *  com.google.appinventor.components.runtime.repackaged.org.json.XMLTokener
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.Iterator
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONArray;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.XML;
import com.google.appinventor.components.runtime.repackaged.org.json.XMLTokener;
import java.util.Iterator;

public class JSONML {
    private static Object parse(XMLTokener object, boolean bl, JSONArray object2) throws JSONException {
        block0: while (object.more()) {
            Object object3 = object.nextContent();
            if (object3 == XML.LT) {
                object3 = object.nextToken();
                if (object3 instanceof Character) {
                    if (object3 == XML.SLASH) {
                        object2 = object.nextToken();
                        if (object2 instanceof String) {
                            if (object.nextToken() == XML.GT) {
                                return object2;
                            }
                            throw object.syntaxError("Misshaped close tag");
                        }
                        throw new JSONException(new StringBuffer().append("Expected a closing name instead of '").append(object2).append("'.").toString());
                    }
                    if (object3 == XML.BANG) {
                        int n = object.next();
                        if (n == 45) {
                            if (object.next() == '-') {
                                object.skipPast("-->");
                                continue;
                            }
                            object.back();
                            continue;
                        }
                        if (n == 91) {
                            if (object.nextToken().equals((Object)"CDATA") && object.next() == '[') {
                                if (object2 == null) continue;
                                ((JSONArray)object2).put(object.nextCDATA());
                                continue;
                            }
                            throw object.syntaxError("Expected 'CDATA['");
                        }
                        int n2 = 1;
                        while ((object3 = object.nextMeta()) != null) {
                            if (object3 == XML.LT) {
                                n = n2 + '\u0001';
                            } else {
                                n = n2;
                                if (object3 == XML.GT) {
                                    n = n2 - 1;
                                }
                            }
                            n2 = n;
                            if (n > 0) continue;
                            continue block0;
                        }
                        throw object.syntaxError("Missing '>' after '<!'.");
                    }
                    if (object3 == XML.QUEST) {
                        object.skipPast("?>");
                        continue;
                    }
                    throw object.syntaxError("Misshaped tag");
                }
                if (object3 instanceof String) {
                    String string = (String)object3;
                    JSONArray jSONArray = new JSONArray();
                    JSONObject jSONObject = new JSONObject();
                    if (bl) {
                        jSONArray.put(string);
                        if (object2 != null) {
                            ((JSONArray)object2).put(jSONArray);
                        }
                    } else {
                        jSONObject.put("tagName", (Object)string);
                        if (object2 != null) {
                            ((JSONArray)object2).put(jSONObject);
                        }
                    }
                    object3 = null;
                    while (true) {
                        Object object4 = object3;
                        if (object3 == null) {
                            object4 = object.nextToken();
                        }
                        if (object4 == null) break;
                        if (!(object4 instanceof String)) {
                            if (bl && jSONObject.length() > 0) {
                                jSONArray.put(jSONObject);
                            }
                            if (object4 == XML.SLASH) {
                                if (object.nextToken() == XML.GT) {
                                    if (object2 != null) continue block0;
                                    if (bl) {
                                        return jSONArray;
                                    }
                                    return jSONObject;
                                }
                                throw object.syntaxError("Misshaped tag");
                            }
                            if (object4 == XML.GT) {
                                object3 = (String)JSONML.parse(object, bl, jSONArray);
                                if (object3 == null) continue block0;
                                if (object3.equals((Object)string)) {
                                    if (!bl && jSONArray.length() > 0) {
                                        jSONObject.put("childNodes", (Object)jSONArray);
                                    }
                                    if (object2 != null) continue block0;
                                    if (bl) {
                                        return jSONArray;
                                    }
                                    return jSONObject;
                                }
                                throw object.syntaxError(new StringBuffer().append("Mismatched '").append(string).append("' and '").append((String)object3).append("'").toString());
                            }
                            throw object.syntaxError("Misshaped tag");
                        }
                        object4 = (String)object4;
                        if (!bl && ("tagName".equals(object4) || "childNode".equals(object4))) {
                            throw object.syntaxError("Reserved attribute.");
                        }
                        object3 = object.nextToken();
                        if (object3 == XML.EQ) {
                            object3 = object.nextToken();
                            if (object3 instanceof String) {
                                jSONObject.accumulate((String)object4, XML.stringToValue((String)((String)object3)));
                                object3 = null;
                                continue;
                            }
                            throw object.syntaxError("Missing value");
                        }
                        jSONObject.accumulate((String)object4, (Object)"");
                    }
                    throw object.syntaxError("Misshaped tag");
                }
                throw object.syntaxError(new StringBuffer().append("Bad tagName '").append(object3).append("'.").toString());
            }
            if (object2 == null) continue;
            if (object3 instanceof String) {
                object3 = XML.stringToValue((String)((String)object3));
            }
            ((JSONArray)object2).put(object3);
        }
        object = object.syntaxError("Bad XML");
        throw object;
    }

    public static JSONArray toJSONArray(XMLTokener xMLTokener) throws JSONException {
        return (JSONArray)JSONML.parse(xMLTokener, true, null);
    }

    public static JSONArray toJSONArray(String string) throws JSONException {
        return JSONML.toJSONArray(new XMLTokener(string));
    }

    public static JSONObject toJSONObject(XMLTokener xMLTokener) throws JSONException {
        return (JSONObject)JSONML.parse(xMLTokener, false, null);
    }

    public static JSONObject toJSONObject(String string) throws JSONException {
        return JSONML.toJSONObject(new XMLTokener(string));
    }

    public static String toString(JSONArray jSONArray) throws JSONException {
        int n;
        int n2;
        StringBuffer stringBuffer = new StringBuffer();
        String string = jSONArray.getString(0);
        XML.noSpace((String)string);
        string = XML.escape((String)string);
        stringBuffer.append('<');
        stringBuffer.append(string);
        Object object = jSONArray.opt(1);
        if (object instanceof JSONObject) {
            n2 = 2;
            object = (JSONObject)object;
            Iterator iterator = object.keys();
            while (true) {
                n = n2;
                if (iterator.hasNext()) {
                    String string2 = iterator.next().toString();
                    XML.noSpace((String)string2);
                    String string3 = object.optString(string2);
                    if (string3 == null) continue;
                    stringBuffer.append(' ');
                    stringBuffer.append(XML.escape((String)string2));
                    stringBuffer.append('=');
                    stringBuffer.append('\"');
                    stringBuffer.append(XML.escape((String)string3));
                    stringBuffer.append('\"');
                    continue;
                }
                break;
            }
        } else {
            n = 1;
        }
        if (n >= (n2 = jSONArray.length())) {
            stringBuffer.append('/');
            stringBuffer.append('>');
        } else {
            stringBuffer.append('>');
            do {
                object = jSONArray.get(n);
                ++n;
                if (object == null) continue;
                if (object instanceof String) {
                    stringBuffer.append(XML.escape((String)object.toString()));
                    continue;
                }
                if (object instanceof JSONObject) {
                    stringBuffer.append(JSONML.toString((JSONObject)object));
                    continue;
                }
                if (!(object instanceof JSONArray)) continue;
                stringBuffer.append(JSONML.toString((JSONArray)object));
            } while (n < n2);
            stringBuffer.append('<');
            stringBuffer.append('/');
            stringBuffer.append(string);
            stringBuffer.append('>');
        }
        return stringBuffer.toString();
    }

    public static String toString(JSONObject object) throws JSONException {
        Object object2;
        StringBuffer stringBuffer = new StringBuffer();
        String string = object.optString("tagName");
        if (string == null) {
            return XML.escape((String)object.toString());
        }
        XML.noSpace((String)string);
        string = XML.escape((String)string);
        stringBuffer.append('<');
        stringBuffer.append(string);
        Iterator iterator = object.keys();
        while (iterator.hasNext()) {
            String string2 = iterator.next().toString();
            if ("tagName".equals((Object)string2) || "childNodes".equals((Object)string2)) continue;
            XML.noSpace((String)string2);
            object2 = object.optString(string2);
            if (object2 == null) continue;
            stringBuffer.append(' ');
            stringBuffer.append(XML.escape((String)string2));
            stringBuffer.append('=');
            stringBuffer.append('\"');
            stringBuffer.append(XML.escape((String)object2));
            stringBuffer.append('\"');
        }
        object2 = object.optJSONArray("childNodes");
        if (object2 == null) {
            stringBuffer.append('/');
            stringBuffer.append('>');
        } else {
            stringBuffer.append('>');
            int n = ((JSONArray)object2).length();
            for (int i = 0; i < n; ++i) {
                object = ((JSONArray)object2).get(i);
                if (object == null) continue;
                if (object instanceof String) {
                    stringBuffer.append(XML.escape((String)object.toString()));
                    continue;
                }
                if (object instanceof JSONObject) {
                    stringBuffer.append(JSONML.toString(object));
                    continue;
                }
                if (object instanceof JSONArray) {
                    stringBuffer.append(JSONML.toString((JSONArray)object));
                    continue;
                }
                stringBuffer.append(object.toString());
            }
            stringBuffer.append('<');
            stringBuffer.append('/');
            stringBuffer.append(string);
            stringBuffer.append('>');
        }
        return stringBuffer.toString();
    }
}

