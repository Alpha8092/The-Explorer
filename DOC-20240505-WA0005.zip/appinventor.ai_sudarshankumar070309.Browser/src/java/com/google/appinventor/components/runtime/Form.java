/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.res.Configuration
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.AsyncTask
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MenuItem$OnMenuItemClickListener
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.FrameLayout
 *  android.widget.ScrollView
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.ContextCompat
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.common.HorizontalAlignment
 *  com.google.appinventor.components.common.Permission
 *  com.google.appinventor.components.common.ScreenAnimation
 *  com.google.appinventor.components.common.ScreenOrientation
 *  com.google.appinventor.components.common.VerticalAlignment
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.Form$15$1
 *  com.google.appinventor.components.runtime.Form$6
 *  com.google.appinventor.components.runtime.LinearLayout
 *  com.google.appinventor.components.runtime.Notifier
 *  com.google.appinventor.components.runtime.util.AlignmentUtil
 *  com.google.appinventor.components.runtime.util.AnimationUtil
 *  com.google.appinventor.components.runtime.util.BulkPermissionRequest
 *  com.google.appinventor.components.runtime.util.ErrorMessages
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  com.google.appinventor.components.runtime.util.FullScreenVideoUtil
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.OnInitializeListener
 *  com.google.appinventor.components.runtime.util.PaintUtil
 *  com.google.appinventor.components.runtime.util.ScreenDensityUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.ViewUtil
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.lang.Void
 *  java.lang.reflect.InvocationTargetException
 *  java.net.URI
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Random
 *  java.util.Set
 *  org.json.JSONException
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.common.HorizontalAlignment;
import com.google.appinventor.components.common.Permission;
import com.google.appinventor.components.common.ScreenAnimation;
import com.google.appinventor.components.common.ScreenOrientation;
import com.google.appinventor.components.common.VerticalAlignment;
import com.google.appinventor.components.runtime.AccessibleComponent;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.LinearLayout;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.OnClearListener;
import com.google.appinventor.components.runtime.OnCreateOptionsMenuListener;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.OnNewIntentListener;
import com.google.appinventor.components.runtime.OnOptionsItemSelectedListener;
import com.google.appinventor.components.runtime.OnOrientationChangeListener;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.OnStopListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.ReplApplication;
import com.google.appinventor.components.runtime.ReplForm;
import com.google.appinventor.components.runtime.ScaledFrameLayout;
import com.google.appinventor.components.runtime.VideoPlayer;
import com.google.appinventor.components.runtime.collect.Lists;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.collect.Sets;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.multidex.MultiDex;
import com.google.appinventor.components.runtime.util.AlignmentUtil;
import com.google.appinventor.components.runtime.util.AnimationUtil;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import com.google.appinventor.components.runtime.util.FileUtil;
import com.google.appinventor.components.runtime.util.FullScreenVideoUtil;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.OnInitializeListener;
import com.google.appinventor.components.runtime.util.PaintUtil;
import com.google.appinventor.components.runtime.util.ScreenDensityUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.ViewUtil;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.json.JSONException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="Top-level component containing all other components in the program", showOnPalette=false, version=31)
@SimpleObject
@UsesPermissions(value={"android.permission.INTERNET"})
public class Form
extends AppInventorCompatActivity
implements Component,
ComponentContainer,
HandlesEventDispatching,
ViewTreeObserver.OnGlobalLayoutListener {
    public static final String APPINVENTOR_URL_SCHEME = "appinventor";
    private static final String ARGUMENT_NAME = "APP_INVENTOR_START";
    public static final String ASSETS_PREFIX = "file:///android_asset/";
    private static final int DEFAULT_ACCENT_COLOR;
    private static final int DEFAULT_PRIMARY_COLOR_DARK;
    private static final String LOG_TAG = "Form";
    public static final int MAX_PERMISSION_NONCE = 100000;
    private static final String RESULT_NAME = "APP_INVENTOR_RESULT";
    private static final int SWITCH_FORM_REQUEST_CODE = 1;
    private static boolean _initialized;
    protected static Form activeForm;
    private static boolean applicationIsBeingClosed;
    private static long minimumToastWait;
    private static int nextRequestCode;
    private static boolean sCompatibilityMode;
    private static boolean showListsAsJson;
    private String aboutScreen;
    private int accentColor;
    private boolean actionBarEnabled = false;
    private final HashMap<Integer, ActivityResultListener> activityResultMap;
    private final Map<Integer, Set<ActivityResultListener>> activityResultMultiMap;
    private AlignmentUtil alignmentSetter;
    private List<Component> allChildren = new ArrayList();
    protected final Handler androidUIHandler = new Handler();
    private int backgroundColor;
    private Drawable backgroundDrawable;
    private String backgroundImagePath = "";
    private boolean bigDefaultText;
    private ScreenAnimation closeAnimType;
    private float compatScalingFactor;
    private FileScope defaultFileScope;
    private float deviceDensity;
    private LinkedHashMap<Integer, PercentStorageRecord> dimChanges;
    private int formHeight;
    protected String formName;
    private int formWidth;
    private FrameLayout frameLayout;
    private FullScreenVideoUtil fullScreenVideoUtil;
    private boolean highContrast;
    private HorizontalAlignment horizontalAlignment;
    private boolean keyboardShown = false;
    private long lastToastTime;
    private String nextFormName;
    private final Set<OnClearListener> onClearListeners;
    private final Set<OnCreateOptionsMenuListener> onCreateOptionsMenuListeners;
    private final Set<OnDestroyListener> onDestroyListeners;
    private final Set<OnInitializeListener> onInitializeListeners;
    private final Set<OnNewIntentListener> onNewIntentListeners;
    private final Set<OnOptionsItemSelectedListener> onOptionsItemSelectedListeners;
    private final Set<OnOrientationChangeListener> onOrientationChangeListeners;
    private final Set<OnPauseListener> onPauseListeners;
    private final Set<OnResumeListener> onResumeListeners;
    private final Set<OnStopListener> onStopListeners;
    private ScreenAnimation openAnimType = ScreenAnimation.Default;
    private final HashMap<Integer, PermissionResultHandler> permissionHandlers;
    private final Random permissionRandom;
    private final Set<String> permissions;
    private int primaryColor;
    private int primaryColorDark;
    private ProgressDialog progress;
    private ScaledFrameLayout scaleLayout;
    private boolean screenInitialized;
    private boolean scrollable;
    private boolean showStatusBar = true;
    private boolean showTitle = true;
    protected String startupValue = "";
    protected String title = "";
    private boolean usesDarkTheme;
    private boolean usesDefaultBackground;
    private VerticalAlignment verticalAlignment;
    private LinearLayout viewLayout;

    static /* bridge */ /* synthetic */ FrameLayout -$$Nest$fgetframeLayout(Form form) {
        return form.frameLayout;
    }

    static /* bridge */ /* synthetic */ Set -$$Nest$fgetonInitializeListeners(Form form) {
        return form.onInitializeListeners;
    }

    static /* bridge */ /* synthetic */ HashMap -$$Nest$fgetpermissionHandlers(Form form) {
        return form.permissionHandlers;
    }

    static /* bridge */ /* synthetic */ Random -$$Nest$fgetpermissionRandom(Form form) {
        return form.permissionRandom;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputscreenInitialized(Form form, boolean bl) {
        form.screenInitialized = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mcloseApplicationFromMenu(Form form) {
        form.closeApplicationFromMenu();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mrecomputeLayout(Form form) {
        form.recomputeLayout();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mshowAboutApplicationNotification(Form form) {
        form.showAboutApplicationNotification();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mshowExitApplicationNotification(Form form) {
        form.showExitApplicationNotification();
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$sfgetsCompatibilityMode() {
        return sCompatibilityMode;
    }

    static {
        DEFAULT_PRIMARY_COLOR_DARK = PaintUtil.hexStringToInt((String)"&HFF303F9F");
        DEFAULT_ACCENT_COLOR = PaintUtil.hexStringToInt((String)"&HFFFF4081");
        nextRequestCode = 2;
        minimumToastWait = 10000000000L;
        _initialized = false;
    }

    public Form() {
        this.closeAnimType = ScreenAnimation.Default;
        this.primaryColor = DEFAULT_PRIMARY_COLOR;
        this.primaryColorDark = DEFAULT_PRIMARY_COLOR_DARK;
        this.accentColor = DEFAULT_ACCENT_COLOR;
        this.permissions = new HashSet();
        this.defaultFileScope = FileScope.App;
        this.activityResultMap = Maps.newHashMap();
        this.activityResultMultiMap = Maps.newHashMap();
        this.onStopListeners = Sets.newHashSet();
        this.onClearListeners = Sets.newHashSet();
        this.onNewIntentListeners = Sets.newHashSet();
        this.onResumeListeners = Sets.newHashSet();
        this.onOrientationChangeListeners = Sets.newHashSet();
        this.onPauseListeners = Sets.newHashSet();
        this.onDestroyListeners = Sets.newHashSet();
        this.onInitializeListeners = Sets.newHashSet();
        this.onCreateOptionsMenuListeners = Sets.newHashSet();
        this.onOptionsItemSelectedListeners = Sets.newHashSet();
        this.permissionHandlers = Maps.newHashMap();
        this.permissionRandom = new Random();
        this.lastToastTime = System.nanoTime() - minimumToastWait;
        this.dimChanges = new LinkedHashMap();
    }

    private void closeApplication() {
        applicationIsBeingClosed = true;
        this.finish();
        if (this.formName.equals((Object)"Screen1")) {
            System.exit((int)0);
        }
    }

    private void closeApplicationFromMenu() {
        this.closeApplication();
    }

    private static Object decodeJSONStringForForm(String string, String string2) {
        Object object2;
        Log.i((String)LOG_TAG, (String)("decodeJSONStringForForm -- decoding JSON representation:" + string));
        Object object3 = "";
        object3 = object2 = JsonUtil.getObjectFromJson((String)string, (boolean)true);
        String string3 = object2.toString();
        object3 = object2;
        object3 = object2;
        StringBuilder stringBuilder = new StringBuilder();
        object3 = object2;
        try {
            Log.i((String)LOG_TAG, (String)stringBuilder.append("decodeJSONStringForForm -- got decoded JSON:").append(string3).toString());
            object3 = object2;
        }
        catch (JSONException jSONException) {
            Form form = activeForm;
            form.dispatchErrorOccurredEvent(form, string2, 903, string);
        }
        return object3;
    }

    public static void finishActivity() {
        Form form = activeForm;
        if (form != null) {
            form.closeForm(null);
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    public static void finishActivityWithResult(Object object2) {
        Object object3 = activeForm;
        if (object3 != null) {
            if (object3 instanceof ReplForm) {
                ((ReplForm)object3).setResult(object2);
                activeForm.closeForm(null);
            } else {
                object3 = Form.jsonEncodeForForm(object2, "close screen with value");
                object2 = new Intent();
                object2.putExtra(RESULT_NAME, (String)object3);
                activeForm.closeForm((Intent)object2);
            }
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    public static void finishActivityWithTextResult(String string) {
        if (activeForm != null) {
            Intent intent = new Intent();
            intent.putExtra(RESULT_NAME, string);
            activeForm.closeForm(intent);
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    public static void finishApplication() {
        Form form = activeForm;
        if (form != null) {
            form.closeApplicationFromBlocks();
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    private Integer generateHashCode(AndroidViewComponent androidViewComponent, Dim dim) {
        if (dim == Dim.HEIGHT) {
            return androidViewComponent.hashCode() * 2 + 1;
        }
        return androidViewComponent.hashCode() * 2;
    }

    private static int generateNewRequestCode() {
        int n = nextRequestCode;
        nextRequestCode = n + 1;
        return n;
    }

    public static Form getActiveForm() {
        return activeForm;
    }

    public static boolean getCompatibilityMode() {
        return sCompatibilityMode;
    }

    public static String getStartText() {
        Form form = activeForm;
        if (form != null) {
            return form.startupValue;
        }
        throw new IllegalStateException("activeForm is null");
    }

    public static Object getStartValue() {
        Form form = activeForm;
        if (form != null) {
            return Form.decodeJSONStringForForm(form.startupValue, "get start value");
        }
        throw new IllegalStateException("activeForm is null");
    }

    protected static String jsonEncodeForForm(Object object2, String string) {
        String string2 = "";
        String string3 = object2.toString();
        Log.i((String)LOG_TAG, (String)("jsonEncodeForForm -- creating JSON representation:" + string3));
        string2 = string3 = JsonUtil.getJsonRepresentation((Object)object2);
        string2 = string3;
        StringBuilder stringBuilder = new StringBuilder();
        string2 = string3;
        try {
            Log.i((String)LOG_TAG, (String)stringBuilder.append("jsonEncodeForForm -- got JSON representation:").append(string3).toString());
            string2 = string3;
        }
        catch (JSONException jSONException) {
            Form form = activeForm;
            form.dispatchErrorOccurredEvent(form, string, 904, object2.toString());
        }
        return string2;
    }

    private void populatePermissions() {
        try {
            PackageInfo packageInfo = this.getPackageManager().getPackageInfo(this.getPackageName(), 4096);
            Collections.addAll(this.permissions, (Object[])packageInfo.requestedPermissions);
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)"Exception while attempting to learn permissions.", (Throwable)exception);
        }
    }

    private void recomputeLayout() {
        Log.d((String)LOG_TAG, (String)"recomputeLayout called");
        Object object2 = this.frameLayout;
        if (object2 != null) {
            object2.removeAllViews();
        }
        boolean bl = this.titleBar != null && this.titleBar.getParent() == this.frameWithTitle;
        this.frameWithTitle.removeAllViews();
        if (bl) {
            this.frameWithTitle.addView((View)this.titleBar, new ViewGroup.LayoutParams(-1, -2));
        }
        if (this.scrollable) {
            this.frameLayout = new ScrollView((Context)this);
            if (Build.VERSION.SDK_INT >= 24) {
                ((ScrollView)this.frameLayout).setFillViewport(true);
            }
        } else {
            this.frameLayout = new FrameLayout((Context)this);
        }
        this.frameLayout.addView((View)this.viewLayout.getLayoutManager(), new ViewGroup.LayoutParams(-1, -1));
        this.setBackground((View)this.frameLayout);
        Log.d((String)LOG_TAG, (String)"About to create a new ScaledFrameLayout");
        object2 = new ScaledFrameLayout((Context)this);
        this.scaleLayout = object2;
        object2.addView((View)this.frameLayout, new ViewGroup.LayoutParams(-1, -1));
        this.frameWithTitle.addView((View)this.scaleLayout, new ViewGroup.LayoutParams(-1, -1));
        this.frameLayout.getViewTreeObserver().addOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
        this.scaleLayout.requestLayout();
        this.androidUIHandler.post(new Runnable(this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public void run() {
                if (Form.-$$Nest$fgetframeLayout(this.this$0) != null && Form.-$$Nest$fgetframeLayout(this.this$0).getWidth() != 0 && Form.-$$Nest$fgetframeLayout(this.this$0).getHeight() != 0) {
                    if (Form.-$$Nest$sfgetsCompatibilityMode()) {
                        this.this$0.Sizing("Fixed");
                    } else {
                        this.this$0.Sizing("Responsive");
                    }
                    this.this$0.ReplayFormOrientation();
                    this.this$0.frameWithTitle.requestLayout();
                } else {
                    this.this$0.androidUIHandler.post((Runnable)this);
                }
            }
        });
    }

    private void setBackground(View view) {
        Drawable drawable = this.backgroundDrawable;
        String string = this.backgroundImagePath;
        int n = -1;
        if (string != "" && drawable != null) {
            string = this.backgroundDrawable.getConstantState().newDrawable();
            int n2 = this.backgroundColor;
            if (n2 != 0) {
                n = n2;
            }
            string.setColorFilter(n, PorterDuff.Mode.DST_OVER);
        } else {
            int n3 = this.backgroundColor;
            if (n3 != 0) {
                n = n3;
            }
            string = new ColorDrawable(n);
        }
        ViewUtil.setBackgroundImage((View)view, (Drawable)string);
        view.invalidate();
    }

    private static void setBigDefaultTextRecursive(ComponentContainer object22, boolean bl) {
        for (Object object22 : object22.getChildren()) {
            if (object22 instanceof ComponentContainer) {
                Form.setBigDefaultTextRecursive((ComponentContainer)object22, bl);
                continue;
            }
            if (!(object22 instanceof AccessibleComponent)) continue;
            ((AccessibleComponent)object22).setLargeFont(bl);
        }
    }

    private static void setHighContrastRecursive(ComponentContainer object22, boolean bl) {
        for (Object object22 : object22.getChildren()) {
            if (object22 instanceof ComponentContainer) {
                Form.setHighContrastRecursive((ComponentContainer)object22, bl);
                continue;
            }
            if (!(object22 instanceof AccessibleComponent)) continue;
            ((AccessibleComponent)object22).setHighContrast(bl);
        }
    }

    private void showAboutApplicationNotification() {
        String string = this.aboutScreen;
        Notifier.oneButtonAlert((Activity)this, (String)(string + "<p><small><em>Invented with MIT App Inventor<br>appinventor.mit.edu</em></small></p>").replaceAll("\\n", "<br>"), (String)"About this app", (String)"Got it");
    }

    private void showExitApplicationNotification() {
        Runnable runnable = new Runnable(this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public void run() {
                Form.-$$Nest$mcloseApplicationFromMenu(this.this$0);
            }
        };
        Runnable runnable2 = new Runnable(this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public void run() {
            }
        };
        Notifier.twoButtonDialog((Activity)this, (String)"Stop this application and exit? You'll need to relaunch the application to use it again.", (String)"Stop application?", (String)"Stop and exit", (String)"Don't stop", (boolean)false, (Runnable)runnable, (Runnable)runnable2, (Runnable)runnable2);
    }

    public static void switchForm(String string) {
        Form form = activeForm;
        if (form != null) {
            form.startNewForm(string, null);
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    public static void switchFormWithStartValue(String string, Object object2) {
        Log.i((String)LOG_TAG, (String)("Open another screen with start value:" + string));
        Form form = activeForm;
        if (form != null) {
            form.startNewForm(string, object2);
            return;
        }
        throw new IllegalStateException("activeForm is null");
    }

    @Override
    public void $add(AndroidViewComponent androidViewComponent) {
        this.viewLayout.add(androidViewComponent);
        this.allChildren.add((Object)androidViewComponent);
    }

    @Override
    public Activity $context() {
        return this;
    }

    protected void $define() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Form $form() {
        return this;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Information about the screen.  It appears when \"About this Application\" is selected from the system menu. Use it to inform people about your app.  In multiple screen apps, each screen has its own AboutScreen info.")
    public String AboutScreen() {
        return this.aboutScreen;
    }

    @DesignerProperty(defaultValue="", editorType="textArea")
    @SimpleProperty
    public void AboutScreen(String string) {
        this.aboutScreen = string;
    }

    @SimpleProperty
    public int AccentColor() {
        return this.accentColor;
    }

    @DesignerProperty(defaultValue="&HFFFF4081", editorType="color")
    @SimpleProperty(category=PropertyCategory.THEMING, description="This is the accent color used for highlights and other user interface accents.", userVisible=false)
    public void AccentColor(int n) {
        this.accentColor = n;
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, userVisible=false)
    public void ActionBar(boolean bl) {
        if (SdkLevel.getLevel() < 11) {
            return;
        }
        if (this.actionBarEnabled != bl) {
            this.setActionBarEnabled(bl);
            if (bl) {
                this.hideTitleBar();
                this.actionBarEnabled = this.themeHelper.setActionBarVisible(this.showTitle);
            } else {
                this.maybeShowTitleBar();
                this.actionBarEnabled = this.themeHelper.setActionBarVisible(false);
            }
            this.actionBarEnabled = bl;
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="A number that encodes how contents of the screen are aligned  horizontally. The choices are: 1 = left aligned, 3 = horizontally centered,  2 = right aligned.")
    public int AlignHorizontal() {
        return this.horizontalAlignment.toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="1", editorType="horizontal_alignment")
    @SimpleProperty
    public void AlignHorizontal(@Options(value=HorizontalAlignment.class) int n) {
        HorizontalAlignment horizontalAlignment = HorizontalAlignment.fromUnderlyingValue((Integer)n);
        if (horizontalAlignment == null) {
            this.dispatchErrorOccurredEvent((Component)this, "HorizontalAlignment", 1401, n);
            return;
        }
        this.AlignHorizontalAbstract(horizontalAlignment);
    }

    public HorizontalAlignment AlignHorizontalAbstract() {
        return this.horizontalAlignment;
    }

    public void AlignHorizontalAbstract(HorizontalAlignment horizontalAlignment) {
        this.alignmentSetter.setHorizontalAlignment(horizontalAlignment);
        this.horizontalAlignment = horizontalAlignment;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="A number that encodes how the contents of the arrangement are aligned vertically. The choices are: 1 = aligned at the top, 2 = vertically centered, 3 = aligned at the bottom. Vertical alignment has no effect if the screen is scrollable.")
    public int AlignVertical() {
        return this.AlignVerticalAbstract().toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="1", editorType="vertical_alignment")
    @SimpleProperty
    public void AlignVertical(@Options(value=VerticalAlignment.class) int n) {
        VerticalAlignment verticalAlignment = VerticalAlignment.fromUnderlyingValue((Integer)n);
        if (verticalAlignment == null) {
            this.dispatchErrorOccurredEvent((Component)this, "VerticalAlignment", 1402, n);
            return;
        }
        this.AlignVerticalAbstract(verticalAlignment);
    }

    public VerticalAlignment AlignVerticalAbstract() {
        return this.verticalAlignment;
    }

    public void AlignVerticalAbstract(VerticalAlignment verticalAlignment) {
        this.alignmentSetter.setVerticalAlignment(verticalAlignment);
        this.verticalAlignment = verticalAlignment;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.GENERAL, description="This is the display name of the installed application in the phone.If the AppName is blank, it will be set to the name of the project when the project is built.", userVisible=false)
    public void AppName(String string) {
    }

    @SimpleFunction(description="Ask the user to grant access to a dangerous permission.")
    public void AskForPermission(@Options(value=Permission.class) String string) {
        String string2 = string;
        if (!string.contains((CharSequence)".")) {
            string2 = "android.permission." + string;
        }
        this.askPermission(string2, (PermissionResultHandler)new 6((Form)this));
    }

    public void AskForPermissionAbstract(Permission permission) {
        this.AskForPermission(permission.toUnderlyingValue());
    }

    @SimpleEvent(description="Device back button pressed.")
    public boolean BackPressed() {
        return EventDispatcher.dispatchEvent(this, "BackPressed", new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public int BackgroundColor() {
        return this.backgroundColor;
    }

    @DesignerProperty(defaultValue="&HFFFFFFFF", editorType="color")
    @SimpleProperty
    public void BackgroundColor(int n) {
        if (n == 0) {
            this.usesDefaultBackground = true;
        } else {
            this.usesDefaultBackground = false;
            this.backgroundColor = n;
        }
        super.setBackground((View)this.frameLayout);
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The screen background image.")
    public String BackgroundImage() {
        return this.backgroundImagePath;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The screen background image.")
    public void BackgroundImage(@Asset String string) {
        if (string == null) {
            string = "";
        }
        this.backgroundImagePath = string;
        try {
            this.backgroundDrawable = MediaUtil.getBitmapDrawable((Form)this, (String)string);
        }
        catch (IOException iOException) {
            String string2 = this.backgroundImagePath;
            Log.e((String)LOG_TAG, (String)("Unable to load " + string2));
            this.backgroundDrawable = null;
        }
        super.setBackground((View)this.frameLayout);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BigDefaultText(boolean bl) {
        this.bigDefaultText = bl;
        Form.setBigDefaultTextRecursive((ComponentContainer)this, bl);
        super.recomputeLayout();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="When checked, we will use high contrast mode")
    public boolean BigDefaultText() {
        return this.bigDefaultText;
    }

    @DesignerProperty(defaultValue="", editorType="subset_json")
    @SimpleProperty(category=PropertyCategory.GENERAL, description="Choose the set of components you\u2019ll need for your project. A smaller set is good for beginner projects, while experts can use all options to build complex apps. For example, the Beginner Toolkit gives you access to all the features you need for our novice tutorials and curriculum.</p><p>You can always change your toolkit in Project Properties, so your choice now won\u2019t limit the future possibilities for your app.</p>", userVisible=false)
    public void BlocksToolkit(String string) {
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The animation for closing current screen and returning  to the previous screen. Valid options are default, fade, zoom, slidehorizontal, slidevertical, and none")
    public String CloseScreenAnimation() {
        if (this.closeAnimType != null) {
            return this.CloseScreenAnimationAbstract().toUnderlyingValue();
        }
        return null;
    }

    @DesignerProperty(defaultValue="default", editorType="screen_animation")
    @SimpleProperty
    public void CloseScreenAnimation(@Options(value=ScreenAnimation.class) String string) {
        ScreenAnimation screenAnimation = ScreenAnimation.fromUnderlyingValue((String)string);
        if (screenAnimation == null) {
            this.dispatchErrorOccurredEvent((Component)this, "Screen", 905, string);
            return;
        }
        this.CloseScreenAnimationAbstract(screenAnimation);
    }

    public ScreenAnimation CloseScreenAnimationAbstract() {
        return this.closeAnimType;
    }

    public void CloseScreenAnimationAbstract(ScreenAnimation screenAnimation) {
        this.closeAnimType = screenAnimation;
    }

    public FileScope DefaultFileScope() {
        return this.defaultFileScope;
    }

    @DesignerProperty(defaultValue="App", editorType="file_scope")
    @SimpleProperty(category=PropertyCategory.GENERAL, userVisible=false)
    public void DefaultFileScope(FileScope fileScope) {
        this.defaultFileScope = fileScope;
    }

    @SimpleEvent(description="Event raised when an error occurs. Only some errors will raise this condition.  For those errors, the system will show a notification by default.  You can use this event handler to prescribe an error behavior different than the default.")
    public void ErrorOccurred(Component component, String string, int n, String string2) {
        String string3 = component.getClass().getName();
        String string4 = string3.substring(string3.lastIndexOf(".") + 1);
        string3 = this.formName;
        Log.e((String)LOG_TAG, (String)("Form " + string3 + " ErrorOccurred, errorNumber = " + n + ", componentType = " + string4 + ", functionName = " + string + ", messages = " + string2));
        if (!EventDispatcher.dispatchEvent((Component)this, "ErrorOccurred", component, string, n, string2) && this.screenInitialized) {
            new Notifier((ComponentContainer)this).ShowAlert("Error " + n + ": " + string2);
        }
    }

    public void ErrorOccurredDialog(Component component, String string, int n, String string2, String string3, String string4) {
        String string5 = component.getClass().getName();
        String string6 = string5.substring(string5.lastIndexOf(".") + 1);
        string5 = this.formName;
        Log.e((String)LOG_TAG, (String)("Form " + string5 + " ErrorOccurred, errorNumber = " + n + ", componentType = " + string6 + ", functionName = " + string + ", messages = " + string2));
        if (!EventDispatcher.dispatchEvent(this, "ErrorOccurred", component, string, n, string2) && this.screenInitialized) {
            new Notifier((ComponentContainer)this).ShowMessageDialog("Error " + n + ": " + string2, string3, string4);
        }
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Screen height (y-size).")
    public int Height() {
        int n = this.formHeight;
        Log.d((String)LOG_TAG, (String)("Form.Height = " + n));
        return this.formHeight;
    }

    @SimpleFunction(description="Hide the onscreen soft keyboard.")
    public void HideKeyboard() {
        View view;
        View view2 = view = this.getCurrentFocus();
        if (view == null) {
            view2 = this.frameLayout;
        }
        ((InputMethodManager)this.getSystemService("input_method")).hideSoftInputFromWindow(view2.getWindowToken(), 0);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void HighContrast(boolean bl) {
        this.highContrast = bl;
        Form.setHighContrastRecursive((ComponentContainer)this, bl);
        super.recomputeLayout();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="When checked, we will use high contrast mode")
    public boolean HighContrast() {
        return this.highContrast;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty(category=PropertyCategory.GENERAL, userVisible=false)
    public void Icon(String string) {
    }

    @SimpleEvent(description="The Initialize event is run when the Screen starts and is only run once per screen.")
    public void Initialize() {
        this.androidUIHandler.post(new Runnable(this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public void run() {
                if (Form.-$$Nest$fgetframeLayout(this.this$0) != null && Form.-$$Nest$fgetframeLayout(this.this$0).getWidth() != 0 && Form.-$$Nest$fgetframeLayout(this.this$0).getHeight() != 0) {
                    EventDispatcher.dispatchEvent(this.this$0, "Initialize", new Object[0]);
                    if (Form.-$$Nest$sfgetsCompatibilityMode()) {
                        this.this$0.Sizing("Fixed");
                    } else {
                        this.this$0.Sizing("Responsive");
                    }
                    Form.-$$Nest$fputscreenInitialized(this.this$0, true);
                    Iterator iterator = Form.-$$Nest$fgetonInitializeListeners(this.this$0).iterator();
                    while (iterator.hasNext()) {
                        ((OnInitializeListener)iterator.next()).onInitialize();
                    }
                    if (activeForm instanceof ReplForm) {
                        ((ReplForm)activeForm).HandleReturnValues();
                    }
                } else {
                    this.this$0.androidUIHandler.post((Runnable)this);
                }
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The animation for switching to another screen. Valid options are default, fade, zoom, slidehorizontal, slidevertical, and none")
    public String OpenScreenAnimation() {
        ScreenAnimation screenAnimation = this.openAnimType;
        if (screenAnimation != null) {
            return screenAnimation.toUnderlyingValue();
        }
        return null;
    }

    @DesignerProperty(defaultValue="default", editorType="screen_animation")
    @SimpleProperty
    public void OpenScreenAnimation(@Options(value=ScreenAnimation.class) String string) {
        ScreenAnimation screenAnimation = ScreenAnimation.fromUnderlyingValue((String)string);
        if (screenAnimation == null) {
            this.dispatchErrorOccurredEvent((Component)this, "Screen", 905, string);
            return;
        }
        this.OpenScreenAnimationAbstract(screenAnimation);
    }

    public ScreenAnimation OpenScreenAnimationAbstract() {
        return this.openAnimType;
    }

    public void OpenScreenAnimationAbstract(ScreenAnimation screenAnimation) {
        this.openAnimType = screenAnimation;
    }

    @SimpleEvent(description="Event raised when another screen has closed and control has returned to this screen.")
    public void OtherScreenClosed(String string, Object object2) {
        String string2 = this.formName;
        String string3 = object2.toString();
        Log.i((String)LOG_TAG, (String)("Form " + string2 + " OtherScreenClosed, otherScreenName = " + string + ", result = " + string3));
        EventDispatcher.dispatchEvent((Component)this, "OtherScreenClosed", string, object2);
    }

    @SimpleEvent
    public void PermissionDenied(Component component, String string, @Options(value=Permission.class) String string2) {
        String string3 = string2;
        if (string2.startsWith("android.permission.")) {
            string3 = string2.replace((CharSequence)"android.permission.", (CharSequence)"");
        }
        if (!EventDispatcher.dispatchEvent((Component)this, "PermissionDenied", component, string, string3)) {
            this.dispatchErrorOccurredEvent(component, string, 908, string3);
        }
    }

    @SimpleEvent(description="Event to handle when the app user has granted a needed permission. This event is only run when permission is granted in response to the AskForPermission method.")
    public void PermissionGranted(@Options(value=Permission.class) String string) {
        String string2 = string;
        if (string.startsWith("android.permission.")) {
            string2 = string.replace((CharSequence)"android.permission.", (CharSequence)"");
        }
        EventDispatcher.dispatchEvent((Component)this, "PermissionGranted", string2);
    }

    @SimpleProperty(description="The platform the app is running on, for example \"Android\" or \"iOS\".")
    public String Platform() {
        return "Android";
    }

    @SimpleProperty(description="The dotted version number of the platform, such as 4.2.2 or 10.0. This is platform specific and there is no guarantee that it has a particular format.")
    public String PlatformVersion() {
        return Build.VERSION.RELEASE;
    }

    @SimpleProperty
    public int PrimaryColor() {
        return this.primaryColor;
    }

    @DesignerProperty(defaultValue="&HFF3F51B5", editorType="color")
    @SimpleProperty(category=PropertyCategory.THEMING, description="This is the primary color used for Material UI elements, such as the ActionBar.", userVisible=false)
    public void PrimaryColor(int n) {
        this.setPrimaryColor(n);
    }

    @SimpleProperty
    public int PrimaryColorDark() {
        return this.primaryColorDark;
    }

    @DesignerProperty(defaultValue="&HFF303F9F", editorType="color")
    @SimpleProperty(category=PropertyCategory.THEMING, description="This is the primary color used for darker elements in Material UI.", userVisible=false)
    public void PrimaryColorDark(int n) {
        this.primaryColorDark = n;
    }

    void ReplayFormOrientation() {
        Log.d((String)LOG_TAG, (String)"ReplayFormOrientation()");
        LinkedHashMap linkedHashMap = (LinkedHashMap)this.dimChanges.clone();
        this.dimChanges.clear();
        for (PercentStorageRecord percentStorageRecord : linkedHashMap.values()) {
            if (percentStorageRecord.dim == Dim.HEIGHT) {
                percentStorageRecord.component.Height(percentStorageRecord.length);
                continue;
            }
            percentStorageRecord.component.Width(percentStorageRecord.length);
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The requested screen orientation, specified as a text value.  Commonly used values are landscape, portrait, sensor, user and unspecified.  See the Android developer documentation for ActivityInfo.Screen_Orientation for the complete list of possible settings.")
    public String ScreenOrientation() {
        return this.ScreenOrientationAbstract().toUnderlyingValue();
    }

    @DesignerProperty(alwaysSend=true, defaultValue="unspecified", editorType="screen_orientation")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void ScreenOrientation(@Options(value=ScreenOrientation.class) String string) {
        ScreenOrientation screenOrientation = ScreenOrientation.fromUnderlyingValue((String)string);
        if (screenOrientation == null) {
            this.dispatchErrorOccurredEvent((Component)this, "ScreenOrientation", 901, string);
            return;
        }
        this.ScreenOrientationAbstract(screenOrientation);
    }

    public ScreenOrientation ScreenOrientationAbstract() {
        switch (this.getRequestedOrientation()) {
            default: {
                return ScreenOrientation.Unspecified;
            }
            case 10: {
                return ScreenOrientation.FullSensor;
            }
            case 9: {
                return ScreenOrientation.ReversePortrait;
            }
            case 8: {
                return ScreenOrientation.ReverseLandscape;
            }
            case 7: {
                return ScreenOrientation.SensorPortrait;
            }
            case 6: {
                return ScreenOrientation.SensorLandscape;
            }
            case 5: {
                return ScreenOrientation.NoSensor;
            }
            case 4: {
                return ScreenOrientation.Sensor;
            }
            case 3: {
                return ScreenOrientation.Behind;
            }
            case 2: {
                return ScreenOrientation.User;
            }
            case 1: {
                return ScreenOrientation.Portrait;
            }
            case 0: {
                return ScreenOrientation.Landscape;
            }
            case -1: 
        }
        return ScreenOrientation.Unspecified;
    }

    public void ScreenOrientationAbstract(ScreenOrientation screenOrientation) {
        int n = screenOrientation.getOrientationConstant();
        if (n > 5 && SdkLevel.getLevel() < 9) {
            this.dispatchErrorOccurredEvent((Component)this, "ScreenOrientation", 901, screenOrientation);
            return;
        }
        this.setRequestedOrientation(n);
    }

    @SimpleEvent(description="Screen orientation changed")
    public void ScreenOrientationChanged() {
        Iterator iterator = this.onOrientationChangeListeners.iterator();
        while (iterator.hasNext()) {
            ((OnOrientationChangeListener)iterator.next()).onOrientationChange();
        }
        EventDispatcher.dispatchEvent(this, "ScreenOrientationChanged", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void Scrollable(boolean bl) {
        if (this.scrollable == bl && this.frameLayout != null) {
            return;
        }
        this.scrollable = bl;
        super.recomputeLayout();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="When checked, there will be a vertical scrollbar on the screen, and the height of the application can exceed the physical height of the device. When unchecked, the application height is constrained to the height of the device.")
    public boolean Scrollable() {
        return this.scrollable;
    }

    @DesignerProperty(alwaysSend=true, defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.GENERAL, description="If false, lists will be converted to strings using Lisp notation, i.e., as symbols separated by spaces, e.g., (a 1 b2 (c d). If true, lists will appear as in Json or Python, e.g.  [\"a\", 1, \"b\", 2, [\"c\", \"d\"]].  This property appears only in Screen 1, and the value for Screen 1 determines the behavior for all screens. The property defaults to \"true\" meaning that the App Inventor programmer must explicitly set it to \"false\" if Lisp syntax is desired. In older versions of App Inventor, this setting defaulted to false. Older projects should not have been affected by this default settings update.", userVisible=false)
    public void ShowListsAsJson(boolean bl) {
        showListsAsJson = bl;
    }

    @SimpleProperty(category=PropertyCategory.GENERAL, userVisible=false)
    public boolean ShowListsAsJson() {
        return showListsAsJson;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void ShowStatusBar(boolean bl) {
        if (bl != this.showStatusBar) {
            if (bl) {
                this.getWindow().addFlags(2048);
                this.getWindow().clearFlags(1024);
            } else {
                this.getWindow().addFlags(1024);
                this.getWindow().clearFlags(2048);
            }
            this.showStatusBar = bl;
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The status bar is the topmost bar on the screen. This property reports whether the status bar is visible.")
    public boolean ShowStatusBar() {
        return this.showStatusBar;
    }

    @DesignerProperty(alwaysSend=true, defaultValue="Responsive", editorType="sizing")
    @SimpleProperty(category=PropertyCategory.GENERAL, description="If set to fixed,  screen layouts will be created for a single fixed-size screen and autoscaled. If set to responsive, screen layouts will use the actual resolution of the device.  See the documentation on responsive design in App Inventor for more information. This property appears on Screen1 only and controls the sizing for all screens in the app.", userVisible=false)
    public void Sizing(String object2) {
        float f;
        Log.d((String)LOG_TAG, (String)("Sizing(" + (String)object2 + ")"));
        this.formWidth = (int)((float)this.getResources().getDisplayMetrics().widthPixels / this.deviceDensity);
        this.formHeight = (int)((float)this.getResources().getDisplayMetrics().heightPixels / this.deviceDensity);
        if (object2.equals((Object)"Fixed")) {
            sCompatibilityMode = true;
            f = this.formWidth;
            float f2 = this.compatScalingFactor;
            this.formWidth = (int)(f / f2);
            this.formHeight = (int)((float)this.formHeight / f2);
        } else {
            sCompatibilityMode = false;
        }
        object2 = this.scaleLayout;
        f = sCompatibilityMode ? this.compatScalingFactor : 1.0f;
        ((ScaledFrameLayout)((Object)object2)).setScale(f);
        object2 = this.frameLayout;
        if (object2 != null) {
            object2.invalidate();
        }
        int n = this.formWidth;
        int n2 = this.formHeight;
        Log.d((String)LOG_TAG, (String)("formWidth = " + n + " formHeight = " + n2));
    }

    @DesignerProperty(defaultValue="AppTheme.Light.DarkActionBar", editorType="theme")
    @SimpleProperty(category=PropertyCategory.THEMING, description="Pick a design theme for your app. Themes change the appearance of an app, such as how buttons and text look. The most common themes are: </p> <ul> <li> <code>Classic</code>: This theme stays consistent whether you are looking at an Android, iOS, or the screen layout in App Inventor\u2019s designer. Choose Classic if you want detailed control of the appearance of your app. </li><li> <code>Device Default</code>: This theme makes your app resemble the other apps on your device. With the default theme, however, your app won\u2019t look consistent across Android, iOS, and App Inventor\u2019s designer. The best way to see the true appearance of your app is to view it using the Companion.", userVisible=false)
    public void Theme(String string) {
        if (this.usesDefaultBackground) {
            this.backgroundColor = string.equalsIgnoreCase("AppTheme") && !Form.isClassicMode() ? -16777216 : -1;
            super.setBackground((View)this.frameLayout);
        }
        this.usesDarkTheme = false;
        if (string.equals((Object)"Classic")) {
            this.setAppInventorTheme(AppInventorCompatActivity.Theme.CLASSIC);
        } else if (string.equals((Object)"AppTheme.Light.DarkActionBar")) {
            this.setAppInventorTheme(AppInventorCompatActivity.Theme.DEVICE_DEFAULT);
        } else if (string.equals((Object)"AppTheme.Light")) {
            this.setAppInventorTheme(AppInventorCompatActivity.Theme.BLACK_TITLE_TEXT);
        } else if (string.equals((Object)"AppTheme")) {
            this.usesDarkTheme = true;
            this.setAppInventorTheme(AppInventorCompatActivity.Theme.DARK);
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The caption for the form, which apears in the title bar")
    public String Title() {
        return this.getTitle().toString();
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty
    public void Title(String string) {
        this.title = string;
        if (this.titleBar != null) {
            this.titleBar.setText((CharSequence)string);
        }
        this.setTitle((CharSequence)string);
        this.updateTitle();
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void TitleVisible(boolean bl) {
        if (bl != this.showTitle) {
            this.showTitle = bl;
            if (this.actionBarEnabled) {
                this.actionBarEnabled = this.themeHelper.setActionBarVisible(bl);
            } else {
                this.maybeShowTitleBar();
            }
        }
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="The title bar is the top gray bar on the screen. This property reports whether the title bar is visible.")
    public boolean TitleVisible() {
        return this.showTitle;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.GENERAL, description="A URL to use to populate the Tutorial Sidebar while editing a project. Used as a teaching aid.", userVisible=false)
    public void TutorialURL(String string) {
    }

    @DesignerProperty(defaultValue="1", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.PUBLISHING, description="An integer value which must be incremented each time a new Android Application Package File (APK) is created for the Google Play Store.", userVisible=false)
    public void VersionCode(int n) {
    }

    @DesignerProperty(defaultValue="1.0", editorType="string")
    @SimpleProperty(category=PropertyCategory.PUBLISHING, description="A string which can be changed to allow Google Play Store users to distinguish between different versions of the App.", userVisible=false)
    public void VersionName(String string) {
    }

    @Override
    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Screen width (x-size).")
    public int Width() {
        int n = this.formWidth;
        Log.d((String)LOG_TAG, (String)("Form.Width = " + n));
        return this.formWidth;
    }

    public void addAboutInfoToMenu(Menu menu) {
        menu.add(0, 0, 2, (CharSequence)"About this application").setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener((Form)this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public boolean onMenuItemClick(MenuItem menuItem) {
                Form.-$$Nest$mshowAboutApplicationNotification(this.this$0);
                return true;
            }
        }).setIcon(17301651);
    }

    public void addExitButtonToMenu(Menu menu) {
        menu.add(0, 0, 1, (CharSequence)"Stop this application").setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener((Form)this){
            final Form this$0;
            {
                this.this$0 = form;
            }

            public boolean onMenuItemClick(MenuItem menuItem) {
                Form.-$$Nest$mshowExitApplicationNotification(this.this$0);
                return true;
            }
        }).setIcon(17301594);
    }

    public void askPermission(BulkPermissionRequest bulkPermissionRequest) {
        List list = bulkPermissionRequest.getPermissions();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            if (this.isDeniedPermission((String)iterator.next())) continue;
            iterator.remove();
        }
        if (list.size() == 0) {
            bulkPermissionRequest.onGranted();
        } else {
            this.androidUIHandler.post(new Runnable((Form)this, list, bulkPermissionRequest){
                final Form this$0;
                final List val$permissionsToAsk;
                final BulkPermissionRequest val$request;
                {
                    this.this$0 = form;
                    this.val$permissionsToAsk = list;
                    this.val$request = bulkPermissionRequest;
                }

                public void run() {
                    Iterator iterator = this.val$permissionsToAsk.iterator();
                    1 var1_2 = new 1(this, iterator);
                    this.this$0.askPermission((String)iterator.next(), (PermissionResultHandler)var1_2);
                }
            });
        }
    }

    public void askPermission(String string, PermissionResultHandler permissionResultHandler) {
        if (!this.isDeniedPermission(string)) {
            permissionResultHandler.HandlePermissionResponse(string, true);
            return;
        }
        this.androidUIHandler.post(new Runnable((Form)this, string, permissionResultHandler, (Form)this){
            final Form this$0;
            final Form val$form;
            final String val$permission;
            final PermissionResultHandler val$responseRequestor;
            {
                this.this$0 = form;
                this.val$permission = string;
                this.val$responseRequestor = permissionResultHandler;
                this.val$form = form2;
            }

            public void run() {
                int n = Form.-$$Nest$fgetpermissionRandom(this.this$0).nextInt(100000);
                String string = this.val$permission;
                Log.d((String)"Form", (String)("askPermission: permission = " + string + " requestCode = " + n));
                Form.-$$Nest$fgetpermissionHandlers(this.this$0).put((Object)n, (Object)this.val$responseRequestor);
                ActivityCompat.requestPermissions((Activity)this.val$form, (String[])new String[]{this.val$permission}, (int)n);
            }
        });
    }

    public void assertPermission(String string) {
        if (!this.isDeniedPermission(string)) {
            return;
        }
        throw new PermissionException(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void callInitialize(Object object2) throws Throwable {
        Object[] objectArray;
        Class clazz;
        try {
            clazz = object2.getClass();
            objectArray = null;
            clazz = clazz.getMethod("Initialize", null);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return;
        }
        catch (SecurityException securityException) {
            String string = securityException.getMessage();
            Log.i((String)LOG_TAG, (String)("Security exception " + string));
            return;
        }
        try {
            String string = object2.toString();
            objectArray = new StringBuilder();
            Log.i((String)LOG_TAG, (String)objectArray.append("calling Initialize method for Object ").append(string).toString());
            objectArray = null;
            clazz.invoke(object2, null);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
            object2 = invocationTargetException.getMessage();
            Log.i((String)LOG_TAG, (String)("invoke exception: " + (String)object2));
            throw invocationTargetException.getTargetException();
        }
    }

    @Override
    public boolean canDispatchEvent(Component component, String string) {
        boolean bl = this.screenInitialized || component == this && string.equals((Object)"Initialize");
        if (bl) {
            activeForm = this;
        }
        return bl;
    }

    public void clear() {
        String string = this.formName;
        Log.d((String)LOG_TAG, (String)("Form " + string + " clear called"));
        this.viewLayout.getLayoutManager().removeAllViews();
        string = this.frameLayout;
        if (string != null) {
            string.removeAllViews();
            this.frameLayout = null;
        }
        this.defaultPropertyValues();
        this.onStopListeners.clear();
        this.onNewIntentListeners.clear();
        this.onResumeListeners.clear();
        this.onOrientationChangeListeners.clear();
        this.onPauseListeners.clear();
        this.onDestroyListeners.clear();
        this.onInitializeListeners.clear();
        this.onCreateOptionsMenuListeners.clear();
        this.onOptionsItemSelectedListeners.clear();
        this.screenInitialized = false;
        string = this.onClearListeners.iterator();
        while (string.hasNext()) {
            ((OnClearListener)string.next()).onClear();
        }
        this.onClearListeners.clear();
        System.err.println("Form.clear() About to do moby GC!");
        System.gc();
        this.dimChanges.clear();
    }

    protected void closeApplicationFromBlocks() {
        this.closeApplication();
    }

    protected void closeForm(Intent intent) {
        if (intent != null) {
            this.setResult(-1, intent);
        }
        this.finish();
        AnimationUtil.ApplyCloseScreenAnimation((Activity)this, (ScreenAnimation)this.closeAnimType);
    }

    public float compatScalingFactor() {
        return this.compatScalingFactor;
    }

    protected void defaultPropertyValues() {
        if (this.isRepl()) {
            this.ActionBar(this.actionBarEnabled);
        } else {
            this.ActionBar(this.themeHelper.hasActionBar());
        }
        this.Scrollable(false);
        this.HighContrast(false);
        this.BigDefaultText(false);
        this.Sizing("Responsive");
        this.AboutScreen("");
        this.BackgroundImage("");
        this.AlignHorizontal(1);
        this.AlignVertical(1);
        this.Title("");
        this.ShowStatusBar(true);
        this.TitleVisible(true);
        this.ShowListsAsJson(true);
        this.ActionBar(false);
        this.AccentColor(DEFAULT_ACCENT_COLOR);
        this.PrimaryColor(DEFAULT_PRIMARY_COLOR);
        this.PrimaryColorDark(DEFAULT_PRIMARY_COLOR_DARK);
        this.BackgroundColor(0);
        this.OpenScreenAnimationAbstract(ScreenAnimation.Default);
        this.CloseScreenAnimationAbstract(ScreenAnimation.Default);
        this.DefaultFileScope(FileScope.App);
    }

    public void deleteComponent(Object object2) {
        if (object2 instanceof OnStopListener) {
            this.onStopListeners.remove(object2);
        }
        if (object2 instanceof OnNewIntentListener) {
            this.onNewIntentListeners.remove(object2);
        }
        if (object2 instanceof OnResumeListener) {
            this.onResumeListeners.remove(object2);
        }
        if (object2 instanceof OnOrientationChangeListener) {
            this.onOrientationChangeListeners.remove(object2);
        }
        if (object2 instanceof OnPauseListener) {
            this.onPauseListeners.remove(object2);
        }
        if (object2 instanceof OnDestroyListener) {
            this.onDestroyListeners.remove(object2);
        }
        if (object2 instanceof OnInitializeListener) {
            this.onInitializeListeners.remove(object2);
        }
        if (object2 instanceof OnCreateOptionsMenuListener) {
            this.onCreateOptionsMenuListeners.remove(object2);
        }
        if (object2 instanceof OnOptionsItemSelectedListener) {
            this.onOptionsItemSelectedListeners.remove(object2);
        }
        if (object2 instanceof Deleteable) {
            ((Deleteable)object2).onDelete();
        }
    }

    public float deviceDensity() {
        return this.deviceDensity;
    }

    @Override
    public void dispatchErrorOccurredEvent(Component component, String string, int n, Object ... objectArray) {
        this.runOnUiThread(new Runnable((Form)this, n, objectArray, component, string){
            final Form this$0;
            final Component val$component;
            final int val$errorNumber;
            final String val$functionName;
            final Object[] val$messageArgs;
            {
                this.this$0 = form;
                this.val$errorNumber = n;
                this.val$messageArgs = objectArray;
                this.val$component = component;
                this.val$functionName = string;
            }

            public void run() {
                String string = ErrorMessages.formatMessage((int)this.val$errorNumber, (Object[])this.val$messageArgs);
                this.this$0.ErrorOccurred(this.val$component, this.val$functionName, this.val$errorNumber, string);
            }
        });
    }

    public void dispatchErrorOccurredEventDialog(Component component, String string, int n, Object ... objectArray) {
        this.runOnUiThread(new Runnable((Form)this, n, objectArray, component, string){
            final Form this$0;
            final Component val$component;
            final int val$errorNumber;
            final String val$functionName;
            final Object[] val$messageArgs;
            {
                this.this$0 = form;
                this.val$errorNumber = n;
                this.val$messageArgs = objectArray;
                this.val$component = component;
                this.val$functionName = string;
            }

            public void run() {
                String string = ErrorMessages.formatMessage((int)this.val$errorNumber, (Object[])this.val$messageArgs);
                Form form = this.this$0;
                Component component = this.val$component;
                String string2 = this.val$functionName;
                form.ErrorOccurredDialog(component, string2, this.val$errorNumber, string, "Error in " + string2, "Dismiss");
            }
        });
    }

    @Override
    public boolean dispatchEvent(Component component, String string, String string2, Object[] objectArray) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void dispatchGenericEvent(Component component, String string, boolean bl, Object[] objectArray) {
        throw new UnsupportedOperationException();
    }

    public void dispatchPermissionDeniedEvent(Component component, String string, PermissionException permissionException) {
        permissionException.printStackTrace();
        this.dispatchPermissionDeniedEvent(component, string, permissionException.getPermissionNeeded());
    }

    public void dispatchPermissionDeniedEvent(Component component, String string, String string2) {
        this.runOnUiThread(new Runnable((Form)this, component, string, string2){
            final Form this$0;
            final Component val$component;
            final String val$functionName;
            final String val$permissionName;
            {
                this.this$0 = form;
                this.val$component = component;
                this.val$functionName = string;
                this.val$permissionName = string2;
            }

            public void run() {
                this.this$0.PermissionDenied(this.val$component, this.val$functionName, this.val$permissionName);
            }
        });
    }

    public boolean doesAppDeclarePermission(String string) {
        return this.permissions.contains((Object)string);
    }

    public void dontGrabTouchEventsForComponent() {
        this.frameLayout.requestDisallowInterceptTouchEvent(true);
    }

    public Bundle fullScreenVideoAction(int n, VideoPlayer videoPlayer, Object object2) {
        void var4_5 = this;
        synchronized (var4_5) {
            videoPlayer = this.fullScreenVideoUtil.performAction(n, videoPlayer, object2);
            return videoPlayer;
        }
    }

    public String getAssetPath(String string) {
        return ASSETS_PREFIX + string;
    }

    public String getAssetPathForExtension(Component object2, String string) throws FileNotFoundException {
        object2 = object2.getClass().getPackage().getName();
        return ASSETS_PREFIX + (String)object2 + "/" + string;
    }

    public String getCachePath(String string) {
        string = new File(this.getCacheDir(), string).getAbsolutePath();
        return "file://" + string;
    }

    @Override
    public List<? extends Component> getChildren() {
        return this.allChildren;
    }

    public String getDefaultPath(String string) {
        return FileUtil.resolveFileName((Form)this, (String)string, (FileScope)this.defaultFileScope);
    }

    @Override
    public HandlesEventDispatching getDispatchDelegate() {
        return this;
    }

    public FrameLayout getFrameLayout() {
        return this.frameLayout;
    }

    public String getPrivatePath(String string) {
        string = new File(this.getFilesDir(), string).getAbsolutePath();
        return "file://" + string;
    }

    public boolean isDarkTheme() {
        return this.usesDarkTheme;
    }

    public boolean isDeniedPermission(String string) {
        boolean bl = Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission((Context)this, (String)string) == -1;
        return bl;
    }

    protected void maybeShowTitleBar() {
        if (this.showTitle) {
            super.maybeShowTitleBar();
        } else {
            super.hideTitleBar();
        }
    }

    protected void onActivityResult(int n, int n2, Intent object2) {
        Object object3 = this.formName;
        Log.i((String)LOG_TAG, (String)("Form " + (String)object3 + " got onActivityResult, requestCode = " + n + ", resultCode = " + n2));
        if (n == 1) {
            object2 = object2 != null && object2.hasExtra(RESULT_NAME) ? object2.getStringExtra(RESULT_NAME) : "";
            object2 = Form.decodeJSONStringForForm((String)object2, "other screen closed");
            this.OtherScreenClosed(this.nextFormName, object2);
        } else {
            object3 = (ActivityResultListener)this.activityResultMap.get((Object)n);
            if (object3 != null) {
                object3.resultReturned(n, n2, (Intent)object2);
            }
            if ((object3 = (Set)this.activityResultMultiMap.get((Object)n)) != null) {
                object3 = (ActivityResultListener[])object3.toArray((Object[])new ActivityResultListener[0]);
                int n3 = ((ActivityResultListener[])object3).length;
                for (int i = 0; i < n3; ++i) {
                    object3[i].resultReturned(n, n2, (Intent)object2);
                }
            }
        }
    }

    public void onBackPressed() {
        if (!this.BackPressed()) {
            AnimationUtil.ApplyCloseScreenAnimation((Activity)this, (ScreenAnimation)this.closeAnimType);
            super.onBackPressed();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Log.d((String)LOG_TAG, (String)"onConfigurationChanged() called");
        int n = configuration.orientation;
        if (n == 2 || n == 1) {
            this.androidUIHandler.post(new Runnable((Form)this, n){
                final Form this$0;
                final int val$newOrientation;
                {
                    this.this$0 = form;
                    this.val$newOrientation = n;
                }

                public void run() {
                    boolean bl;
                    boolean bl2 = bl = false;
                    if (Form.-$$Nest$fgetframeLayout(this.this$0) != null) {
                        if (this.val$newOrientation == 2) {
                            bl2 = bl;
                            if (Form.-$$Nest$fgetframeLayout(this.this$0).getWidth() >= Form.-$$Nest$fgetframeLayout(this.this$0).getHeight()) {
                                bl2 = true;
                            }
                        } else {
                            bl2 = bl;
                            if (Form.-$$Nest$fgetframeLayout(this.this$0).getHeight() >= Form.-$$Nest$fgetframeLayout(this.this$0).getWidth()) {
                                bl2 = true;
                            }
                        }
                    }
                    if (bl2) {
                        Form.-$$Nest$mrecomputeLayout(this.this$0);
                        FrameLayout frameLayout = Form.-$$Nest$fgetframeLayout(this.this$0);
                        this.this$0.androidUIHandler.postDelayed(new Runnable(this, frameLayout){
                            final 1 this$1;
                            final FrameLayout val$savedLayout;
                            {
                                this.this$1 = var1;
                                this.val$savedLayout = frameLayout;
                            }

                            public void run() {
                                FrameLayout frameLayout = this.val$savedLayout;
                                if (frameLayout != null) {
                                    frameLayout.invalidate();
                                }
                            }
                        }, 100L);
                        this.this$0.ScreenOrientationChanged();
                    } else {
                        this.this$0.androidUIHandler.post((Runnable)this);
                    }
                }
            });
        }
    }

    public void onCreate(Bundle object2) {
        float f;
        super.onCreate(object2);
        object2 = this.getClass().getName();
        object2 = object2.substring(object2.lastIndexOf(46) + 1);
        this.formName = object2;
        Log.d((String)LOG_TAG, (String)("Form " + (String)object2 + " got onCreate"));
        activeForm = this;
        object2 = this.formName;
        Log.i((String)LOG_TAG, (String)("activeForm is now " + (String)object2));
        this.deviceDensity = f = this.getResources().getDisplayMetrics().density;
        Log.d((String)LOG_TAG, (String)("deviceDensity = " + f));
        this.compatScalingFactor = f = ScreenDensityUtil.computeCompatibleScaling((Context)this);
        Log.i((String)LOG_TAG, (String)("compatScalingFactor = " + f));
        object2 = new LinearLayout((Context)this, 0);
        this.viewLayout = object2;
        this.alignmentSetter = new AlignmentUtil((LinearLayout)object2);
        this.progress = null;
        if (!_initialized && this.formName.equals((Object)"Screen1")) {
            boolean bl = _initialized;
            object2 = this.formName;
            Log.d((String)LOG_TAG, (String)("MULTI: _initialized = " + bl + " formName = " + (String)object2));
            _initialized = true;
            if (ReplApplication.installed) {
                Log.d((String)LOG_TAG, (String)"MultiDex already installed.");
                this.onCreateFinish();
            } else {
                object2 = ProgressDialog.show((Context)this, (CharSequence)"Please Wait...", (CharSequence)"Installation Finishing");
                this.progress = object2;
                object2.show();
                new AsyncTask<Form, Void, Boolean>(null){
                    Form ourForm;

                    protected Boolean doInBackground(Form ... formArray) {
                        this.ourForm = formArray[0];
                        Log.d((String)Form.LOG_TAG, (String)"Doing Full MultiDex Install");
                        MultiDex.install((Context)this.ourForm, true);
                        return true;
                    }

                    protected void onPostExecute(Boolean bl) {
                        this.ourForm.onCreateFinish();
                    }
                }.execute((Object[])new Form[]{this});
            }
        } else {
            boolean bl = _initialized;
            object2 = this.formName;
            Log.d((String)LOG_TAG, (String)("NO MULTI: _initialized = " + bl + " formName = " + (String)object2));
            _initialized = true;
            this.onCreateFinish();
        }
    }

    public Dialog onCreateDialog(int n) {
        switch (n) {
            default: {
                return super.onCreateDialog(n);
            }
            case 189: 
        }
        return this.fullScreenVideoUtil.createFullScreenVideoDialog();
    }

    void onCreateFinish() {
        long l = System.currentTimeMillis();
        Log.d((String)LOG_TAG, (String)("onCreateFinish called " + l));
        ProgressDialog progressDialog = this.progress;
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
        this.populatePermissions();
        this.defaultPropertyValues();
        progressDialog = this.getIntent();
        if (progressDialog != null && progressDialog.hasExtra(ARGUMENT_NAME)) {
            this.startupValue = progressDialog.getStringExtra(ARGUMENT_NAME);
        }
        this.fullScreenVideoUtil = new FullScreenVideoUtil(this, this.androidUIHandler);
        int n = this.getWindow().getAttributes().softInputMode;
        this.getWindow().setSoftInputMode(n | 0x10);
        this.$define();
        this.Initialize();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        this.addExitButtonToMenu(menu);
        this.addAboutInfoToMenu(menu);
        Iterator iterator = this.onCreateOptionsMenuListeners.iterator();
        while (iterator.hasNext()) {
            ((OnCreateOptionsMenuListener)iterator.next()).onCreateOptionsMenu(menu);
        }
        return true;
    }

    protected void onDestroy() {
        String string = this.formName;
        Log.i((String)LOG_TAG, (String)("Form " + string + " got onDestroy"));
        EventDispatcher.removeDispatchDelegate(this);
        string = this.onDestroyListeners.iterator();
        while (string.hasNext()) {
            ((OnDestroyListener)string.next()).onDestroy();
        }
        super.onDestroy();
    }

    public void onGlobalLayout() {
        int n = this.scaleLayout.getRootView().getHeight();
        float f = (float)(n - this.scaleLayout.getHeight()) / (float)n;
        Log.d((String)LOG_TAG, (String)("onGlobalLayout(): diffPercent = " + f));
        if ((double)f < 0.25) {
            Log.d((String)LOG_TAG, (String)"keyboard hidden!");
            if (this.keyboardShown) {
                this.keyboardShown = false;
                if (sCompatibilityMode) {
                    this.scaleLayout.setScale(this.compatScalingFactor);
                    this.scaleLayout.invalidate();
                }
            }
        } else {
            Log.d((String)LOG_TAG, (String)"keyboard shown!");
            this.keyboardShown = true;
            ScaledFrameLayout scaledFrameLayout = this.scaleLayout;
            if (scaledFrameLayout != null) {
                scaledFrameLayout.setScale(1.0f);
                this.scaleLayout.invalidate();
            }
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String string = this.formName;
        Log.d((String)LOG_TAG, (String)("Form " + string + " got onNewIntent " + intent));
        string = this.onNewIntentListeners.iterator();
        while (string.hasNext()) {
            ((OnNewIntentListener)string.next()).onNewIntent(intent);
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        Iterator iterator = this.onOptionsItemSelectedListeners.iterator();
        while (iterator.hasNext()) {
            if (!((OnOptionsItemSelectedListener)iterator.next()).onOptionsItemSelected(menuItem)) continue;
            return true;
        }
        return false;
    }

    protected void onPause() {
        super.onPause();
        String string = this.formName;
        Log.i((String)LOG_TAG, (String)("Form " + string + " got onPause"));
        string = this.onPauseListeners.iterator();
        while (string.hasNext()) {
            ((OnPauseListener)string.next()).onPause();
        }
    }

    public void onPrepareDialog(int n, Dialog dialog) {
        switch (n) {
            default: {
                super.onPrepareDialog(n, dialog);
                break;
            }
            case 189: {
                this.fullScreenVideoUtil.prepareFullScreenVideoDialog(dialog);
            }
        }
    }

    public void onRequestPermissionsResult(int n, String[] stringArray, int[] nArray) {
        PermissionResultHandler permissionResultHandler = (PermissionResultHandler)this.permissionHandlers.get((Object)n);
        if (permissionResultHandler == null) {
            Log.e((String)LOG_TAG, (String)"Received permission response which we cannot match.");
            return;
        }
        if (nArray.length > 0) {
            if (nArray[0] == 0) {
                permissionResultHandler.HandlePermissionResponse(stringArray[0], true);
            } else {
                permissionResultHandler.HandlePermissionResponse(stringArray[0], false);
            }
        } else {
            int n2 = nArray.length;
            Log.d((String)LOG_TAG, (String)("onRequestPermissionsResult: grantResults.length = " + n2 + " requestCode = " + n));
        }
        this.permissionHandlers.remove((Object)n);
    }

    protected void onResume() {
        super.onResume();
        String string = this.formName;
        Log.i((String)LOG_TAG, (String)("Form " + string + " got onResume"));
        activeForm = this;
        if (applicationIsBeingClosed) {
            this.closeApplication();
            return;
        }
        string = this.onResumeListeners.iterator();
        while (string.hasNext()) {
            ((OnResumeListener)string.next()).onResume();
        }
    }

    protected void onStop() {
        super.onStop();
        String string = this.formName;
        Log.i((String)LOG_TAG, (String)("Form " + string + " got onStop"));
        string = this.onStopListeners.iterator();
        while (string.hasNext()) {
            ((OnStopListener)string.next()).onStop();
        }
    }

    public InputStream openAsset(String string) throws IOException {
        return this.openAssetInternal(this.getAssetPath(string));
    }

    public InputStream openAssetForExtension(Component component, String string) throws IOException {
        return this.openAssetInternal(this.getAssetPathForExtension(component, string));
    }

    InputStream openAssetInternal(String string) throws IOException {
        if (string.startsWith(ASSETS_PREFIX)) {
            return this.getAssets().open(string.substring(ASSETS_PREFIX.length()));
        }
        if (string.startsWith("file:")) {
            return FileUtil.openFile((Form)this, (URI)URI.create((String)string));
        }
        return FileUtil.openFile((Form)this, (String)string);
    }

    public int registerForActivityResult(ActivityResultListener activityResultListener) {
        int n = Form.generateNewRequestCode();
        this.activityResultMap.put((Object)n, (Object)activityResultListener);
        return n;
    }

    public void registerForActivityResult(ActivityResultListener activityResultListener, int n) {
        HashSet hashSet;
        HashSet hashSet2 = hashSet = (HashSet)this.activityResultMultiMap.get((Object)n);
        if (hashSet == null) {
            hashSet2 = Sets.newHashSet();
            this.activityResultMultiMap.put((Object)n, hashSet2);
        }
        hashSet2.add((Object)activityResultListener);
    }

    public void registerForOnClear(OnClearListener onClearListener) {
        this.onClearListeners.add((Object)onClearListener);
    }

    public void registerForOnCreateOptionsMenu(OnCreateOptionsMenuListener onCreateOptionsMenuListener) {
        this.onCreateOptionsMenuListeners.add((Object)onCreateOptionsMenuListener);
    }

    public void registerForOnDestroy(OnDestroyListener onDestroyListener) {
        this.onDestroyListeners.add((Object)onDestroyListener);
    }

    public void registerForOnInitialize(OnInitializeListener onInitializeListener) {
        this.onInitializeListeners.add((Object)onInitializeListener);
    }

    public void registerForOnNewIntent(OnNewIntentListener onNewIntentListener) {
        this.onNewIntentListeners.add((Object)onNewIntentListener);
    }

    public void registerForOnOptionsItemSelected(OnOptionsItemSelectedListener onOptionsItemSelectedListener) {
        this.onOptionsItemSelectedListeners.add((Object)onOptionsItemSelectedListener);
    }

    public void registerForOnOrientationChange(OnOrientationChangeListener onOrientationChangeListener) {
        this.onOrientationChangeListeners.add((Object)onOrientationChangeListener);
    }

    public void registerForOnPause(OnPauseListener onPauseListener) {
        this.onPauseListeners.add((Object)onPauseListener);
    }

    public void registerForOnResume(OnResumeListener onResumeListener) {
        this.onResumeListeners.add((Object)onResumeListener);
    }

    public void registerForOnStop(OnStopListener onStopListener) {
        this.onStopListeners.add((Object)onStopListener);
    }

    public void registerPercentLength(AndroidViewComponent androidViewComponent, int n, Dim dim) {
        Object object2 = new Object(androidViewComponent, n, dim){
            AndroidViewComponent component;
            Dim dim;
            int length;
            {
                this.component = androidViewComponent;
                this.length = n;
                this.dim = dim;
            }

            public static final class Dim
            extends Enum<Dim> {
                private static final Dim[] $VALUES;
                public static final /* enum */ Dim HEIGHT;
                public static final /* enum */ Dim WIDTH;

                static {
                    Dim dim;
                    Dim dim2;
                    HEIGHT = dim2 = new Dim();
                    WIDTH = dim = new Dim();
                    $VALUES = new Dim[]{dim2, dim};
                }

                public static Dim valueOf(String string) {
                    return (Dim)Enum.valueOf(Dim.class, (String)string);
                }

                public static Dim[] values() {
                    return (Dim[])$VALUES.clone();
                }
            }
        };
        androidViewComponent = super.generateHashCode(androidViewComponent, dim);
        this.dimChanges.put((Object)androidViewComponent, object2);
    }

    public void runtimeFormErrorOccurredEvent(String string, int n, String string2) {
        Log.d((String)"FORM_RUNTIME_ERROR", (String)("functionName is " + string));
        Log.d((String)"FORM_RUNTIME_ERROR", (String)("errorNumber is " + n));
        Log.d((String)"FORM_RUNTIME_ERROR", (String)("message is " + string2));
        this.dispatchErrorOccurredEvent(activeForm, string, n, string2);
    }

    @Override
    public void setChildHeight(AndroidViewComponent androidViewComponent, int n) {
        if (this.Height() == 0) {
            this.androidUIHandler.postDelayed(new Runnable((Form)this, androidViewComponent, n){
                final Form this$0;
                final AndroidViewComponent val$component;
                final int val$fHeight;
                {
                    this.this$0 = form;
                    this.val$component = androidViewComponent;
                    this.val$fHeight = n;
                }

                public void run() {
                    System.err.println("(Form)Height not stable yet... trying again");
                    this.this$0.setChildHeight(this.val$component, this.val$fHeight);
                }
            }, 100L);
        }
        int n2 = n;
        if (n <= -1000) {
            n2 = this.Height() * -(n + 1000) / 100;
        }
        androidViewComponent.setLastHeight(n2);
        ViewUtil.setChildHeightForVerticalLayout((View)androidViewComponent.getView(), (int)n2);
    }

    @Override
    public void setChildWidth(AndroidViewComponent androidViewComponent, int n) {
        int n2 = this.Width();
        if (n2 == 0) {
            this.androidUIHandler.postDelayed(new Runnable((Form)this, androidViewComponent, n){
                final Form this$0;
                final AndroidViewComponent val$component;
                final int val$fWidth;
                {
                    this.this$0 = form;
                    this.val$component = androidViewComponent;
                    this.val$fWidth = n;
                }

                public void run() {
                    System.err.println("(Form)Width not stable yet... trying again");
                    this.this$0.setChildWidth(this.val$component, this.val$fWidth);
                }
            }, 100L);
        }
        System.err.println("Form.setChildWidth(): width = " + n + " parent Width = " + n2 + " child = " + androidViewComponent);
        int n3 = n;
        if (n <= -1000) {
            n3 = -(n + 1000) * n2 / 100;
        }
        androidViewComponent.setLastWidth(n3);
        ViewUtil.setChildWidthForVerticalLayout((View)androidViewComponent.getView(), (int)n3);
    }

    protected void startNewForm(String string, Object object2) {
        Log.i((String)LOG_TAG, (String)("startNewForm:" + string));
        Intent intent = new Intent();
        String string2 = this.getPackageName();
        intent.setClassName((Context)this, string2 + "." + string);
        string2 = object2 == null ? "open another screen" : "open another screen with start value";
        if (object2 != null) {
            Log.i((String)LOG_TAG, (String)("StartNewForm about to JSON encode:" + object2));
            object2 = Form.jsonEncodeForForm(object2, string2);
            Log.i((String)LOG_TAG, (String)("StartNewForm got JSON encoding:" + (String)object2));
        } else {
            object2 = "";
        }
        intent.putExtra(ARGUMENT_NAME, (String)object2);
        this.nextFormName = string;
        Log.i((String)LOG_TAG, (String)("about to start new form" + string));
        try {
            object2 = new StringBuilder();
            Log.i((String)LOG_TAG, (String)object2.append("startNewForm starting activity:").append((Object)intent).toString());
            this.startActivityForResult(intent, 1);
            AnimationUtil.ApplyOpenScreenAnimation((Activity)this, (ScreenAnimation)this.openAnimType);
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            this.dispatchErrorOccurredEvent((Component)this, string2, 902, string);
        }
    }

    protected boolean toastAllowed() {
        long l = System.nanoTime();
        if (l > this.lastToastTime + minimumToastWait) {
            this.lastToastTime = l;
            return true;
        }
        return false;
    }

    public void unregisterForActivityResult(ActivityResultListener activityResultListener) {
        Iterator iterator2;
        ArrayList arrayList = Lists.newArrayList();
        for (Iterator iterator2 : this.activityResultMap.entrySet()) {
            if (!activityResultListener.equals(iterator2.getValue())) continue;
            arrayList.add((Object)((Integer)iterator2.getKey()));
        }
        for (Iterator iterator3 : arrayList) {
            this.activityResultMap.remove((Object)iterator3);
        }
        iterator2 = this.activityResultMultiMap.entrySet().iterator();
        while (iterator2.hasNext()) {
            Iterator iterator3;
            iterator3 = (Map.Entry)iterator2.next();
            ((Set)iterator3.getValue()).remove((Object)activityResultListener);
            if (((Set)iterator3.getValue()).size() != 0) continue;
            iterator2.remove();
        }
    }

    public void unregisterPercentLength(AndroidViewComponent androidViewComponent, Dim dim) {
        this.dimChanges.remove((Object)super.generateHashCode(androidViewComponent, dim));
    }

    protected void updateTitle() {
        this.themeHelper.setTitle(this.title);
    }
}

