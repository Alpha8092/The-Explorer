/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime.multidex;

import android.app.Application;
import android.content.Context;
import com.google.appinventor.components.runtime.multidex.MultiDex;

public class MultiDexApplication
extends Application {
    public static boolean installed = false;

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install((Context)this, true);
    }
}

