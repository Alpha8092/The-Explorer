/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.HorizontalScrollView
 *  android.widget.ScrollView
 *  com.google.appinventor.components.common.HorizontalAlignment
 *  com.google.appinventor.components.common.VerticalAlignment
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.LinearLayout
 *  com.google.appinventor.components.runtime.util.AlignmentUtil
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.ViewUtil
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.HorizontalAlignment;
import com.google.appinventor.components.common.VerticalAlignment;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.LinearLayout;
import com.google.appinventor.components.runtime.util.AlignmentUtil;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.ViewUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SimpleObject
public class HVArrangement
extends AndroidViewComponent
implements Component,
ComponentContainer {
    private static final String LOG_TAG = "HVArrangement";
    private AlignmentUtil alignmentSetter;
    private List<Component> allChildren;
    private final Handler androidUIHandler;
    private int backgroundColor;
    private Drawable backgroundImageDrawable;
    private final Activity context;
    private Drawable defaultButtonDrawable;
    private ViewGroup frameContainer;
    private HorizontalAlignment horizontalAlignment = HorizontalAlignment.Left;
    private String imagePath = "";
    private final int orientation;
    private boolean scrollable = false;
    private VerticalAlignment verticalAlignment = VerticalAlignment.Top;
    private final LinearLayout viewLayout;

    public HVArrangement(ComponentContainer componentContainer, int n, boolean bl) {
        super(componentContainer);
        LinearLayout linearLayout;
        Activity activity;
        this.allChildren = new ArrayList();
        this.androidUIHandler = new Handler();
        this.context = activity = componentContainer.$context();
        this.orientation = n;
        this.scrollable = bl;
        Integer n2 = 100;
        this.viewLayout = linearLayout = new LinearLayout((Context)activity, n, n2, n2);
        linearLayout.setBaselineAligned(false);
        n2 = new AlignmentUtil(linearLayout);
        this.alignmentSetter = n2;
        n2.setHorizontalAlignment(this.horizontalAlignment);
        this.alignmentSetter.setVerticalAlignment(this.verticalAlignment);
        if (bl) {
            switch (n) {
                default: {
                    break;
                }
                case 1: {
                    Log.d((String)LOG_TAG, (String)"Setting up frameContainer = HorizontalScrollView()");
                    this.frameContainer = new HorizontalScrollView((Context)activity);
                    break;
                }
                case 0: {
                    Log.d((String)LOG_TAG, (String)"Setting up frameContainer = ScrollView()");
                    this.frameContainer = new ScrollView((Context)activity);
                    break;
                }
            }
        } else {
            Log.d((String)LOG_TAG, (String)"Setting up frameContainer = FrameLayout()");
            this.frameContainer = new FrameLayout((Context)activity);
        }
        this.frameContainer.setLayoutParams(new ViewGroup.LayoutParams(100, 100));
        this.frameContainer.addView((View)linearLayout.getLayoutManager(), new ViewGroup.LayoutParams(-1, -1));
        this.defaultButtonDrawable = this.getView().getBackground();
        componentContainer.$add((AndroidViewComponent)this);
        this.BackgroundColor(0);
    }

    private void updateAppearance() {
        if (this.backgroundImageDrawable == null) {
            if (this.backgroundColor == 0) {
                ViewUtil.setBackgroundDrawable((View)this.viewLayout.getLayoutManager(), (Drawable)this.defaultButtonDrawable);
            } else {
                ViewUtil.setBackgroundDrawable((View)this.viewLayout.getLayoutManager(), null);
                this.viewLayout.getLayoutManager().setBackgroundColor(this.backgroundColor);
            }
        } else {
            ViewUtil.setBackgroundImage((View)this.viewLayout.getLayoutManager(), (Drawable)this.backgroundImageDrawable);
        }
    }

    @Override
    public void $add(AndroidViewComponent androidViewComponent) {
        this.viewLayout.add(androidViewComponent);
        this.allChildren.add((Object)androidViewComponent);
    }

    @Override
    public Activity $context() {
        return this.context;
    }

    @Override
    public Form $form() {
        return this.container.$form();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="A number that encodes how contents of the %type% are aligned  horizontally. The choices are: 1 = left aligned, 2 = right aligned,  3 = horizontally centered.  Alignment has no effect if the arrangement's width is automatic.")
    public int AlignHorizontal() {
        return this.AlignHorizontalAbstract().toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="1", editorType="horizontal_alignment")
    @SimpleProperty
    public void AlignHorizontal(@Options(value=HorizontalAlignment.class) int n) {
        HorizontalAlignment horizontalAlignment = HorizontalAlignment.fromUnderlyingValue((Integer)n);
        if (horizontalAlignment == null) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "HorizontalAlignment", 1401, n);
            return;
        }
        this.AlignHorizontalAbstract(horizontalAlignment);
    }

    public HorizontalAlignment AlignHorizontalAbstract() {
        return this.horizontalAlignment;
    }

    public void AlignHorizontalAbstract(HorizontalAlignment horizontalAlignment) {
        this.alignmentSetter.setHorizontalAlignment(horizontalAlignment);
        this.horizontalAlignment = horizontalAlignment;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="A number that encodes how the contents of the %type% are aligned  vertically. The choices are: 1 = aligned at the top, 2 = vertically centered, 3 = aligned at the bottom.  Alignment has no effect if the arrangement's height is automatic.")
    public int AlignVertical() {
        return this.AlignVerticalAbstract().toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="1", editorType="vertical_alignment")
    @SimpleProperty
    public void AlignVertical(@Options(value=VerticalAlignment.class) int n) {
        VerticalAlignment verticalAlignment = VerticalAlignment.fromUnderlyingValue((Integer)n);
        if (verticalAlignment == null) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "VerticalAlignment", 1402, n);
            return;
        }
        this.AlignVerticalAbstract(verticalAlignment);
    }

    public VerticalAlignment AlignVerticalAbstract() {
        return this.verticalAlignment;
    }

    public void AlignVerticalAbstract(VerticalAlignment verticalAlignment) {
        this.alignmentSetter.setVerticalAlignment(verticalAlignment);
        this.verticalAlignment = verticalAlignment;
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE, description="Returns the background color of the %type%")
    public int BackgroundColor() {
        return this.backgroundColor;
    }

    @DesignerProperty(defaultValue="&H00000000", editorType="color")
    @SimpleProperty(description="Specifies the background color of the %type%. The background color will not be visible if an Image is being displayed.")
    public void BackgroundColor(int n) {
        this.backgroundColor = n;
        super.updateAppearance();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public String Image() {
        return this.imagePath;
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty(description="Specifies the path of the background image for the %type%.  If there is both an Image and a BackgroundColor, only the Image will be visible.")
    public void Image(@Asset String string) {
        if (string.equals((Object)this.imagePath) && this.backgroundImageDrawable != null) {
            return;
        }
        if (string == null) {
            string = "";
        }
        this.imagePath = string;
        this.backgroundImageDrawable = null;
        if (string.length() > 0) {
            try {
                this.backgroundImageDrawable = MediaUtil.getBitmapDrawable((Form)this.container.$form(), (String)this.imagePath);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        super.updateAppearance();
    }

    @Override
    public List<? extends Component> getChildren() {
        return this.allChildren;
    }

    public View getView() {
        return this.frameContainer;
    }

    @Override
    public void setChildHeight(AndroidViewComponent androidViewComponent, int n) {
        int n2 = this.container.$form().Height();
        if (n2 == 0) {
            this.androidUIHandler.postDelayed(new Runnable((HVArrangement)this, androidViewComponent, n){
                final HVArrangement this$0;
                final AndroidViewComponent val$component;
                final int val$fHeight;
                {
                    this.this$0 = hVArrangement;
                    this.val$component = androidViewComponent;
                    this.val$fHeight = n;
                }

                public void run() {
                    Log.d((String)"HVArrangement", (String)"(HVArrangement)Height not stable yet... trying again");
                    this.this$0.setChildHeight(this.val$component, this.val$fHeight);
                }
            }, 100L);
        }
        int n3 = n;
        if (n <= -1000) {
            n3 = -(n + 1000) * n2 / 100;
        }
        androidViewComponent.setLastHeight(n3);
        if (this.orientation == 1) {
            ViewUtil.setChildHeightForHorizontalLayout((View)androidViewComponent.getView(), (int)n3);
        } else {
            ViewUtil.setChildHeightForVerticalLayout((View)androidViewComponent.getView(), (int)n3);
        }
    }

    @Override
    public void setChildWidth(AndroidViewComponent androidViewComponent, int n) {
        this.setChildWidth(androidViewComponent, n, 0);
    }

    public void setChildWidth(AndroidViewComponent androidViewComponent, int n, int n2) {
        int n3 = this.container.$form().Width();
        if (n3 == 0 && n2 < 2) {
            this.androidUIHandler.postDelayed(new Runnable((HVArrangement)this, androidViewComponent, n, n2){
                final HVArrangement this$0;
                final AndroidViewComponent val$component;
                final int val$fWidth;
                final int val$trycount;
                {
                    this.this$0 = hVArrangement;
                    this.val$component = androidViewComponent;
                    this.val$fWidth = n;
                    this.val$trycount = n2;
                }

                public void run() {
                    Log.d((String)"HVArrangement", (String)"(HVArrangement)Width not stable yet... trying again");
                    this.this$0.setChildWidth(this.val$component, this.val$fWidth, this.val$trycount + 1);
                }
            }, 100L);
        }
        n2 = n;
        if (n <= -1000) {
            Log.d((String)LOG_TAG, (String)("HVArrangement.setChildWidth(): width = " + n + " parent Width = " + n3 + " child = " + androidViewComponent));
            n2 = -(n + 1000) * n3 / 100;
        }
        androidViewComponent.setLastWidth(n2);
        if (this.orientation == 1) {
            ViewUtil.setChildWidthForHorizontalLayout((View)androidViewComponent.getView(), (int)n2);
        } else {
            ViewUtil.setChildWidthForVerticalLayout((View)androidViewComponent.getView(), (int)n2);
        }
    }
}

