package com.google.appinventor.components.runtime.util;

import java.util.Iterator;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface YailObject<T> extends Iterable<T> {
    Object getObject(int i);

    boolean isEmpty();

    @Override // java.lang.Iterable
    Iterator<T> iterator();

    int size();
}
