/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 */
package com.google.appinventor.components.runtime.collect;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Lists {
    public static <E> ArrayList<E> newArrayList() {
        return new ArrayList();
    }

    public static <E> ArrayList<E> newArrayList(E ... EArray) {
        ArrayList arrayList = new ArrayList(EArray.length * 110 / 100 + 5);
        Collections.addAll((Collection)arrayList, (Object[])EArray);
        return arrayList;
    }
}

