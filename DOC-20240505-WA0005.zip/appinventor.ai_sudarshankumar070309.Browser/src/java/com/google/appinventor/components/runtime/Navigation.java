/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.common.TransportMethod
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.GeoJSONUtil
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.JsonUtil
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.io.BufferedOutputStream
 *  java.io.IOException
 *  java.io.InputStreamReader
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.util.Arrays
 *  java.util.List
 *  org.json.JSONException
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.TransportMethod;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.GeoJSONUtil;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.JsonUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import com.google.appinventor.components.runtime.util.YailDictionary;
import com.google.appinventor.components.runtime.util.YailList;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import org.json.JSONException;
import org.osmdroid.util.GeoPoint;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MAPS, description="Navigation", iconName="images/navigation.png", nonVisible=true, version=2)
@SimpleObject
@UsesLibraries(value={"osmdroid.jar"})
@UsesPermissions(permissionNames="android.permission.INTERNET")
public class Navigation
extends AndroidNonvisibleComponent
implements Component {
    public static final String OPEN_ROUTE_SERVICE_URL = "https://api.openrouteservice.org/v2/directions/";
    private static final String TAG = "Navigation";
    private String apiKey = "";
    private GeoPoint endLocation;
    private String language = "en";
    private YailDictionary lastResponse = YailDictionary.makeDictionary();
    private TransportMethod method;
    private String serviceUrl = "https://api.openrouteservice.org/v2/directions/";
    private GeoPoint startLocation = new GeoPoint(0.0, 0.0);

    static /* bridge */ /* synthetic */ void -$$Nest$fputlastResponse(Navigation navigation, YailDictionary yailDictionary) {
        navigation.lastResponse = yailDictionary;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mperformRequest(Navigation navigation, GeoPoint geoPoint, GeoPoint geoPoint2, TransportMethod transportMethod) {
        navigation.performRequest(geoPoint, geoPoint2, transportMethod);
    }

    public Navigation(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.endLocation = new GeoPoint(0.0, 0.0);
        this.method = TransportMethod.Foot;
    }

    private Double[][] getCoordinates(GeoPoint geoPoint, GeoPoint geoPoint2) {
        Double[][] doubleArray = new Double[2][2];
        doubleArray[0][0] = geoPoint.getLongitude();
        doubleArray[0][1] = geoPoint.getLatitude();
        doubleArray[1][0] = geoPoint2.getLongitude();
        doubleArray[1][1] = geoPoint2.getLatitude();
        return doubleArray;
    }

    private List<?> getDirections(YailDictionary yailDictionary) {
        return YailDictionary.walkKeyPath(yailDictionary, Arrays.asList((Object[])new Object[]{"properties", "segments", YailDictionary.ALL, "steps", YailDictionary.ALL, "instruction"}));
    }

    private YailList getLineStringCoords(YailDictionary yailDictionary) {
        return GeoJSONUtil.swapCoordinates((YailList)((YailList)yailDictionary.getObjectAtKeyPath(Arrays.asList((Object[])new String[]{"geometry", "coordinates"}))));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String getResponseContent(HttpURLConnection object2) throws IOException {
        Object object3 = object2.getContentEncoding();
        String string = object3;
        if (object3 == null) {
            string = "UTF-8";
        }
        Log.d((String)TAG, (String)Integer.toString((int)object2.getResponseCode()));
        string = new InputStreamReader(object2.getInputStream(), string);
        try {
            int n = object2.getContentLength();
            object2 = n != -1 ? new StringBuilder(n) : new StringBuilder();
            object3 = new char[1024];
            while ((n = string.read((char[])object3)) != -1) {
                object2.append((char[])object3, 0, n);
            }
            object2 = object2.toString();
            return object2;
        }
        finally {
            string.close();
        }
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     */
    private void performRequest(GeoPoint object2, GeoPoint object3, TransportMethod object4) throws IOException, JSONException {
        void var1_9;
        block20: {
            block23: {
                block21: {
                    block22: {
                        Object object5;
                        block19: {
                            object5 = this.serviceUrl;
                            object4 = object4.toUnderlyingValue();
                            object4 = (HttpURLConnection)new URL((String)object5 + (String)object4 + "/geojson/").openConnection();
                            object4.setDoInput(true);
                            object4.setDoOutput(true);
                            object4.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                            object4.setRequestMethod("POST");
                            object4.setRequestProperty("Authorization", this.apiKey);
                            object2 = JsonUtil.getJsonRepresentation((Object)super.getCoordinates((GeoPoint)object2, (GeoPoint)object3));
                            object5 = this.language;
                            object3 = new StringBuilder();
                            object3 = object3.append("{\"coordinates\": ").append((String)object2).append(", \"language\": \"").append((String)object5).append("\"}").toString().getBytes("UTF-8");
                            object4.setFixedLengthStreamingMode(((GeoPoint)object3).length);
                            object2 = new BufferedOutputStream(object4.getOutputStream());
                            object2.write((byte[])object3, 0, ((GeoPoint)object3).length);
                            object2.flush();
                            object2.close();
                            int n = object4.getResponseCode();
                            if (n == 200) break block19;
                            try {
                                this.form.dispatchErrorOccurredEvent((Component)this, "RequestDirections", 4003, object4.getResponseCode(), object4.getResponseMessage());
                            }
                            catch (Throwable throwable) {
                                break block20;
                            }
                            catch (Exception exception) {
                                break block21;
                            }
                            object4.disconnect();
                            return;
                        }
                        object2 = Navigation.getResponseContent((HttpURLConnection)object4);
                        Log.d((String)TAG, (String)object2);
                        object2 = (YailDictionary)((Object)JsonUtil.getObjectFromJson((String)object2, (boolean)true));
                        object3 = (YailList)((YailDictionary)((Object)object2)).get("features");
                        if (object3.size() <= 0) break block22;
                        object5 = (YailDictionary)((Object)object3.getObject(0));
                        object3 = (YailDictionary)((Object)((YailDictionary)((Object)object5)).getObjectAtKeyPath(Arrays.asList((Object[])new String[]{"properties", "summary"})));
                        double d = (Double)((YailDictionary)((Object)object3)).get("distance");
                        double d2 = (Double)((YailDictionary)((Object)object3)).get("duration");
                        object3 = YailList.makeList(super.getDirections((YailDictionary)((Object)object5)));
                        YailList yailList = super.getLineStringCoords((YailDictionary)((Object)object5));
                        object5 = this.form;
                        Runnable runnable = new Runnable((Navigation)this, (YailDictionary)((Object)object2), (YailList)object3, yailList, d, d2){
                            final Navigation this$0;
                            final YailList val$coordinates;
                            final YailList val$directions;
                            final double val$distance;
                            final double val$duration;
                            final YailDictionary val$response;
                            {
                                this.this$0 = navigation;
                                this.val$response = yailDictionary;
                                this.val$directions = yailList;
                                this.val$coordinates = yailList2;
                                this.val$distance = d;
                                this.val$duration = d2;
                            }

                            public void run() {
                                Navigation.-$$Nest$fputlastResponse(this.this$0, this.val$response);
                                this.this$0.GotDirections(this.val$directions, this.val$coordinates, this.val$distance, this.val$duration);
                            }
                        };
                        object5.runOnUiThread(runnable);
                        break block23;
                    }
                    this.form.dispatchErrorOccurredEvent((Component)this, "RequestDirections", 4004, new Object[0]);
                    break block23;
                    catch (Throwable throwable) {
                        try {
                            object2.close();
                            throw throwable;
                        }
                        catch (Exception exception) {}
                    }
                    break block21;
                    catch (Throwable throwable) {
                        break block20;
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                this.form.dispatchErrorOccurredEvent((Component)this, "RequestDirections", 4002, object2.getMessage());
                object2.printStackTrace();
            }
            object4.disconnect();
            return;
            {
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
        }
        object4.disconnect();
        throw var1_9;
    }

    @DesignerProperty(editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="API Key for Open Route Service.")
    public void ApiKey(String string) {
        this.apiKey = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The latitude of the end location.")
    public double EndLatitude() {
        return this.endLocation.getLatitude();
    }

    @DesignerProperty(defaultValue="0.0", editorType="latitude")
    @SimpleProperty
    public void EndLatitude(double d) {
        if (GeometryUtil.isValidLatitude((double)d)) {
            this.endLocation.setLatitude(d);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "EndLatitude", 3413, d);
        }
    }

    @SimpleProperty(description="Set the end location.")
    public void EndLocation(MapFactory.MapFeature mapFeature) {
        mapFeature = mapFeature.getCentroid();
        double d = mapFeature.getLatitude();
        double d2 = mapFeature.getLongitude();
        if (!GeometryUtil.isValidLatitude((double)d)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetEndLocation", 3413, d);
        } else if (!GeometryUtil.isValidLongitude((double)d2)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetEndLocation", 3414, d2);
        } else {
            this.endLocation.setCoords(d, d2);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The longitude of the end location.")
    public double EndLongitude() {
        return this.endLocation.getLongitude();
    }

    @DesignerProperty(defaultValue="0.0", editorType="longitude")
    @SimpleProperty
    public void EndLongitude(double d) {
        if (GeometryUtil.isValidLongitude((double)d)) {
            this.endLocation.setLongitude(d);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "EndLongitude", 3414, d);
        }
    }

    @SimpleEvent(description="Event triggered when the Openrouteservice returns the directions.")
    public void GotDirections(YailList yailList, YailList yailList2, double d, double d2) {
        Log.d((String)TAG, (String)"GotDirections");
        EventDispatcher.dispatchEvent((Component)this, "GotDirections", yailList, yailList2, d, d2);
    }

    @SimpleProperty
    public String Language() {
        return this.language;
    }

    @DesignerProperty(defaultValue="en")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The language to use for textual directions.")
    public void Language(String string) {
        this.language = string;
    }

    @SimpleFunction(description="Request directions from the routing service.")
    public void RequestDirections() {
        if (this.apiKey.equals((Object)"")) {
            this.form.dispatchErrorOccurredEvent(this, "Authorization", 4001, new Object[0]);
            return;
        }
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this, this.startLocation, this.endLocation, this.method){
            final Navigation this$0;
            final GeoPoint val$endLocation;
            final TransportMethod val$method;
            final GeoPoint val$startLocation;
            {
                this.this$0 = navigation;
                this.val$startLocation = geoPoint;
                this.val$endLocation = geoPoint2;
                this.val$method = transportMethod;
            }

            public void run() {
                try {
                    Navigation.-$$Nest$mperformRequest(this.this$0, this.val$startLocation, this.val$endLocation, this.val$method);
                }
                catch (JSONException jSONException) {
                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestDirections", 0, new Object[0]);
                }
                catch (IOException iOException) {
                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestDirections", 0, new Object[0]);
                }
            }
        });
    }

    @SimpleProperty(description="Content of the last response as a dictionary.")
    public YailDictionary ResponseContent() {
        return this.lastResponse;
    }

    @SimpleProperty(userVisible=false)
    public void ServiceURL(String string) {
        this.serviceUrl = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The latitude of the start location.")
    public double StartLatitude() {
        return this.startLocation.getLatitude();
    }

    @DesignerProperty(defaultValue="0.0", editorType="latitude")
    @SimpleProperty
    public void StartLatitude(double d) {
        if (GeometryUtil.isValidLatitude((double)d)) {
            this.startLocation.setLatitude(d);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "StartLatitude", 3413, d);
        }
    }

    @SimpleProperty(description="Set the start location.")
    public void StartLocation(MapFactory.MapFeature mapFeature) {
        mapFeature = mapFeature.getCentroid();
        double d = mapFeature.getLatitude();
        double d2 = mapFeature.getLongitude();
        if (!GeometryUtil.isValidLatitude((double)d)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetStartLocation", 3413, d);
        } else if (!GeometryUtil.isValidLongitude((double)d2)) {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "SetStartLocation", 3414, d2);
        } else {
            this.startLocation.setCoords(d, d2);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The longitude of the start location.")
    public double StartLongitude() {
        return this.startLocation.getLongitude();
    }

    @DesignerProperty(defaultValue="0.0", editorType="longitude")
    @SimpleProperty
    public void StartLongitude(double d) {
        if (GeometryUtil.isValidLongitude((double)d)) {
            this.startLocation.setLongitude(d);
        } else {
            this.getDispatchDelegate().dispatchErrorOccurredEvent((Component)this, "StartLongitude", 3414, d);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String TransportationMethod() {
        return this.TransportationMethodAbstract().toUnderlyingValue();
    }

    @DesignerProperty(defaultValue="foot-walking", editorType="navigation_method")
    @SimpleProperty(description="The transportation method used for determining the route.")
    public void TransportationMethod(@Options(value=TransportMethod.class) String string) {
        if ((string = TransportMethod.fromUnderlyingValue((String)string)) != null) {
            this.TransportationMethodAbstract((TransportMethod)string);
        }
    }

    public TransportMethod TransportationMethodAbstract() {
        return this.method;
    }

    public void TransportationMethodAbstract(TransportMethod transportMethod) {
        this.method = transportMethod;
    }
}

