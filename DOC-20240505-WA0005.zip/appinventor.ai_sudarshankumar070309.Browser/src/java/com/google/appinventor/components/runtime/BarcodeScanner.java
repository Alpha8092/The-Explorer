/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ActivityNotFoundException
 *  android.content.ComponentName
 *  android.content.Intent
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.BarcodeScanner$1
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.BarcodeScanner;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.util.SdkLevel;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class BarcodeScanner
extends AndroidNonvisibleComponent
implements ActivityResultListener,
Component {
    private static final String LOCAL_SCAN = "com.google.zxing.client.android.AppInvCaptureActivity";
    private static final String SCANNER_RESULT_NAME = "SCAN_RESULT";
    private static final String SCAN_INTENT = "com.google.zxing.client.android.SCAN";
    private final ComponentContainer container;
    private boolean havePermission = false;
    private int requestCode;
    private String result = "";
    private boolean useExternalScanner = true;

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(BarcodeScanner barcodeScanner, boolean bl) {
        barcodeScanner.havePermission = bl;
    }

    public BarcodeScanner(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.container = componentContainer;
    }

    @SimpleEvent
    public void AfterScan(String string) {
        EventDispatcher.dispatchEvent((Component)this, "AfterScan", string);
    }

    @SimpleFunction(description="Begins a barcode scan, using the camera. When the scan is complete, the AfterScan event will be raised.")
    public void DoScan() {
        Intent intent = new Intent(SCAN_INTENT);
        if (!this.useExternalScanner && SdkLevel.getLevel() >= 5) {
            if (!this.havePermission) {
                this.container.$form().askPermission("android.permission.CAMERA", (PermissionResultHandler)new 1(this));
                return;
            }
            intent.setComponent(new ComponentName(this.container.$form().getPackageName(), LOCAL_SCAN));
        }
        if (this.requestCode == 0) {
            this.requestCode = this.form.registerForActivityResult(this);
        }
        try {
            this.container.$context().startActivityForResult(intent, this.requestCode);
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            activityNotFoundException.printStackTrace();
            this.container.$form().dispatchErrorOccurredEvent(this, "BarcodeScanner", 1501, "");
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Text result of the previous scan.")
    public String Result() {
        return this.result;
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty
    public void UseExternalScanner(boolean bl) {
        this.useExternalScanner = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true App Inventor will look for and use an external scanning program such as \"Bar Code Scanner.\"")
    public boolean UseExternalScanner() {
        return this.useExternalScanner;
    }

    @Override
    public void resultReturned(int n, int n2, Intent intent) {
        if (n == this.requestCode && n2 == -1) {
            this.result = intent.hasExtra(SCANNER_RESULT_NAME) ? intent.getStringExtra(SCANNER_RESULT_NAME) : "";
            this.AfterScan(this.result);
        }
    }
}

