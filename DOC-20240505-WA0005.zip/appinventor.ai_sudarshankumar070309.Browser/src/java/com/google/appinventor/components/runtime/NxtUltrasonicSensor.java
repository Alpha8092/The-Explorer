/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorType
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsNxtSensor;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to an ultrasonic sensor on a LEGO MINDSTORMS NXT robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtUltrasonicSensor
extends LegoMindstormsNxtSensor
implements Deleteable {
    private static final int DEFAULT_BOTTOM_OF_RANGE = 30;
    private static final String DEFAULT_SENSOR_PORT = "4";
    private static final int DEFAULT_TOP_OF_RANGE = 90;
    private boolean aboveRangeEventEnabled;
    private boolean belowRangeEventEnabled;
    private int bottomOfRange;
    private Handler handler = new Handler();
    private State previousState = State.UNKNOWN;
    private final Runnable sensorReader;
    private int topOfRange;
    private boolean withinRangeEventEnabled;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetaboveRangeEventEnabled(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.aboveRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetbelowRangeEventEnabled(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.belowRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetbottomOfRange(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.bottomOfRange;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.handler;
    }

    static /* bridge */ /* synthetic */ State -$$Nest$fgetpreviousState(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.previousState;
    }

    static /* bridge */ /* synthetic */ Runnable -$$Nest$fgetsensorReader(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.sensorReader;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgettopOfRange(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.topOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetwithinRangeEventEnabled(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.withinRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousState(NxtUltrasonicSensor nxtUltrasonicSensor, State state) {
        nxtUltrasonicSensor.previousState = state;
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetDistanceValue(NxtUltrasonicSensor nxtUltrasonicSensor, String string2) {
        return nxtUltrasonicSensor.getDistanceValue(string2);
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$misHandlerNeeded(NxtUltrasonicSensor nxtUltrasonicSensor) {
        return nxtUltrasonicSensor.isHandlerNeeded();
    }

    public NxtUltrasonicSensor(ComponentContainer componentContainer) {
        super(componentContainer, "NxtUltrasonicSensor");
        this.sensorReader = new Runnable((NxtUltrasonicSensor)this){
            final NxtUltrasonicSensor this$0;
            {
                this.this$0 = nxtUltrasonicSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    Object object = NxtUltrasonicSensor.-$$Nest$mgetDistanceValue(this.this$0, "");
                    if (object.valid) {
                        object = (Integer)object.value < NxtUltrasonicSensor.-$$Nest$fgetbottomOfRange(this.this$0) ? State.BELOW_RANGE : ((Integer)object.value > NxtUltrasonicSensor.-$$Nest$fgettopOfRange(this.this$0) ? State.ABOVE_RANGE : State.WITHIN_RANGE);
                        if (object != NxtUltrasonicSensor.-$$Nest$fgetpreviousState(this.this$0)) {
                            if (object == State.BELOW_RANGE && NxtUltrasonicSensor.-$$Nest$fgetbelowRangeEventEnabled(this.this$0)) {
                                this.this$0.BelowRange();
                            }
                            if (object == State.WITHIN_RANGE && NxtUltrasonicSensor.-$$Nest$fgetwithinRangeEventEnabled(this.this$0)) {
                                this.this$0.WithinRange();
                            }
                            if (object == State.ABOVE_RANGE && NxtUltrasonicSensor.-$$Nest$fgetaboveRangeEventEnabled(this.this$0)) {
                                this.this$0.AboveRange();
                            }
                        }
                        NxtUltrasonicSensor.-$$Nest$fputpreviousState(this.this$0, (Object)object);
                    }
                }
                if (NxtUltrasonicSensor.-$$Nest$misHandlerNeeded(this.this$0)) {
                    NxtUltrasonicSensor.-$$Nest$fgethandler(this.this$0).post(NxtUltrasonicSensor.-$$Nest$fgetsensorReader(this.this$0));
                }
            }
        };
        this.SensorPort(DEFAULT_SENSOR_PORT);
        this.BottomOfRange(30);
        this.TopOfRange(90);
        this.BelowRangeEventEnabled(false);
        this.WithinRangeEventEnabled(false);
        this.AboveRangeEventEnabled(false);
    }

    private void configureUltrasonicSensor(String string2) {
        this.lsWrite(string2, this.port, new byte[]{2, 65, 2}, 0);
    }

    private LegoMindstormsNxtSensor.SensorValue<Integer> getDistanceValue(String object) {
        this.lsWrite((String)object, this.port, new byte[]{2, 66}, 1);
        for (int i = 0; i < 3; ++i) {
            if (this.lsGetStatus((String)object, this.port) <= 0) continue;
            if ((object = (Object)this.lsRead((String)object, this.port)) == null || (i = this.getUBYTEValueFromBytes((byte[])object, 4)) < 0 || i > 254) break;
            return new Object(true, i){
                final boolean valid;
                final T value;
                {
                    this.valid = bl;
                    this.value = t;
                }
            };
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private boolean isHandlerNeeded() {
        boolean bl = this.belowRangeEventEnabled || this.withinRangeEventEnabled || this.aboveRangeEventEnabled;
        return bl;
    }

    @SimpleEvent(description="Distance has gone above the range.")
    public void AboveRange() {
        EventDispatcher.dispatchEvent(this, "AboveRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void AboveRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.aboveRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the AboveRange event should fire when the distance goes above the TopOfRange.")
    public boolean AboveRangeEventEnabled() {
        return this.aboveRangeEventEnabled;
    }

    @SimpleEvent(description="Distance has gone below the range.")
    public void BelowRange() {
        EventDispatcher.dispatchEvent(this, "BelowRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BelowRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.belowRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the BelowRange event should fire when the distance goes below the BottomOfRange.")
    public boolean BelowRangeEventEnabled() {
        return this.belowRangeEventEnabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The bottom of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int BottomOfRange() {
        return this.bottomOfRange;
    }

    @DesignerProperty(defaultValue="30", editorType="non_negative_integer")
    @SimpleProperty
    public void BottomOfRange(int n) {
        this.bottomOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleFunction(description="Returns the current distance in centimeters as a value between 0 and 254, or -1 if the distance can not be read.")
    public int GetDistance() {
        if (!this.checkBluetooth("GetDistance")) {
            return -1;
        }
        LegoMindstormsNxtSensor.SensorValue<Integer> sensorValue = this.getDistanceValue("GetDistance");
        if (sensorValue.valid) {
            return (Integer)sensorValue.value;
        }
        return -1;
    }

    @Override
    @DesignerProperty(defaultValue="4", editorType="lego_nxt_sensor_port")
    @SimpleProperty(userVisible=false)
    public void SensorPort(String string2) {
        this.setSensorPort(string2);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The top of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int TopOfRange() {
        return this.topOfRange;
    }

    @DesignerProperty(defaultValue="90", editorType="non_negative_integer")
    @SimpleProperty
    public void TopOfRange(int n) {
        this.topOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleEvent(description="Distance has gone within the range.")
    public void WithinRange() {
        EventDispatcher.dispatchEvent(this, "WithinRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WithinRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.withinRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the WithinRange event should fire when the distance goes between the BottomOfRange and the TopOfRange.")
    public boolean WithinRangeEventEnabled() {
        return this.withinRangeEventEnabled;
    }

    @Override
    protected void initializeSensor(String string2) {
        this.setInputMode(string2, this.port, NxtSensorType.Digital12C9V, NxtSensorMode.Raw);
        super.configureUltrasonicSensor(string2);
    }

    @Override
    public void onDelete() {
        this.handler.removeCallbacks(this.sensorReader);
        super.onDelete();
    }
}

