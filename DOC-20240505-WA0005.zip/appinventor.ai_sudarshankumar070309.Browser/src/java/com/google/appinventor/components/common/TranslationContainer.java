/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.common;

import java.util.HashMap;
import java.util.Map;

public class TranslationContainer {
    private Map<String, String> CompTransMap;

    public TranslationContainer() {
        HashMap hashMap;
        this.CompTransMap = hashMap = new HashMap();
        hashMap.put((Object)"Basic", (Object)"\u57fa\u672c");
        this.CompTransMap.put((Object)"Media", (Object)"\u5a92\u4f53");
        this.CompTransMap.put((Object)"Animation", (Object)"\u52a8\u753b");
        this.CompTransMap.put((Object)"Social", (Object)"\u793e\u4ea4\u7684");
        this.CompTransMap.put((Object)"Sensors", (Object)"\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"Screen Arrangement", (Object)"\u5c4f\u5e55\u5e03\u5c40");
        this.CompTransMap.put((Object)"LEGO\u00ae MINDSTORMS\u00ae", (Object)"\u4e50\u9ad8\u673a\u5668\u4eba\u5957\u4ef6\u00ae");
        this.CompTransMap.put((Object)"Other stuff", (Object)"\u5176\u4ed6\u4e1c\u897f");
        this.CompTransMap.put((Object)"Not ready for prime time", (Object)"\u6d4b\u8bd5\u4e2d\u7684\u5957\u4ef6");
        this.CompTransMap.put((Object)"Old stuff", (Object)"\u65e7\u4e1c\u897f");
        this.CompTransMap.put((Object)"Button", (Object)"\u6309\u94ae");
        this.CompTransMap.put((Object)"Canvas", (Object)"\u753b\u5e03");
        this.CompTransMap.put((Object)"CheckBox", (Object)"\u590d\u9009\u6846");
        this.CompTransMap.put((Object)"Clock", (Object)"\u65f6\u949f");
        this.CompTransMap.put((Object)"Image", (Object)"\u56fe\u50cf");
        this.CompTransMap.put((Object)"Label", (Object)"\u4fbf\u7b7e");
        this.CompTransMap.put((Object)"ListPicker", (Object)"\u5217\u8868\u9009\u62e9\u5668");
        this.CompTransMap.put((Object)"PasswordTextBox", (Object)"\u5bc6\u7801\u6846");
        this.CompTransMap.put((Object)"TextBox", (Object)"\u6587\u672c\u6846");
        this.CompTransMap.put((Object)"TinyDB", (Object)"\u7ec6\u5c0f\u6570\u636e\u5e93");
        this.CompTransMap.put((Object)"Camcorder", (Object)"\u6444\u50cf\u673a");
        this.CompTransMap.put((Object)"Camera", (Object)"\u76f8\u673a");
        this.CompTransMap.put((Object)"ImagePicker", (Object)"\u753b\u50cf\u9009\u62e9\u5668");
        this.CompTransMap.put((Object)"Player", (Object)"\u64ad\u653e\u5668");
        this.CompTransMap.put((Object)"Sound", (Object)"\u58f0\u97f3");
        this.CompTransMap.put((Object)"VideoPlayer", (Object)"\u5a92\u4f53\u64ad\u653e\u5668");
        this.CompTransMap.put((Object)"Ball", (Object)"\u7403");
        this.CompTransMap.put((Object)"ImageSprite", (Object)"\u56fe\u7247\u7cbe\u7075");
        this.CompTransMap.put((Object)"ContactPicker", (Object)"\u8054\u7cfb\u4fe1\u606f\u9009\u62e9\u5668");
        this.CompTransMap.put((Object)"EmailPicker", (Object)"\u90ae\u4ef6\u9009\u62e9\u5668");
        this.CompTransMap.put((Object)"PhoneCall", (Object)"\u7535\u8bdd");
        this.CompTransMap.put((Object)"PhoneNumberPicker", (Object)"\u7535\u8bdd\u53f7\u7801\u9009\u62e9\u5668");
        this.CompTransMap.put((Object)"Texting", (Object)"\u4fe1\u606f");
        this.CompTransMap.put((Object)"Twitter", (Object)"Twitter");
        this.CompTransMap.put((Object)"AccelerometerSensor", (Object)"\u52a0\u901f\u5ea6\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"LocationSensor", (Object)"\u4f4d\u7f6e\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"OrientationSensor", (Object)"\u65b9\u5411\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"HorizontalArrangement", (Object)"\u6c34\u5e73\u6392\u5217");
        this.CompTransMap.put((Object)"TableArrangement", (Object)"\u8868\u5b89\u6392");
        this.CompTransMap.put((Object)"VerticalArrangement", (Object)"\u7ad6\u5411\u5e03\u7f6e");
        this.CompTransMap.put((Object)"NxtColorSensor", (Object)"Nxt\u989c\u8272\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"NxtDirectCommands", (Object)"Nxt\u76f4\u63a5\u547d\u4ee4");
        this.CompTransMap.put((Object)"NxtDrive", (Object)"Nxt\u9a71\u52a8");
        this.CompTransMap.put((Object)"NxtLightSensor", (Object)"Nxt\u5149\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"NxtSoundSensor", (Object)"Nxt\u58f0\u97f3\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"NxtTouchSensor", (Object)"Nxt\u89e6\u6478\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"NxtUltrasonicSensor", (Object)"Nxt\u8d85\u58f0\u6ce2\u4f20\u611f\u5668");
        this.CompTransMap.put((Object)"ActivityStarter", (Object)"\u6d3b\u52a8\u542f\u52a8");
        this.CompTransMap.put((Object)"BarcodeScanner", (Object)"\u6761\u7801\u626b\u63cf\u5668");
        this.CompTransMap.put((Object)"BluetoothClient", (Object)"\u84dd\u7259\u5ba2\u6237");
        this.CompTransMap.put((Object)"BluetoothServer", (Object)"\u84dd\u7259\u670d\u52a1\u5668");
        this.CompTransMap.put((Object)"Notifier", (Object)"\u901a\u544a\u4eba");
        this.CompTransMap.put((Object)"SpeechRecognizer", (Object)"\u8bed\u97f3\u8bc6\u522b");
        this.CompTransMap.put((Object)"TextToSpeech", (Object)"\u6587\u672c\u5230\u8bed\u97f3");
        this.CompTransMap.put((Object)"TinyWebDB", (Object)"\u7ec6\u5c0f\u7f51\u7edc\u6570\u636e\u5e93");
        this.CompTransMap.put((Object)"Web", (Object)"\u7f51\u7edc");
        this.CompTransMap.put((Object)"FusiontablesControl", (Object)"Fusiontables\u63a7\u5236");
        this.CompTransMap.put((Object)"GameClient", (Object)"\u6e38\u620f\u5ba2\u6237\u7aef");
        this.CompTransMap.put((Object)"SoundRecorder", (Object)"\u58f0\u97f3\u8bb0\u5f55\u5668");
        this.CompTransMap.put((Object)"Voting", (Object)"\u6295\u7968");
        this.CompTransMap.put((Object)"WebViewer", (Object)"\u7f51\u9875\u6d4f\u89c8\u5668");
    }

    public String getCorrespondingString(String string2) {
        if (this.CompTransMap.containsKey((Object)string2)) {
            return (String)this.CompTransMap.get((Object)string2);
        }
        return "Missing name";
    }
}

