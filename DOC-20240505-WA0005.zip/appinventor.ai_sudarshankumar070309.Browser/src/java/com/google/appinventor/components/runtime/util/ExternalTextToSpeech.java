/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  com.google.appinventor.components.runtime.util.ITextToSpeech
 *  com.google.appinventor.components.runtime.util.ITextToSpeech$TextToSpeechCallback
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.Locale
 */
package com.google.appinventor.components.runtime.util;

import android.content.Intent;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.util.ITextToSpeech;
import java.util.Locale;

public class ExternalTextToSpeech
implements ITextToSpeech,
ActivityResultListener {
    private static final String TTS_INTENT = "com.google.tts.makeBagel";
    private final ITextToSpeech.TextToSpeechCallback callback;
    private final ComponentContainer container;
    private int requestCode;

    public ExternalTextToSpeech(ComponentContainer componentContainer, ITextToSpeech.TextToSpeechCallback textToSpeechCallback) {
        this.container = componentContainer;
        this.callback = textToSpeechCallback;
    }

    public boolean isInitialized() {
        return true;
    }

    public int isLanguageAvailable(Locale locale) {
        return -1;
    }

    public void onDestroy() {
    }

    public void onResume() {
    }

    public void onStop() {
    }

    @Override
    public void resultReturned(int n, int n2, Intent intent) {
        if ((n = n == this.requestCode && n2 == -1 ? 1 : 0) != 0) {
            this.callback.onSuccess();
        } else {
            this.callback.onFailure();
        }
    }

    public void setPitch(float f) {
    }

    public void setSpeechRate(float f) {
    }

    public void speak(String string, Locale locale) {
        Intent intent = new Intent(TTS_INTENT);
        intent.setFlags(131072);
        intent.setFlags(0x800000);
        intent.setFlags(0x40000000);
        intent.putExtra("message", string);
        intent.putExtra("language", locale.getISO3Language());
        intent.putExtra("country", locale.getISO3Country());
        if (this.requestCode == 0) {
            this.requestCode = this.container.$form().registerForActivityResult((ActivityResultListener)this);
        }
        this.container.$context().startActivityForResult(intent, this.requestCode);
    }

    public void stop() {
    }
}

