/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.common;

import java.util.HashMap;
import java.util.Map;

public final class ComponentCategory
extends Enum<ComponentCategory> {
    private static final ComponentCategory[] $VALUES;
    public static final /* enum */ ComponentCategory ANIMATION;
    public static final /* enum */ ComponentCategory CHARTS;
    public static final /* enum */ ComponentCategory CONNECTIVITY;
    public static final /* enum */ ComponentCategory DATASCIENCE;
    private static final Map<String, String> DOC_MAP;
    public static final /* enum */ ComponentCategory EXPERIMENTAL;
    public static final /* enum */ ComponentCategory EXTENSION;
    public static final /* enum */ ComponentCategory FUTURE;
    public static final /* enum */ ComponentCategory INTERNAL;
    public static final /* enum */ ComponentCategory LAYOUT;
    public static final /* enum */ ComponentCategory LEGOMINDSTORMS;
    public static final /* enum */ ComponentCategory MAPS;
    public static final /* enum */ ComponentCategory MEDIA;
    public static final /* enum */ ComponentCategory SENSORS;
    public static final /* enum */ ComponentCategory SOCIAL;
    public static final /* enum */ ComponentCategory STORAGE;
    public static final /* enum */ ComponentCategory UNINITIALIZED;
    public static final /* enum */ ComponentCategory USERINTERFACE;
    private final String name;

    static {
        ComponentCategory componentCategory;
        ComponentCategory componentCategory2;
        ComponentCategory componentCategory3;
        ComponentCategory componentCategory4;
        ComponentCategory componentCategory5;
        ComponentCategory componentCategory6;
        ComponentCategory componentCategory7;
        ComponentCategory componentCategory8;
        ComponentCategory componentCategory9;
        ComponentCategory componentCategory10;
        ComponentCategory componentCategory11;
        ComponentCategory componentCategory12;
        ComponentCategory componentCategory13;
        ComponentCategory componentCategory14;
        ComponentCategory componentCategory15;
        ComponentCategory componentCategory16;
        ComponentCategory componentCategory17;
        USERINTERFACE = componentCategory17 = new ComponentCategory("User Interface");
        LAYOUT = componentCategory16 = new ComponentCategory("Layout");
        MEDIA = componentCategory15 = new ComponentCategory("Media");
        ANIMATION = componentCategory14 = new ComponentCategory("Drawing and Animation");
        MAPS = componentCategory13 = new ComponentCategory("Maps");
        CHARTS = componentCategory12 = new ComponentCategory("Charts");
        DATASCIENCE = componentCategory11 = new ComponentCategory("Data Science");
        SENSORS = componentCategory10 = new ComponentCategory("Sensors");
        SOCIAL = componentCategory9 = new ComponentCategory("Social");
        STORAGE = componentCategory8 = new ComponentCategory("Storage");
        CONNECTIVITY = componentCategory7 = new ComponentCategory("Connectivity");
        LEGOMINDSTORMS = componentCategory6 = new ComponentCategory("LEGO\u00ae MINDSTORMS\u00ae");
        EXPERIMENTAL = componentCategory5 = new ComponentCategory("Experimental");
        EXTENSION = componentCategory4 = new ComponentCategory("Extension");
        FUTURE = componentCategory3 = new ComponentCategory("Future");
        INTERNAL = componentCategory2 = new ComponentCategory("For internal use only");
        UNINITIALIZED = componentCategory = new ComponentCategory("Uninitialized");
        $VALUES = new ComponentCategory[]{componentCategory17, componentCategory16, componentCategory15, componentCategory14, componentCategory13, componentCategory12, componentCategory11, componentCategory10, componentCategory9, componentCategory8, componentCategory7, componentCategory6, componentCategory5, componentCategory4, componentCategory3, componentCategory2, componentCategory};
        componentCategory = new HashMap();
        DOC_MAP = componentCategory;
        componentCategory.put("User Interface", "userinterface");
        componentCategory.put("Layout", "layout");
        componentCategory.put("Media", "media");
        componentCategory.put("Drawing and Animation", "animation");
        componentCategory.put("Maps", "maps");
        componentCategory.put("Charts", "charts");
        componentCategory.put("Data Science", "datascience");
        componentCategory.put("Sensors", "sensors");
        componentCategory.put("Social", "social");
        componentCategory.put("Storage", "storage");
        componentCategory.put("Connectivity", "connectivity");
        componentCategory.put("LEGO\u00ae MINDSTORMS\u00ae", "legomindstorms");
        componentCategory.put("Experimental", "experimental");
        componentCategory.put("Extension", "extension");
        componentCategory.put("Future", "future");
    }

    private ComponentCategory(String string2) {
        this.name = string2;
    }

    public static ComponentCategory valueOf(String string) {
        return (ComponentCategory)Enum.valueOf(ComponentCategory.class, (String)string);
    }

    public static ComponentCategory[] values() {
        return (ComponentCategory[])$VALUES.clone();
    }

    public String getDocName() {
        return (String)DOC_MAP.get((Object)this.name);
    }

    public String getName() {
        return this.name;
    }
}

