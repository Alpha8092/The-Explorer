/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Parcelable
 *  android.webkit.MimeTypeMap
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.util.NougatUtil
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.webkit.MimeTypeMap;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.NougatUtil;
import java.io.File;

@DesignerComponent(category=ComponentCategory.SOCIAL, description="Sharing is a non-visible component that enables sharing files and/or messages between your app and other apps installed on a device. The component will display a list of the installed apps that can handle the information provided, and will allow the user to choose one to share the content with, for instance a mail app, a social network app, a texting app, and so on.<br>The file path can be taken directly from other components such as the Camera or the ImagePicker, but can also be specified directly to read from storage. The default behaviour is to share files from the private data directory associated with your app. If the file path starts with a slash (/), the the file relative to / is shared.<br>Be aware that different devices treat storage differently, so a few things to try if, for instance, you have a file called arrow.gif in the folder <code>Appinventor/assets</code>, would be: <ul><li><code>\"file:///sdcard/Appinventor/assets/arrow.gif\"</code></li> or <li><code>\"/storage/Appinventor/assets/arrow.gif\"</code></li></ul>", iconName="images/sharing.png", nonVisible=true, version=1)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.READ_EXTERNAL_STORAGE")
public class Sharing
extends AndroidNonvisibleComponent {
    public Sharing(ComponentContainer componentContainer) {
        super(componentContainer.$form());
    }

    @SimpleFunction(description="Shares a file through any capable application installed on the phone by displaying a list of the available apps and allowing the user to choose one from the list. The selected app will open with the file inserted on it.")
    public void ShareFile(String string) {
        this.ShareFileWithMessage(string, "");
    }

    @SimpleFunction(description="Shares both a file and a message through any capable application installed on the phone by displaying a list of available apps and allowing the user to  choose one from the list. The selected app will open with the file and message inserted on it.")
    public void ShareFileWithMessage(String string, String string2) {
        File file;
        String string3 = string;
        if (!string.startsWith("file://")) {
            string3 = !string.startsWith("/") ? this.form.getDefaultPath(string) : "file://" + string;
        }
        if ((file = new File(Uri.parse((String)string3).getPath())).isFile()) {
            string = string3.substring(string3.lastIndexOf(".") + 1).toLowerCase();
            string = string3 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(string);
            if (string3 == null) {
                string = "application/octet-stream";
            }
            string3 = NougatUtil.getPackageUri((Form)this.form, (File)file);
            file = new Intent("android.intent.action.SEND");
            file.putExtra("android.intent.extra.STREAM", (Parcelable)string3);
            file.setFlags(1);
            file.setType(string);
            if (string2.length() > 0) {
                file.putExtra("android.intent.extra.TEXT", string2);
            }
            this.form.startActivity((Intent)file);
        } else {
            string = "ShareFile";
            if (string2.equals((Object)"")) {
                string = "ShareFileWithMessage";
            }
            this.form.dispatchErrorOccurredEvent((Component)this, string, 2001, string3);
        }
    }

    @SimpleFunction(description="Shares a message through any capable application installed on the phone by displaying a list of the available apps and allowing the user to choose one from the list. The selected app will open with the message inserted on it.")
    public void ShareMessage(String string) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", string);
        intent.setType("text/plain");
        this.form.startActivity(intent);
    }
}

