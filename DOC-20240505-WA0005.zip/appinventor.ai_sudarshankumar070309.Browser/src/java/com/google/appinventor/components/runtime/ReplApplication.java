/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.acra.ACRA
 *  org.acra.ACRAConfiguration
 *  org.acra.annotation.ReportsCrashes
 */
package com.google.appinventor.components.runtime;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import com.google.appinventor.common.version.GitBuildId;
import com.google.appinventor.components.runtime.multidex.MultiDex;
import org.acra.ACRA;
import org.acra.ACRAConfiguration;
import org.acra.annotation.ReportsCrashes;

@ReportsCrashes(formKey="")
public class ReplApplication
extends Application {
    public static boolean installed = true;
    private static ReplApplication thisInstance;
    private boolean active = false;

    public static boolean isAcraActive() {
        ReplApplication replApplication = thisInstance;
        return replApplication != null && replApplication.active;
    }

    public static void reportError(Throwable throwable) {
        ReplApplication replApplication = thisInstance;
        if (replApplication != null && replApplication.active) {
            ACRA.getErrorReporter().handleException(throwable);
        }
    }

    public static void reportError(Throwable throwable, String string) {
        ACRA.getErrorReporter().putCustomData("reportid", string);
        ReplApplication.reportError(throwable);
    }

    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        installed = MultiDex.install((Context)this, false);
    }

    public void onCreate() {
        super.onCreate();
        thisInstance = this;
        String string = GitBuildId.getAcraUri();
        if (string.equals((Object)"")) {
            Log.i((String)"ReplApplication", (String)"ACRA Not Active");
        } else {
            Log.i((String)"ReplApplication", (String)("ACRA Active, URI = " + string));
            ACRAConfiguration aCRAConfiguration = ACRA.getNewDefaultConfig((Application)this);
            aCRAConfiguration.setFormUri(string);
            aCRAConfiguration.setDisableSSLCertValidation(true);
            ACRA.setConfig((ACRAConfiguration)aCRAConfiguration);
            ACRA.init((Application)this);
            this.active = true;
        }
    }
}

