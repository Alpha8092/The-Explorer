/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.bluetooth.BluetoothAdapter
 *  android.bluetooth.BluetoothDevice
 *  android.bluetooth.BluetoothSocket
 *  android.os.Build$VERSION
 *  android.util.Log
 *  com.google.appinventor.components.runtime.BluetoothClient$1
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  com.google.appinventor.components.runtime.util.SUtil
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.UUID
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ScheduledExecutorService
 *  java.util.concurrent.TimeUnit
 */
package com.google.appinventor.components.runtime;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Build;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PermissionConstraint;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.BluetoothClient;
import com.google.appinventor.components.runtime.BluetoothConnectionBase;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.util.SUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.CONNECTIVITY, description="Bluetooth client component", iconName="images/bluetooth.png", nonVisible=true, version=8)
@SimpleObject
@UsesPermissions(value={"android.permission.BLUETOOTH", "android.permission.BLUETOOTH_ADMIN", "android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_SCAN"})
public final class BluetoothClient
extends BluetoothConnectionBase
implements RealTimeDataSource<String, String> {
    private static final String[] RUNTIME_PERMISSIONS = new String[]{"android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_SCAN"};
    private static final String SPP_UUID = "00001101-0000-1000-8000-00805F9B34FB";
    private Set<Integer> acceptableDeviceClasses;
    private final List<Component> attachedComponents = new ArrayList();
    private ScheduledExecutorService dataPollService;
    private final HashSet<DataSourceChangeListener> dataSourceObservers = new HashSet();
    private boolean noLocationNeeded = false;
    private int pollingRate = 10;

    static /* bridge */ /* synthetic */ boolean -$$Nest$mconnect(BluetoothClient bluetoothClient, String string, String string2, String string3) {
        return bluetoothClient.connect(string, string2, string3);
    }

    public BluetoothClient(ComponentContainer componentContainer) {
        super(componentContainer, "BluetoothClient");
        this.DisconnectOnError(false);
    }

    private void connect(BluetoothDevice object2, UUID object3) throws IOException {
        object3 = !this.secure && Build.VERSION.SDK_INT >= 10 ? object2.createInsecureRfcommSocketToServiceRecord(object3) : object2.createRfcommSocketToServiceRecord(object3);
        object3.connect();
        this.setConnection((BluetoothSocket)object3);
        object3 = this.logTag;
        String string = object2.getAddress();
        object2 = object2.getName();
        Log.i((String)object3, (String)("Connected to Bluetooth device " + string + " " + (String)object2 + "."));
    }

    private boolean connect(String string, String string2, String string3) {
        if (SUtil.requestPermissionsForConnecting((Form)this.form, (BluetoothClient)this, (String)string, (PermissionResultHandler)new 1((BluetoothClient)this, string, string2, string3))) {
            return false;
        }
        if (this.adapter == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 501, new Object[0]);
            return false;
        }
        if (!this.adapter.isEnabled()) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 502, new Object[0]);
            return false;
        }
        int n = string2.indexOf(" ");
        String string4 = string2;
        if (n != -1) {
            string4 = string2.substring(0, n);
        }
        if (!BluetoothAdapter.checkBluetoothAddress((String)string4)) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 503, new Object[0]);
            return false;
        }
        string2 = this.adapter.getRemoteDevice(string4);
        if (string2.getBondState() != 12) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 504, new Object[0]);
            return false;
        }
        if (!super.isDeviceClassAcceptable((BluetoothDevice)string2)) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 505, new Object[0]);
            return false;
        }
        try {
            string4 = UUID.fromString((String)string3);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 506, string3);
            return false;
        }
        this.Disconnect();
        try {
            super.connect((BluetoothDevice)string2, (UUID)string4);
            return true;
        }
        catch (IOException iOException) {
            this.Disconnect();
            this.form.dispatchErrorOccurredEvent((Component)this, string, 507, new Object[0]);
            return false;
        }
    }

    private boolean isDeviceClassAcceptable(BluetoothDevice bluetoothDevice) {
        if (this.acceptableDeviceClasses == null) {
            return true;
        }
        if ((bluetoothDevice = bluetoothDevice.getBluetoothClass()) == null) {
            return false;
        }
        return this.acceptableDeviceClasses.contains((Object)bluetoothDevice.getDeviceClass());
    }

    private void startBluetoothDataPolling() {
        ScheduledExecutorService scheduledExecutorService;
        this.dataPollService = scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleWithFixedDelay(new Runnable(this){
            final BluetoothClient this$0;
            {
                this.this$0 = bluetoothClient;
            }

            public void run() {
                String string = this.this$0.getDataValue(null);
                if (!string.equals((Object)"")) {
                    this.this$0.notifyDataObservers(null, (Object)string);
                }
            }
        }, 0L, (long)this.pollingRate, TimeUnit.MILLISECONDS);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The addresses and names of paired Bluetooth devices")
    public List<String> AddressesAndNames() {
        if (Build.VERSION.SDK_INT >= 31) {
            for (Object object2 : RUNTIME_PERMISSIONS) {
                if (!this.form.isDeniedPermission((String)object2)) {
                    continue;
                }
                throw new PermissionException((String)object2);
            }
        }
        ArrayList arrayList = new ArrayList();
        if (this.adapter == null) {
            return arrayList;
        }
        for (Object object3 : this.adapter.getBondedDevices()) {
            Object object2;
            if (!this.isDeviceClassAcceptable((BluetoothDevice)object3)) continue;
            object2 = object3.getAddress();
            object3 = object3.getName();
            arrayList.add((Object)((String)object2 + " " + (String)object3));
        }
        return arrayList;
    }

    @SimpleFunction(description="Connect to the Bluetooth device with the specified address and the Serial Port Profile (SPP). Returns true if the connection was successful.")
    public boolean Connect(String string) {
        return super.connect("Connect", string, SPP_UUID);
    }

    @SimpleFunction(description="Connect to the Bluetooth device with the specified address and UUID. Returns true if the connection was successful.")
    public boolean ConnectWithUUID(String string, String string2) {
        return super.connect("ConnectWithUUID", string, string2);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void DisconnectOnError(boolean bl) {
        this.disconnectOnError = bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Disconnects BluetoothClient automatically when an error occurs.")
    public boolean DisconnectOnError() {
        return this.disconnectOnError;
    }

    @SimpleFunction(description="Checks whether the Bluetooth device with the specified address is paired.")
    public boolean IsDevicePaired(String string) {
        Object object2 = this.adapter;
        boolean bl = false;
        if (object2 == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "IsDevicePaired", 501, new Object[0]);
            return false;
        }
        if (!this.adapter.isEnabled()) {
            this.form.dispatchErrorOccurredEvent((Component)this, "IsDevicePaired", 502, new Object[0]);
            return false;
        }
        int n = string.indexOf(" ");
        object2 = string;
        if (n != -1) {
            object2 = string.substring(0, n);
        }
        if (!BluetoothAdapter.checkBluetoothAddress((String)object2)) {
            this.form.dispatchErrorOccurredEvent((Component)this, "IsDevicePaired", 503, new Object[0]);
            return false;
        }
        if (this.adapter.getRemoteDevice((String)object2).getBondState() == 12) {
            bl = true;
        }
        return bl;
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, userVisible=false)
    @UsesPermissions(constraints={@PermissionConstraint(name="android.permission.BLUETOOTH_SCAN", usesPermissionFlags="neverForLocation")})
    public void NoLocationNeeded(boolean bl) {
        this.noLocationNeeded = bl;
    }

    @SimpleProperty(userVisible=false)
    public boolean NoLocationNeeded() {
        return this.noLocationNeeded;
    }

    @SimpleProperty
    public int PollingRate() {
        return this.pollingRate;
    }

    @DesignerProperty(defaultValue="10")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void PollingRate(int n) {
        this.pollingRate = Math.max((int)n, (int)1);
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        void var2_3 = this;
        synchronized (var2_3) {
            if (this.dataPollService == null) {
                super.startBluetoothDataPolling();
            }
            this.dataSourceObservers.add((Object)dataSourceChangeListener);
            return;
        }
    }

    boolean attachComponent(Component component, Set<Integer> object2) {
        if (this.attachedComponents.isEmpty()) {
            object2 = object2 == null ? null : new HashSet(object2);
            this.acceptableDeviceClasses = object2;
        } else {
            Set<Integer> set = this.acceptableDeviceClasses;
            if (set == null) {
                if (object2 != null) {
                    return false;
                }
            } else {
                if (object2 == null) {
                    return false;
                }
                if (!set.containsAll((Collection)object2)) {
                    return false;
                }
                if (!object2.containsAll(this.acceptableDeviceClasses)) {
                    return false;
                }
            }
        }
        this.attachedComponents.add((Object)component);
        return true;
    }

    void detachComponent(Component component) {
        this.attachedComponents.remove((Object)component);
        if (this.attachedComponents.isEmpty()) {
            this.acceptableDeviceClasses = null;
        }
    }

    public String getDataValue(String string) {
        String string2;
        string = string2 = "";
        if (this.IsConnected()) {
            string = string2;
            if (this.BytesAvailableToReceive() > 0) {
                string = this.ReceiveText(-1);
            }
        }
        return string;
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        void var2_3 = this;
        synchronized (var2_3) {
            this.dataSourceObservers.remove((Object)dataSourceChangeListener);
            if (this.dataSourceObservers.isEmpty()) {
                this.dataPollService.shutdown();
                this.dataPollService = null;
            }
            return;
        }
    }
}

