/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.net.Uri
 *  com.google.appinventor.components.common.FileAction
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Intent;
import android.net.Uri;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileAction;
import com.google.appinventor.components.common.FileType;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.FilePicker;
import com.google.appinventor.components.runtime.Picker;

@DesignerComponent(androidMinSdk=19, category=ComponentCategory.MEDIA, iconName="images/filepicker.png", version=1)
@SimpleObject
public class FilePicker
extends Picker {
    private FileAction action = FileAction.PickExistingFile;
    private String mimeType = "*/*";
    private String selection = "";

    public FilePicker(ComponentContainer componentContainer) {
        super(componentContainer);
    }

    private static String actionToIntent(FileAction fileAction) {
        switch (1.$SwitchMap$com$google$appinventor$components$common$FileAction[fileAction.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unknown file action: " + fileAction);
            }
            case 3: {
                return "android.intent.action.CREATE_DOCUMENT";
            }
            case 2: {
                return "android.intent.action.OPEN_DOCUMENT_TREE";
            }
            case 1: 
        }
        return "android.intent.action.OPEN_DOCUMENT";
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public FileAction Action() {
        return this.action;
    }

    @DesignerProperty(defaultValue="Pick Existing File", editorArgs={"Pick Existing File", "Pick New File", "Pick Directory"}, editorType="choices")
    @SimpleProperty
    public void Action(FileAction fileAction) {
        this.action = fileAction;
    }

    public void Action(String string2) {
        this.Action(FileAction.fromUnderlyingValue((String)string2));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String MimeType() {
        return this.mimeType;
    }

    @DesignerProperty(defaultValue="*/*", editorType="string")
    @SimpleProperty
    public void MimeType(@Options(value=FileType.class) String string2) {
        this.mimeType = string2;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String Selection() {
        return this.selection;
    }

    @Override
    protected Intent getIntent() {
        Intent intent = new Intent(FilePicker.actionToIntent(this.action));
        if (this.action == FileAction.PickExistingFile) {
            intent.addCategory("android.intent.category.OPENABLE");
        }
        if (this.action == FileAction.PickDirectory) {
            intent = Intent.createChooser((Intent)intent, (CharSequence)"Test");
        } else {
            intent.setType(this.mimeType);
            int n = 65;
            if (this.action == FileAction.PickExistingFile) {
                n = 0x41 | 2;
            }
            intent.setFlags(n);
        }
        return intent;
    }

    @Override
    public void resultReturned(int n, int n2, Intent intent) {
        if (intent != null) {
            Uri uri = intent.getData();
            n = intent.getFlags();
            this.container.$form().getContentResolver().takePersistableUriPermission(uri, n & 3);
            this.selection = uri.toString();
            this.AfterPicking();
        } else {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "Open", 4501, new Object[0]);
        }
    }
}

