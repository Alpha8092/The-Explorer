/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.net.Uri
 *  android.os.Handler
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 *  twitter4j.DirectMessage
 *  twitter4j.Query
 *  twitter4j.Status
 *  twitter4j.StatusUpdate
 *  twitter4j.Twitter
 *  twitter4j.TwitterException
 *  twitter4j.TwitterFactory
 *  twitter4j.User
 *  twitter4j.auth.AccessToken
 *  twitter4j.auth.RequestToken
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesActivities;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.annotations.androidmanifest.ActionElement;
import com.google.appinventor.components.annotations.androidmanifest.ActivityElement;
import com.google.appinventor.components.annotations.androidmanifest.IntentFilterElement;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Twitter;
import com.google.appinventor.components.runtime.WebViewActivity;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import twitter4j.DirectMessage;
import twitter4j.Query;
import twitter4j.Status;
import twitter4j.StatusUpdate;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.INTERNAL, description="A non-visible component that enables communication with <a href=\"http://www.twitter.com\" target=\"_blank\">Twitter</a>. Once a user has logged into their Twitter account (and the authorization has been confirmed successful by the <code>IsAuthorized</code> event), many more operations are available:<ul><li> Searching Twitter for tweets or labels (<code>SearchTwitter</code>)</li>\n<li> Sending a Tweet (<code>Tweet</code>)     </li>\n<li> Sending a Tweet with an Image (<code>TweetWithImage</code>)     </li>\n<li> Directing a message to a specific user      (<code>DirectMessage</code>)</li>\n <li> Receiving the most recent messages directed to the logged-in user      (<code>RequestDirectMessages</code>)</li>\n <li> Following a specific user (<code>Follow</code>)</li>\n<li> Ceasing to follow a specific user (<code>StopFollowing</code>)</li>\n<li> Getting a list of users following the logged-in user      (<code>RequestFollowers</code>)</li>\n <li> Getting the most recent messages of users followed by the      logged-in user (<code>RequestFriendTimeline</code>)</li>\n <li> Getting the most recent mentions of the logged-in user      (<code>RequestMentions</code>)</li></ul></p>\n <p>You must obtain a Consumer Key and Consumer Secret for Twitter authorization  specific to your app from http://twitter.com/oauth_clients/new", iconName="images/twitter.png", nonVisible=true, version=4)
@SimpleObject
@UsesActivities(activities={@ActivityElement(configChanges="orientation|keyboardHidden", intentFilters={@IntentFilterElement(actionElements={@ActionElement(name="android.intent.action.MAIN")})}, name="com.google.appinventor.components.runtime.WebViewActivity", screenOrientation="behind")})
@UsesLibraries(libraries="twitter4j.jar,twitter4jmedia.jar")
@UsesPermissions(permissionNames="android.permission.INTERNET")
public final class Twitter
extends AndroidNonvisibleComponent
implements ActivityResultListener,
Component {
    private static final String ACCESS_SECRET_TAG = "TwitterOauthAccessSecret";
    private static final String ACCESS_TOKEN_TAG = "TwitterOauthAccessToken";
    private static final String CALLBACK_URL = "appinventor://twitter";
    private static final String MAX_CHARACTERS = "160";
    private static final String MAX_MENTIONS_RETURNED = "20";
    private static final String URL_HOST = "twitter";
    private static final String WEBVIEW_ACTIVITY_CLASS = WebViewActivity.class.getName();
    private String TwitPic_API_Key = "";
    private AccessToken accessToken;
    private String consumerKey = "";
    private String consumerSecret = "";
    private final ComponentContainer container;
    private final List<String> directMessages;
    private final List<String> followers;
    private final Handler handler;
    private final List<String> mentions;
    private final int requestCode;
    private RequestToken requestToken;
    private final List<String> searchResults;
    private final SharedPreferences sharedPreferences;
    private final List<List<String>> timeline;
    private twitter4j.Twitter twitter;
    private String userName = "";

    static /* bridge */ /* synthetic */ AccessToken -$$Nest$fgetaccessToken(Twitter twitter) {
        return twitter.accessToken;
    }

    static /* bridge */ /* synthetic */ ComponentContainer -$$Nest$fgetcontainer(Twitter twitter) {
        return twitter.container;
    }

    static /* bridge */ /* synthetic */ List -$$Nest$fgetdirectMessages(Twitter twitter) {
        return twitter.directMessages;
    }

    static /* bridge */ /* synthetic */ List -$$Nest$fgetfollowers(Twitter twitter) {
        return twitter.followers;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(Twitter twitter) {
        return twitter.handler;
    }

    static /* bridge */ /* synthetic */ List -$$Nest$fgetmentions(Twitter twitter) {
        return twitter.mentions;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetrequestCode(Twitter twitter) {
        return twitter.requestCode;
    }

    static /* bridge */ /* synthetic */ RequestToken -$$Nest$fgetrequestToken(Twitter twitter) {
        return twitter.requestToken;
    }

    static /* bridge */ /* synthetic */ List -$$Nest$fgetsearchResults(Twitter twitter) {
        return twitter.searchResults;
    }

    static /* bridge */ /* synthetic */ List -$$Nest$fgettimeline(Twitter twitter) {
        return twitter.timeline;
    }

    static /* bridge */ /* synthetic */ twitter4j.Twitter -$$Nest$fgettwitter(Twitter twitter) {
        return twitter.twitter;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputaccessToken(Twitter twitter, AccessToken accessToken) {
        twitter.accessToken = accessToken;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputrequestToken(Twitter twitter, RequestToken requestToken) {
        twitter.requestToken = requestToken;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputuserName(Twitter twitter, String string) {
        twitter.userName = string;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$mcheckAccessToken(Twitter twitter, String string, String string2) {
        return twitter.checkAccessToken(string, string2);
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mdeAuthorize(Twitter twitter) {
        twitter.deAuthorize();
    }

    static /* bridge */ /* synthetic */ void -$$Nest$msaveAccessToken(Twitter twitter, AccessToken accessToken) {
        twitter.saveAccessToken(accessToken);
    }

    static /* bridge */ /* synthetic */ String -$$Nest$sfgetWEBVIEW_ACTIVITY_CLASS() {
        return WEBVIEW_ACTIVITY_CLASS;
    }

    public Twitter(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.container = componentContainer;
        this.handler = new Handler();
        this.mentions = new ArrayList();
        this.followers = new ArrayList();
        this.timeline = new ArrayList();
        this.directMessages = new ArrayList();
        this.searchResults = new ArrayList();
        this.sharedPreferences = componentContainer.$context().getSharedPreferences("Twitter", 0);
        this.accessToken = super.retrieveAccessToken();
        this.requestCode = this.form.registerForActivityResult((ActivityResultListener)this);
    }

    private boolean checkAccessToken(String string, String string2) {
        string = super.retrieveAccessToken();
        this.accessToken = string;
        if (string == null) {
            return false;
        }
        if (this.twitter == null) {
            this.twitter = new TwitterFactory().getInstance();
        }
        try {
            this.twitter.setOAuthConsumer(this.consumerKey, this.consumerSecret);
            this.twitter.setOAuthAccessToken(this.accessToken);
        }
        catch (IllegalStateException illegalStateException) {
            // empty catch block
        }
        if (this.userName.trim().length() == 0) {
            try {
                this.userName = this.twitter.verifyCredentials().getScreenName();
            }
            catch (TwitterException twitterException) {
                super.deAuthorize();
                return false;
            }
        }
        return true;
    }

    private void deAuthorize() {
        this.requestToken = null;
        this.accessToken = null;
        this.userName = "";
        twitter4j.Twitter twitter = this.twitter;
        this.twitter = null;
        this.saveAccessToken(null);
        if (twitter != null) {
            twitter.setOAuthAccessToken(null);
        }
    }

    private AccessToken retrieveAccessToken() {
        String string = this.sharedPreferences.getString(ACCESS_TOKEN_TAG, "");
        String string2 = this.sharedPreferences.getString(ACCESS_SECRET_TAG, "");
        if (string.length() != 0 && string2.length() != 0) {
            return new AccessToken(string, string2);
        }
        return null;
    }

    private void saveAccessToken(AccessToken accessToken) {
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        if (accessToken == null) {
            editor.remove(ACCESS_TOKEN_TAG);
            editor.remove(ACCESS_SECRET_TAG);
        } else {
            editor.putString(ACCESS_TOKEN_TAG, accessToken.getToken());
            editor.putString(ACCESS_SECRET_TAG, accessToken.getTokenSecret());
        }
        editor.commit();
    }

    @SimpleFunction(description="Redirects user to login to Twitter via the Web browser using the OAuth protocol if we don't already have authorization.")
    public void Authorize() {
        if (this.consumerKey.length() != 0 && this.consumerSecret.length() != 0) {
            if (this.twitter == null) {
                this.twitter = new TwitterFactory().getInstance();
            }
            AsynchUtil.runAsynchronously((Runnable)new Runnable(this, this.consumerKey, this.consumerSecret){
                final Twitter this$0;
                final String val$myConsumerKey;
                final String val$myConsumerSecret;
                {
                    this.this$0 = twitter;
                    this.val$myConsumerKey = string;
                    this.val$myConsumerSecret = string2;
                }

                public void run() {
                    if (Twitter.-$$Nest$mcheckAccessToken(this.this$0, this.val$myConsumerKey, this.val$myConsumerSecret)) {
                        Twitter.-$$Nest$fgethandler(this.this$0).post(new Runnable(this){
                            final 1 this$1;
                            {
                                this.this$1 = var1;
                            }

                            public void run() {
                                this.this$1.this$0.IsAuthorized();
                            }
                        });
                        return;
                    }
                    try {
                        Twitter.-$$Nest$fgettwitter(this.this$0).setOAuthConsumer(this.val$myConsumerKey, this.val$myConsumerSecret);
                        RequestToken requestToken = Twitter.-$$Nest$fgettwitter(this.this$0).getOAuthRequestToken("appinventor://twitter");
                        String string = requestToken.getAuthorizationURL();
                        Twitter.-$$Nest$fputrequestToken(this.this$0, requestToken);
                        requestToken = new Intent("android.intent.action.MAIN", Uri.parse((String)string));
                        requestToken.setClassName((Context)Twitter.-$$Nest$fgetcontainer(this.this$0).$context(), Twitter.-$$Nest$sfgetWEBVIEW_ACTIVITY_CLASS());
                        Twitter.-$$Nest$fgetcontainer(this.this$0).$context().startActivityForResult((Intent)requestToken, Twitter.-$$Nest$fgetrequestCode(this.this$0));
                    }
                    catch (IllegalStateException illegalStateException) {
                        Log.e((String)"Twitter", (String)"OAuthConsumer was already set: launch IsAuthorized()");
                        Twitter.-$$Nest$fgethandler(this.this$0).post(new Runnable(this){
                            final 1 this$1;
                            {
                                this.this$1 = var1;
                            }

                            public void run() {
                                this.this$1.this$0.IsAuthorized();
                            }
                        });
                    }
                    catch (TwitterException twitterException) {
                        String string = twitterException.getMessage();
                        Log.i((String)"Twitter", (String)("Got exception: " + string));
                        twitterException.printStackTrace();
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "Authorize", 303, twitterException.getMessage());
                        this.this$0.DeAuthorize();
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent(this, "Authorize", 302, new Object[0]);
    }

    @SimpleFunction(description="Checks whether we already have access, and if so, causes IsAuthorized event handler to be called.")
    public void CheckAuthorized() {
        AsynchUtil.runAsynchronously((Runnable)new Runnable(this, this.consumerKey, this.consumerSecret){
            final Twitter this$0;
            final String val$myConsumerKey;
            final String val$myConsumerSecret;
            {
                this.this$0 = twitter;
                this.val$myConsumerKey = string;
                this.val$myConsumerSecret = string2;
            }

            public void run() {
                if (Twitter.-$$Nest$mcheckAccessToken(this.this$0, this.val$myConsumerKey, this.val$myConsumerSecret)) {
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new Runnable(this){
                        final 2 this$1;
                        {
                            this.this$1 = var1;
                        }

                        public void run() {
                            this.this$1.this$0.IsAuthorized();
                        }
                    });
                }
            }
        });
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String ConsumerKey() {
        return this.consumerKey;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The the consumer key to be used when authorizing with Twitter via OAuth.")
    public void ConsumerKey(String string) {
        this.consumerKey = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String ConsumerSecret() {
        return this.consumerSecret;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(description="The consumer secret to be used when authorizing with Twitter via OAuth")
    public void ConsumerSecret(String string) {
        this.consumerSecret = string;
    }

    @SimpleFunction(description="Removes Twitter authorization from this running app instance")
    public void DeAuthorize() {
        this.deAuthorize();
    }

    @SimpleFunction(description="This sends a direct (private) message to the specified user.  The message will be trimmed if it exceeds 160characters. <p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void DirectMessage(String string, String string2) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string, string2){
                final Twitter this$0;
                final String val$message;
                final String val$user;
                {
                    this.this$0 = twitter;
                    this.val$user = string;
                    this.val$message = string2;
                }

                public void run() {
                    try {
                        Twitter.-$$Nest$fgettwitter(this.this$0).sendDirectMessage(this.val$user, this.val$message);
                    }
                    catch (TwitterException twitterException) {
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "DirectMessage", 310, twitterException.getMessage());
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "DirectMessage", 310, "Need to login?");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property contains a list of the most recent messages mentioning the logged-in user.  Initially, the list is empty.  To set it, the program must: <ol> <li> Call the <code>Authorize</code> method.</li> <li> Wait for the <code>Authorized</code> event.</li> <li> Call the <code>RequestDirectMessages</code> method.</li> <li> Wait for the <code>DirectMessagesReceived</code> event.</li></ol>\nThe value of this property will then be set to the list of direct messages retrieved (and maintain that value until any subsequent call to <code>RequestDirectMessages</code>).")
    public List<String> DirectMessages() {
        return this.directMessages;
    }

    @SimpleEvent(description="This event is raised when the recent messages requested through <code>RequestDirectMessages</code> have been retrieved. A list of the messages can then be found in the <code>messages</code> parameter or the <code>Messages</code> property.")
    public void DirectMessagesReceived(List<String> list) {
        EventDispatcher.dispatchEvent((Component)this, "DirectMessagesReceived", list);
    }

    @SimpleFunction
    public void Follow(String string) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string){
                final Twitter this$0;
                final String val$user;
                {
                    this.this$0 = twitter;
                    this.val$user = string;
                }

                public void run() {
                    try {
                        Twitter.-$$Nest$fgettwitter(this.this$0).createFriendship(this.val$user);
                    }
                    catch (TwitterException twitterException) {
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "Follow", 311, twitterException.getMessage());
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "Follow", 311, "Need to login?");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property contains a list of the followers of the logged-in user.  Initially, the list is empty.  To set it, the program must: <ol> <li> Call the <code>Authorize</code> method.</li> <li> Wait for the <code>IsAuthorized</code> event.</li> <li> Call the <code>RequestFollowers</code> method.</li> <li> Wait for the <code>FollowersReceived</code> event.</li></ol>\nThe value of this property will then be set to the list of followers (and maintain its value until any subsequent call to <code>RequestFollowers</code>).")
    public List<String> Followers() {
        return this.followers;
    }

    @SimpleEvent(description="This event is raised when all of the followers of the logged-in user requested through <code>RequestFollowers</code> have been retrieved. A list of the followers can then be found in the <code>followers</code> parameter or the <code>Followers</code> property.")
    public void FollowersReceived(List<String> list) {
        EventDispatcher.dispatchEvent((Component)this, "FollowersReceived", list);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property contains the 20 most recent messages of users being followed.  Initially, the list is empty.  To set it, the program must: <ol> <li> Call the <code>Authorize</code> method.</li> <li> Wait for the <code>IsAuthorized</code> event.</li> <li> Specify users to follow with one or more calls to the <code>Follow</code> method.</li> <li> Call the <code>RequestFriendTimeline</code> method.</li> <li> Wait for the <code>FriendTimelineReceived</code> event.</li> </ol>\nThe value of this property will then be set to the list of messages (and maintain its value until any subsequent call to <code>RequestFriendTimeline</code>.")
    public List<List<String>> FriendTimeline() {
        return this.timeline;
    }

    @SimpleEvent(description="This event is raised when the messages requested through <code>RequestFriendTimeline</code> have been retrieved. The <code>timeline</code> parameter and the <code>Timeline</code> property will contain a list of lists, where each sub-list contains a status update of the form (username message)")
    public void FriendTimelineReceived(List<List<String>> list) {
        EventDispatcher.dispatchEvent((Component)this, "FriendTimelineReceived", list);
    }

    @SimpleEvent(description="This event is raised after the program calls <code>Authorize</code> if the authorization was successful.  It is also called after a call to <code>CheckAuthorized</code> if we already have a valid access token. After this event has been raised, any other method for this component can be called.")
    public void IsAuthorized() {
        EventDispatcher.dispatchEvent(this, "IsAuthorized", new Object[0]);
    }

    @SimpleFunction(description="Twitter's API no longer supports login via username and password. Use the Authorize call instead.", userVisible=false)
    public void Login(String string, String string2) {
        this.form.dispatchErrorOccurredEvent((Component)this, "Login", 301, new Object[0]);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property contains a list of mentions of the logged-in user.  Initially, the list is empty.  To set it, the program must: <ol> <li> Call the <code>Authorize</code> method.</li> <li> Wait for the <code>IsAuthorized</code> event.</li> <li> Call the <code>RequestMentions</code> method.</li> <li> Wait for the <code>MentionsReceived</code> event.</li></ol>\nThe value of this property will then be set to the list of mentions (and will maintain its value until any subsequent calls to <code>RequestMentions</code>).")
    public List<String> Mentions() {
        return this.mentions;
    }

    @SimpleEvent(description="This event is raised when the mentions of the logged-in user requested through <code>RequestMentions</code> have been retrieved.  A list of the mentions can then be found in the <code>mentions</code> parameter or the <code>Mentions</code> property.")
    public void MentionsReceived(List<String> list) {
        EventDispatcher.dispatchEvent((Component)this, "MentionsReceived", list);
    }

    @SimpleFunction(description="Requests the 20 most recent direct messages sent to the logged-in user.  When the messages have been retrieved, the system will raise the <code>DirectMessagesReceived</code> event and set the <code>DirectMessages</code> property to the list of messages.<p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void RequestDirectMessages() {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
                List<DirectMessage> messages;
                final Twitter this$0;
                {
                    this.this$0 = twitter;
                    this.messages = Collections.emptyList();
                }

                /*
                 * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                 * Loose catch block
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Throwable throwable2;
                    block4: {
                        Runnable runnable;
                        Handler handler;
                        block5: {
                            this.messages = Twitter.-$$Nest$fgettwitter(this.this$0).getDirectMessages();
                            {
                                catch (Throwable throwable2) {
                                    break block4;
                                }
                                catch (TwitterException twitterException) {}
                                {
                                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestDirectMessages", 309, twitterException.getMessage());
                                }
                                handler = Twitter.-$$Nest$fgethandler(this.this$0);
                                runnable = new Runnable(this){
                                    final 8 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        Twitter.-$$Nest$fgetdirectMessages(this.this$1.this$0).clear();
                                        for (Object object2 : this.this$1.messages) {
                                            List list = Twitter.-$$Nest$fgetdirectMessages(this.this$1.this$0);
                                            String string = object2.getSenderScreenName();
                                            object2 = object2.getText();
                                            list.add((Object)(string + " " + (String)object2));
                                        }
                                        this.this$1.this$0.DirectMessagesReceived((List<String>)Twitter.-$$Nest$fgetdirectMessages(this.this$1.this$0));
                                    }
                                };
                                break block5;
                            }
                            handler = Twitter.-$$Nest$fgethandler(this.this$0);
                            runnable = new /* invalid duplicate definition of identical inner class */;
                        }
                        handler.post(runnable);
                        return;
                    }
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new /* invalid duplicate definition of identical inner class */);
                    throw throwable2;
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent(this, "RequestDirectMessages", 309, "Need to login?");
    }

    @SimpleFunction
    public void RequestFollowers() {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
                List<User> friends;
                final Twitter this$0;
                {
                    this.this$0 = twitter;
                    this.friends = new ArrayList();
                }

                /*
                 * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                 * Loose catch block
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Throwable throwable2;
                    block6: {
                        Handler handler;
                        Object object2;
                        block7: {
                            object2 = Twitter.-$$Nest$fgettwitter(this.this$0).getFollowersIDs(-1L).getIDs();
                            int n = ((long[])object2).length;
                            {
                                catch (Throwable throwable2) {
                                    break block6;
                                }
                                catch (TwitterException twitterException) {}
                                {
                                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestFollowers", 308, twitterException.getMessage());
                                }
                                handler = Twitter.-$$Nest$fgethandler(this.this$0);
                                object2 = new Runnable(this){
                                    final 7 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        Twitter.-$$Nest$fgetfollowers(this.this$1.this$0).clear();
                                        for (User user : this.this$1.friends) {
                                            Twitter.-$$Nest$fgetfollowers(this.this$1.this$0).add((Object)user.getName());
                                        }
                                        this.this$1.this$0.FollowersReceived((List<String>)Twitter.-$$Nest$fgetfollowers(this.this$1.this$0));
                                    }
                                };
                                break block7;
                            }
                            for (int i = 0; i < n; ++i) {
                                long l = object2[i];
                                {
                                    this.friends.add((Object)Twitter.-$$Nest$fgettwitter(this.this$0).showUser(l));
                                    continue;
                                }
                            }
                            handler = Twitter.-$$Nest$fgethandler(this.this$0);
                            object2 = new /* invalid duplicate definition of identical inner class */;
                        }
                        handler.post((Runnable)object2);
                        return;
                    }
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new /* invalid duplicate definition of identical inner class */);
                    throw throwable2;
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent(this, "RequestFollowers", 308, "Need to login?");
    }

    @SimpleFunction
    public void RequestFriendTimeline() {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
                List<Status> messages;
                final Twitter this$0;
                {
                    this.this$0 = twitter;
                    this.messages = Collections.emptyList();
                }

                /*
                 * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                 * Loose catch block
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Throwable throwable2;
                    block4: {
                        Runnable runnable;
                        Handler handler;
                        block5: {
                            this.messages = Twitter.-$$Nest$fgettwitter(this.this$0).getHomeTimeline();
                            {
                                catch (Throwable throwable2) {
                                    break block4;
                                }
                                catch (TwitterException twitterException) {}
                                {
                                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestFriendTimeline", 313, twitterException.getMessage());
                                }
                                handler = Twitter.-$$Nest$fgethandler(this.this$0);
                                runnable = new Runnable(this){
                                    final 12 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        Twitter.-$$Nest$fgettimeline(this.this$1.this$0).clear();
                                        for (Status status : this.this$1.messages) {
                                            ArrayList arrayList = new ArrayList();
                                            arrayList.add((Object)status.getUser().getScreenName());
                                            arrayList.add((Object)status.getText());
                                            Twitter.-$$Nest$fgettimeline(this.this$1.this$0).add((Object)arrayList);
                                        }
                                        this.this$1.this$0.FriendTimelineReceived((List<List<String>>)Twitter.-$$Nest$fgettimeline(this.this$1.this$0));
                                    }
                                };
                                break block5;
                            }
                            handler = Twitter.-$$Nest$fgethandler(this.this$0);
                            runnable = new /* invalid duplicate definition of identical inner class */;
                        }
                        handler.post(runnable);
                        return;
                    }
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new /* invalid duplicate definition of identical inner class */);
                    throw throwable2;
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent(this, "RequestFriendTimeline", 313, "Need to login?");
    }

    @SimpleFunction(description="Requests the 20 most recent mentions of the logged-in user.  When the mentions have been retrieved, the system will raise the <code>MentionsReceived</code> event and set the <code>Mentions</code> property to the list of mentions.<p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void RequestMentions() {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable(this){
                List<Status> replies;
                final Twitter this$0;
                {
                    this.this$0 = twitter;
                    this.replies = Collections.emptyList();
                }

                /*
                 * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                 * Loose catch block
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Throwable throwable2;
                    block4: {
                        Runnable runnable;
                        Handler handler;
                        block5: {
                            this.replies = Twitter.-$$Nest$fgettwitter(this.this$0).getMentionsTimeline();
                            {
                                catch (Throwable throwable2) {
                                    break block4;
                                }
                                catch (TwitterException twitterException) {}
                                {
                                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "RequestMentions", 307, twitterException.getMessage());
                                }
                                handler = Twitter.-$$Nest$fgethandler(this.this$0);
                                runnable = new Runnable(this){
                                    final 6 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        Twitter.-$$Nest$fgetmentions(this.this$1.this$0).clear();
                                        for (Object object2 : this.this$1.replies) {
                                            List list = Twitter.-$$Nest$fgetmentions(this.this$1.this$0);
                                            String string = object2.getUser().getScreenName();
                                            object2 = object2.getText();
                                            list.add((Object)(string + " " + (String)object2));
                                        }
                                        this.this$1.this$0.MentionsReceived((List<String>)Twitter.-$$Nest$fgetmentions(this.this$1.this$0));
                                    }
                                };
                                break block5;
                            }
                            handler = Twitter.-$$Nest$fgethandler(this.this$0);
                            runnable = new /* invalid duplicate definition of identical inner class */;
                        }
                        handler.post(runnable);
                        return;
                    }
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new /* invalid duplicate definition of identical inner class */);
                    throw throwable2;
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent(this, "RequestMentions", 307, "Need to login?");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property, which is initially empty, is set to a list of search results after the program: <ol><li>Calls the <code>SearchTwitter</code> method.</li> <li>Waits for the <code>SearchSuccessful</code> event.</li></ol>\nThe value of the property will then be the same as the parameter to <code>SearchSuccessful</code>.  Note that it is not necessary to call the <code>Authorize</code> method before calling <code>SearchTwitter</code>.")
    public List<String> SearchResults() {
        return this.searchResults;
    }

    @SimpleEvent(description="This event is raised when the results of the search requested through <code>SearchSuccessful</code> have been retrieved. A list of the results can then be found in the <code>results</code> parameter or the <code>Results</code> property.")
    public void SearchSuccessful(List<String> list) {
        EventDispatcher.dispatchEvent((Component)this, "SearchSuccessful", list);
    }

    @SimpleFunction(description="This searches Twitter for the given String query.<p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void SearchTwitter(String string) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string){
                final Twitter this$0;
                List<Status> tweets;
                final String val$query;
                {
                    this.this$0 = twitter;
                    this.val$query = string;
                    this.tweets = Collections.emptyList();
                }

                /*
                 * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                 * Loose catch block
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Throwable throwable2;
                    block4: {
                        Object object2;
                        twitter4j.Twitter twitter;
                        block5: {
                            twitter = Twitter.-$$Nest$fgettwitter(this.this$0);
                            object2 = new Query(this.val$query);
                            this.tweets = twitter.search(object2).getTweets();
                            {
                                catch (Throwable throwable2) {
                                    break block4;
                                }
                                catch (TwitterException twitterException) {}
                                {
                                    this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "SearchTwitter", 314, twitterException.getMessage());
                                }
                                twitter = Twitter.-$$Nest$fgethandler(this.this$0);
                                object2 = new Runnable(this){
                                    final 13 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        Twitter.-$$Nest$fgetsearchResults(this.this$1.this$0).clear();
                                        for (Object object2 : this.this$1.tweets) {
                                            List list = Twitter.-$$Nest$fgetsearchResults(this.this$1.this$0);
                                            String string = object2.getUser().getName();
                                            object2 = object2.getText();
                                            list.add((Object)(string + " " + (String)object2));
                                        }
                                        this.this$1.this$0.SearchSuccessful((List<String>)Twitter.-$$Nest$fgetsearchResults(this.this$1.this$0));
                                    }
                                };
                                break block5;
                            }
                            twitter = Twitter.-$$Nest$fgethandler(this.this$0);
                            object2 = new /* invalid duplicate definition of identical inner class */;
                        }
                        twitter.post((Runnable)object2);
                        return;
                    }
                    Twitter.-$$Nest$fgethandler(this.this$0).post(new /* invalid duplicate definition of identical inner class */);
                    throw throwable2;
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "SearchTwitter", 314, "Need to login?");
    }

    @SimpleFunction
    public void StopFollowing(String string) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string){
                final Twitter this$0;
                final String val$user;
                {
                    this.this$0 = twitter;
                    this.val$user = string;
                }

                public void run() {
                    try {
                        Twitter.-$$Nest$fgettwitter(this.this$0).destroyFriendship(this.val$user);
                    }
                    catch (TwitterException twitterException) {
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "StopFollowing", 312, twitterException.getMessage());
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "StopFollowing", 312, "Need to login?");
    }

    @SimpleFunction(description="This sends a tweet as the logged-in user with the specified Text, which will be trimmed if it exceeds 160 characters. <p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void Tweet(String string) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string){
                final Twitter this$0;
                final String val$status;
                {
                    this.this$0 = twitter;
                    this.val$status = string;
                }

                public void run() {
                    try {
                        Twitter.-$$Nest$fgettwitter(this.this$0).updateStatus(this.val$status);
                    }
                    catch (TwitterException twitterException) {
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "Tweet", 306, twitterException.getMessage());
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "Tweet", 306, "Need to login?");
    }

    @SimpleFunction(description="This sends a tweet as the logged-in user with the specified Text and a path to the image to be uploaded, which will be trimmed if it exceeds 160 characters. If an image is not found or invalid, only the text will be tweeted.<p><u>Requirements</u>: This should only be called after the <code>IsAuthorized</code> event has been raised, indicating that the user has successfully logged in to Twitter.</p>")
    public void TweetWithImage(String string, String string2) {
        if (this.twitter != null && this.userName.length() != 0) {
            AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, string2, string){
                final Twitter this$0;
                final String val$imagePath;
                final String val$status;
                {
                    this.this$0 = twitter;
                    this.val$imagePath = string;
                    this.val$status = string2;
                }

                public void run() {
                    String string;
                    String string2 = string = this.val$imagePath;
                    try {
                        if (string.startsWith("file://")) {
                            string2 = this.val$imagePath.replace((CharSequence)"file://", (CharSequence)"");
                        }
                        if ((string = new File(string2)).exists()) {
                            string2 = new StatusUpdate(this.val$status);
                            string2.setMedia((File)string);
                            Twitter.-$$Nest$fgettwitter(this.this$0).updateStatus((StatusUpdate)string2);
                        } else {
                            this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "TweetWithImage", 315, new Object[0]);
                        }
                    }
                    catch (TwitterException twitterException) {
                        this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "TweetWithImage", 306, twitterException.getMessage());
                    }
                }
            });
            return;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, "TweetWithImage", 306, "Need to login?");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    @Deprecated
    public String TwitPic_API_Key() {
        return this.TwitPic_API_Key;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The API Key for image uploading, provided by TwitPic.")
    @Deprecated
    public void TwitPic_API_Key(String string) {
        this.TwitPic_API_Key = string;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The user name of the authorized user. Empty if there is no authorized user.")
    public String Username() {
        return this.userName;
    }

    @Override
    public void resultReturned(int n, int n2, Intent object2) {
        Log.i((String)"Twitter", (String)("Got result " + n2));
        if (object2 != null) {
            if ((object2 = object2.getData()) != null) {
                String string = object2.toString();
                Log.i((String)"Twitter", (String)("Intent URI: " + string));
                object2 = object2.getQueryParameter("oauth_verifier");
                if (this.twitter == null) {
                    Log.e((String)"Twitter", (String)"twitter field is unexpectedly null");
                    this.form.dispatchErrorOccurredEvent((Component)this, "Authorize", 304, "internal error: can't access Twitter library");
                    new RuntimeException().printStackTrace();
                }
                if (this.requestToken != null && object2 != null && object2.length() != 0) {
                    AsynchUtil.runAsynchronously((Runnable)new Runnable((Twitter)this, (String)object2){
                        final Twitter this$0;
                        final String val$oauthVerifier;
                        {
                            this.this$0 = twitter;
                            this.val$oauthVerifier = string;
                        }

                        public void run() {
                            try {
                                Object object2 = Twitter.-$$Nest$fgettwitter(this.this$0).getOAuthAccessToken(Twitter.-$$Nest$fgetrequestToken(this.this$0), this.val$oauthVerifier);
                                Twitter.-$$Nest$fputaccessToken(this.this$0, object2);
                                Twitter twitter = this.this$0;
                                Twitter.-$$Nest$fputuserName(twitter, Twitter.-$$Nest$fgetaccessToken(twitter).getScreenName());
                                Twitter.-$$Nest$msaveAccessToken(this.this$0, object2);
                                twitter = Twitter.-$$Nest$fgethandler(this.this$0);
                                object2 = new Runnable(this){
                                    final 3 this$1;
                                    {
                                        this.this$1 = var1;
                                    }

                                    public void run() {
                                        this.this$1.this$0.IsAuthorized();
                                    }
                                };
                                twitter.post((Runnable)object2);
                            }
                            catch (TwitterException twitterException) {
                                String string = twitterException.getMessage();
                                Log.e((String)"Twitter", (String)("Got exception: " + string));
                                twitterException.printStackTrace();
                                this.this$0.form.dispatchErrorOccurredEvent(this.this$0, "Authorize", 304, twitterException.getMessage());
                                Twitter.-$$Nest$mdeAuthorize(this.this$0);
                            }
                        }
                    });
                } else {
                    this.form.dispatchErrorOccurredEvent((Component)this, "Authorize", 305, new Object[0]);
                    super.deAuthorize();
                }
            } else {
                Log.e((String)"Twitter", (String)"uri returned from WebView activity was unexpectedly null");
                super.deAuthorize();
            }
        } else {
            Log.e((String)"Twitter", (String)"intent returned from WebView activity was unexpectedly null");
            super.deAuthorize();
        }
    }
}

