package com.google.appinventor.components.runtime.util;

/* compiled from: D8$$SyntheticClass */
/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public final /* synthetic */ class JavaStringUtils$MappingEarliestOccurrenceFirstOrder$1$$ExternalSyntheticBackport0 {
    public static /* synthetic */ int m(int i, int i2) {
        if (i == i2) {
            return 0;
        }
        return i < i2 ? -1 : 1;
    }
}
