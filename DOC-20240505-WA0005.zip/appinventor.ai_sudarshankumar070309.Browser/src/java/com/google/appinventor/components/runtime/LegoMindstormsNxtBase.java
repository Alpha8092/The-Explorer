/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.common.NxtMotorMode
 *  com.google.appinventor.components.common.NxtMotorPort
 *  com.google.appinventor.components.common.NxtRegulationMode
 *  com.google.appinventor.components.common.NxtRunState
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorPort
 *  com.google.appinventor.components.common.NxtSensorType
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  java.io.UnsupportedEncodingException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.util.Log;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.NxtMotorMode;
import com.google.appinventor.components.common.NxtMotorPort;
import com.google.appinventor.components.common.NxtRegulationMode;
import com.google.appinventor.components.common.NxtRunState;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorPort;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.BluetoothClient;
import com.google.appinventor.components.runtime.BluetoothConnectionBase;
import com.google.appinventor.components.runtime.BluetoothConnectionListener;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.Form;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@SimpleObject
public class LegoMindstormsNxtBase
extends AndroidNonvisibleComponent
implements BluetoothConnectionListener,
Component,
Deleteable {
    private static final Map<Integer, String> ERROR_MESSAGES;
    private static final int TOY_ROBOT = 2052;
    protected BluetoothClient bluetooth;
    protected final String logTag;

    static {
        HashMap hashMap;
        ERROR_MESSAGES = hashMap = new HashMap();
        hashMap.put((Object)32, (Object)"Pending communication transaction in progress");
        hashMap.put((Object)64, (Object)"Specified mailbox queue is empty");
        hashMap.put((Object)129, (Object)"No more handles");
        hashMap.put((Object)130, (Object)"No space");
        hashMap.put((Object)131, (Object)"No more files");
        hashMap.put((Object)132, (Object)"End of file expected");
        hashMap.put((Object)133, (Object)"End of file");
        hashMap.put((Object)134, (Object)"Not a linear file");
        hashMap.put((Object)135, (Object)"File not found");
        hashMap.put((Object)136, (Object)"Handle already closed");
        hashMap.put((Object)137, (Object)"No linear space");
        hashMap.put((Object)138, (Object)"Undefined error");
        hashMap.put((Object)139, (Object)"File is busy");
        hashMap.put((Object)140, (Object)"No write buffers");
        hashMap.put((Object)141, (Object)"Append not possible");
        hashMap.put((Object)142, (Object)"File is full");
        hashMap.put((Object)143, (Object)"File exists");
        hashMap.put((Object)144, (Object)"Module not found");
        hashMap.put((Object)145, (Object)"Out of boundary");
        hashMap.put((Object)146, (Object)"Illegal file name");
        hashMap.put((Object)147, (Object)"Illegal handle");
        hashMap.put((Object)189, (Object)"Request failed (i.e. specified file not found)");
        hashMap.put((Object)190, (Object)"Unknown command opcode");
        hashMap.put((Object)191, (Object)"Insane packet");
        hashMap.put((Object)192, (Object)"Data contains out-of-range values");
        hashMap.put((Object)221, (Object)"Communication bus error");
        hashMap.put((Object)222, (Object)"No free memory in communication buffer");
        hashMap.put((Object)223, (Object)"Specified channel/connection is not valid");
        hashMap.put((Object)224, (Object)"Specified channel/connection not configured or busy");
        hashMap.put((Object)236, (Object)"No active program");
        hashMap.put((Object)237, (Object)"Illegal size specified");
        hashMap.put((Object)238, (Object)"Illegal mailbox queue ID specified");
        hashMap.put((Object)239, (Object)"Attempted to access invalid field of a structure");
        hashMap.put((Object)240, (Object)"Bad input or output specified");
        hashMap.put((Object)251, (Object)"Insufficient memory available");
        hashMap.put((Object)255, (Object)"Bad arguments");
    }

    protected LegoMindstormsNxtBase() {
        super(null);
        this.logTag = null;
    }

    protected LegoMindstormsNxtBase(ComponentContainer componentContainer, String string) {
        super(componentContainer.$form());
        this.logTag = string;
    }

    private void handleError(String string, int n) {
        if (n >= 0) {
            String string2 = (String)ERROR_MESSAGES.get((Object)n);
            if (string2 != null) {
                this.form.dispatchErrorOccurredEvent((Component)this, string, 404, string2);
            } else {
                Form form = this.form;
                string2 = Integer.toHexString((int)(n & 0xFF));
                form.dispatchErrorOccurredEvent((Component)this, string, 404, "Error code 0x" + string2);
            }
        }
    }

    private byte[] receiveReturnPackage(String string) {
        int n;
        byte[] byArray = this.bluetooth.read(string, 2);
        if (byArray.length == 2 && (byArray = this.bluetooth.read(string, n = this.getUWORDValueFromBytes(byArray, 0))).length >= 3) {
            return byArray;
        }
        this.form.dispatchErrorOccurredEvent((Component)this, string, 403, new Object[0]);
        return new byte[0];
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The BluetoothClient component that should be used for communication.", userVisible=false)
    public BluetoothClient BluetoothClient() {
        return this.bluetooth;
    }

    @DesignerProperty(defaultValue="", editorType="BluetoothClient")
    @SimpleProperty(userVisible=false)
    public void BluetoothClient(BluetoothClient bluetoothClient) {
        BluetoothClient bluetoothClient2 = this.bluetooth;
        if (bluetoothClient2 != null) {
            bluetoothClient2.removeBluetoothConnectionListener((BluetoothConnectionListener)this);
            this.bluetooth.detachComponent((Component)this);
            this.bluetooth = null;
        }
        if (bluetoothClient != null) {
            this.bluetooth = bluetoothClient;
            bluetoothClient.attachComponent((Component)this, (Set<Integer>)Collections.singleton((Object)2052));
            this.bluetooth.addBluetoothConnectionListener((BluetoothConnectionListener)this);
            if (this.bluetooth.IsConnected()) {
                this.afterConnect(this.bluetooth);
            }
        }
    }

    public final void Initialize() {
    }

    @Override
    public void afterConnect(BluetoothConnectionBase bluetoothConnectionBase) {
    }

    @Override
    public void beforeDisconnect(BluetoothConnectionBase bluetoothConnectionBase) {
    }

    protected final boolean checkBluetooth(String string) {
        BluetoothClient bluetoothClient = this.bluetooth;
        if (bluetoothClient == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 401, new Object[0]);
            return false;
        }
        if (!bluetoothClient.IsConnected()) {
            this.form.dispatchErrorOccurredEvent((Component)this, string, 402, new Object[0]);
            return false;
        }
        return true;
    }

    protected final int convertMotorPortLetterToNumber(char c) {
        if (c != 'A' && c != 'a') {
            if (c != 'B' && c != 'b') {
                if (c != 'C' && c != 'c') {
                    throw new IllegalArgumentException("Illegal motor port letter " + c);
                }
                return 2;
            }
            return 1;
        }
        return 0;
    }

    protected final int convertMotorPortLetterToNumber(String string) {
        if (string.length() == 1) {
            return this.convertMotorPortLetterToNumber(string.charAt(0));
        }
        throw new IllegalArgumentException("Illegal motor port letter " + string);
    }

    protected final int convertSensorPortLetterToNumber(char c) {
        if (c == '1') {
            return 0;
        }
        if (c == '2') {
            return 1;
        }
        if (c == '3') {
            return 2;
        }
        if (c == '4') {
            return 3;
        }
        throw new IllegalArgumentException("Illegal sensor port letter " + c);
    }

    protected final int convertSensorPortLetterToNumber(String string) {
        if (string.length() == 1) {
            return this.convertSensorPortLetterToNumber(string.charAt(0));
        }
        throw new IllegalArgumentException("Illegal sensor port letter " + string);
    }

    protected final void copyBooleanValueToBytes(boolean bl, byte[] byArray, int n) {
        byArray[n] = (byte)(bl ? 1 : 0);
    }

    protected final void copySBYTEValueToBytes(int n, byte[] byArray, int n2) {
        byArray[n2] = (byte)n;
    }

    protected final void copySLONGValueToBytes(int n, byte[] byArray, int n2) {
        byArray[n2] = (byte)(n & 0xFF);
        byArray[n2 + 1] = (byte)((n >>= 8) & 0xFF);
        byArray[n2 + 2] = (byte)((n >>= 8) & 0xFF);
        byArray[n2 + 3] = (byte)(n >> 8 & 0xFF);
    }

    protected final void copySWORDValueToBytes(int n, byte[] byArray, int n2) {
        byArray[n2] = (byte)(n & 0xFF);
        byArray[n2 + 1] = (byte)(n >> 8 & 0xFF);
    }

    protected final void copyStringValueToBytes(String object2, byte[] byArray, int n, int n2) {
        String string = object2;
        if (object2.length() > n2) {
            string = object2.substring(0, n2);
        }
        try {
            object2 = string.getBytes("ISO-8859-1");
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            object2 = this.logTag;
            String string2 = unsupportedEncodingException.getMessage();
            Log.w((String)object2, (String)("UnsupportedEncodingException: " + string2));
            object2 = string.getBytes();
        }
        System.arraycopy((Object)object2, (int)0, (Object)byArray, (int)n, (int)Math.min((int)n2, (int)((Object)object2).length));
    }

    protected final void copyUBYTEValueToBytes(int n, byte[] byArray, int n2) {
        byArray[n2] = (byte)n;
    }

    protected final void copyULONGValueToBytes(long l, byte[] byArray, int n) {
        byArray[n] = (byte)(l & 0xFFL);
        byArray[n + 1] = (byte)((l >>= 8) & 0xFFL);
        byArray[n + 2] = (byte)((l >>= 8) & 0xFFL);
        byArray[n + 3] = (byte)(0xFFL & l >> 8);
    }

    protected final void copyUWORDValueToBytes(int n, byte[] byArray, int n2) {
        byArray[n2] = (byte)(n & 0xFF);
        byArray[n2 + 1] = (byte)(n >> 8 & 0xFF);
    }

    protected final boolean evaluateStatus(String string, byte[] byArray, byte by) {
        int n = this.getStatus(string, byArray, by);
        if (n == 0) {
            return true;
        }
        super.handleError(string, n);
        return false;
    }

    protected final boolean getBooleanValueFromBytes(byte[] byArray, int n) {
        boolean bl = byArray[n] != 0;
        return bl;
    }

    protected final byte[] getInputValues(String string, int n) {
        Object object2 = new byte[3];
        object2[0] = 0;
        object2[1] = 7;
        this.copyUBYTEValueToBytes(n, (byte[])object2, 2);
        byte[] byArray = this.sendCommandAndReceiveReturnPackage(string, (byte[])object2);
        if (this.evaluateStatus(string, byArray, object2[1])) {
            if (byArray.length == 16) {
                return byArray;
            }
            object2 = this.logTag;
            n = byArray.length;
            Log.w((String)object2, (String)(string + ": unexpected return package length " + n + " (expected 16)"));
        }
        return null;
    }

    protected final byte[] getInputValues(String string, NxtSensorPort nxtSensorPort) {
        return this.getInputValues(string, nxtSensorPort.toInt());
    }

    protected final int getSBYTEValueFromBytes(byte[] byArray, int n) {
        return byArray[n];
    }

    protected final int getSLONGValueFromBytes(byte[] byArray, int n) {
        return byArray[n] & 0xFF | (byArray[n + 1] & 0xFF) << 8 | (byArray[n + 2] & 0xFF) << 16 | byArray[n + 3] << 24;
    }

    protected final int getSWORDValueFromBytes(byte[] byArray, int n) {
        return byArray[n] & 0xFF | byArray[n + 1] << 8;
    }

    protected final int getStatus(String string, byte[] byArray, byte by) {
        if (byArray.length >= 3) {
            String string2;
            String string3;
            if (byArray[0] != 2) {
                string3 = this.logTag;
                string2 = Integer.toHexString((int)(byArray[0] & 0xFF));
                Log.w((String)string3, (String)(string + ": unexpected return package byte 0: 0x" + string2 + " (expected 0x02)"));
            }
            if (byArray[1] != by) {
                string2 = this.logTag;
                string3 = Integer.toHexString((int)(byArray[1] & 0xFF));
                String string4 = Integer.toHexString((int)(by & 0xFF));
                Log.w((String)string2, (String)(string + ": unexpected return package byte 1: 0x" + string3 + " (expected 0x" + string4 + ")"));
            }
            return this.getUBYTEValueFromBytes(byArray, 2);
        }
        String string5 = this.logTag;
        by = (byte)byArray.length;
        Log.w((String)string5, (String)(string + ": unexpected return package length " + by + " (expected >= 3)"));
        return -1;
    }

    protected final String getStringValueFromBytes(byte[] byArray, int n) {
        int n2;
        int n3 = 0;
        int n4 = n;
        while (true) {
            n2 = n3;
            if (n4 >= byArray.length) break;
            if (byArray[n4] == 0) {
                n2 = n4 - n;
                break;
            }
            ++n4;
        }
        return this.getStringValueFromBytes(byArray, n, n2);
    }

    protected final String getStringValueFromBytes(byte[] byArray, int n, int n2) {
        try {
            String string = new String(byArray, n, n2, "ISO-8859-1");
            return string;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            String string = this.logTag;
            String string2 = unsupportedEncodingException.getMessage();
            Log.w((String)string, (String)("UnsupportedEncodingException: " + string2));
            return new String(byArray, n, n2);
        }
    }

    protected final int getUBYTEValueFromBytes(byte[] byArray, int n) {
        return byArray[n] & 0xFF;
    }

    protected final long getULONGValueFromBytes(byte[] byArray, int n) {
        return (long)byArray[n] & 0xFFL | ((long)byArray[n + 1] & 0xFFL) << 8 | ((long)byArray[n + 2] & 0xFFL) << 16 | (0xFFL & (long)byArray[n + 3]) << 24;
    }

    protected final int getUWORDValueFromBytes(byte[] byArray, int n) {
        return byArray[n] & 0xFF | (byArray[n + 1] & 0xFF) << 8;
    }

    protected final int lsGetStatus(String string, int n) {
        Object object2 = new byte[3];
        object2[0] = 0;
        object2[1] = 14;
        this.copyUBYTEValueToBytes(n, (byte[])object2, 2);
        byte[] byArray = this.sendCommandAndReceiveReturnPackage(string, (byte[])object2);
        if (this.evaluateStatus(string, byArray, object2[1])) {
            if (byArray.length == 4) {
                return this.getUBYTEValueFromBytes(byArray, 3);
            }
            object2 = this.logTag;
            n = byArray.length;
            Log.w((String)object2, (String)(string + ": unexpected return package length " + n + " (expected 4)"));
        }
        return 0;
    }

    protected final int lsGetStatus(String string, NxtSensorPort nxtSensorPort) {
        return this.lsGetStatus(string, nxtSensorPort.toInt());
    }

    protected final byte[] lsRead(String string, int n) {
        Object object2 = new byte[3];
        object2[0] = 0;
        object2[1] = 16;
        this.copyUBYTEValueToBytes(n, (byte[])object2, 2);
        byte[] byArray = this.sendCommandAndReceiveReturnPackage(string, (byte[])object2);
        if (this.evaluateStatus(string, byArray, object2[1])) {
            if (byArray.length == 20) {
                return byArray;
            }
            object2 = this.logTag;
            n = byArray.length;
            Log.w((String)object2, (String)(string + ": unexpected return package length " + n + " (expected 20)"));
        }
        return null;
    }

    protected final byte[] lsRead(String string, NxtSensorPort nxtSensorPort) {
        return this.lsRead(string, nxtSensorPort.toInt());
    }

    protected final void lsWrite(String string, int n, byte[] byArray, int n2) {
        if (byArray.length <= 16) {
            byte[] byArray2 = new byte[byArray.length + 5];
            byArray2[0] = 0;
            byArray2[1] = 15;
            this.copyUBYTEValueToBytes(n, byArray2, 2);
            this.copyUBYTEValueToBytes(byArray.length, byArray2, 3);
            this.copyUBYTEValueToBytes(n2, byArray2, 4);
            System.arraycopy((Object)byArray, (int)0, (Object)byArray2, (int)5, (int)byArray.length);
            this.evaluateStatus(string, this.sendCommandAndReceiveReturnPackage(string, byArray2), byArray2[1]);
            return;
        }
        throw new IllegalArgumentException("length must be <= 16");
    }

    protected final void lsWrite(String string, NxtSensorPort nxtSensorPort, byte[] byArray, int n) {
        this.lsWrite(string, nxtSensorPort.toInt(), byArray, n);
    }

    @Override
    public void onDelete() {
        BluetoothClient bluetoothClient = this.bluetooth;
        if (bluetoothClient != null) {
            bluetoothClient.removeBluetoothConnectionListener(this);
            this.bluetooth.detachComponent(this);
            this.bluetooth = null;
        }
    }

    protected final void resetInputScaledValue(String string, int n) {
        byte[] byArray = new byte[3];
        byArray[0] = -128;
        byArray[1] = 8;
        this.copyUBYTEValueToBytes(n, byArray, 2);
        this.sendCommand(string, byArray);
    }

    protected final void resetInputScaledValue(String string, NxtSensorPort nxtSensorPort) {
        this.resetInputScaledValue(string, nxtSensorPort.toInt());
    }

    protected final int sanitizePower(int n) {
        int n2 = n;
        if (n < -100) {
            Log.w((String)this.logTag, (String)("power " + n + " is invalid, using -100."));
            n2 = -100;
        }
        n = n2;
        if (n2 > 100) {
            Log.w((String)this.logTag, (String)("power " + n2 + " is invalid, using 100."));
            n = 100;
        }
        return n;
    }

    protected final int sanitizeTurnRatio(int n) {
        int n2 = n;
        if (n < -100) {
            Log.w((String)this.logTag, (String)("turnRatio " + n + " is invalid, using -100."));
            n2 = -100;
        }
        n = n2;
        if (n2 > 100) {
            Log.w((String)this.logTag, (String)("turnRatio " + n2 + " is invalid, using 100."));
            n = 100;
        }
        return n;
    }

    protected final void sendCommand(String string, byte[] byArray) {
        byte[] byArray2 = new byte[2];
        this.copyUWORDValueToBytes(byArray.length, byArray2, 0);
        this.bluetooth.write(string, byArray2);
        this.bluetooth.write(string, byArray);
    }

    protected final byte[] sendCommandAndReceiveReturnPackage(String string, byte[] byArray) {
        this.sendCommand(string, byArray);
        return super.receiveReturnPackage(string);
    }

    protected final void setInputMode(String string, int n, int n2, int n3) {
        byte[] byArray = new byte[5];
        byArray[0] = -128;
        byArray[1] = 5;
        this.copyUBYTEValueToBytes(n, byArray, 2);
        this.copyUBYTEValueToBytes(n2, byArray, 3);
        this.copyUBYTEValueToBytes(n3, byArray, 4);
        this.sendCommand(string, byArray);
    }

    protected final void setInputMode(String string, NxtSensorPort nxtSensorPort, NxtSensorType nxtSensorType, NxtSensorMode nxtSensorMode) {
        this.setInputMode(string, nxtSensorPort.toInt(), nxtSensorType.toUnderlyingValue(), nxtSensorMode.toUnderlyingValue());
    }

    protected final void setOutputState(String string, int n, int n2, int n3, int n4, int n5, int n6, long l) {
        n2 = this.sanitizePower(n2);
        n5 = this.sanitizeTurnRatio(n5);
        byte[] byArray = new byte[12];
        byArray[0] = -128;
        byArray[1] = 4;
        this.copyUBYTEValueToBytes(n, byArray, 2);
        this.copySBYTEValueToBytes(n2, byArray, 3);
        this.copyUBYTEValueToBytes(n3, byArray, 4);
        this.copyUBYTEValueToBytes(n4, byArray, 5);
        this.copySBYTEValueToBytes(n5, byArray, 6);
        this.copyUBYTEValueToBytes(n6, byArray, 7);
        this.copyULONGValueToBytes(l, byArray, 8);
        this.sendCommand(string, byArray);
    }

    protected final void setOutputState(String string, NxtMotorPort nxtMotorPort, int n, NxtMotorMode nxtMotorMode, NxtRegulationMode nxtRegulationMode, int n2, NxtRunState nxtRunState, long l) {
        this.setOutputState(string, nxtMotorPort.toInt(), n, nxtMotorMode.toUnderlyingValue(), nxtRegulationMode.toUnderlyingValue(), n2, nxtRunState.toUnderlyingValue(), l);
    }
}

