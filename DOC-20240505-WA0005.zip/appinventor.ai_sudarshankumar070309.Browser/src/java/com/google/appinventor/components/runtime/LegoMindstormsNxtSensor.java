/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.common.NxtSensorPort
 *  com.google.appinventor.components.runtime.BluetoothConnectionBase
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.NxtSensorPort;
import com.google.appinventor.components.runtime.BluetoothConnectionBase;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.LegoMindstormsNxtBase;

@SimpleObject
public abstract class LegoMindstormsNxtSensor
extends LegoMindstormsNxtBase {
    protected NxtSensorPort port;

    protected LegoMindstormsNxtSensor(ComponentContainer componentContainer, String string) {
        super(componentContainer, string);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The sensor port that the sensor is connected to.", userVisible=false)
    public String SensorPort() {
        return this.port.toUnderlyingValue();
    }

    public abstract void SensorPort(String var1);

    @Override
    public void afterConnect(BluetoothConnectionBase bluetoothConnectionBase) {
        this.initializeSensor("Connect");
    }

    protected abstract void initializeSensor(String var1);

    protected final void setSensorPort(String string) {
        NxtSensorPort nxtSensorPort = NxtSensorPort.fromUnderlyingValue((String)string);
        if (nxtSensorPort == null) {
            this.form.dispatchErrorOccurredEvent((Component)this, "SensorPort", 408, string);
            return;
        }
        this.port = nxtSensorPort;
        if (this.bluetooth != null && this.bluetooth.IsConnected()) {
            this.initializeSensor("SensorPort");
        }
    }
}

