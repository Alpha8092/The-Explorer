/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;

public class Cookie {
    public static String escape(String string) {
        String string2 = string.trim();
        string = new StringBuffer();
        int n = string2.length();
        for (int i = 0; i < n; ++i) {
            char c = string2.charAt(i);
            if (c >= ' ' && c != '+' && c != '%' && c != '=' && c != ';') {
                string.append(c);
                continue;
            }
            string.append('%');
            string.append(Character.forDigit((int)((char)(c >>> 4 & 0xF)), (int)16));
            string.append(Character.forDigit((int)((char)(c & 0xF)), (int)16));
        }
        return string.toString();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static JSONObject toJSONObject(String string) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        JSONTokener jSONTokener = new JSONTokener(string);
        jSONObject.put("name", (Object)jSONTokener.nextTo('='));
        jSONTokener.next('=');
        jSONObject.put("value", (Object)jSONTokener.nextTo(';'));
        jSONTokener.next();
        while (jSONTokener.more()) {
            String string2 = Cookie.unescape(jSONTokener.nextTo("=;"));
            if (jSONTokener.next() != '=') {
                if (!string2.equals((Object)"secure")) throw jSONTokener.syntaxError("Missing '=' in cookie parameter.");
                string = Boolean.TRUE;
            } else {
                string = Cookie.unescape(jSONTokener.nextTo(';'));
                jSONTokener.next();
            }
            jSONObject.put(string2, (Object)string);
        }
        return jSONObject;
    }

    public static String toString(JSONObject jSONObject) throws JSONException {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(Cookie.escape(jSONObject.getString("name")));
        stringBuffer.append("=");
        stringBuffer.append(Cookie.escape(jSONObject.getString("value")));
        if (jSONObject.has("expires")) {
            stringBuffer.append(";expires=");
            stringBuffer.append(jSONObject.getString("expires"));
        }
        if (jSONObject.has("domain")) {
            stringBuffer.append(";domain=");
            stringBuffer.append(Cookie.escape(jSONObject.getString("domain")));
        }
        if (jSONObject.has("path")) {
            stringBuffer.append(";path=");
            stringBuffer.append(Cookie.escape(jSONObject.getString("path")));
        }
        if (jSONObject.optBoolean("secure")) {
            stringBuffer.append(";secure");
        }
        return stringBuffer.toString();
    }

    public static String unescape(String string) {
        int n = string.length();
        StringBuffer stringBuffer = new StringBuffer();
        int n2 = 0;
        while (n2 < n) {
            int n3;
            char c;
            char c2 = string.charAt(n2);
            if (c2 == '+') {
                c = ' ';
                n3 = n2;
            } else {
                n3 = n2;
                c = c2;
                if (c2 == '%') {
                    n3 = n2;
                    c = c2;
                    if (n2 + 2 < n) {
                        int n4 = JSONTokener.dehexchar((char)string.charAt(n2 + 1));
                        int n5 = JSONTokener.dehexchar((char)string.charAt(n2 + 2));
                        n3 = n2;
                        c = c2;
                        if (n4 >= 0) {
                            n3 = n2;
                            c = c2;
                            if (n5 >= 0) {
                                c = (char)(n4 * 16 + n5);
                                n3 = n2 + 2;
                            }
                        }
                    }
                }
            }
            stringBuffer.append(c);
            n2 = n3 + 1;
        }
        return stringBuffer.toString();
    }
}

