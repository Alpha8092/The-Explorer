/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.charts.BarLineChartBase
 *  com.github.mikephil.charting.data.BarLineScatterCandleBubbleData
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.interfaces.datasets.IBarLineScatterCandleBubbleDataSet
 *  com.google.appinventor.components.runtime.Chart2DDataModel
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.lang.Float
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.NullPointerException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.charts.BarLineChartBase;
import com.github.mikephil.charting.data.BarLineScatterCandleBubbleData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.interfaces.datasets.IBarLineScatterCandleBubbleDataSet;
import com.google.appinventor.components.runtime.Chart2DDataModel;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.PointChartView;
import com.google.appinventor.components.runtime.util.YailList;

public abstract class PointChartDataModel<E extends Entry, T extends IBarLineScatterCandleBubbleDataSet<E>, D extends BarLineScatterCandleBubbleData<T>, C extends BarLineChartBase<D>, V extends PointChartView<E, T, D, C, V>>
extends Chart2DDataModel<E, T, D, C, V> {
    protected PointChartDataModel(D d, V v) {
        super(d, v);
    }

    public Entry getEntryFromTuple(YailList yailList) {
        String string = yailList.getString(0);
        String string2 = yailList.getString(1);
        try {
            Entry entry = new Entry(Float.parseFloat((String)string), Float.parseFloat((String)string2));
            return entry;
        }
        catch (NumberFormatException numberFormatException) {
            try {
                ((PointChartView)((Object)this.view)).getForm().dispatchErrorOccurredEvent((Component)((PointChartView)((Object)this.view)).chartComponent, "GetEntryFromTuple", 4101, string, string2);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                ((PointChartView)((Object)this.view)).getForm().dispatchErrorOccurredEvent((Component)((PointChartView)((Object)this.view)).chartComponent, "GetEntryFromTuple", 4103, this.getTupleSize(), yailList.size());
            }
            catch (NullPointerException nullPointerException) {
                ((PointChartView)((Object)this.view)).getForm().dispatchErrorOccurredEvent((Component)((PointChartView)((Object)this.view)).chartComponent, "GetEntryFromTuple", 4102, new Object[0]);
            }
        }
        return null;
    }
}

