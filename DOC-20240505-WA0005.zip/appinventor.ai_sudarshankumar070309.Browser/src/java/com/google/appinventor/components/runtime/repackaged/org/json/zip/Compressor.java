/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.Kim
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONArray;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.Kim;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.Huff;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.JSONzip;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.Keep;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

public class Compressor
extends JSONzip {
    final BitWriter bitwriter;

    public Compressor(BitWriter bitWriter) {
        this.bitwriter = bitWriter;
    }

    private static int bcd(char c) {
        if (c >= '0' && c <= '9') {
            return c - 48;
        }
        switch (c) {
            default: {
                return 13;
            }
            case '.': {
                return 10;
            }
            case '-': {
                return 11;
            }
            case '+': 
        }
        return 12;
    }

    private void one() throws JSONException {
        this.write(1, 1);
    }

    private void write(int n, int n2) throws JSONException {
        try {
            this.bitwriter.write(n, n2);
            return;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
    }

    private void write(int n, Huff huff) throws JSONException {
        huff.write(n, this.bitwriter);
    }

    private void write(Kim kim, int n, int n2, Huff huff) throws JSONException {
        while (n < n2) {
            super.write(kim.get(n), huff);
            ++n;
        }
    }

    private void write(Kim kim, Huff huff) throws JSONException {
        super.write(kim, 0, kim.length, huff);
    }

    private void writeAndTick(int n, Keep keep) throws JSONException {
        int n2 = keep.bitsize();
        keep.tick(n);
        super.write(n, n2);
    }

    private void writeArray(JSONArray jSONArray) throws JSONException {
        boolean bl = false;
        int n = jSONArray.length();
        if (n == 0) {
            super.write(1, 3);
        } else {
            Object object2;
            Object object3 = object2 = jSONArray.get(0);
            if (object2 == null) {
                object3 = JSONObject.NULL;
            }
            if (object3 instanceof String) {
                bl = true;
                super.write(6, 3);
                super.writeString((String)object3);
            } else {
                super.write(7, 3);
                super.writeValue(object3);
            }
            for (int i = 1; i < n; ++i) {
                object3 = object2 = jSONArray.get(i);
                if (object2 == null) {
                    object3 = JSONObject.NULL;
                }
                if (object3 instanceof String != bl) {
                    super.zero();
                }
                super.one();
                if (object3 instanceof String) {
                    super.writeString((String)object3);
                    continue;
                }
                super.writeValue(object3);
            }
            super.zero();
            super.zero();
        }
    }

    private void writeJSON(Object object2) throws JSONException {
        block13: {
            block9: {
                Object object3;
                block12: {
                    block11: {
                        block10: {
                            block8: {
                                if (!JSONObject.NULL.equals(object2)) break block8;
                                super.write(4, 3);
                                break block9;
                            }
                            if (!Boolean.FALSE.equals(object2)) break block10;
                            super.write(3, 3);
                            break block9;
                        }
                        if (!Boolean.TRUE.equals(object2)) break block11;
                        super.write(2, 3);
                        break block9;
                    }
                    if (object2 instanceof Map) {
                        object3 = new JSONObject((Map)object2);
                    } else if (object2 instanceof Collection) {
                        object3 = new JSONArray((Collection)object2);
                    } else {
                        object3 = object2;
                        if (object2.getClass().isArray()) {
                            object3 = new JSONArray(object2);
                        }
                    }
                    if (!(object3 instanceof JSONObject)) break block12;
                    super.writeObject((JSONObject)object3);
                    break block9;
                }
                if (!(object3 instanceof JSONArray)) break block13;
                super.writeArray((JSONArray)object3);
            }
            return;
        }
        throw new JSONException("Unrecognized object");
    }

    private void writeName(String string) throws JSONException {
        int n = this.namekeep.find(string = new Kim(string));
        if (n != -1) {
            super.one();
            super.writeAndTick(n, this.namekeep);
        } else {
            super.zero();
            super.write((Kim)string, this.namehuff);
            super.write(256, this.namehuff);
            this.namekeep.register(string);
        }
    }

    private void writeObject(JSONObject jSONObject) throws JSONException {
        boolean bl = true;
        Iterator iterator = jSONObject.keys();
        while (iterator.hasNext()) {
            Object object2 = iterator.next();
            boolean bl2 = bl;
            if (object2 instanceof String) {
                if (bl) {
                    bl = false;
                    super.write(5, 3);
                } else {
                    super.one();
                }
                super.writeName((String)object2);
                object2 = jSONObject.get((String)object2);
                if (object2 instanceof String) {
                    super.zero();
                    super.writeString((String)object2);
                    bl2 = bl;
                } else {
                    super.one();
                    super.writeValue(object2);
                    bl2 = bl;
                }
            }
            bl = bl2;
        }
        if (bl) {
            super.write(0, 3);
        } else {
            super.zero();
        }
    }

    private void writeString(String string) throws JSONException {
        if (string.length() == 0) {
            super.zero();
            super.zero();
            super.write(256, this.substringhuff);
            super.zero();
        } else {
            int n = this.stringkeep.find(string = new Kim(string));
            if (n != -1) {
                super.one();
                super.writeAndTick(n, this.stringkeep);
            } else {
                super.writeSubstring((Kim)string);
                this.stringkeep.register(string);
            }
        }
    }

    private void writeSubstring(Kim kim) throws JSONException {
        this.substringkeep.reserve();
        super.zero();
        int n = 0;
        int n2 = kim.length;
        int n3 = -1;
        int n4 = 0;
        while (true) {
            int n5;
            int n6 = -1;
            int n7 = n;
            while (true) {
                n5 = n6;
                if (n7 > n2 - 3) break;
                n6 = this.substringkeep.match(kim, n7, n2);
                if (n6 != -1) {
                    n5 = n6;
                    break;
                }
                ++n7;
            }
            if (n5 == -1) {
                super.zero();
                if (n < n2) {
                    super.write(kim, n, n2, this.substringhuff);
                    if (n3 != -1) {
                        this.substringkeep.registerOne(kim, n3, n4);
                    }
                }
                super.write(256, this.substringhuff);
                super.zero();
                this.substringkeep.registerMany(kim);
                return;
            }
            n6 = n3;
            if (n != n7) {
                super.zero();
                super.write(kim, n, n7, this.substringhuff);
                super.write(256, this.substringhuff);
                n6 = n3;
                if (n3 != -1) {
                    this.substringkeep.registerOne(kim, n3, n4);
                    n6 = -1;
                }
            }
            super.one();
            super.writeAndTick(n5, this.substringkeep);
            n = n7 + this.substringkeep.length(n5);
            if (n6 != -1) {
                this.substringkeep.registerOne(kim, n6, n4);
            }
            n3 = n7;
            n4 = n + 1;
        }
    }

    private void writeValue(Object object2) throws JSONException {
        if (object2 instanceof Number) {
            long l;
            String string = JSONObject.numberToString((Number)((Number)object2));
            int n = this.values.find(string);
            if (n != -1) {
                super.write(2, 2);
                super.writeAndTick(n, this.values);
                return;
            }
            if ((object2 instanceof Integer || object2 instanceof Long) && (l = ((Number)object2).longValue()) >= 0L && l < 16384L) {
                super.write(0, 2);
                if (l < 16L) {
                    super.zero();
                    super.write((int)l, 4);
                    return;
                }
                super.one();
                if (l < 128L) {
                    super.zero();
                    super.write((int)l, 7);
                    return;
                }
                super.one();
                super.write((int)l, 14);
                return;
            }
            super.write(1, 2);
            for (n = 0; n < string.length(); ++n) {
                super.write(Compressor.bcd(string.charAt(n)), 4);
            }
            super.write(endOfNumber, 4);
            this.values.register(string);
        } else {
            super.write(3, 2);
            super.writeJSON(object2);
        }
    }

    private void zero() throws JSONException {
        this.write(0, 1);
    }

    public void flush() throws JSONException {
        this.pad(8);
    }

    public void pad(int n) throws JSONException {
        try {
            this.bitwriter.pad(n);
            return;
        }
        catch (Throwable throwable) {
            throw new JSONException(throwable);
        }
    }

    public void zip(JSONArray jSONArray) throws JSONException {
        this.begin();
        super.writeJSON(jSONArray);
    }

    public void zip(JSONObject jSONObject) throws JSONException {
        this.begin();
        super.writeJSON(jSONObject);
    }
}

