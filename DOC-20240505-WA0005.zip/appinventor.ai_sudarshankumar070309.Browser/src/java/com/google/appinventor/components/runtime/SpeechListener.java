/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

public interface SpeechListener {
    public void onError(int var1);

    public void onPartialResult(String var1);

    public void onResult(String var1);
}

