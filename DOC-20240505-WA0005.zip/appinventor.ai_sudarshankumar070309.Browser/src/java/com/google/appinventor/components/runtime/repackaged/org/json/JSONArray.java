/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  java.io.IOException
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.reflect.Array
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public class JSONArray {
    private final ArrayList myArrayList;

    public JSONArray() {
        this.myArrayList = new ArrayList();
    }

    public JSONArray(JSONTokener object) throws JSONException {
        if (object.nextClean() == '[') {
            if (object.nextClean() != ']') {
                object.back();
                while (true) {
                    if (object.nextClean() == ',') {
                        object.back();
                        this.myArrayList.add(JSONObject.NULL);
                    } else {
                        object.back();
                        this.myArrayList.add(object.nextValue());
                    }
                    switch (object.nextClean()) {
                        default: {
                            throw object.syntaxError("Expected a ',' or ']'");
                        }
                        case ']': {
                            return;
                        }
                        case ',': 
                    }
                    if (object.nextClean() == ']') {
                        return;
                    }
                    object.back();
                }
            }
            return;
        }
        object = object.syntaxError("A JSONArray text must start with '['");
        throw object;
    }

    public JSONArray(Object object) throws JSONException {
        if (object.getClass().isArray()) {
            int n = Array.getLength((Object)object);
            for (int i = 0; i < n; ++i) {
                this.put(JSONObject.wrap((Object)Array.get((Object)object, (int)i)));
            }
            return;
        }
        object = new JSONException("JSONArray initial value should be a string or collection or array.");
        throw object;
    }

    public JSONArray(String string) throws JSONException {
        super(new JSONTokener(string));
    }

    public JSONArray(Collection collection) {
        this.myArrayList = new ArrayList();
        if (collection != null) {
            collection = collection.iterator();
            while (collection.hasNext()) {
                this.myArrayList.add(JSONObject.wrap((Object)collection.next()));
            }
        }
    }

    public Object get(int n) throws JSONException {
        Object object = this.opt(n);
        if (object != null) {
            return object;
        }
        throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] not found.").toString());
    }

    public boolean getBoolean(int n) throws JSONException {
        Object object = this.get(n);
        if (!(object.equals((Object)Boolean.FALSE) || object instanceof String && ((String)object).equalsIgnoreCase("false"))) {
            if (!(object.equals((Object)Boolean.TRUE) || object instanceof String && ((String)object).equalsIgnoreCase("true"))) {
                throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a boolean.").toString());
            }
            return true;
        }
        return false;
    }

    public double getDouble(int n) throws JSONException {
        Object object = this.get(n);
        try {
            double d = object instanceof Number ? ((Number)object).doubleValue() : Double.parseDouble((String)((String)object));
            return d;
        }
        catch (Exception exception) {
            throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a number.").toString());
        }
    }

    public int getInt(int n) throws JSONException {
        block4: {
            int n2;
            Object object;
            block3: {
                object = this.get(n);
                try {
                    int n3;
                    if (!(object instanceof Number)) break block3;
                    n = n3 = ((Number)object).intValue();
                    break block4;
                }
                catch (Exception exception) {
                    throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a number.").toString());
                }
            }
            n = n2 = Integer.parseInt((String)((String)object));
        }
        return n;
    }

    public JSONArray getJSONArray(int n) throws JSONException {
        Object object = this.get(n);
        if (object instanceof JSONArray) {
            return (JSONArray)object;
        }
        throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a JSONArray.").toString());
    }

    public JSONObject getJSONObject(int n) throws JSONException {
        Object object = this.get(n);
        if (object instanceof JSONObject) {
            return (JSONObject)object;
        }
        throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a JSONObject.").toString());
    }

    public long getLong(int n) throws JSONException {
        Object object = this.get(n);
        try {
            long l = object instanceof Number ? ((Number)object).longValue() : Long.parseLong((String)((String)object));
            return l;
        }
        catch (Exception exception) {
            throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] is not a number.").toString());
        }
    }

    public String getString(int n) throws JSONException {
        Object object = this.get(n);
        if (object instanceof String) {
            return (String)object;
        }
        throw new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] not a string.").toString());
    }

    public boolean isNull(int n) {
        return JSONObject.NULL.equals(this.opt(n));
    }

    public String join(String string) throws JSONException {
        int n = this.length();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < n; ++i) {
            if (i > 0) {
                stringBuffer.append(string);
            }
            stringBuffer.append(JSONObject.valueToString((Object)this.myArrayList.get(i)));
        }
        return stringBuffer.toString();
    }

    public int length() {
        return this.myArrayList.size();
    }

    public Object opt(int n) {
        Object object = n >= 0 && n < this.length() ? this.myArrayList.get(n) : null;
        return object;
    }

    public boolean optBoolean(int n) {
        return this.optBoolean(n, false);
    }

    public boolean optBoolean(int n, boolean bl) {
        try {
            boolean bl2 = this.getBoolean(n);
            return bl2;
        }
        catch (Exception exception) {
            return bl;
        }
    }

    public double optDouble(int n) {
        return this.optDouble(n, Double.NaN);
    }

    public double optDouble(int n, double d) {
        try {
            double d2 = this.getDouble(n);
            return d2;
        }
        catch (Exception exception) {
            return d;
        }
    }

    public int optInt(int n) {
        return this.optInt(n, 0);
    }

    public int optInt(int n, int n2) {
        try {
            n = this.getInt(n);
            return n;
        }
        catch (Exception exception) {
            return n2;
        }
    }

    public JSONArray optJSONArray(int n) {
        Object object = this.opt(n);
        object = object instanceof JSONArray ? (JSONArray)object : null;
        return object;
    }

    public JSONObject optJSONObject(int n) {
        Object object = this.opt(n);
        object = object instanceof JSONObject ? (JSONObject)object : null;
        return object;
    }

    public long optLong(int n) {
        return this.optLong(n, 0L);
    }

    public long optLong(int n, long l) {
        try {
            long l2 = this.getLong(n);
            return l2;
        }
        catch (Exception exception) {
            return l;
        }
    }

    public String optString(int n) {
        return this.optString(n, "");
    }

    public String optString(int n, String string) {
        Object object = this.opt(n);
        if (!JSONObject.NULL.equals(object)) {
            string = object.toString();
        }
        return string;
    }

    public JSONArray put(double d) throws JSONException {
        Double d2 = new Double(d);
        JSONObject.testValidity((Object)d2);
        this.put(d2);
        return this;
    }

    public JSONArray put(int n) {
        this.put(new Integer(n));
        return this;
    }

    public JSONArray put(int n, double d) throws JSONException {
        this.put(n, new Double(d));
        return this;
    }

    public JSONArray put(int n, int n2) throws JSONException {
        this.put(n, new Integer(n2));
        return this;
    }

    public JSONArray put(int n, long l) throws JSONException {
        this.put(n, new Long(l));
        return this;
    }

    public JSONArray put(int n, Object object) throws JSONException {
        JSONObject.testValidity((Object)object);
        if (n >= 0) {
            if (n < this.length()) {
                this.myArrayList.set(n, object);
            } else {
                while (n != this.length()) {
                    this.put(JSONObject.NULL);
                }
                this.put(object);
            }
            return this;
        }
        object = new JSONException(new StringBuffer().append("JSONArray[").append(n).append("] not found.").toString());
        throw object;
    }

    public JSONArray put(int n, Collection collection) throws JSONException {
        this.put(n, new JSONArray(collection));
        return this;
    }

    public JSONArray put(int n, Map map) throws JSONException {
        this.put(n, new JSONObject(map));
        return this;
    }

    public JSONArray put(int n, boolean bl) throws JSONException {
        Boolean bl2 = bl ? Boolean.TRUE : Boolean.FALSE;
        this.put(n, bl2);
        return this;
    }

    public JSONArray put(long l) {
        this.put(new Long(l));
        return this;
    }

    public JSONArray put(Object object) {
        this.myArrayList.add(object);
        return this;
    }

    public JSONArray put(Collection collection) {
        this.put(new JSONArray(collection));
        return this;
    }

    public JSONArray put(Map map) {
        this.put(new JSONObject(map));
        return this;
    }

    public JSONArray put(boolean bl) {
        Boolean bl2 = bl ? Boolean.TRUE : Boolean.FALSE;
        this.put(bl2);
        return this;
    }

    public Object remove(int n) {
        Object object = this.opt(n);
        this.myArrayList.remove(n);
        return object;
    }

    public JSONObject toJSONObject(JSONArray jSONArray) throws JSONException {
        if (jSONArray != null && jSONArray.length() != 0 && this.length() != 0) {
            JSONObject jSONObject = new JSONObject();
            for (int i = 0; i < jSONArray.length(); ++i) {
                jSONObject.put(jSONArray.getString(i), this.opt(i));
            }
            return jSONObject;
        }
        return null;
    }

    public String toString() {
        try {
            String string = this.toString(0);
            return string;
        }
        catch (Exception exception) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public String toString(int n) throws JSONException {
        StringBuffer stringBuffer;
        Object object = new StringWriter();
        StringBuffer stringBuffer2 = stringBuffer = object.getBuffer();
        synchronized (stringBuffer2) {
            return this.write((Writer)object, n, 0).toString();
        }
    }

    public Writer write(Writer writer) throws JSONException {
        return this.write(writer, 0, 0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    Writer write(Writer writer, int n, int n2) throws JSONException {
        boolean bl = false;
        try {
            int n3 = this.length();
            writer.write(91);
            if (n3 == 1) {
                JSONObject.writeValue((Writer)writer, (Object)this.myArrayList.get(0), (int)n, (int)n2);
            } else if (n3 != 0) {
                int n4 = n2 + n;
                for (int i = 0; i < n3; ++i) {
                    if (bl) {
                        writer.write(44);
                    }
                    if (n > 0) {
                        writer.write(10);
                    }
                    JSONObject.indent((Writer)writer, (int)n4);
                    JSONObject.writeValue((Writer)writer, (Object)this.myArrayList.get(i), (int)n, (int)n4);
                    bl = true;
                }
                if (n > 0) {
                    writer.write(10);
                }
                JSONObject.indent((Writer)writer, (int)n2);
            }
            writer.write(93);
            return writer;
        }
        catch (IOException iOException) {
            JSONException jSONException = new JSONException(iOException);
            throw jSONException;
        }
    }
}

