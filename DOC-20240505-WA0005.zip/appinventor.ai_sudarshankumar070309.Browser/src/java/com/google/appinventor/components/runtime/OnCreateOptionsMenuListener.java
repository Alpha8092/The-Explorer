/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.Menu
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import android.view.Menu;

public interface OnCreateOptionsMenuListener {
    public void onCreateOptionsMenu(Menu var1);
}

