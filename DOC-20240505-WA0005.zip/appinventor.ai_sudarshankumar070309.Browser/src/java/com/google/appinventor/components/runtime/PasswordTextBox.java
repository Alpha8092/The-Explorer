/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.method.PasswordTransformationMethod
 *  android.text.method.TransformationMethod
 *  android.widget.EditText
 *  android.widget.TextView
 *  com.google.appinventor.components.runtime.TextBoxBase
 *  com.google.appinventor.components.runtime.util.TextViewUtil
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.widget.EditText;
import android.widget.TextView;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.TextBoxBase;
import com.google.appinventor.components.runtime.util.TextViewUtil;

@DesignerComponent(category=ComponentCategory.USERINTERFACE, description="<p>A box for entering passwords.  This is the same as the ordinary <code>TextBox</code> component except this does not display the characters typed by the user.</p><p>The value of the text in the box can be found or set through the <code>Text</code> property. If blank, the <code>Hint</code> property, which appears as faint text in the box, can provide the user with guidance as to what to type.</p> <p>Text boxes are usually used with the <code>Button</code> component, with the user clicking on the button when text entry is complete.</p>", iconName="images/passwordTextBox.png", version=7)
@SimpleObject
public final class PasswordTextBox
extends TextBoxBase {
    private boolean acceptsNumbersOnly;
    private boolean passwordVisible;

    public PasswordTextBox(ComponentContainer componentContainer) {
        super(componentContainer, new EditText((Context)componentContainer.$context()));
        this.view.setSingleLine(true);
        this.view.setTransformationMethod((TransformationMethod)new PasswordTransformationMethod());
        this.view.setImeOptions(6);
        this.PasswordVisible(false);
        this.NumbersOnly(false);
    }

    private void setPasswordInputType(boolean bl, boolean bl2) {
        if (bl2 && bl) {
            this.view.setInputType(2);
        } else if (bl2 && !bl) {
            this.view.setInputType(145);
        } else if (bl && !bl2) {
            this.view.setInputType(18);
        } else if (!bl && !bl2) {
            this.view.setInputType(129);
        }
        TextViewUtil.setFontTypeface((Form)this.container.$form(), (TextView)this.view, (String)this.FontTypeface(), (boolean)this.FontBold(), (boolean)this.FontItalic());
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty(description="If true, then this password text box accepts only numbers as keyboard input.  Numbers can include a decimal point and an optional leading minus sign.  This applies to keyboard input only.  Even if NumbersOnly is true, you can use [set Text to] to enter any text at all.")
    public void NumbersOnly(boolean bl) {
        this.acceptsNumbersOnly = bl;
        super.setPasswordInputType(bl, this.passwordVisible);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="If true, then this password text box accepts only numbers as keyboard input.  Numbers can include a decimal point and an optional leading minus sign.  This applies to keyboard input only.  Even if NumbersOnly is true, you can use [set Text to] to enter any text at all.")
    public boolean NumbersOnly() {
        return this.acceptsNumbersOnly;
    }

    @SimpleProperty(description="Visibility of password.")
    public void PasswordVisible(boolean bl) {
        this.passwordVisible = bl;
        super.setPasswordInputType(this.acceptsNumbersOnly, bl);
    }

    @SimpleProperty(description="Visibility of password.")
    public boolean PasswordVisible() {
        return this.passwordVisible;
    }
}

