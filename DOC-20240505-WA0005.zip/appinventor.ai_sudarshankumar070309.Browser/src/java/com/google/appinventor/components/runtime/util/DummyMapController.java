/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.google.appinventor.components.common.MapType
 *  com.google.appinventor.components.common.ScaleUnits
 *  com.google.appinventor.components.runtime.util.MapFactory$HasFill
 *  com.google.appinventor.components.runtime.util.MapFactory$HasStroke
 *  com.google.appinventor.components.runtime.util.MapFactory$MapController
 *  com.google.appinventor.components.runtime.util.MapFactory$MapEventListener
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureCollection
 *  com.google.appinventor.components.runtime.util.MapFactory$MapScaleUnits
 *  com.google.appinventor.components.runtime.util.MapFactory$MapType
 *  java.lang.Object
 *  java.lang.UnsupportedOperationException
 *  org.osmdroid.util.BoundingBox
 */
package com.google.appinventor.components.runtime.util;

import android.view.View;
import com.google.appinventor.components.common.MapType;
import com.google.appinventor.components.common.ScaleUnits;
import com.google.appinventor.components.runtime.LocationSensor;
import com.google.appinventor.components.runtime.util.MapFactory;
import org.osmdroid.util.BoundingBox;

class DummyMapController
implements MapFactory.MapController {
    DummyMapController() {
    }

    public void addEventListener(MapFactory.MapEventListener mapEventListener) {
        throw new UnsupportedOperationException();
    }

    public void addFeature(MapFactory.MapCircle mapCircle) {
        throw new UnsupportedOperationException();
    }

    public void addFeature(MapFactory.MapLineString mapLineString) {
        throw new UnsupportedOperationException();
    }

    public void addFeature(MapFactory.MapMarker mapMarker) {
        throw new UnsupportedOperationException();
    }

    public void addFeature(MapFactory.MapPolygon mapPolygon) {
        throw new UnsupportedOperationException();
    }

    public void addFeature(MapFactory.MapRectangle mapRectangle) {
        throw new UnsupportedOperationException();
    }

    public BoundingBox getBoundingBox() {
        throw new UnsupportedOperationException();
    }

    public double getLatitude() {
        throw new UnsupportedOperationException();
    }

    public LocationSensor.LocationSensorListener getLocationListener() {
        throw new UnsupportedOperationException();
    }

    public double getLongitude() {
        throw new UnsupportedOperationException();
    }

    public MapFactory.MapType getMapType() {
        throw new UnsupportedOperationException();
    }

    public MapType getMapTypeAbstract() {
        throw new UnsupportedOperationException();
    }

    public int getOverlayCount() {
        throw new UnsupportedOperationException();
    }

    public float getRotation() {
        throw new UnsupportedOperationException();
    }

    public MapFactory.MapScaleUnits getScaleUnits() {
        throw new UnsupportedOperationException();
    }

    public ScaleUnits getScaleUnitsAbstract() {
        throw new UnsupportedOperationException();
    }

    public View getView() {
        throw new UnsupportedOperationException();
    }

    public int getZoom() {
        throw new UnsupportedOperationException();
    }

    public void hideFeature(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public void hideInfobox(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public boolean isCompassEnabled() {
        throw new UnsupportedOperationException();
    }

    public boolean isFeatureCollectionVisible(MapFactory.MapFeatureCollection mapFeatureCollection) {
        throw new UnsupportedOperationException();
    }

    public boolean isFeatureVisible(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public boolean isInfoboxVisible(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public boolean isPanEnabled() {
        throw new UnsupportedOperationException();
    }

    public boolean isRotationEnabled() {
        throw new UnsupportedOperationException();
    }

    public boolean isScaleVisible() {
        throw new UnsupportedOperationException();
    }

    public boolean isShowUserEnabled() {
        throw new UnsupportedOperationException();
    }

    public boolean isZoomControlEnabled() {
        throw new UnsupportedOperationException();
    }

    public boolean isZoomEnabled() {
        throw new UnsupportedOperationException();
    }

    public void panTo(double d, double d2, int n, double d3) {
        throw new UnsupportedOperationException();
    }

    public void removeFeature(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public void setBoundingBox(BoundingBox boundingBox) {
        throw new UnsupportedOperationException();
    }

    public void setCenter(double d, double d2) {
        throw new UnsupportedOperationException();
    }

    public void setCompassEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setFeatureCollectionVisible(MapFactory.MapFeatureCollection mapFeatureCollection, boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setMapType(MapFactory.MapType mapType) {
        throw new UnsupportedOperationException();
    }

    public void setMapTypeAbstract(MapType mapType) {
        throw new UnsupportedOperationException();
    }

    public void setPanEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setRotation(float f) {
        throw new UnsupportedOperationException();
    }

    public void setRotationEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setScaleUnits(MapFactory.MapScaleUnits mapScaleUnits) {
        throw new UnsupportedOperationException();
    }

    public void setScaleUnitsAbstract(ScaleUnits scaleUnits) {
        throw new UnsupportedOperationException();
    }

    public void setScaleVisible(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setShowUserEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setZoom(int n) {
        throw new UnsupportedOperationException();
    }

    public void setZoomControlEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void setZoomEnabled(boolean bl) {
        throw new UnsupportedOperationException();
    }

    public void showFeature(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public void showInfobox(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureDraggable(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureFill(MapFactory.HasFill hasFill) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureHoles(MapFactory.MapPolygon mapPolygon) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureImage(MapFactory.MapMarker mapMarker) {
        throw new UnsupportedOperationException();
    }

    public void updateFeaturePosition(MapFactory.MapCircle mapCircle) {
        throw new UnsupportedOperationException();
    }

    public void updateFeaturePosition(MapFactory.MapLineString mapLineString) {
        throw new UnsupportedOperationException();
    }

    public void updateFeaturePosition(MapFactory.MapMarker mapMarker) {
        throw new UnsupportedOperationException();
    }

    public void updateFeaturePosition(MapFactory.MapPolygon mapPolygon) {
        throw new UnsupportedOperationException();
    }

    public void updateFeaturePosition(MapFactory.MapRectangle mapRectangle) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureSize(MapFactory.MapMarker mapMarker) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureStroke(MapFactory.HasStroke hasStroke) {
        throw new UnsupportedOperationException();
    }

    public void updateFeatureText(MapFactory.MapFeature mapFeature) {
        throw new UnsupportedOperationException();
    }
}

