/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;

public class HTTPTokener
extends JSONTokener {
    public HTTPTokener(String string) {
        super(string);
    }

    public String nextToken() throws JSONException {
        char c;
        char c2;
        StringBuffer stringBuffer = new StringBuffer();
        while (Character.isWhitespace((char)(c2 = this.next()))) {
        }
        if (c2 != '\"') {
            c = c2;
            if (c2 != '\'') {
                while (c != '\u0000' && !Character.isWhitespace((char)c)) {
                    stringBuffer.append(c);
                    c = this.next();
                }
                return stringBuffer.toString();
            }
        }
        while ((c = this.next()) >= ' ') {
            if (c == c2) {
                return stringBuffer.toString();
            }
            stringBuffer.append(c);
        }
        throw this.syntaxError("Unterminated string.");
    }
}

