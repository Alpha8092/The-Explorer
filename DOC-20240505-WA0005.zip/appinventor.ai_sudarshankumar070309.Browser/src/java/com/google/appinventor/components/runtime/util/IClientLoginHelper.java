package com.google.appinventor.components.runtime.util;

import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpUriRequest;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public interface IClientLoginHelper {
    HttpResponse execute(HttpUriRequest httpUriRequest) throws ClientProtocolException, IOException;

    void forgetAccountName();

    String getAuthToken() throws ClientProtocolException;
}
