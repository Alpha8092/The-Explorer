/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.util.FileAccessMode
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  com.google.appinventor.components.runtime.util.ScopedFile
 *  com.google.appinventor.components.runtime.util.SingleFileOperation
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 */
package com.google.appinventor.components.runtime.util;

import android.util.Log;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.util.FileAccessMode;
import com.google.appinventor.components.runtime.util.IOUtils;
import com.google.appinventor.components.runtime.util.ScopedFile;
import com.google.appinventor.components.runtime.util.SingleFileOperation;
import java.io.Closeable;
import java.io.IOException;

public class FileStreamOperation<T extends Closeable>
extends SingleFileOperation {
    private static final String LOG_TAG = FileStreamOperation.class.getSimpleName();

    protected FileStreamOperation(Form form, Component component, String string, ScopedFile scopedFile, FileAccessMode fileAccessMode, boolean bl) {
        super(form, component, string, scopedFile, fileAccessMode, bl);
    }

    protected FileStreamOperation(Form form, Component component, String string, String string2, FileScope fileScope, FileAccessMode fileAccessMode, boolean bl) {
        super(form, component, string, string2, fileScope, fileAccessMode, bl);
    }

    public void onError(IOException iOException) {
        Log.e((String)LOG_TAG, (String)"IO error in file operation", (Throwable)iOException);
    }

    protected T openFile() throws IOException {
        throw new UnsupportedOperationException("Subclasses must implement FileOperation#openFile.");
    }

    protected boolean process(T t) throws IOException {
        throw new UnsupportedOperationException("Subclasses must implement FileOperation#process.");
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected void processFile(ScopedFile object2) {
        Throwable throwable2;
        Object object3;
        block4: {
            object2 /* !! */  = null;
            object3 = null;
            T t = this.openFile();
            object3 = t;
            object2 /* !! */  = t;
            boolean bl = this.process(t);
            if (!bl) return;
            object2 /* !! */  = t;
            {
                catch (Throwable throwable2) {
                    break block4;
                }
                catch (IOException iOException) {}
                object3 = object2 /* !! */ ;
                {
                    iOException.printStackTrace();
                    object3 = object2 /* !! */ ;
                    this.onError(iOException);
                }
            }
            IOUtils.closeQuietly((String)this.component.getClass().getSimpleName(), (Closeable)object2 /* !! */ );
            return;
        }
        IOUtils.closeQuietly((String)this.component.getClass().getSimpleName(), (Closeable)object3);
        throw throwable2;
    }
}

