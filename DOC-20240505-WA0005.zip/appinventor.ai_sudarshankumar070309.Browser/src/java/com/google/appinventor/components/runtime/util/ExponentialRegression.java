/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.util.OlsTrendLine;
import java.util.List;
import java.util.Map;

public class ExponentialRegression
extends OlsTrendLine {
    @Override
    public Map<String, Object> compute(List<Double> list, List<Double> list2) {
        list = super.compute(list, list2);
        list.remove((Object)"x^2");
        double d = (Double)list.remove((Object)"slope");
        list.put((Object)"a", (Object)Math.exp((double)((Double)list.remove((Object)"intercept"))));
        list.put((Object)"b", (Object)Math.exp((double)d));
        return list;
    }

    @Override
    public float[] computePoints(Map<String, Object> object2, float f, float f2, int n, int n2) {
        if (!object2.containsKey((Object)"a")) {
            return new float[0];
        }
        double d = (Double)object2.get((Object)"a");
        double d2 = (Double)object2.get((Object)"b");
        object2 = new float[n2 * 4];
        float f3 = Float.NEGATIVE_INFINITY;
        float f4 = Float.NEGATIVE_INFINITY;
        boolean bl = true;
        for (n = 0; n < n2; ++n) {
            boolean bl2 = bl;
            if (bl) {
                bl2 = false;
                f3 = f + (float)n * (f2 - f) / (float)n2;
                f4 = (float)(Math.pow((double)d2, (double)f3) * d);
            }
            object2[n * 4] = (Map<String, Object>)f3;
            object2[n * 4 + 1] = (Map<String, Object>)f4;
            f3 = f + (float)(n + 1) * (f2 - f) / (float)n2;
            f4 = (float)(Math.pow((double)d2, (double)f3) * d);
            object2[n * 4 + 2] = (Map<String, Object>)f3;
            object2[n * 4 + 3] = (Map<String, Object>)f4;
            bl = bl2;
        }
        return object2;
    }

    @Override
    protected boolean logY() {
        return true;
    }

    @Override
    protected int size() {
        return 2;
    }

    @Override
    protected double[] xVector(double d) {
        return new double[]{1.0, d};
    }
}

