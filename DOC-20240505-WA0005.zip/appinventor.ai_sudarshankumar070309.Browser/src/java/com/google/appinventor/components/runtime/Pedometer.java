/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences$Editor
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  java.lang.Deprecated
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.DataSourceChangeListener;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.RealTimeDataSource;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@DesignerComponent(category=ComponentCategory.SENSORS, description="A Component that acts like a Pedometer. It senses motion via the Accelerometer and attempts to determine if a step has been taken. Using a configurable stride length, it can estimate the distance traveled as well. ", iconName="images/pedometer.png", nonVisible=true, version=3)
@SimpleObject
public class Pedometer
extends AndroidNonvisibleComponent
implements Component,
SensorEventListener,
Deleteable,
RealTimeDataSource<String, Float> {
    private static final int INTERVAL_VARIATION = 250;
    private static final int NUM_INTERVALS = 2;
    private static final float PEAK_VALLEY_RANGE = 40.0f;
    private static final String PREFS_NAME = "PedometerPrefs";
    private static final float STRIDE_LENGTH = 0.73f;
    private static final String TAG = "Pedometer";
    private static final int WIN_SIZE = 100;
    private int avgPos = 0;
    private float[] avgWindow;
    private final Context context;
    private Set<DataSourceChangeListener> dataSourceObservers;
    private boolean foundNonStep = true;
    private boolean foundValley = false;
    private int intervalPos = 0;
    private float lastValley = 0.0f;
    private float[] lastValues = new float[100];
    private int numStepsRaw = 0;
    private int numStepsWithFilter = 0;
    private boolean pedometerPaused = true;
    private long prevStopClockTime = 0L;
    private final SensorManager sensorManager;
    private boolean startPeaking = false;
    private long startTime = 0L;
    private long[] stepInterval = new long[2];
    private long stepTimestamp = 0L;
    private int stopDetectionTimeout = 2000;
    private float strideLength = 0.73f;
    private float totalDistance = 0.0f;
    private int winPos = 0;

    public Pedometer(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.avgWindow = new float[10];
        this.dataSourceObservers = new HashSet();
        componentContainer = componentContainer.$context();
        this.context = componentContainer;
        this.winPos = 0;
        this.startPeaking = false;
        this.numStepsWithFilter = 0;
        this.numStepsRaw = 0;
        this.foundValley = true;
        this.lastValley = 0.0f;
        this.sensorManager = (SensorManager)componentContainer.getSystemService("sensor");
        componentContainer = componentContainer.getSharedPreferences(PREFS_NAME, 0);
        this.strideLength = componentContainer.getFloat("Pedometer.stridelength", 0.73f);
        this.totalDistance = componentContainer.getFloat("Pedometer.distance", 0.0f);
        this.numStepsRaw = componentContainer.getInt("Pedometer.prevStepCount", 0);
        this.prevStopClockTime = componentContainer.getLong("Pedometer.clockTime", 0L);
        this.numStepsWithFilter = this.numStepsRaw;
        this.startTime = System.currentTimeMillis();
        Log.d((String)TAG, (String)"Pedometer Created");
    }

    private boolean areStepsEquallySpaced() {
        int n;
        float f = 0.0f;
        int n2 = 0;
        for (long l : this.stepInterval) {
            float f2 = f;
            n = n2;
            if (l > 0L) {
                n = n2 + 1;
                f2 = f + (float)l;
            }
            f = f2;
            n2 = n;
        }
        f /= (float)n2;
        long[] lArray = this.stepInterval;
        n = lArray.length;
        for (int i = 0; i < n; ++i) {
            if (!(Math.abs((float)((float)lArray[i] - f)) > 250.0f)) continue;
            return false;
        }
        return true;
    }

    private boolean isPeak() {
        int n = (this.winPos + 50) % 100;
        for (int i = 0; i < 100; ++i) {
            float[] fArray;
            if (i == n || !((fArray = this.lastValues)[i] > fArray[n])) continue;
            return false;
        }
        return true;
    }

    private boolean isValley() {
        int n = (this.winPos + 50) % 100;
        for (int i = 0; i < 100; ++i) {
            float[] fArray;
            if (i == n || !((fArray = this.lastValues)[i] < fArray[n])) continue;
            return false;
        }
        return true;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property has been deprecated.")
    @Deprecated
    public void CalibrateStrideLength(boolean bl) {
    }

    @SimpleProperty(description="This property has been deprecated.")
    @Deprecated
    public boolean CalibrateStrideLength() {
        return false;
    }

    @SimpleEvent(description="This event has been deprecated.")
    @Deprecated
    public void CalibrationFailed() {
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The approximate distance traveled in meters.")
    public float Distance() {
        return this.totalDistance;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Time elapsed in milliseconds since the pedometer was started.")
    public long ElapsedTime() {
        if (this.pedometerPaused) {
            return this.prevStopClockTime;
        }
        return this.prevStopClockTime + (System.currentTimeMillis() - this.startTime);
    }

    @SimpleEvent(description="This event has been deprecated.")
    @Deprecated
    public void GPSAvailable() {
    }

    @SimpleEvent(description="This event has been deprecated.")
    @Deprecated
    public void GPSLost() {
    }

    @SimpleProperty(description="This property has been deprecated.")
    @Deprecated
    public boolean Moving() {
        return false;
    }

    @SimpleFunction(description="Pause counting of steps and distance.")
    @Deprecated
    public void Pause() {
        this.Stop();
    }

    @SimpleFunction(description="Resets the step counter, distance measure and time running.")
    public void Reset() {
        this.numStepsWithFilter = 0;
        this.numStepsRaw = 0;
        this.totalDistance = 0.0f;
        this.prevStopClockTime = 0L;
        this.startTime = System.currentTimeMillis();
    }

    @SimpleFunction(description="Resumes counting, synonym of Start.")
    @Deprecated
    public void Resume() {
        this.Start();
    }

    @SimpleFunction(description="Saves the pedometer state to the phone. Permits permits accumulation of steps and distance between invocations of an App that uses the pedometer. Different Apps will have their own saved state.")
    public void Save() {
        SharedPreferences.Editor editor = this.context.getSharedPreferences(PREFS_NAME, 0).edit();
        editor.putFloat("Pedometer.stridelength", this.strideLength);
        editor.putFloat("Pedometer.distance", this.totalDistance);
        editor.putInt("Pedometer.prevStepCount", this.numStepsRaw);
        if (this.pedometerPaused) {
            editor.putLong("Pedometer.clockTime", this.prevStopClockTime);
        } else {
            editor.putLong("Pedometer.clockTime", this.prevStopClockTime + (System.currentTimeMillis() - this.startTime));
        }
        editor.putLong("Pedometer.closeTime", System.currentTimeMillis());
        editor.commit();
        Log.d((String)TAG, (String)"Pedometer state saved.");
    }

    @SimpleEvent(description="This event is run when a raw step is detected.")
    public void SimpleStep(int n, float f) {
        this.notifyDataObservers("SimpleSteps", (Object)n);
        this.notifyDataObservers("Distance", (Object)Float.valueOf((float)f));
        EventDispatcher.dispatchEvent((Component)this, "SimpleStep", n, Float.valueOf((float)f));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The number of simple steps taken since the pedometer has started.")
    public int SimpleSteps() {
        return this.numStepsRaw;
    }

    @SimpleFunction(description="Start counting steps")
    public void Start() {
        if (this.pedometerPaused) {
            this.pedometerPaused = false;
            SensorManager sensorManager = this.sensorManager;
            sensorManager.registerListener((SensorEventListener)this, (Sensor)sensorManager.getSensorList(1).get(0), 0);
            this.startTime = System.currentTimeMillis();
        }
    }

    @SimpleEvent(description="This event has been deprecated.")
    @Deprecated
    public void StartedMoving() {
    }

    @SimpleFunction(description="Stop counting steps")
    public void Stop() {
        if (!this.pedometerPaused) {
            this.pedometerPaused = true;
            this.sensorManager.unregisterListener((SensorEventListener)this);
            Log.d((String)TAG, (String)"Unregistered listener on pause");
            this.prevStopClockTime += System.currentTimeMillis() - this.startTime;
        }
    }

    @SimpleProperty
    public int StopDetectionTimeout() {
        return this.stopDetectionTimeout;
    }

    @DesignerProperty(defaultValue="2000", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The duration in milliseconds of idleness (no steps detected) after which to go into a \"stopped\" state")
    public void StopDetectionTimeout(int n) {
        this.stopDetectionTimeout = n;
    }

    @SimpleEvent(description="This event has been deprecated.")
    @Deprecated
    public void StoppedMoving() {
    }

    @SimpleProperty
    public float StrideLength() {
        return this.strideLength;
    }

    @DesignerProperty(defaultValue="0.73", editorType="non_negative_float")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Set the average stride length in meters.")
    public void StrideLength(float f) {
        this.strideLength = f;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="This property has been deprecated.")
    @Deprecated
    public void UseGPS(boolean bl) {
    }

    @SimpleEvent(description="This event is run when a walking step is detected. A walking step is a step that appears to be involved in forward motion.")
    public void WalkStep(int n, float f) {
        this.notifyDataObservers("WalkSteps", (Object)n);
        this.notifyDataObservers("Distance", (Object)Float.valueOf((float)f));
        EventDispatcher.dispatchEvent((Component)this, "WalkStep", n, Float.valueOf((float)f));
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="the number of walk steps taken since the pedometer has started.")
    public int WalkSteps() {
        return this.numStepsWithFilter;
    }

    public void addDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.add((Object)dataSourceChangeListener);
    }

    /*
     * Enabled aggressive block sorting
     */
    public Float getDataValue(String string) {
        int n;
        block10: {
            switch (string.hashCode()) {
                case 353103893: {
                    if (!string.equals((Object)"Distance")) break;
                    n = 2;
                    break block10;
                }
                case 237934709: {
                    if (!string.equals((Object)"SimpleSteps")) break;
                    n = 0;
                    break block10;
                }
                case -871160130: {
                    if (!string.equals((Object)"WalkSteps")) break;
                    n = 1;
                    break block10;
                }
            }
            n = -1;
        }
        switch (n) {
            default: {
                return Float.valueOf((float)0.0f);
            }
            case 2: {
                return Float.valueOf((float)this.totalDistance);
            }
            case 1: {
                return Float.valueOf((float)this.numStepsWithFilter);
            }
            case 0: 
        }
        return Float.valueOf((float)this.numStepsRaw);
    }

    public void notifyDataObservers(String string, Object object2) {
        Iterator iterator = this.dataSourceObservers.iterator();
        while (iterator.hasNext()) {
            ((DataSourceChangeListener)iterator.next()).onReceiveValue((RealTimeDataSource<?, ?>)this, string, object2);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
        Log.d((String)TAG, (String)"Accelerometer accuracy changed.");
    }

    @Override
    public void onDelete() {
        this.sensorManager.unregisterListener((SensorEventListener)this);
    }

    /*
     * WARNING - void declaration
     */
    public void onSensorChanged(SensorEvent object2) {
        int n;
        int n2;
        long l;
        void var0_6;
        if (((SensorEvent)object2).sensor.getType() != 1) {
            return;
        }
        float[] fArray = ((SensorEvent)object2).values;
        float f = 0.0f;
        for (float f2 : fArray) {
            f += f2 * f2;
        }
        int n3 = (var0_6.winPos + 50) % 100;
        if (var0_6.startPeaking && super.isPeak() && var0_6.foundValley && var0_6.lastValues[n3] - var0_6.lastValley > 40.0f) {
            l = System.currentTimeMillis();
            long[] lArray = var0_6.stepInterval;
            n2 = var0_6.intervalPos;
            lArray[n2] = l - var0_6.stepTimestamp;
            var0_6.intervalPos = (n2 + 1) % 2;
            var0_6.stepTimestamp = l;
            if (super.areStepsEquallySpaced()) {
                if (var0_6.foundNonStep) {
                    var0_6.numStepsWithFilter += 2;
                    var0_6.totalDistance += var0_6.strideLength * 2.0f;
                    var0_6.foundNonStep = false;
                }
                var0_6.numStepsWithFilter = n2 = var0_6.numStepsWithFilter + 1;
                var0_6.WalkStep(n2, var0_6.totalDistance);
                var0_6.totalDistance += var0_6.strideLength;
            } else {
                var0_6.foundNonStep = true;
            }
            var0_6.numStepsRaw = n2 = var0_6.numStepsRaw + 1;
            var0_6.SimpleStep(n2, var0_6.totalDistance);
            var0_6.foundValley = false;
        }
        if (var0_6.startPeaking && super.isValley()) {
            var0_6.foundValley = true;
            var0_6.lastValley = var0_6.lastValues[n3];
        }
        float[] fArray2 = var0_6.avgWindow;
        n3 = var0_6.avgPos;
        fArray2[n3] = f;
        var0_6.avgPos = (n3 + 1) % fArray2.length;
        var0_6.lastValues[var0_6.winPos] = 0.0f;
        n2 = fArray2.length;
        for (n3 = 0; n3 < n2; ++n3) {
            f = fArray2[n3];
            float[] fArray3 = var0_6.lastValues;
            n = var0_6.winPos;
            fArray3[n] = fArray3[n] + f;
        }
        float[] fArray4 = var0_6.lastValues;
        n = var0_6.winPos;
        fArray4[n] = f = fArray4[n] / (float)var0_6.avgWindow.length;
        boolean bl = var0_6.startPeaking;
        if (!bl && n <= 1) {
            if (!bl && n == 1) {
                fArray4[1] = (fArray4[1] + fArray4[0]) / 2.0f;
            }
        } else {
            n3 = n2 = var0_6.winPos - 1;
            if (n2 < 0) {
                n3 = n2 + 100;
            }
            fArray4[n] = f += fArray4[n3] * 2.0f;
            n3 = n2 = n3 - 1;
            if (n2 < 0) {
                n3 = n2 + 100;
            }
            fArray4[n] = f += fArray4[n3];
            fArray4[n] = f / 4.0f;
        }
        l = System.currentTimeMillis();
        if (l - var0_6.stepTimestamp > (long)var0_6.stopDetectionTimeout) {
            var0_6.stepTimestamp = l;
        }
        if ((n3 = var0_6.winPos) == 99 && !var0_6.startPeaking) {
            var0_6.startPeaking = true;
        }
        var0_6.winPos = (n3 + 1) % 100;
    }

    public void removeDataObserver(DataSourceChangeListener dataSourceChangeListener) {
        this.dataSourceObservers.remove((Object)dataSourceChangeListener);
    }
}

