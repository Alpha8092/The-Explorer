/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.util.AsyncCallbackPair
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.util;

import com.google.appinventor.components.runtime.util.AsyncCallbackPair;

public abstract class AsyncCallbackFacade<S, T>
implements AsyncCallbackPair<S> {
    protected final AsyncCallbackPair<T> callback;

    public AsyncCallbackFacade(AsyncCallbackPair<T> asyncCallbackPair) {
        this.callback = asyncCallbackPair;
    }

    public void onFailure(String string) {
        this.callback.onFailure(string);
    }
}

