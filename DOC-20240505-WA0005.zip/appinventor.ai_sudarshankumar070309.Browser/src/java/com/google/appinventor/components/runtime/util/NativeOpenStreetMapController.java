/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Picture
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.PictureDrawable
 *  android.location.Location
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewTreeObserver$OnPreDrawListener
 *  android.view.animation.Animation
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  androidx.core.view.ViewCompat
 *  com.caverock.androidsvg.SVG
 *  com.caverock.androidsvg.SVG$Colour
 *  com.caverock.androidsvg.SVG$Length
 *  com.caverock.androidsvg.SVG$Style
 *  com.caverock.androidsvg.SVG$Svg
 *  com.caverock.androidsvg.SVG$SvgConditionalElement
 *  com.caverock.androidsvg.SVG$SvgObject
 *  com.google.appinventor.components.common.MapType
 *  com.google.appinventor.components.common.ScaleUnits
 *  com.google.appinventor.components.runtime.util.AsyncCallbackPair
 *  com.google.appinventor.components.runtime.util.MapFactory$HasFill
 *  com.google.appinventor.components.runtime.util.MapFactory$HasStroke
 *  com.google.appinventor.components.runtime.util.MapFactory$MapController
 *  com.google.appinventor.components.runtime.util.MapFactory$MapEventListener
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureCollection
 *  com.google.appinventor.components.runtime.util.MapFactory$MapScaleUnits
 *  com.google.appinventor.components.runtime.util.MapFactory$MapType
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$1
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$14
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$2
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$3$1
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$3$2
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$4
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$5
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$6
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$7
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$8
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$9
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$AppInventorLocationSensorAdapter-IA
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$CustomMapView
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$MultiPolygon
 *  com.google.appinventor.components.runtime.util.NativeOpenStreetMapController$TouchOverlay
 *  com.google.appinventor.components.runtime.util.PaintUtil
 *  com.google.appinventor.components.runtime.view.ZoomControlView
 *  java.io.File
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.config.Configuration
 *  org.osmdroid.events.MapListener
 *  org.osmdroid.events.ScrollEvent
 *  org.osmdroid.events.ZoomEvent
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.tilesource.TileSourceFactory
 *  org.osmdroid.util.BoundingBox
 *  org.osmdroid.util.GeoPoint
 *  org.osmdroid.views.MapView
 *  org.osmdroid.views.MapView$OnTapListener
 *  org.osmdroid.views.overlay.CopyrightOverlay
 *  org.osmdroid.views.overlay.Marker
 *  org.osmdroid.views.overlay.Marker$OnMarkerClickListener
 *  org.osmdroid.views.overlay.Marker$OnMarkerDragListener
 *  org.osmdroid.views.overlay.OverlayWithIW
 *  org.osmdroid.views.overlay.OverlayWithIWVisitor
 *  org.osmdroid.views.overlay.Polygon
 *  org.osmdroid.views.overlay.Polygon$OnClickListener
 *  org.osmdroid.views.overlay.Polygon$OnDragListener
 *  org.osmdroid.views.overlay.Polyline
 *  org.osmdroid.views.overlay.Polyline$OnClickListener
 *  org.osmdroid.views.overlay.Polyline$OnDragListener
 *  org.osmdroid.views.overlay.ScaleBarOverlay
 *  org.osmdroid.views.overlay.ScaleBarOverlay$UnitsOfMeasure
 *  org.osmdroid.views.overlay.compass.CompassOverlay
 *  org.osmdroid.views.overlay.compass.IOrientationProvider
 *  org.osmdroid.views.overlay.compass.InternalCompassOrientationProvider
 *  org.osmdroid.views.overlay.gestures.RotationGestureOverlay
 *  org.osmdroid.views.overlay.infowindow.InfoWindow
 *  org.osmdroid.views.overlay.infowindow.OverlayInfoWindow
 *  org.osmdroid.views.overlay.mylocation.IMyLocationConsumer
 *  org.osmdroid.views.overlay.mylocation.IMyLocationProvider
 *  org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
 */
package com.google.appinventor.components.runtime.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Picture;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PictureDrawable;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.widget.RelativeLayout;
import androidx.core.view.ViewCompat;
import com.caverock.androidsvg.SVG;
import com.google.appinventor.components.common.MapType;
import com.google.appinventor.components.common.ScaleUnits;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.LocationSensor;
import com.google.appinventor.components.runtime.util.AsyncCallbackFacade;
import com.google.appinventor.components.runtime.util.AsyncCallbackPair;
import com.google.appinventor.components.runtime.util.MapFactory;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.NativeOpenStreetMapController;
import com.google.appinventor.components.runtime.util.PaintUtil;
import com.google.appinventor.components.runtime.view.ZoomControlView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapListener;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.CopyrightOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.OverlayWithIW;
import org.osmdroid.views.overlay.OverlayWithIWVisitor;
import org.osmdroid.views.overlay.Polygon;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.ScaleBarOverlay;
import org.osmdroid.views.overlay.compass.CompassOverlay;
import org.osmdroid.views.overlay.compass.IOrientationProvider;
import org.osmdroid.views.overlay.compass.InternalCompassOrientationProvider;
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay;
import org.osmdroid.views.overlay.infowindow.InfoWindow;
import org.osmdroid.views.overlay.infowindow.OverlayInfoWindow;
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer;
import org.osmdroid.views.overlay.mylocation.IMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Exception performing whole class analysis ignored.
 */
class NativeOpenStreetMapController
implements MapFactory.MapController,
MapListener {
    private static final float[] ANCHOR_HORIZONTAL;
    private static final float[] ANCHOR_VERTICAL;
    private static final long SPECIFIED_FILL = 1L;
    private static final long SPECIFIED_FILL_OPACITY = 4L;
    private static final long SPECIFIED_STROKE = 8L;
    private static final long SPECIFIED_STROKE_OPACITY = 16L;
    private static final long SPECIFIED_STROKE_WIDTH = 32L;
    private static final String TAG;
    private boolean caches;
    private CompassOverlay compass = null;
    private RelativeLayout containerView;
    private OverlayInfoWindow defaultInfoWindow = null;
    private SVG defaultMarkerSVG = null;
    private Set<MapFactory.MapEventListener> eventListeners = new HashSet();
    private Map<MapFactory.MapFeature, OverlayWithIW> featureOverlays = new HashMap();
    private final Form form;
    private Set<MapFactory.MapFeatureCollection> hiddenFeatureCollections;
    private Set<MapFactory.MapFeature> hiddenFeatures;
    private float lastAzimuth = Float.NaN;
    private final AppInventorLocationSensorAdapter locationProvider;
    private boolean ready = false;
    private RotationGestureOverlay rotation = null;
    private ScaleBarOverlay scaleBar;
    private MapType tileType;
    private TouchOverlay touch = null;
    private final MyLocationNewOverlay userLocation;
    private MapView view;
    private boolean zoomControlEnabled;
    private ZoomControlView zoomControls = null;
    private boolean zoomEnabled;

    static /* bridge */ /* synthetic */ CompassOverlay -$$Nest$fgetcompass(NativeOpenStreetMapController nativeOpenStreetMapController) {
        return nativeOpenStreetMapController.compass;
    }

    static /* bridge */ /* synthetic */ Set -$$Nest$fgeteventListeners(NativeOpenStreetMapController nativeOpenStreetMapController) {
        return nativeOpenStreetMapController.eventListeners;
    }

    static /* bridge */ /* synthetic */ Form -$$Nest$fgetform(NativeOpenStreetMapController nativeOpenStreetMapController) {
        return nativeOpenStreetMapController.form;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetready(NativeOpenStreetMapController nativeOpenStreetMapController) {
        return nativeOpenStreetMapController.ready;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputready(NativeOpenStreetMapController nativeOpenStreetMapController, boolean bl) {
        nativeOpenStreetMapController.ready = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mgetMarkerDrawable(NativeOpenStreetMapController nativeOpenStreetMapController, MapFactory.MapMarker mapMarker, AsyncCallbackPair asyncCallbackPair) {
        nativeOpenStreetMapController.getMarkerDrawable(mapMarker, (AsyncCallbackPair<Drawable>)asyncCallbackPair);
    }

    static {
        TAG = NativeOpenStreetMapController.class.getSimpleName();
        ANCHOR_HORIZONTAL = new float[]{Float.NaN, 0.0f, 1.0f, 0.5f};
        ANCHOR_VERTICAL = new float[]{Float.NaN, 0.0f, 0.5f, 1.0f};
    }

    NativeOpenStreetMapController(Form form) {
        this.hiddenFeatureCollections = new HashSet();
        this.hiddenFeatures = new HashSet();
        OpenStreetMapTileProviderConstants.setUserAgentValue((String)form.getApplication().getPackageName());
        Object object2 = new File(form.getCacheDir(), "osmdroid");
        if (object2.exists() || object2.mkdirs()) {
            Configuration.getInstance().setOsmdroidBasePath(object2);
            object2 = new File(object2, "tiles");
            if (object2.exists() || object2.mkdirs()) {
                Configuration.getInstance().setOsmdroidTileCache(object2);
                this.caches = true;
            }
        }
        this.form = form;
        this.touch = new /* Unavailable Anonymous Inner Class!! */;
        this.view = this.createCustomMapView(form.getApplicationContext());
        object2 = new AppInventorLocationSensorAdapter(null);
        this.locationProvider = object2;
        this.defaultInfoWindow = new OverlayInfoWindow(this.view);
        this.view.setTilesScaledToDpi(true);
        this.view.setMapListener((MapListener)this);
        this.view.getOverlayManager().add((Object)new CopyrightOverlay((Context)form));
        this.view.getOverlayManager().add((Object)this.touch);
        this.view.addOnTapListener((MapView.OnTapListener)new 1((NativeOpenStreetMapController)this));
        this.zoomControls = new ZoomControlView(this.view);
        this.userLocation = new MyLocationNewOverlay((IMyLocationProvider)object2, this.view);
        object2 = new ScaleBarOverlay(this.view);
        this.scaleBar = object2;
        object2.setAlignBottom(true);
        this.scaleBar.setAlignRight(true);
        this.scaleBar.disableScaleBar();
        this.view.getOverlayManager().add((Object)this.scaleBar);
        form = new RelativeLayout((Context)form);
        this.containerView = form;
        form.setClipChildren(true);
        this.containerView.addView((View)this.view, (ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
        this.containerView.addView((View)this.zoomControls);
        this.zoomControls.setVisibility(8);
    }

    private void configurePolygon(MapFactory.MapFeature mapFeature, Polygon polygon) {
        this.featureOverlays.put((Object)mapFeature, (Object)polygon);
        polygon.setOnClickListener((Polygon.OnClickListener)new 6((NativeOpenStreetMapController)this, mapFeature));
        polygon.setOnDragListener((Polygon.OnDragListener)new 7((NativeOpenStreetMapController)this, mapFeature));
        if (mapFeature.Visible()) {
            this.showOverlay((OverlayWithIW)polygon);
        } else {
            this.hideOverlay((OverlayWithIW)polygon);
        }
    }

    private Polygon createNativeCircle(MapFactory.MapCircle mapCircle) {
        Polygon polygon = new Polygon();
        super.createPolygon(polygon, mapCircle);
        polygon.setPoints((List)Polygon.pointsAsCircle((GeoPoint)new GeoPoint(mapCircle.Latitude(), mapCircle.Longitude()), (double)mapCircle.Radius()));
        return polygon;
    }

    private void createNativeMarker(MapFactory.MapMarker mapMarker, AsyncCallbackPair<Marker> asyncCallbackPair) {
        Marker marker = new Marker(this.view);
        this.featureOverlays.put((Object)mapMarker, (Object)marker);
        marker.setDraggable(mapMarker.Draggable());
        marker.setTitle(mapMarker.Title());
        marker.setSnippet(mapMarker.Description());
        marker.setPosition(new GeoPoint(mapMarker.Latitude(), mapMarker.Longitude()));
        marker.setAnchor(0.5f, 1.0f);
        super.getMarkerDrawable(mapMarker, (AsyncCallbackPair<Drawable>)new AsyncCallbackFacade<Drawable, Marker>((NativeOpenStreetMapController)this, asyncCallbackPair, marker){
            final NativeOpenStreetMapController this$0;
            final Marker val$osmMarker;
            {
                this.this$0 = nativeOpenStreetMapController;
                this.val$osmMarker = marker;
                super(asyncCallbackPair);
            }

            @Override
            public void onFailure(String string) {
                this.callback.onFailure(string);
            }

            public void onSuccess(Drawable drawable) {
                this.val$osmMarker.setIcon(drawable);
                this.callback.onSuccess((Object)this.val$osmMarker);
            }
        });
    }

    private MultiPolygon createNativePolygon(MapFactory.MapPolygon mapPolygon) {
        MultiPolygon multiPolygon = new /* Unavailable Anonymous Inner Class!! */;
        super.createPolygon((Polygon)multiPolygon, mapPolygon);
        multiPolygon.setMultiPoints(mapPolygon.getPoints());
        multiPolygon.setMultiHoles(mapPolygon.getHolePoints());
        return multiPolygon;
    }

    private Polyline createNativePolyline(MapFactory.MapLineString mapLineString) {
        Polyline polyline = new Polyline();
        polyline.setDraggable(mapLineString.Draggable());
        polyline.setTitle(mapLineString.Title());
        polyline.setSnippet(mapLineString.Description());
        polyline.setPoints(mapLineString.getPoints());
        polyline.setColor(mapLineString.StrokeColor());
        polyline.setWidth((float)mapLineString.StrokeWidth());
        polyline.setInfoWindow((InfoWindow)this.defaultInfoWindow);
        return polyline;
    }

    private Polygon createNativeRectangle(MapFactory.MapRectangle mapRectangle) {
        BoundingBox boundingBox = new BoundingBox(mapRectangle.NorthLatitude(), mapRectangle.EastLongitude(), mapRectangle.SouthLatitude(), mapRectangle.WestLongitude());
        Polygon polygon = new Polygon();
        super.createPolygon(polygon, mapRectangle);
        polygon.setPoints((List)new ArrayList((Collection)Polygon.pointsAsRect((BoundingBox)boundingBox)));
        return polygon;
    }

    private void createPolygon(Polygon polygon, MapFactory.MapFeature mapFeature) {
        polygon.setDraggable(mapFeature.Draggable());
        polygon.setTitle(mapFeature.Title());
        polygon.setSnippet(mapFeature.Description());
        polygon.setStrokeColor(((MapFactory.HasStroke)mapFeature).StrokeColor());
        polygon.setStrokeWidth((float)((MapFactory.HasStroke)mapFeature).StrokeWidth());
        polygon.setFillColor(((MapFactory.HasFill)mapFeature).FillColor());
        polygon.setInfoWindow((InfoWindow)this.defaultInfoWindow);
    }

    private static float getBestGuessHeight(SVG.Svg svg) {
        if (svg.height != null) {
            return svg.height.floatValue();
        }
        if (svg.viewBox != null) {
            return svg.viewBox.height;
        }
        return 50.0f;
    }

    private static float getBestGuessWidth(SVG.Svg svg) {
        if (svg.width != null) {
            return svg.width.floatValue();
        }
        if (svg.viewBox != null) {
            return svg.viewBox.width;
        }
        return 30.0f;
    }

    private Drawable getDefaultMarkerDrawable(MapFactory.MapMarker mapMarker) {
        return super.rasterizeSVG(mapMarker, this.defaultMarkerSVG);
    }

    private void getMarkerDrawable(MapFactory.MapMarker mapMarker, AsyncCallbackPair<Drawable> asyncCallbackPair) {
        String string = mapMarker.ImageAsset();
        if (string != null && string.length() != 0 && !string.endsWith(".svg")) {
            super.getMarkerDrawableRaster(mapMarker, asyncCallbackPair);
        } else {
            super.getMarkerDrawableVector(mapMarker, asyncCallbackPair);
        }
    }

    private void getMarkerDrawableRaster(MapFactory.MapMarker mapMarker, AsyncCallbackPair<Drawable> asyncCallbackPair) {
        MediaUtil.getBitmapDrawableAsync((Form)this.form, (String)mapMarker.ImageAsset(), (int)mapMarker.Width(), (int)mapMarker.Height(), (AsyncCallbackPair)new AsyncCallbackPair<BitmapDrawable>((NativeOpenStreetMapController)this, asyncCallbackPair, mapMarker){
            final NativeOpenStreetMapController this$0;
            final MapFactory.MapMarker val$aiMarker;
            final AsyncCallbackPair val$callback;
            {
                this.this$0 = nativeOpenStreetMapController;
                this.val$callback = asyncCallbackPair;
                this.val$aiMarker = mapMarker;
            }

            public void onFailure(String string) {
                this.val$callback.onSuccess((Object)this.this$0.getDefaultMarkerDrawable(this.val$aiMarker));
            }

            public void onSuccess(BitmapDrawable bitmapDrawable) {
                bitmapDrawable.setAlpha(Math.round((float)(this.val$aiMarker.FillOpacity() * 255.0f)));
                this.val$callback.onSuccess((Object)bitmapDrawable);
            }
        });
    }

    /*
     * Exception decompiling
     */
    private void getMarkerDrawableVector(MapFactory.MapMarker var1, AsyncCallbackPair<Drawable> var2_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Back jump on a try block [egrp 4[TRYBLOCK] [10 : 262->267)] java.lang.Throwable
         *     at kb.g.H1(SourceFile:239)
         *     at ib.f.d(SourceFile:57)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1133)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:607)
         *     at java.lang.Thread.run(Thread.java:760)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private Drawable rasterizeSVG(MapFactory.MapMarker mapMarker, SVG sVG) {
        SVG.Svg svg = sVG.getRootElement();
        float f = this.view.getContext().getResources().getDisplayMetrics().density;
        float f2 = mapMarker.Height() <= 0 ? NativeOpenStreetMapController.getBestGuessHeight(svg) : (float)mapMarker.Height();
        float f3 = mapMarker.Width() <= 0 ? NativeOpenStreetMapController.getBestGuessWidth(svg) : (float)mapMarker.Width();
        float f4 = f2 / NativeOpenStreetMapController.getBestGuessHeight(svg);
        float f5 = f3 / NativeOpenStreetMapController.getBestGuessWidth(svg);
        float f6 = (float)Math.sqrt((double)(f4 * f4 + f5 * f5));
        Paint paint = new Paint();
        Paint paint2 = new Paint();
        PaintUtil.changePaint((Paint)paint, (int)mapMarker.FillColor());
        PaintUtil.changePaint((Paint)paint2, (int)mapMarker.StrokeColor());
        SVG.Length length = new SVG.Length((float)mapMarker.StrokeWidth() / f6);
        for (SVG.SvgObject svgObject : svg.getChildren()) {
            SVG.Style style;
            if (!(svgObject instanceof SVG.SvgConditionalElement)) continue;
            svgObject = (SVG.SvgConditionalElement)svgObject;
            svgObject.baseStyle.fill = new SVG.Colour(paint.getColor());
            svgObject.baseStyle.fillOpacity = Float.valueOf((float)((float)paint.getAlpha() / 255.0f));
            svgObject.baseStyle.stroke = new SVG.Colour(paint2.getColor());
            svgObject.baseStyle.strokeOpacity = Float.valueOf((float)((float)paint2.getAlpha() / 255.0f));
            svgObject.baseStyle.strokeWidth = length;
            svgObject.baseStyle.specifiedFlags = 61L;
            if (svgObject.style == null) continue;
            if ((svgObject.style.specifiedFlags & 1L) == 0L) {
                svgObject.style.fill = new SVG.Colour(paint.getColor());
                style = svgObject.style;
                style.specifiedFlags |= 1L;
            }
            if ((svgObject.style.specifiedFlags & 4L) == 0L) {
                svgObject.style.fillOpacity = Float.valueOf((float)((float)paint.getAlpha() / 255.0f));
                style = svgObject.style;
                style.specifiedFlags |= 4L;
            }
            if ((svgObject.style.specifiedFlags & 8L) == 0L) {
                svgObject.style.stroke = new SVG.Colour(paint2.getColor());
                style = svgObject.style;
                style.specifiedFlags |= 8L;
            }
            if ((svgObject.style.specifiedFlags & 0x10L) == 0L) {
                svgObject.style.strokeOpacity = Float.valueOf((float)((float)paint2.getAlpha() / 255.0f));
                style = svgObject.style;
                style.specifiedFlags |= 0x10L;
            }
            if ((svgObject.style.specifiedFlags & 0x20L) != 0L) continue;
            svgObject.style.strokeWidth = length;
            svgObject = svgObject.style;
            svgObject.specifiedFlags |= 0x20L;
        }
        sVG = sVG.renderToPicture();
        svg = new Picture();
        mapMarker = svg.beginRecording((int)(((float)mapMarker.StrokeWidth() * 2.0f + f3) * f), (int)(((float)mapMarker.StrokeWidth() * 2.0f + f2) * f));
        mapMarker.scale(f * f5, f * f4);
        mapMarker.translate(length.floatValue(), length.floatValue());
        sVG.draw((Canvas)mapMarker);
        svg.endRecording();
        return new PictureDrawable((Picture)svg);
    }

    public void addEventListener(MapFactory.MapEventListener mapEventListener) {
        this.eventListeners.add((Object)mapEventListener);
        if ((this.ready || ViewCompat.isAttachedToWindow((View)this.view)) && this.form.canDispatchEvent(null, "MapReady")) {
            this.ready = true;
            mapEventListener.onReady((MapFactory.MapController)this);
        }
    }

    public void addFeature(MapFactory.MapCircle mapCircle) {
        super.configurePolygon(mapCircle, super.createNativeCircle(mapCircle));
    }

    public void addFeature(MapFactory.MapLineString mapLineString) {
        Polyline polyline = super.createNativePolyline(mapLineString);
        this.featureOverlays.put((Object)mapLineString, (Object)polyline);
        polyline.setOnClickListener((Polyline.OnClickListener)new 4((NativeOpenStreetMapController)this, mapLineString));
        polyline.setOnDragListener((Polyline.OnDragListener)new 5((NativeOpenStreetMapController)this, mapLineString));
        if (mapLineString.Visible()) {
            this.showOverlay((OverlayWithIW)polyline);
        } else {
            this.hideOverlay((OverlayWithIW)polyline);
        }
    }

    public void addFeature(MapFactory.MapMarker mapMarker) {
        super.createNativeMarker(mapMarker, new AsyncCallbackPair<Marker>((NativeOpenStreetMapController)this, mapMarker){
            final NativeOpenStreetMapController this$0;
            final MapFactory.MapMarker val$aiMarker;
            {
                this.this$0 = nativeOpenStreetMapController;
                this.val$aiMarker = mapMarker;
            }

            public void onFailure(String string) {
                Log.e((String)TAG, (String)("Unable to create marker: " + string));
            }

            public void onSuccess(Marker marker) {
                marker.setOnMarkerClickListener((Marker.OnMarkerClickListener)new 1(this));
                marker.setOnMarkerDragListener((Marker.OnMarkerDragListener)new 2(this));
                if (this.val$aiMarker.Visible()) {
                    this.this$0.showOverlay((OverlayWithIW)marker);
                } else {
                    this.this$0.hideOverlay((OverlayWithIW)marker);
                }
            }
        });
    }

    public void addFeature(MapFactory.MapPolygon mapPolygon) {
        super.configurePolygon(mapPolygon, (Polygon)super.createNativePolygon(mapPolygon));
    }

    public void addFeature(MapFactory.MapRectangle mapRectangle) {
        super.configurePolygon(mapRectangle, super.createNativeRectangle(mapRectangle));
    }

    CustomMapView createCustomMapView(Context context) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public BoundingBox getBoundingBox() {
        return this.view.getBoundingBox();
    }

    public double getLatitude() {
        return this.view.getMapCenter().getLatitude();
    }

    public LocationSensor.LocationSensorListener getLocationListener() {
        return this.locationProvider;
    }

    public double getLongitude() {
        return this.view.getMapCenter().getLongitude();
    }

    public MapFactory.MapType getMapType() {
        return MapFactory.MapType.values()[this.tileType.toUnderlyingValue()];
    }

    public MapType getMapTypeAbstract() {
        return this.tileType;
    }

    public int getOverlayCount() {
        System.err.println((Object)this.view.getOverlays());
        return this.view.getOverlays().size();
    }

    public float getRotation() {
        return this.view.getMapOrientation();
    }

    public MapFactory.MapScaleUnits getScaleUnits() {
        switch (14.$SwitchMap$org$osmdroid$views$overlay$ScaleBarOverlay$UnitsOfMeasure[this.scaleBar.getUnitsOfMeasure().ordinal()]) {
            default: {
                throw new IllegalStateException("Somehow we have an unallowed unit system");
            }
            case 2: {
                return MapFactory.MapScaleUnits.METRIC;
            }
            case 1: 
        }
        return MapFactory.MapScaleUnits.IMPERIAL;
    }

    public ScaleUnits getScaleUnitsAbstract() {
        switch (14.$SwitchMap$org$osmdroid$views$overlay$ScaleBarOverlay$UnitsOfMeasure[this.scaleBar.getUnitsOfMeasure().ordinal()]) {
            default: {
                throw new IllegalStateException("Somehow we have an unallowed unit system");
            }
            case 2: {
                return ScaleUnits.Metric;
            }
            case 1: 
        }
        return ScaleUnits.Imperial;
    }

    public View getView() {
        return this.containerView;
    }

    public int getZoom() {
        return (int)this.view.getZoomLevel(true);
    }

    public void hideFeature(MapFactory.MapFeature mapFeature) {
        this.hideOverlay((OverlayWithIW)this.featureOverlays.get((Object)mapFeature));
    }

    public void hideInfobox(MapFactory.MapFeature mapFeature) {
        ((OverlayWithIW)this.featureOverlays.get((Object)mapFeature)).closeInfoWindow();
    }

    protected void hideOverlay(OverlayWithIW overlayWithIW) {
        this.view.getOverlayManager().remove((Object)overlayWithIW);
        this.view.invalidate();
    }

    public boolean isCompassEnabled() {
        CompassOverlay compassOverlay = this.compass;
        boolean bl = compassOverlay != null && compassOverlay.isCompassEnabled();
        return bl;
    }

    public boolean isFeatureCollectionVisible(MapFactory.MapFeatureCollection mapFeatureCollection) {
        return this.hiddenFeatureCollections.contains((Object)mapFeatureCollection) ^ true;
    }

    public boolean isFeatureVisible(MapFactory.MapFeature mapFeature) {
        boolean bl = (mapFeature = (OverlayWithIW)this.featureOverlays.get((Object)mapFeature)) != null && this.view.getOverlayManager().contains((Object)mapFeature);
        return bl;
    }

    public boolean isInfoboxVisible(MapFactory.MapFeature mapFeature) {
        boolean bl = (mapFeature = (OverlayWithIW)this.featureOverlays.get((Object)mapFeature)) != null && mapFeature.isInfoWindowOpen();
        return bl;
    }

    public boolean isPanEnabled() {
        return TouchOverlay.-$$Nest$fgetscrollEnabled(this.touch);
    }

    public boolean isRotationEnabled() {
        RotationGestureOverlay rotationGestureOverlay = this.rotation;
        boolean bl = rotationGestureOverlay != null && rotationGestureOverlay.isEnabled();
        return bl;
    }

    public boolean isScaleVisible() {
        return this.scaleBar.isEnabled();
    }

    public boolean isShowUserEnabled() {
        MyLocationNewOverlay myLocationNewOverlay = this.userLocation;
        boolean bl = myLocationNewOverlay != null && myLocationNewOverlay.isEnabled();
        return bl;
    }

    public boolean isZoomControlEnabled() {
        return this.zoomControlEnabled;
    }

    public boolean isZoomEnabled() {
        return this.zoomEnabled;
    }

    public boolean onScroll(ScrollEvent scrollEvent) {
        scrollEvent = this.eventListeners.iterator();
        while (scrollEvent.hasNext()) {
            ((MapFactory.MapEventListener)scrollEvent.next()).onBoundsChanged();
        }
        return true;
    }

    public boolean onZoom(ZoomEvent zoomEvent) {
        this.zoomControls.updateButtons();
        zoomEvent = this.eventListeners.iterator();
        while (zoomEvent.hasNext()) {
            ((MapFactory.MapEventListener)zoomEvent.next()).onZoom();
        }
        return true;
    }

    public void panTo(double d, double d2, int n, double d3) {
        Animation animation;
        this.view.getController().animateTo((IGeoPoint)new GeoPoint(d, d2));
        if (this.view.getController().zoomTo((double)n) && (animation = this.view.getAnimation()) != null) {
            animation.setDuration((long)(1000.0 * d3));
        }
    }

    public void removeFeature(MapFactory.MapFeature mapFeature) {
        this.view.getOverlayManager().remove(this.featureOverlays.get((Object)mapFeature));
        this.featureOverlays.remove((Object)mapFeature);
    }

    public void setBoundingBox(BoundingBox boundingBox) {
        this.view.getController().setCenter((IGeoPoint)boundingBox.getCenter());
        this.view.getController().zoomToSpan(boundingBox.getLatitudeSpan(), boundingBox.getLongitudeSpan());
    }

    public void setCenter(double d, double d2) {
        this.view.getController().setCenter((IGeoPoint)new GeoPoint(d, d2));
    }

    public void setCompassEnabled(boolean bl) {
        CompassOverlay compassOverlay;
        if (bl && this.compass == null) {
            this.compass = new CompassOverlay(this.view.getContext(), this.view);
            this.view.getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)new 2((NativeOpenStreetMapController)this));
            this.view.getOverlayManager().add((Object)this.compass);
        }
        if ((compassOverlay = this.compass) != null) {
            if (bl) {
                if (compassOverlay.getOrientationProvider() != null) {
                    this.compass.enableCompass();
                } else {
                    this.compass.enableCompass((IOrientationProvider)new InternalCompassOrientationProvider(this.view.getContext()));
                }
                this.compass.onOrientationChanged(this.lastAzimuth, null);
            } else {
                this.lastAzimuth = compassOverlay.getOrientation();
                this.compass.disableCompass();
            }
        }
    }

    public void setFeatureCollectionVisible(MapFactory.MapFeatureCollection object2, boolean bl) {
        if (!bl && this.hiddenFeatureCollections.contains(object2) || bl && !this.hiddenFeatureCollections.contains(object2)) {
            return;
        }
        if (bl) {
            this.hiddenFeatureCollections.remove(object2);
            Iterator iterator = object2.iterator();
            while (iterator.hasNext()) {
                object2 = (MapFactory.MapFeature)iterator.next();
                this.hiddenFeatures.remove(object2);
                if (!object2.Visible()) continue;
                this.showFeature((MapFactory.MapFeature)object2);
            }
        } else {
            this.hiddenFeatureCollections.add(object2);
            object2 = object2.iterator();
            while (object2.hasNext()) {
                MapFactory.MapFeature mapFeature = (MapFactory.MapFeature)object2.next();
                this.hiddenFeatures.add((Object)mapFeature);
                this.hideFeature(mapFeature);
            }
        }
    }

    public void setMapType(MapFactory.MapType mapType) {
        if ((mapType = MapType.fromUnderlyingValue((Integer)mapType.ordinal())) != null) {
            this.setMapTypeAbstract((MapType)mapType);
        }
    }

    public void setMapTypeAbstract(MapType mapType) {
        this.tileType = mapType;
        switch (14.$SwitchMap$com$google$appinventor$components$common$MapType[mapType.ordinal()]) {
            default: {
                break;
            }
            case 3: {
                this.view.setTileSource((ITileSource)TileSourceFactory.USGS_TOPO);
                break;
            }
            case 2: {
                this.view.setTileSource((ITileSource)TileSourceFactory.USGS_SAT);
                break;
            }
            case 1: {
                this.view.setTileSource((ITileSource)TileSourceFactory.MAPNIK);
            }
        }
    }

    public void setPanEnabled(boolean bl) {
        TouchOverlay.-$$Nest$fputscrollEnabled(this.touch, (boolean)bl);
    }

    public void setRotation(float f) {
        this.view.setMapOrientation(f);
    }

    public void setRotationEnabled(boolean bl) {
        RotationGestureOverlay rotationGestureOverlay;
        if (bl && this.rotation == null) {
            this.rotation = new RotationGestureOverlay(this.view);
        }
        if ((rotationGestureOverlay = this.rotation) != null) {
            rotationGestureOverlay.setEnabled(bl);
            if (bl) {
                this.view.getOverlayManager().add((Object)this.rotation);
            } else {
                this.view.getOverlayManager().remove((Object)this.rotation);
            }
        }
    }

    public void setScaleUnits(MapFactory.MapScaleUnits mapScaleUnits) {
        switch (14.$SwitchMap$com$google$appinventor$components$runtime$util$MapFactory$MapScaleUnits[mapScaleUnits.ordinal()]) {
            default: {
                throw new IllegalArgumentException("Unallowable unit system: " + mapScaleUnits);
            }
            case 2: {
                this.scaleBar.setUnitsOfMeasure(ScaleBarOverlay.UnitsOfMeasure.imperial);
                break;
            }
            case 1: {
                this.scaleBar.setUnitsOfMeasure(ScaleBarOverlay.UnitsOfMeasure.metric);
            }
        }
        this.view.invalidate();
    }

    public void setScaleUnitsAbstract(ScaleUnits scaleUnits) {
        switch (14.$SwitchMap$com$google$appinventor$components$common$ScaleUnits[scaleUnits.ordinal()]) {
            default: {
                break;
            }
            case 2: {
                this.scaleBar.setUnitsOfMeasure(ScaleBarOverlay.UnitsOfMeasure.imperial);
                break;
            }
            case 1: {
                this.scaleBar.setUnitsOfMeasure(ScaleBarOverlay.UnitsOfMeasure.metric);
            }
        }
        this.view.invalidate();
    }

    public void setScaleVisible(boolean bl) {
        this.scaleBar.setEnabled(bl);
        this.view.invalidate();
    }

    public void setShowUserEnabled(boolean bl) {
        this.userLocation.setEnabled(bl);
        if (bl) {
            this.userLocation.enableMyLocation();
            this.view.getOverlayManager().add((Object)this.userLocation);
        } else {
            this.userLocation.disableMyLocation();
            this.view.getOverlayManager().remove((Object)this.userLocation);
        }
    }

    public void setZoom(int n) {
        this.view.getController().setZoom((double)n);
        this.zoomControls.updateButtons();
    }

    public void setZoomControlEnabled(boolean bl) {
        if (this.zoomControlEnabled != bl) {
            ZoomControlView zoomControlView = this.zoomControls;
            int n = bl ? 0 : 8;
            zoomControlView.setVisibility(n);
            this.zoomControlEnabled = bl;
            this.containerView.invalidate();
        }
    }

    public void setZoomEnabled(boolean bl) {
        this.zoomEnabled = bl;
        this.view.setMultiTouchControls(bl);
    }

    public void showFeature(MapFactory.MapFeature mapFeature) {
        if (!this.hiddenFeatures.contains((Object)mapFeature)) {
            this.showOverlay((OverlayWithIW)this.featureOverlays.get((Object)mapFeature));
        }
    }

    public void showInfobox(MapFactory.MapFeature mapFeature) {
        OverlayWithIW overlayWithIW = (OverlayWithIW)this.featureOverlays.get((Object)mapFeature);
        if (overlayWithIW instanceof Marker) {
            overlayWithIW.showInfoWindow();
        } else if (overlayWithIW instanceof Polyline) {
            ((Polyline)overlayWithIW).showInfoWindow(mapFeature.getCentroid());
        } else {
            ((Polygon)overlayWithIW).showInfoWindow(mapFeature.getCentroid());
        }
    }

    protected void showOverlay(OverlayWithIW overlayWithIW) {
        this.view.getOverlayManager().add((Object)overlayWithIW);
        this.view.invalidate();
    }

    public void updateFeatureDraggable(MapFactory.MapFeature mapFeature) {
        OverlayWithIW overlayWithIW = (OverlayWithIW)this.featureOverlays.get((Object)mapFeature);
        if (overlayWithIW != null) {
            overlayWithIW.setDraggable(mapFeature.Draggable());
        }
    }

    public void updateFeatureFill(MapFactory.HasFill hasFill) {
        OverlayWithIW overlayWithIW = (OverlayWithIW)this.featureOverlays.get((Object)hasFill);
        if (overlayWithIW == null) {
            return;
        }
        overlayWithIW.accept((OverlayWithIWVisitor)new 8((NativeOpenStreetMapController)this, hasFill));
    }

    public void updateFeatureHoles(MapFactory.MapPolygon mapPolygon) {
        MultiPolygon multiPolygon = this.featureOverlays.get((Object)mapPolygon);
        if (multiPolygon != null) {
            multiPolygon.setMultiHoles(mapPolygon.getHolePoints());
            this.view.invalidate();
        }
    }

    public void updateFeatureImage(MapFactory.MapMarker mapMarker) {
        Marker marker = (Marker)this.featureOverlays.get((Object)mapMarker);
        if (marker == null) {
            return;
        }
        super.getMarkerDrawable(mapMarker, new AsyncCallbackPair<Drawable>((NativeOpenStreetMapController)this, marker){
            final NativeOpenStreetMapController this$0;
            final Marker val$marker;
            {
                this.this$0 = nativeOpenStreetMapController;
                this.val$marker = marker;
            }

            public void onFailure(String string) {
                Log.e((String)TAG, (String)("Unable to update feature image: " + string));
            }

            public void onSuccess(Drawable drawable) {
                this.val$marker.setIcon(drawable);
                this.this$0.view.invalidate();
            }
        });
    }

    public void updateFeaturePosition(MapFactory.MapCircle mapCircle) {
        GeoPoint geoPoint = new GeoPoint(mapCircle.Latitude(), mapCircle.Longitude());
        Polygon polygon = (Polygon)this.featureOverlays.get((Object)mapCircle);
        if (polygon != null) {
            polygon.setPoints((List)Polygon.pointsAsCircle((GeoPoint)geoPoint, (double)mapCircle.Radius()));
            this.view.invalidate();
        }
    }

    public void updateFeaturePosition(MapFactory.MapLineString mapLineString) {
        Polyline polyline = (Polyline)this.featureOverlays.get((Object)mapLineString);
        if (polyline != null) {
            polyline.setPoints(mapLineString.getPoints());
            this.view.invalidate();
        }
    }

    public void updateFeaturePosition(MapFactory.MapMarker mapMarker) {
        Marker marker = (Marker)this.featureOverlays.get((Object)mapMarker);
        if (marker != null) {
            marker.setAnchor(ANCHOR_HORIZONTAL[mapMarker.AnchorHorizontal()], ANCHOR_VERTICAL[mapMarker.AnchorVertical()]);
            marker.setPosition(new GeoPoint(mapMarker.Latitude(), mapMarker.Longitude()));
            this.view.invalidate();
        }
    }

    public void updateFeaturePosition(MapFactory.MapPolygon mapPolygon) {
        MultiPolygon multiPolygon = this.featureOverlays.get((Object)mapPolygon);
        if (multiPolygon != null) {
            multiPolygon.setMultiPoints(mapPolygon.getPoints());
            this.view.invalidate();
        }
    }

    public void updateFeaturePosition(MapFactory.MapRectangle mapRectangle) {
        Polygon polygon = (Polygon)this.featureOverlays.get((Object)mapRectangle);
        if (polygon != null) {
            polygon.setPoints((List)Polygon.pointsAsRect((BoundingBox)new BoundingBox(mapRectangle.NorthLatitude(), mapRectangle.EastLongitude(), mapRectangle.SouthLatitude(), mapRectangle.WestLongitude())));
            this.view.invalidate();
        }
    }

    public void updateFeatureSize(MapFactory.MapMarker mapMarker) {
        Marker marker = (Marker)this.featureOverlays.get((Object)mapMarker);
        if (marker == null) {
            return;
        }
        super.getMarkerDrawable(mapMarker, new AsyncCallbackPair<Drawable>((NativeOpenStreetMapController)this, marker){
            final NativeOpenStreetMapController this$0;
            final Marker val$marker;
            {
                this.this$0 = nativeOpenStreetMapController;
                this.val$marker = marker;
            }

            public void onFailure(String string) {
                Log.wtf((String)TAG, (String)"Cannot find default marker");
            }

            public void onSuccess(Drawable drawable) {
                this.val$marker.setIcon(drawable);
                this.this$0.view.invalidate();
            }
        });
    }

    public void updateFeatureStroke(MapFactory.HasStroke hasStroke) {
        OverlayWithIW overlayWithIW = (OverlayWithIW)this.featureOverlays.get((Object)hasStroke);
        if (overlayWithIW == null) {
            return;
        }
        overlayWithIW.accept((OverlayWithIWVisitor)new 9((NativeOpenStreetMapController)this, hasStroke));
    }

    public void updateFeatureText(MapFactory.MapFeature mapFeature) {
        OverlayWithIW overlayWithIW = (OverlayWithIW)this.featureOverlays.get((Object)mapFeature);
        if (overlayWithIW != null) {
            overlayWithIW.setTitle(mapFeature.Title());
            overlayWithIW.setSnippet(mapFeature.Description());
        }
    }

    private static class AppInventorLocationSensorAdapter
    implements IMyLocationProvider,
    LocationSensor.LocationSensorListener {
        private IMyLocationConsumer consumer;
        private boolean enabled;
        private Location lastLocation;
        private LocationSensor source;

        private AppInventorLocationSensorAdapter() {
            this.enabled = false;
        }

        /* synthetic */ AppInventorLocationSensorAdapter(AppInventorLocationSensorAdapter-IA appInventorLocationSensorAdapter-IA) {
        }

        public void destroy() {
            this.consumer = null;
        }

        public Location getLastKnownLocation() {
            return this.lastLocation;
        }

        @Override
        public void onDistanceIntervalChanged(int n) {
        }

        public void onLocationChanged(Location location2) {
            this.lastLocation = location2;
            IMyLocationConsumer iMyLocationConsumer = this.consumer;
            if (iMyLocationConsumer != null) {
                iMyLocationConsumer.onLocationChanged(location2, (IMyLocationProvider)this);
            }
        }

        public void onProviderDisabled(String string) {
        }

        public void onProviderEnabled(String string) {
        }

        public void onStatusChanged(String string, int n, Bundle bundle) {
        }

        @Override
        public void onTimeIntervalChanged(int n) {
        }

        @Override
        public void setSource(LocationSensor locationSensor) {
            LocationSensor locationSensor2 = this.source;
            if (locationSensor2 == locationSensor) {
                return;
            }
            if (locationSensor2 != null) {
                locationSensor2.Enabled(false);
            }
            this.source = locationSensor;
            if (locationSensor != null) {
                locationSensor.Enabled(this.enabled);
            }
        }

        public boolean startLocationProvider(IMyLocationConsumer object2) {
            this.consumer = object2;
            object2 = this.source;
            if (object2 != null) {
                ((LocationSensor)object2).Enabled(true);
                this.enabled = true;
            }
            return this.enabled;
        }

        public void stopLocationProvider() {
            LocationSensor locationSensor = this.source;
            if (locationSensor != null) {
                locationSensor.Enabled(false);
            }
            this.enabled = false;
        }
    }
}

