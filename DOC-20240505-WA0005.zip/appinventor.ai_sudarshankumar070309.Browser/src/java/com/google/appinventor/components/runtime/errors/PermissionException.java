/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.google.appinventor.components.runtime.errors;

public class PermissionException
extends RuntimeException {
    private final String permissionNeeded;

    public PermissionException(String string) {
        this.permissionNeeded = string;
    }

    public String getMessage() {
        String string = this.permissionNeeded;
        return "Unable to complete the operation because the user denied permission: " + string;
    }

    public String getPermissionNeeded() {
        return this.permissionNeeded;
    }
}

