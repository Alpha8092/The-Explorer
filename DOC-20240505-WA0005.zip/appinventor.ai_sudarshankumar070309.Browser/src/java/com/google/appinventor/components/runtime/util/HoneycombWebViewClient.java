/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.webkit.WebResourceRequest
 *  android.webkit.WebResourceResponse
 *  android.webkit.WebView
 *  com.google.appinventor.components.runtime.util.FroyoWebViewClient
 *  java.io.ByteArrayInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.URLConnection
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.appinventor.components.runtime.util;

import android.os.Build;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.WebViewer;
import com.google.appinventor.components.runtime.util.FroyoWebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

public class HoneycombWebViewClient
extends FroyoWebViewClient<WebViewer> {
    private static final String ASSET_PREFIX = "file:///appinventor_asset/";
    private static final String TAG = HoneycombWebViewClient.class.getSimpleName();

    public HoneycombWebViewClient(boolean bl, boolean bl2, Form form, WebViewer webViewer) {
        super(bl, bl2, form, (Component)((Object)webViewer));
    }

    protected WebResourceResponse handleAppRequest(String string) {
        String string2;
        HashMap hashMap;
        StringBuilder stringBuilder;
        block7: {
            block6: {
                string = string.startsWith(ASSET_PREFIX) ? string.substring(ASSET_PREFIX.length()) : string.substring(string.indexOf("//localhost/") + 12);
                try {
                    String string3 = TAG;
                    stringBuilder = new StringBuilder();
                    Log.i((String)string3, (String)stringBuilder.append("webviewer requested path = ").append(string).toString());
                    stringBuilder = this.getForm().openAsset(string);
                    hashMap = new HashMap();
                    hashMap.put((Object)"Access-Control-Allow-Origin", (Object)"localhost");
                    string2 = URLConnection.getFileNameMap().getContentTypeFor(string);
                    string = new StringBuilder();
                    Log.i((String)string3, (String)string.append("Mime type = ").append(string2).toString());
                    if (string2 == null) break block6;
                }
                catch (IOException iOException) {
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream("404 Not Found".getBytes());
                    if (Build.VERSION.SDK_INT >= 21) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, (InputStream)byteArrayInputStream);
                    }
                    return new WebResourceResponse("text/plain", "utf-8", (InputStream)byteArrayInputStream);
                }
                if (!string2.startsWith("text/") && !string2.equals((Object)"application/javascript")) break block6;
                string = "utf-8";
                break block7;
            }
            string = null;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            return new WebResourceResponse(string2, string, 200, "OK", (Map)hashMap, (InputStream)stringBuilder);
        }
        string = new WebResourceResponse(string2, string, (InputStream)stringBuilder);
        return string;
    }

    public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
        String string = TAG;
        String string2 = webResourceRequest.getUrl().getScheme();
        Log.d((String)string, (String)("scheme = " + string2));
        if (!"localhost".equals((Object)webResourceRequest.getUrl().getAuthority()) && !webResourceRequest.getUrl().toString().startsWith(ASSET_PREFIX)) {
            return super.shouldInterceptRequest(webView, webResourceRequest);
        }
        return this.handleAppRequest(webResourceRequest.getUrl().toString());
    }

    public WebResourceResponse shouldInterceptRequest(WebView webView, String string) {
        if (!string.startsWith("http://localhost/") && !string.startsWith(ASSET_PREFIX)) {
            return super.shouldInterceptRequest(webView, string);
        }
        return this.handleAppRequest(string);
    }
}

