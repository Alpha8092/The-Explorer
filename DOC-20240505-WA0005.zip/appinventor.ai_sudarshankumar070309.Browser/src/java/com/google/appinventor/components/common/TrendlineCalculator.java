/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 */
package com.google.appinventor.components.common;

import java.util.List;
import java.util.Map;

public interface TrendlineCalculator {
    public Map<String, Object> compute(List<Double> var1, List<Double> var2);

    public float[] computePoints(Map<String, Object> var1, float var2, float var3, int var4, int var5);
}

