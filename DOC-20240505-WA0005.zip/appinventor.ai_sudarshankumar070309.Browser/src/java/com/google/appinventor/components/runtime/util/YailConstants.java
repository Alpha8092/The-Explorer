package com.google.appinventor.components.runtime.util;

import gnu.mapping.SimpleSymbol;

/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public class YailConstants {
    public static final SimpleSymbol YAIL_HEADER = new SimpleSymbol("*list*");

    private YailConstants() {
    }
}
