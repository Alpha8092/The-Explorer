/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Handler
 *  android.speech.tts.TextToSpeech
 *  android.speech.tts.TextToSpeech$OnInitListener
 *  android.speech.tts.TextToSpeech$OnUtteranceCompletedListener
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.ITextToSpeech
 *  com.google.appinventor.components.runtime.util.ITextToSpeech$TextToSpeechCallback
 *  com.google.appinventor.components.runtime.util.InternalTextToSpeech$1
 *  com.google.appinventor.components.runtime.util.InternalTextToSpeech$2
 *  com.google.appinventor.components.runtime.util.InternalTextToSpeech$3
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Locale
 */
package com.google.appinventor.components.runtime.util;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import com.google.appinventor.components.runtime.util.ITextToSpeech;
import com.google.appinventor.components.runtime.util.InternalTextToSpeech;
import java.util.HashMap;
import java.util.Locale;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class InternalTextToSpeech
implements ITextToSpeech {
    private static final String LOG_TAG = "InternalTTS";
    private final Activity activity;
    private final ITextToSpeech.TextToSpeechCallback callback;
    private volatile boolean isTtsInitialized;
    private Handler mHandler = new Handler();
    private int nextUtteranceId = 1;
    private TextToSpeech tts;
    private int ttsMaxRetries = 20;
    private int ttsRetryDelay = 500;

    static /* bridge */ /* synthetic */ Activity -$$Nest$fgetactivity(InternalTextToSpeech internalTextToSpeech) {
        return internalTextToSpeech.activity;
    }

    static /* bridge */ /* synthetic */ ITextToSpeech.TextToSpeechCallback -$$Nest$fgetcallback(InternalTextToSpeech internalTextToSpeech) {
        return internalTextToSpeech.callback;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputisTtsInitialized(InternalTextToSpeech internalTextToSpeech, boolean bl) {
        internalTextToSpeech.isTtsInitialized = bl;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$mspeak(InternalTextToSpeech internalTextToSpeech, String string, Locale locale, int n) {
        internalTextToSpeech.speak(string, locale, n);
    }

    public InternalTextToSpeech(Activity activity, ITextToSpeech.TextToSpeechCallback textToSpeechCallback) {
        this.activity = activity;
        this.callback = textToSpeechCallback;
    }

    private void initializeTts() {
        if (this.tts == null) {
            Log.d((String)LOG_TAG, (String)"INTERNAL TTS is reinitializing");
            this.tts = new TextToSpeech((Context)this.activity, (TextToSpeech.OnInitListener)new 1(this));
        }
    }

    private void speak(String string, Locale locale, int n) {
        Log.d((String)LOG_TAG, (String)("InternalTTS speak called, message = " + string));
        int n2 = this.ttsMaxRetries;
        if (n > n2) {
            Log.d((String)LOG_TAG, (String)("max number of speak retries exceeded (" + n2 + "): speak will fail"));
            this.callback.onFailure();
            return;
        }
        if (this.isTtsInitialized) {
            Log.d((String)LOG_TAG, (String)("TTS initialized after " + n + " retries."));
            this.tts.setLanguage(locale);
            this.tts.setOnUtteranceCompletedListener((TextToSpeech.OnUtteranceCompletedListener)new 2((InternalTextToSpeech)this));
            locale = new HashMap();
            n = this.nextUtteranceId;
            this.nextUtteranceId = n + 1;
            locale.put((Object)"utteranceId", (Object)Integer.toString((int)n));
            if (this.tts.speak(string, 0, (HashMap)locale) == -1) {
                Log.d((String)LOG_TAG, (String)"speak called and tts.speak result was an error");
                this.callback.onFailure();
            }
        } else {
            Log.d((String)LOG_TAG, (String)"speak called when TTS not initialized");
            this.mHandler.postDelayed((Runnable)new 3((InternalTextToSpeech)this, n, string, locale), (long)this.ttsRetryDelay);
        }
    }

    public boolean isInitialized() {
        return this.isTtsInitialized;
    }

    public int isLanguageAvailable(Locale locale) {
        return this.tts.isLanguageAvailable(locale);
    }

    public void onDestroy() {
        Log.d((String)LOG_TAG, (String)"Internal TTS got onDestroy");
        TextToSpeech textToSpeech = this.tts;
        if (textToSpeech != null) {
            textToSpeech.shutdown();
            this.isTtsInitialized = false;
            this.tts = null;
        }
    }

    public void onResume() {
        Log.d((String)LOG_TAG, (String)"Internal TTS got onResume");
        this.initializeTts();
    }

    public void onStop() {
        Log.d((String)LOG_TAG, (String)"Internal TTS got onStop");
    }

    public void setPitch(float f) {
        this.tts.setPitch(f);
    }

    public void setSpeechRate(float f) {
        this.tts.setSpeechRate(f);
    }

    public void speak(String string, Locale locale) {
        Log.d((String)LOG_TAG, (String)"Internal TTS got speak");
        super.speak(string, locale, 0);
    }

    public void stop() {
        TextToSpeech textToSpeech = this.tts;
        if (textToSpeech != null) {
            textToSpeech.stop();
        }
    }
}

