/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.ElementType
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.lang.annotation.Target
 */
package com.google.appinventor.components.annotations.androidmanifest;

import com.google.appinventor.components.annotations.androidmanifest.GrantUriPermissionElement;
import com.google.appinventor.components.annotations.androidmanifest.MetaDataElement;
import com.google.appinventor.components.annotations.androidmanifest.PathPermissionElement;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.TYPE})
public @interface ProviderElement {
    public String authorities();

    public String directBootAware() default "false";

    public String enabled() default "";

    public String exported() default "";

    public GrantUriPermissionElement[] grantUriPermissionElement() default {};

    public String grantUriPermissions() default "";

    public String icon() default "";

    public String initOrder() default "";

    public String label() default "";

    public MetaDataElement[] metaDataElements() default {};

    public String multiprocess() default "";

    public String name();

    public PathPermissionElement[] pathPermissionElement() default {};

    public String permission() default "";

    public String process() default "";

    public String readPermission() default "";

    public String syncable() default "";

    public String writePermission() default "";
}

