/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 *  java.nio.charset.Charset
 *  java.util.GregorianCalendar
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipException
 */
package com.google.appinventor.components.runtime.multidex;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.GregorianCalendar;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;

class ZipEntryReader {
    private static final long CENSIG = 33639248L;
    private static final int GPBF_ENCRYPTED_FLAG = 1;
    private static final int GPBF_UNSUPPORTED_MASK = 1;
    static final Charset UTF_8 = Charset.forName((String)"UTF-8");

    ZipEntryReader() {
    }

    private static long getTime(int n, int n2) {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.set(14, 0);
        gregorianCalendar.set((n2 >> 9 & 0x7F) + 1980, (n2 >> 5 & 0xF) - 1, n2 & 0x1F, n >> 11 & 0x1F, n >> 5 & 0x3F, (n & 0x1F) << 1);
        return gregorianCalendar.getTime().getTime();
    }

    static ZipEntry readEntry(ByteBuffer byteBuffer) throws IOException {
        if ((long)byteBuffer.getInt() == 33639248L) {
            Object object = (ByteBuffer)byteBuffer.position(8);
            int n = byteBuffer.getShort() & 0xFFFF;
            if ((n & 1) == 0) {
                short s = byteBuffer.getShort();
                short s2 = byteBuffer.getShort();
                n = byteBuffer.getShort();
                long l = byteBuffer.getInt();
                long l2 = byteBuffer.getInt();
                long l3 = byteBuffer.getInt();
                int n2 = byteBuffer.getShort();
                int n3 = byteBuffer.getShort() & 0xFFFF;
                int n4 = 0xFFFF & byteBuffer.getShort();
                object = (ByteBuffer)byteBuffer.position(42);
                long l4 = byteBuffer.getInt();
                Object object2 = new byte[n2 & 0xFFFF];
                byteBuffer.get(object2, 0, ((byte[])object2).length);
                n2 = ((byte[])object2).length;
                object = UTF_8;
                object2 = new ZipEntry(new String(object2, 0, n2, (Charset)object));
                object2.setMethod(s & 0xFFFF);
                object2.setTime(ZipEntryReader.getTime(s2 & 0xFFFF, n & 0xFFFF));
                object2.setCrc(l & 0xFFFFFFFFL);
                object2.setCompressedSize(l2 & 0xFFFFFFFFL);
                object2.setSize(l3 & 0xFFFFFFFFL);
                if (n4 > 0) {
                    byte[] byArray = new byte[n4];
                    byteBuffer.get(byArray, 0, n4);
                    object2.setComment(new String(byArray, 0, byArray.length, (Charset)object));
                }
                if (n3 > 0) {
                    object = new byte[n3];
                    byteBuffer.get((byte[])object, 0, n3);
                    object2.setExtra((byte[])object);
                }
                return object2;
            }
            throw new ZipException("Invalid General Purpose Bit Flag: " + n);
        }
        throw new ZipException("Central Directory Entry not found");
    }
}

