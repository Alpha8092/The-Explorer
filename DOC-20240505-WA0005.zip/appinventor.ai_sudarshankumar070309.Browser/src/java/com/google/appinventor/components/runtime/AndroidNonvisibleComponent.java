package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.SimpleObject;

@SimpleObject
/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/1.dex */
public abstract class AndroidNonvisibleComponent implements Component {
    protected final Form form;

    /* JADX INFO: Access modifiers changed from: protected */
    public AndroidNonvisibleComponent(Form form) {
        this.form = form;
    }

    @Override // com.google.appinventor.components.runtime.Component
    public HandlesEventDispatching getDispatchDelegate() {
        return this.form;
    }
}
