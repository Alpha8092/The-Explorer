/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.None
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.zip.Huff;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.MapKeep;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.None;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.PostMortem;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.TrieKeep;

public abstract class JSONzip
implements None,
PostMortem {
    public static final byte[] bcd;
    public static final int end = 256;
    public static final int endOfNumber;
    public static final long int14 = 16384L;
    public static final long int4 = 16L;
    public static final long int7 = 128L;
    public static final int maxSubstringLength = 10;
    public static final int minSubstringLength = 3;
    public static final boolean probe = false;
    public static final int substringLimit = 40;
    public static final int[] twos;
    public static final int zipArrayString = 6;
    public static final int zipArrayValue = 7;
    public static final int zipEmptyArray = 1;
    public static final int zipEmptyObject = 0;
    public static final int zipFalse = 3;
    public static final int zipNull = 4;
    public static final int zipObject = 5;
    public static final int zipTrue = 2;
    protected final Huff namehuff;
    protected final MapKeep namekeep;
    protected final MapKeep stringkeep;
    protected final Huff substringhuff;
    protected final TrieKeep substringkeep;
    protected final MapKeep values;

    static {
        byte[] byArray;
        twos = new int[]{1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536};
        byte[] byArray2 = byArray = new byte[14];
        byArray[0] = 48;
        byArray2[1] = 49;
        byArray2[2] = 50;
        byArray2[3] = 51;
        byArray2[4] = 52;
        byArray2[5] = 53;
        byArray2[6] = 54;
        byArray2[7] = 55;
        byArray2[8] = 56;
        byArray2[9] = 57;
        byArray2[10] = 46;
        byArray2[11] = 45;
        byArray2[12] = 43;
        byArray2[13] = 69;
        bcd = byArray;
        endOfNumber = byArray.length;
    }

    protected JSONzip() {
        Huff huff;
        Huff huff2;
        this.namehuff = huff2 = new Huff(257);
        this.namekeep = new MapKeep(9);
        this.stringkeep = new MapKeep(11);
        this.substringhuff = huff = new Huff(257);
        this.substringkeep = new TrieKeep(12);
        this.values = new MapKeep(10);
        huff2.tick(32, 125);
        huff2.tick(97, 122);
        huff2.tick(256);
        huff2.tick(256);
        huff.tick(32, 125);
        huff.tick(97, 122);
        huff.tick(256);
        huff.tick(256);
    }

    static void log() {
        JSONzip.log("\n");
    }

    static void log(int n) {
        JSONzip.log(new StringBuffer().append(n).append(" ").toString());
    }

    static void log(int n, int n2) {
        JSONzip.log(new StringBuffer().append(n).append(":").append(n2).append(" ").toString());
    }

    static void log(String string) {
        System.out.print(string);
    }

    static void logchar(int n, int n2) {
        if (n > 32 && n <= 125) {
            JSONzip.log(new StringBuffer().append("'").append((char)n).append("':").append(n2).append(" ").toString());
        } else {
            JSONzip.log(n, n2);
        }
    }

    protected void begin() {
        this.namehuff.generate();
        this.substringhuff.generate();
    }

    public boolean postMortem(PostMortem postMortem) {
        postMortem = (JSONzip)postMortem;
        boolean bl = this.namehuff.postMortem(postMortem.namehuff) && this.namekeep.postMortem(postMortem.namekeep) && this.stringkeep.postMortem(postMortem.stringkeep) && this.substringhuff.postMortem(postMortem.substringhuff) && this.substringkeep.postMortem(postMortem.substringkeep) && this.values.postMortem(postMortem.values);
        return bl;
    }
}

