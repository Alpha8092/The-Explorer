/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.media.MediaPlayer$OnErrorListener
 *  android.media.MediaPlayer$OnPreparedListener
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.widget.MediaController
 *  android.widget.VideoView
 *  com.google.appinventor.components.runtime.AndroidViewComponent
 *  com.google.appinventor.components.runtime.VideoPlayer$1
 *  com.google.appinventor.components.runtime.util.MediaUtil
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  com.google.appinventor.components.runtime.util.TiramisuUtil
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.ClassCastException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidViewComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.OnDestroyListener;
import com.google.appinventor.components.runtime.PermissionResultHandler;
import com.google.appinventor.components.runtime.VideoPlayer;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.util.MediaUtil;
import com.google.appinventor.components.runtime.util.SdkLevel;
import com.google.appinventor.components.runtime.util.TiramisuUtil;
import java.io.IOException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="A multimedia component capable of playing videos. When the application is run, the VideoPlayer will be displayed as a rectangle on-screen.  If the user touches the rectangle, controls will appear to play/pause, skip ahead, and skip backward within the video.  The application can also control behavior by calling the <code>Start</code>, <code>Pause</code>, and <code>SeekTo</code> methods.  <p>Video files should be in 3GPP (.3gp) or MPEG-4 (.mp4) formats.  For more details about legal formats, see <a href=\"http://developer.android.com/guide/appendix/media-formats.html\" target=\"_blank\">Android Supported Media Formats</a>.</p><p>App Inventor for Android only permits video files under 1 MB and limits the total size of an application to 5 MB, not all of which is available for media (video, audio, and sound) files.  If your media files are too large, you may get errors when packaging or installing your application, in which case you should reduce the number of media files or their sizes.  Most video editing software, such as Windows Movie Maker and Apple iMovie, can help you decrease the size of videos by shortening them or re-encoding the video into a more compact format.</p><p>You can also set the media source to a URL that points to a streaming video, but the URL must point to the video file itself, not to a program that plays the video.", iconName="images/videoPlayer.png", version=7)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.INTERNET")
public final class VideoPlayer
extends AndroidViewComponent
implements OnDestroyListener,
Deleteable,
MediaPlayer.OnCompletionListener,
MediaPlayer.OnErrorListener,
MediaPlayer.OnPreparedListener {
    private final Handler androidUIHandler = new Handler();
    private boolean delayedStart = false;
    private boolean inFullScreen = false;
    private MediaPlayer mPlayer;
    private boolean mediaReady = false;
    private String sourcePath;
    private final ResizableVideoView videoView;

    public VideoPlayer(ComponentContainer componentContainer) {
        super(componentContainer);
        componentContainer.$form().registerForOnDestroy((OnDestroyListener)this);
        VideoView videoView = new VideoView((VideoPlayer)this, (Context)componentContainer.$context()){
            public int forcedHeight;
            public int forcedWidth;
            private Boolean mFoundMediaPlayer;
            private MediaPlayer mVideoPlayer;
            final VideoPlayer this$0;
            {
                this.this$0 = videoPlayer;
                super(context);
                this.mFoundMediaPlayer = false;
                this.forcedWidth = -1;
                this.forcedHeight = -1;
            }

            private void onMeasure(int n, int n2, int n3) {
                String string;
                int n4;
                int n5 = 0;
                int n6 = 0;
                float f = this.this$0.container.$form().deviceDensity();
                Log.i((String)"VideoPlayer..onMeasure", (String)("Device Density = " + f));
                int n7 = this.forcedWidth;
                int n8 = this.forcedHeight;
                Log.i((String)"VideoPlayer..onMeasure", (String)("AI setting dimensions as:" + n7 + ":" + n8));
                n8 = View.MeasureSpec.getSize((int)n);
                n7 = View.MeasureSpec.getSize((int)n2);
                Log.i((String)"VideoPlayer..onMeasure", (String)("Dimenions from super>>" + n8 + ":" + n7));
                n8 = 176;
                n7 = 144;
                switch (this.forcedWidth) {
                    default: {
                        n4 = 1;
                        n8 = this.forcedWidth;
                        break;
                    }
                    case -1: {
                        n4 = n6;
                        if (!this.mFoundMediaPlayer.booleanValue()) break;
                        try {
                            n8 = this.mVideoPlayer.getVideoWidth();
                            string = new StringBuilder();
                            Log.i((String)"VideoPlayer.onMeasure", (String)string.append("Got width from MediaPlayer>").append(n8).toString());
                        }
                        catch (NullPointerException nullPointerException) {
                            string = nullPointerException.getMessage();
                            Log.e((String)"VideoPlayer..onMeasure", (String)("Failed to get MediaPlayer for width:\n" + string));
                            n8 = 176;
                        }
                        n4 = n6;
                        break;
                    }
                    case -2: {
                        switch (View.MeasureSpec.getMode((int)n)) {
                            default: {
                                break;
                            }
                            case 0: {
                                try {
                                    n8 = ((View)this.getParent()).getMeasuredWidth();
                                }
                                catch (NullPointerException nullPointerException) {
                                    n8 = 176;
                                }
                                catch (ClassCastException classCastException) {
                                    n8 = 176;
                                }
                                break;
                            }
                            case -2147483648: 
                            case 0x40000000: {
                                n8 = View.MeasureSpec.getSize((int)n);
                            }
                        }
                        n4 = n6;
                    }
                }
                if (this.forcedWidth <= -1000) {
                    n6 = this.this$0.container.$form().Width();
                    if (n6 == 0 && n3 < 2) {
                        Log.d((String)"VideoPlayer...onMeasure", (String)("Width not stable... trying again (onMeasure " + n3 + ")"));
                        this.this$0.androidUIHandler.postDelayed(new Runnable(this, n, n2, n3){
                            final ResizableVideoView this$1;
                            final int val$specheight;
                            final int val$specwidth;
                            final int val$trycount;
                            {
                                this.this$1 = resizableVideoView;
                                this.val$specwidth = n;
                                this.val$specheight = n2;
                                this.val$trycount = n3;
                            }

                            public void run() {
                                this.this$1.onMeasure(this.val$specwidth, this.val$specheight, this.val$trycount + 1);
                            }
                        }, 100L);
                        this.setMeasuredDimension(100, 100);
                        return;
                    }
                    n6 = (int)((float)(-(n8 + 1000) * n6 / 100) * f);
                } else {
                    n6 = n8;
                    if (n4 != 0) {
                        n6 = (int)((float)n8 * f);
                    }
                }
                switch (this.forcedHeight) {
                    default: {
                        n4 = 1;
                        n8 = this.forcedHeight;
                        break;
                    }
                    case -1: {
                        n4 = n5;
                        n8 = n7;
                        if (!this.mFoundMediaPlayer.booleanValue()) break;
                        try {
                            n8 = this.mVideoPlayer.getVideoHeight();
                            string = new StringBuilder();
                            Log.i((String)"VideoPlayer.onMeasure", (String)string.append("Got height from MediaPlayer>").append(n8).toString());
                        }
                        catch (NullPointerException nullPointerException) {
                            String string2 = nullPointerException.getMessage();
                            Log.e((String)"VideoPlayer..onMeasure", (String)("Failed to get MediaPlayer for height:\n" + string2));
                            n8 = 144;
                        }
                        n4 = n5;
                        break;
                    }
                    case -2: {
                        switch (View.MeasureSpec.getMode((int)n2)) {
                            default: {
                                n8 = n7;
                                break;
                            }
                            case -2147483648: 
                            case 0x40000000: {
                                n8 = View.MeasureSpec.getSize((int)n2);
                            }
                        }
                        n4 = n5;
                    }
                }
                if (this.forcedHeight <= -1000) {
                    n7 = this.this$0.container.$form().Height();
                    if (n7 == 0 && n3 < 2) {
                        Log.d((String)"VideoPlayer...onMeasure", (String)("Height not stable... trying again (onMeasure " + n3 + ")"));
                        this.this$0.androidUIHandler.postDelayed(new Runnable(this, n, n2, n3){
                            final ResizableVideoView this$1;
                            final int val$specheight;
                            final int val$specwidth;
                            final int val$trycount;
                            {
                                this.this$1 = resizableVideoView;
                                this.val$specwidth = n;
                                this.val$specheight = n2;
                                this.val$trycount = n3;
                            }

                            public void run() {
                                this.this$1.onMeasure(this.val$specwidth, this.val$specheight, this.val$trycount + 1);
                            }
                        }, 100L);
                        this.setMeasuredDimension(100, 100);
                        return;
                    }
                    n = (int)((float)(-(n8 + 1000) * n7 / 100) * f);
                } else {
                    n = n8;
                    if (n4 != 0) {
                        n = (int)((float)n8 * f);
                    }
                }
                Log.i((String)"VideoPlayer.onMeasure", (String)("Setting dimensions to:" + n6 + "x" + n));
                this.getHolder().setFixedSize(n6, n);
                this.setMeasuredDimension(n6, n);
            }

            public void changeVideoSize(int n, int n2) {
                this.forcedWidth = n;
                this.forcedHeight = n2;
                this.forceLayout();
                this.invalidate();
            }

            public void invalidateMediaPlayer(boolean bl) {
                this.mFoundMediaPlayer = false;
                this.mVideoPlayer = null;
                if (bl) {
                    this.forceLayout();
                    this.invalidate();
                }
            }

            public void onMeasure(int n, int n2) {
                super.onMeasure(n, n2, 0);
            }

            public void setMediaPlayer(MediaPlayer mediaPlayer, boolean bl) {
                this.mVideoPlayer = mediaPlayer;
                this.mFoundMediaPlayer = true;
                if (bl) {
                    this.forceLayout();
                    this.invalidate();
                }
            }
        };
        this.videoView = videoView;
        videoView.setMediaController(new MediaController((Context)componentContainer.$context()));
        videoView.setOnCompletionListener((MediaPlayer.OnCompletionListener)this);
        videoView.setOnErrorListener((MediaPlayer.OnErrorListener)this);
        videoView.setOnPreparedListener((MediaPlayer.OnPreparedListener)this);
        componentContainer.$add((AndroidViewComponent)this);
        componentContainer.setChildWidth((AndroidViewComponent)this, 176);
        componentContainer.setChildHeight((AndroidViewComponent)this, 144);
        componentContainer.$form().setVolumeControlStream(3);
        this.sourcePath = "";
    }

    private void prepareToDie() {
        if (this.videoView.isPlaying()) {
            this.videoView.stopPlayback();
        }
        this.videoView.setVideoURI(null);
        this.videoView.clearAnimation();
        this.delayedStart = false;
        this.mediaReady = false;
        if (this.inFullScreen) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("FullScreenKey", false);
            this.container.$form().fullScreenVideoAction(195, this, bundle);
        }
    }

    @SimpleEvent
    public void Completed() {
        EventDispatcher.dispatchEvent((Component)((Object)this), "Completed", new Object[0]);
    }

    @SimpleProperty(userVisible=true)
    public void FullScreen(boolean bl) {
        if (bl && SdkLevel.getLevel() <= 4) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "FullScreen(true)", 1303, new Object[0]);
            return;
        }
        if (bl != this.inFullScreen) {
            if (bl) {
                Bundle bundle = new Bundle();
                bundle.putInt("PositionKey", this.videoView.getCurrentPosition());
                bundle.putBoolean("PlayingKey", this.videoView.isPlaying());
                this.videoView.pause();
                bundle.putBoolean("FullScreenKey", true);
                bundle.putString("SourceKey", this.sourcePath);
                if (this.container.$form().fullScreenVideoAction(195, (VideoPlayer)this, bundle).getBoolean("ActionSuccess")) {
                    this.inFullScreen = true;
                } else {
                    this.inFullScreen = false;
                    this.container.$form().dispatchErrorOccurredEvent((Component)this, "FullScreen", 1301, "");
                }
            } else {
                Bundle bundle = new Bundle();
                bundle.putBoolean("FullScreenKey", false);
                bundle = this.container.$form().fullScreenVideoAction(195, (VideoPlayer)this, bundle);
                if (bundle.getBoolean("ActionSuccess")) {
                    this.fullScreenKilled(bundle);
                } else {
                    this.inFullScreen = true;
                    this.container.$form().dispatchErrorOccurredEvent((Component)this, "FullScreen", 1302, "");
                }
            }
        }
    }

    @SimpleProperty
    public boolean FullScreen() {
        return this.inFullScreen;
    }

    @SimpleFunction(description="Returns duration of the video in milliseconds.")
    public int GetDuration() {
        Log.i((String)"VideoPlayer", (String)"Calling GetDuration");
        if (this.inFullScreen) {
            Bundle bundle = this.container.$form().fullScreenVideoAction(196, this, null);
            if (bundle.getBoolean("ActionSuccess")) {
                return bundle.getInt("ActionData");
            }
            return 0;
        }
        return this.videoView.getDuration();
    }

    @SimpleProperty
    public int Height() {
        return super.Height();
    }

    @SimpleProperty(userVisible=true)
    public void Height(int n) {
        super.Height(n);
        ResizableVideoView resizableVideoView = this.videoView;
        resizableVideoView.changeVideoSize(resizableVideoView.forcedWidth, n);
    }

    @SimpleFunction(description="Pauses playback of the video.  Playback can be resumed at the same location by calling the <code>Start</code> method.")
    public void Pause() {
        Log.i((String)"VideoPlayer", (String)"Calling Pause");
        if (this.inFullScreen) {
            this.container.$form().fullScreenVideoAction(192, this, null);
            this.delayedStart = false;
        } else {
            this.delayedStart = false;
            this.videoView.pause();
        }
    }

    @SimpleFunction(description="Seeks to the requested time (specified in milliseconds) in the video. If the video is paused, the frame shown will not be updated by the seek. The player can jump only to key frames in the video, so seeking to times that differ by short intervals may not actually move to different frames.")
    public void SeekTo(int n) {
        Log.i((String)"VideoPlayer", (String)"Calling SeekTo");
        int n2 = n;
        if (n < 0) {
            n2 = 0;
        }
        if (this.inFullScreen) {
            this.container.$form().fullScreenVideoAction(190, (VideoPlayer)this, n2);
        } else {
            this.videoView.seekTo(n2);
        }
    }

    @DesignerProperty(defaultValue="", editorType="asset")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The \"path\" to the video.  Usually, this will be the name of the video file, which should be added in the Designer.")
    @UsesPermissions(value={"android.permission.READ_EXTERNAL_STORAGE"})
    public void Source(@Asset String string) {
        String string2 = "";
        String string3 = string == null ? "" : string;
        if (TiramisuUtil.requestVideoPermissions((Form)this.container.$form(), (String)string, (PermissionResultHandler)new 1((VideoPlayer)this, string3))) {
            return;
        }
        if (this.inFullScreen) {
            this.container.$form().fullScreenVideoAction(194, (VideoPlayer)this, string);
        } else {
            if (string == null) {
                string = string2;
            }
            this.sourcePath = string;
            this.videoView.invalidateMediaPlayer(true);
            if (this.videoView.isPlaying()) {
                this.videoView.stopPlayback();
            }
            this.videoView.setVideoURI(null);
            this.videoView.clearAnimation();
            if (this.sourcePath.length() > 0) {
                string = this.sourcePath;
                Log.i((String)"VideoPlayer", (String)("Source path is " + string));
                try {
                    this.mediaReady = false;
                    MediaUtil.loadVideoView((VideoView)this.videoView, (Form)this.container.$form(), (String)this.sourcePath);
                }
                catch (IOException iOException) {
                    this.container.$form().dispatchErrorOccurredEvent((Component)this, "Source", 701, this.sourcePath);
                    return;
                }
                catch (PermissionException permissionException) {
                    this.container.$form().dispatchPermissionDeniedEvent((Component)this, "Source", permissionException);
                    return;
                }
                Log.i((String)"VideoPlayer", (String)"loading video succeeded");
            }
        }
    }

    @SimpleFunction(description="Starts playback of the video.")
    public void Start() {
        Log.i((String)"VideoPlayer", (String)"Calling Start");
        if (this.inFullScreen) {
            this.container.$form().fullScreenVideoAction(191, this, null);
        } else if (this.mediaReady) {
            this.videoView.start();
        } else {
            this.delayedStart = true;
        }
    }

    @SimpleFunction(description="Resets to start of video and pauses it if video was playing.")
    public void Stop() {
        Log.i((String)"VideoPlayer", (String)"Calling Stop");
        this.Start();
        this.SeekTo(0);
        this.Pause();
    }

    @SimpleEvent(description="The VideoPlayerError event is no longer used. Please use the Screen.ErrorOccurred event instead.", userVisible=false)
    public void VideoPlayerError(String string) {
    }

    @DesignerProperty(defaultValue="50", editorType="non_negative_float")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Sets the volume to a number between 0 and 100. Values less than 0 will be treated as 0, and values greater than 100 will be treated as 100.")
    public void Volume(int n) {
        n = Math.min((int)Math.max((int)n, (int)0), (int)100);
        MediaPlayer mediaPlayer = this.mPlayer;
        if (mediaPlayer != null) {
            mediaPlayer.setVolume((float)n / 100.0f, (float)n / 100.0f);
        }
    }

    @SimpleProperty
    public int Width() {
        return super.Width();
    }

    @SimpleProperty(userVisible=true)
    public void Width(int n) {
        super.Width(n);
        ResizableVideoView resizableVideoView = this.videoView;
        resizableVideoView.changeVideoSize(n, resizableVideoView.forcedHeight);
    }

    public void delayedStart() {
        this.delayedStart = true;
        this.Start();
    }

    public void fullScreenKilled(Bundle bundle) {
        this.inFullScreen = false;
        String string = bundle.getString("SourceKey");
        if (!string.equals((Object)this.sourcePath)) {
            this.Source(string);
        }
        this.videoView.setVisibility(0);
        this.videoView.requestLayout();
        this.SeekTo(bundle.getInt("PositionKey"));
        if (bundle.getBoolean("PlayingKey")) {
            this.Start();
        }
    }

    public int getPassedHeight() {
        return this.videoView.forcedHeight;
    }

    public int getPassedWidth() {
        return this.videoView.forcedWidth;
    }

    public View getView() {
        return this.videoView;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        this.Completed();
    }

    @Override
    public void onDelete() {
        this.prepareToDie();
    }

    @Override
    public void onDestroy() {
        this.prepareToDie();
    }

    public boolean onError(MediaPlayer object2, int n, int n2) {
        this.videoView.invalidateMediaPlayer(true);
        this.delayedStart = false;
        this.mediaReady = false;
        String string = Integer.toHexString((int)n);
        object2 = Integer.toHexString((int)n2);
        Log.e((String)"VideoPlayer", (String)("onError: what is " + n + " 0x" + string + ", extra is " + n2 + " 0x" + (String)object2));
        this.container.$form().dispatchErrorOccurredEvent((Component)this, "Source", 701, this.sourcePath);
        return true;
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        this.mediaReady = true;
        this.delayedStart = false;
        this.mPlayer = mediaPlayer;
        this.videoView.setMediaPlayer(mediaPlayer, true);
        if (this.delayedStart) {
            this.Start();
        }
    }
}

