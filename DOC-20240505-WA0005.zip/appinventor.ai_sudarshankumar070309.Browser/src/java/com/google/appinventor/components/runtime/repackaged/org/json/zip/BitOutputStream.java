/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime.repackaged.org.json.zip;

import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitInputStream;
import com.google.appinventor.components.runtime.repackaged.org.json.zip.BitWriter;
import java.io.IOException;
import java.io.OutputStream;

public class BitOutputStream
implements BitWriter {
    private long nrBits = 0L;
    private OutputStream out;
    private int unwritten;
    private int vacant = 8;

    public BitOutputStream(OutputStream outputStream) {
        this.out = outputStream;
    }

    public long nrBits() {
        return this.nrBits;
    }

    public void one() throws IOException {
        this.write(1, 1);
    }

    public void pad(int n) throws IOException {
        int n2 = n - (int)(this.nrBits % (long)n);
        int n3 = n2 & 7;
        n = n2;
        if (n3 > 0) {
            this.write(0, n3);
            n = n2 - n3;
        }
        while (n > 0) {
            this.write(0, 8);
            n -= 8;
        }
        this.out.flush();
    }

    public void write(int n, int n2) throws IOException {
        if (n == 0 && n2 == 0) {
            return;
        }
        if (n2 > 0 && n2 <= 32) {
            while (n2 > 0) {
                int n3;
                int n4 = n3 = n2;
                if (n3 > this.vacant) {
                    n4 = this.vacant;
                }
                int n5 = this.unwritten;
                int n6 = BitInputStream.mask[n4];
                n3 = this.vacant;
                this.unwritten = n5 |= (n >>> n2 - n4 & n6) << n3 - n4;
                n2 -= n4;
                this.nrBits += (long)n4;
                this.vacant = n4 = n3 - n4;
                if (n4 != 0) continue;
                this.out.write(n5);
                this.unwritten = 0;
                this.vacant = 8;
            }
            return;
        }
        IOException iOException = new IOException("Bad write width.");
        throw iOException;
    }

    public void zero() throws IOException {
        this.write(0, 1);
    }
}

