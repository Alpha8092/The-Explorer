/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONObject
 *  com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.Iterator
 */
package com.google.appinventor.components.runtime.repackaged.org.json;

import com.google.appinventor.components.runtime.repackaged.org.json.Cookie;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONException;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONObject;
import com.google.appinventor.components.runtime.repackaged.org.json.JSONTokener;
import java.util.Iterator;

public class CookieList {
    public static JSONObject toJSONObject(String string) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        string = new JSONTokener(string);
        while (string.more()) {
            String string2 = Cookie.unescape(string.nextTo('='));
            string.next('=');
            jSONObject.put(string2, (Object)Cookie.unescape(string.nextTo(';')));
            string.next();
        }
        return jSONObject;
    }

    public static String toString(JSONObject jSONObject) throws JSONException {
        boolean bl = false;
        Iterator iterator = jSONObject.keys();
        StringBuffer stringBuffer = new StringBuffer();
        while (iterator.hasNext()) {
            String string = iterator.next().toString();
            if (jSONObject.isNull(string)) continue;
            if (bl) {
                stringBuffer.append(';');
            }
            stringBuffer.append(Cookie.escape(string));
            stringBuffer.append("=");
            stringBuffer.append(Cookie.escape(jSONObject.getString(string)));
            bl = true;
        }
        return stringBuffer.toString();
    }
}

