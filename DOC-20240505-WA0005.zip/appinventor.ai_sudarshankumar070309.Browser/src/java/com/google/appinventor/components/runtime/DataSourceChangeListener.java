/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.appinventor.components.runtime.RealTimeDataSource
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.runtime.DataSource;
import com.google.appinventor.components.runtime.RealTimeDataSource;

public interface DataSourceChangeListener {
    public void onDataSourceValueChange(DataSource<?, ?> var1, String var2, Object var3);

    public void onReceiveValue(RealTimeDataSource<?, ?> var1, String var2, Object var3);
}

