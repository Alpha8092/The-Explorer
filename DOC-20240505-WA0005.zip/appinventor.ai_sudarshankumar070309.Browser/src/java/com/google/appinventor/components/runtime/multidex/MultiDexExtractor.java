/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.os.Build$VERSION
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.IOUtils
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileFilter
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipException
 *  java.util.zip.ZipFile
 *  java.util.zip.ZipOutputStream
 */
package com.google.appinventor.components.runtime.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import com.google.appinventor.components.runtime.multidex.ZipUtil;
import com.google.appinventor.components.runtime.util.IOUtils;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class MultiDexExtractor {
    private static final int BUFFER_SIZE = 16384;
    private static final String DEX_PREFIX = "classes";
    private static final String DEX_SUFFIX = ".dex";
    private static final String EXTRACTED_NAME_EXT = ".classes";
    private static final String EXTRACTED_SUFFIX = ".zip";
    private static final String KEY_CRC = "crc";
    private static final String KEY_DEX_NUMBER = "dex.number";
    private static final String KEY_TIME_STAMP = "timestamp";
    private static final int MAX_EXTRACT_ATTEMPTS = 3;
    private static final long NO_VALUE = -1L;
    private static final String PREFS_FILE = "multidex.version";
    private static final String TAG = "MultiDex";
    private static Method sApplyMethod;

    static {
        try {
            sApplyMethod = SharedPreferences.Editor.class.getMethod("apply", new Class[0]);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            sApplyMethod = null;
        }
    }

    MultiDexExtractor() {
    }

    private static void apply(SharedPreferences.Editor editor) {
        Method method = sApplyMethod;
        if (method != null) {
            try {
                method.invoke((Object)editor, new Object[0]);
                return;
            }
            catch (IllegalAccessException illegalAccessException) {
            }
            catch (InvocationTargetException invocationTargetException) {
                // empty catch block
            }
        }
        editor.commit();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void extract(ZipFile zipFile, ZipEntry object, File file, String string) throws IOException, FileNotFoundException {
        zipFile = zipFile.getInputStream(object);
        string = File.createTempFile((String)string, (String)EXTRACTED_SUFFIX, (File)file.getParentFile());
        String string2 = string.getPath();
        Log.i((String)TAG, (String)("Extracting " + string2));
        FileOutputStream fileOutputStream = new FileOutputStream((File)string);
        Object object2 = new BufferedOutputStream((OutputStream)fileOutputStream);
        string2 = new ZipOutputStream((OutputStream)object2);
        object2 = new ZipEntry("classes.dex");
        object2.setTime(object.getTime());
        string2.putNextEntry((ZipEntry)object2);
        object = new byte[16384];
        int n = zipFile.read((byte[])object);
        while (n != -1) {
            string2.write((byte[])object, 0, n);
            n = zipFile.read((byte[])object);
        }
        string2.closeEntry();
        {
            catch (Throwable throwable) {
                string2.close();
                throw throwable;
            }
        }
        try {
            string2.close();
            string2 = file.getPath();
            object = new StringBuilder();
            Log.i((String)TAG, (String)object.append("Renaming to ").append(string2).toString());
            boolean bl = string.renameTo(file);
            if (bl) {
                return;
            }
            string2 = string.getAbsolutePath();
            object2 = file.getAbsolutePath();
            file = new StringBuilder();
            object = new IOException(file.append("Failed to rename \"").append(string2).append("\" to \"").append((String)object2).append("\"").toString());
            throw object;
        }
        catch (Throwable throwable) {
            throw throwable;
        }
        finally {
            IOUtils.closeQuietly((String)TAG, (Closeable)zipFile);
            string.delete();
        }
    }

    private static SharedPreferences getMultiDexPreferences(Context context) {
        int n = Build.VERSION.SDK_INT < 11 ? 0 : 4;
        return context.getSharedPreferences(PREFS_FILE, n);
    }

    private static long getTimeStamp(File file) {
        long l;
        long l2 = l = file.lastModified();
        if (l == -1L) {
            l2 = l - 1L;
        }
        return l2;
    }

    private static long getZipCrc(File file) throws IOException {
        long l;
        long l2 = l = ZipUtil.getZipCrc(file);
        if (l == -1L) {
            l2 = l - 1L;
        }
        return l2;
    }

    private static boolean isModified(Context context, File file, long l) {
        boolean bl = (context = MultiDexExtractor.getMultiDexPreferences(context)).getLong(KEY_TIME_STAMP, -1L) != MultiDexExtractor.getTimeStamp(file) || context.getLong(KEY_CRC, -1L) != l;
        return bl;
    }

    static List<File> load(Context list, ApplicationInfo list2, File file, boolean bl) throws IOException {
        String string = list2.sourceDir;
        Log.i((String)TAG, (String)("MultiDexExtractor.load(" + string + ", " + bl + ")"));
        string = new File(list2.sourceDir);
        long l = MultiDexExtractor.getZipCrc((File)string);
        if (!bl && !MultiDexExtractor.isModified((Context)list, (File)string, l)) {
            try {
                list = list2 = MultiDexExtractor.loadExistingExtractions((Context)list, (File)string, file);
            }
            catch (IOException iOException) {
                Log.w((String)TAG, (String)"Failed to reload existing extracted secondary dex files, falling back to fresh extraction", (Throwable)iOException);
                List<File> list3 = MultiDexExtractor.performExtractions((File)string, file);
                MultiDexExtractor.putStoredApkInfo(list, MultiDexExtractor.getTimeStamp((File)string), l, list3.size() + 1);
                list = list3;
            }
        } else {
            Log.i((String)TAG, (String)"Detected that extraction must be performed.");
            list2 = MultiDexExtractor.performExtractions((File)string, file);
            MultiDexExtractor.putStoredApkInfo(list, MultiDexExtractor.getTimeStamp((File)string), l, list2.size() + 1);
            list = list2;
        }
        int n = list.size();
        Log.i((String)TAG, (String)("load found " + n + " secondary dex files"));
        return list;
    }

    private static List<File> loadExistingExtractions(Context object, File object2, File file) throws IOException {
        Log.i((String)TAG, (String)"loading existing secondary dex files");
        object2 = object2.getName();
        object2 = (String)object2 + EXTRACTED_NAME_EXT;
        int n = MultiDexExtractor.getMultiDexPreferences(object).getInt(KEY_DEX_NUMBER, 1);
        object = new ArrayList(n);
        for (int i = 2; i <= n; ++i) {
            File file2 = new File(file, (String)object2 + i + EXTRACTED_SUFFIX);
            if (file2.isFile()) {
                object.add((Object)file2);
                if (MultiDexExtractor.verifyZipFile(file2)) {
                    continue;
                }
                Log.i((String)TAG, (String)("Invalid zip file: " + file2));
                throw new IOException("Invalid ZIP file.");
            }
            object = file2.getPath();
            throw new IOException("Missing extracted secondary dex file '" + (String)object + "'");
        }
        return object;
    }

    public static boolean mustLoad(Context context, ApplicationInfo applicationInfo) {
        applicationInfo = new File(applicationInfo.sourceDir);
        try {
            boolean bl = MultiDexExtractor.isModified(context, (File)applicationInfo, MultiDexExtractor.getZipCrc((File)applicationInfo));
            if (bl) {
                return true;
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
        return false;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static List<File> performExtractions(File var0_2, File var1) throws IOException {
        block14: {
            block13: {
                block15: {
                    block12: {
                        var6_7 = var0_2 /* !! */ .getName();
                        var8_8 = var6_7 + ".classes";
                        MultiDexExtractor.prepareDexDir(var1 /* !! */ , var8_8);
                        var11_9 = new ArrayList();
                        var10_10 = new ZipFile(var0_2 /* !! */ );
                        var2_11 = 2;
                        var6_7 = var8_8;
                        try {
                            var6_7 = var8_8;
                            var0_2 /* !! */  = new StringBuilder();
                            var6_7 = var8_8;
                            var7_12 = var10_10.getEntry(var0_2 /* !! */ .append("classes").append(2).append(".dex").toString());
                            var0_2 /* !! */  = var8_8;
lbl14:
                            // 2 sources

                            while (var7_12 != null) {
                                var6_7 = var0_2 /* !! */ ;
                                var6_7 = var0_2 /* !! */ ;
                                var8_8 = new StringBuilder();
                                var6_7 = var0_2 /* !! */ ;
                                var8_8 = var8_8.append((String)var0_2 /* !! */ ).append(var2_11).append(".zip").toString();
                                var6_7 = var0_2 /* !! */ ;
                                var6_7 = var0_2 /* !! */ ;
                                var12_17 = new File(var1 /* !! */ , var8_8);
                                var6_7 = var0_2 /* !! */ ;
                                var11_9.add((Object)var12_17);
                                var6_7 = var0_2 /* !! */ ;
                                var6_7 = var0_2 /* !! */ ;
                                var9_16 /* !! */  = new StringBuilder();
                                var6_7 = var0_2 /* !! */ ;
                                Log.i((String)"MultiDex", (String)var9_16 /* !! */ .append("Extraction is needed for file ").append((Object)var12_17).toString());
                                var14_18 = false;
                                break block12;
                            }
                            break block13;
                        }
                        catch (Throwable var0_5) {
                            // empty catch block
                            break block14;
                        }
                    }
                    for (var3_14 = 0; var3_14 < 3 && !var14_18; ++var3_14) {
                        var6_7 = var0_2 /* !! */ ;
                        {
                            MultiDexExtractor.extract(var10_10, var7_12, var12_17, (String)var0_2 /* !! */ );
                            var6_7 = var0_2 /* !! */ ;
                            var14_18 = MultiDexExtractor.verifyZipFile(var12_17);
                            var9_16 /* !! */  = var14_18 != false ? "success" : "failed";
                            var6_7 = var0_2 /* !! */ ;
                            var13_13 = var12_17.getAbsolutePath();
                            var6_7 = var0_2 /* !! */ ;
                            var4_15 = var12_17.length();
                        }
                        try {
                            var6_7 = new StringBuilder();
                            Log.i((String)"MultiDex", (String)var6_7.append("Extraction ").append((String)var9_16 /* !! */ ).append(" - length ").append(var13_13).append(": ").append(var4_15).toString());
                            if (var14_18) continue;
                            var12_17.delete();
                            if (!var12_17.exists()) continue;
                            var6_7 = var12_17.getPath();
                            var9_16 /* !! */  = new StringBuilder();
                            Log.w((String)"MultiDex", (String)var9_16 /* !! */ .append("Failed to delete corrupted secondary dex '").append(var6_7).append("'").toString());
                            continue;
                        }
                        catch (Throwable var0_3) {
                            break block14;
                        }
                    }
                    if (!var14_18) break block15;
                    var6_7 = new StringBuilder();
                    var7_12 = var10_10.getEntry(var6_7.append("classes").append(++var2_11).append(".dex").toString());
                    ** GOTO lbl14
                }
                var1 /* !! */  = var12_17.getAbsolutePath();
                var6_7 = new StringBuilder();
                var0_2 /* !! */  = new IOException(var6_7.append("Could not create zip file ").append((String)var1 /* !! */ ).append(" for secondary dex (").append(var2_11).append(")").toString());
                throw var0_2 /* !! */ ;
            }
            try {
                var10_10.close();
                return var11_9;
            }
            catch (IOException var0_4) {
                Log.w((String)"MultiDex", (String)"Failed to close resource", (Throwable)var0_4);
            }
            return var11_9;
        }
        try {
            var10_10.close();
            throw var0_6;
        }
        catch (IOException var1_1) {
            Log.w((String)"MultiDex", (String)"Failed to close resource", (Throwable)var1_1);
            throw var0_6;
        }
    }

    private static void prepareDexDir(File object2, String fileArray) throws IOException {
        object2.mkdirs();
        if (object2.isDirectory()) {
            if ((fileArray = object2.listFiles(new FileFilter((String)fileArray){
                final String val$extractedFilePrefix;
                {
                    this.val$extractedFilePrefix = string;
                }

                public boolean accept(File file) {
                    return file.getName().startsWith(this.val$extractedFilePrefix) ^ true;
                }
            })) == null) {
                object2 = object2.getPath();
                Log.w((String)TAG, (String)("Failed to list secondary dex dir content (" + (String)object2 + ")."));
                return;
            }
            for (Object object2 : fileArray) {
                String string = object2.getPath();
                long l = object2.length();
                Log.i((String)TAG, (String)("Trying to delete old file " + string + " of size " + l));
                if (!object2.delete()) {
                    object2 = object2.getPath();
                    Log.w((String)TAG, (String)("Failed to delete old file " + (String)object2));
                    continue;
                }
                object2 = object2.getPath();
                Log.i((String)TAG, (String)("Deleted old file " + (String)object2));
            }
            return;
        }
        object2 = object2.getPath();
        object2 = new IOException("Failed to create dex directory " + (String)object2);
        throw object2;
    }

    private static void putStoredApkInfo(Context context, long l, long l2, int n) {
        context = MultiDexExtractor.getMultiDexPreferences(context).edit();
        context.putLong(KEY_TIME_STAMP, l);
        context.putLong(KEY_CRC, l2);
        context.putInt(KEY_DEX_NUMBER, n);
        MultiDexExtractor.apply((SharedPreferences.Editor)context);
    }

    /*
     * Enabled aggressive exception aggregation
     */
    static boolean verifyZipFile(File object) {
        try {
            ZipFile zipFile = new ZipFile((File)object);
            try {
                zipFile.close();
                return true;
            }
            catch (IOException iOException) {
                try {
                    String string = object.getAbsolutePath();
                    StringBuilder stringBuilder = new StringBuilder();
                    Log.w((String)TAG, (String)stringBuilder.append("Failed to close zip file: ").append(string).toString());
                }
                catch (IOException iOException2) {
                    object = object.getAbsolutePath();
                    Log.w((String)TAG, (String)("Got an IOException trying to open zip file: " + (String)object), (Throwable)iOException2);
                }
            }
        }
        catch (ZipException zipException) {
            object = object.getAbsolutePath();
            Log.w((String)TAG, (String)("File " + (String)object + " is not a valid zip file."), (Throwable)zipException);
        }
        return false;
    }
}

