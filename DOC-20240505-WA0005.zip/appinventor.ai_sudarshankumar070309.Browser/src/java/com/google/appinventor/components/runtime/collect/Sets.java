/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.SortedSet
 *  java.util.TreeSet
 */
package com.google.appinventor.components.runtime.collect;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class Sets {
    public static <K> HashSet<K> newHashSet() {
        return new HashSet();
    }

    public static <E> HashSet<E> newHashSet(E ... EArray) {
        HashSet hashSet = new HashSet(EArray.length * 4 / 3 + 1);
        Collections.addAll((Collection)hashSet, (Object[])EArray);
        return hashSet;
    }

    public static <E> SortedSet<E> newSortedSet(E ... EArray) {
        TreeSet treeSet = new TreeSet();
        Collections.addAll((Collection)treeSet, (Object[])EArray);
        return treeSet;
    }
}

