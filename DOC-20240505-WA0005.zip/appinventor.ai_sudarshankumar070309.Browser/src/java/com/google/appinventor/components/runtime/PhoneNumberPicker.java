/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentUris
 *  android.content.Intent
 *  android.database.Cursor
 *  android.net.Uri
 *  android.provider.Contacts$People
 *  android.provider.Contacts$Phones
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.HoneycombMR1Util
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.ContactPicker;
import com.google.appinventor.components.runtime.util.HoneycombMR1Util;
import com.google.appinventor.components.runtime.util.SdkLevel;
import java.util.ArrayList;

@DesignerComponent(category=ComponentCategory.SOCIAL, description="A button that, when clicked on, displays a list of the contacts' phone numbers to choose among. After the user has made a selection, the following properties will be set to information about the chosen contact: <ul>\n<li> <code>ContactName</code>: the contact's name </li>\n <li> <code>PhoneNumber</code>: the contact's phone number </li>\n <li> <code>EmailAddress</code>: the contact's email address </li> <li> <code>Picture</code>: the name of the file containing the contact's image, which can be used as a <code>Picture</code> property value for the <code>Image</code> or <code>ImageSprite</code> component.</li></ul>\n</p><p>Other properties affect the appearance of the button (<code>TextAlignment</code>, <code>BackgroundColor</code>, etc.) and whether it can be clicked on (<code>Enabled</code>).</p>\n<p>The PhoneNumberPicker component may not work on all Android devices. For example, on Android systems before system 3.0, the returned lists of phone numbers and email addresses will be empty.\n", iconName="images/phoneNumberPicker.png", version=4)
@SimpleObject
@UsesPermissions(permissionNames="android.permission.READ_CONTACTS")
public class PhoneNumberPicker
extends ContactPicker {
    private static String[] DATA_PROJECTION;
    private static final int EMAIL_INDEX = 3;
    private static final String LOG_TAG = "PhoneNumberPicker";
    private static final int NAME_INDEX = 0;
    private static String[] NAME_PROJECTION;
    private static final int NUMBER_INDEX = 1;
    private static final int PERSON_INDEX = 2;
    private static final String[] PROJECTION;

    static {
        PROJECTION = new String[]{"name", "number", "person", "primary_email"};
    }

    public PhoneNumberPicker(ComponentContainer componentContainer) {
        super(componentContainer, Contacts.Phones.CONTENT_URI);
    }

    @Override
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public String PhoneNumber() {
        return this.ensureNotNull(this.phoneNumber);
    }

    public void postHoneycombGetContactEmailsAndPhones(Cursor cursor) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (cursor.moveToFirst()) {
            int n = HoneycombMR1Util.getPhoneIndex((Cursor)cursor);
            int n2 = HoneycombMR1Util.getEmailIndex((Cursor)cursor);
            int n3 = HoneycombMR1Util.getMimeIndex((Cursor)cursor);
            String string2 = HoneycombMR1Util.getPhoneType();
            String string3 = HoneycombMR1Util.getEmailType();
            while (!cursor.isAfterLast()) {
                String string4 = this.guardCursorGetString(cursor, n3);
                if (string4.contains((CharSequence)string2)) {
                    arrayList.add((Object)this.guardCursorGetString(cursor, n));
                } else if (string4.contains((CharSequence)string3)) {
                    arrayList2.add((Object)this.guardCursorGetString(cursor, n2));
                } else {
                    Log.i((String)"ContactPicker", (String)("Type mismatch: " + string4 + " not " + string2 + " or " + string3));
                }
                cursor.moveToNext();
            }
            this.phoneNumberList = arrayList;
            this.emailAddressList = arrayList2;
            this.emailAddress = !this.emailAddressList.isEmpty() ? (String)this.emailAddressList.get(0) : "";
        }
    }

    @Override
    public String postHoneycombGetContactNameAndPicture(Cursor cursor) {
        String string2 = "";
        if (cursor.moveToFirst()) {
            int n = HoneycombMR1Util.getContactIdIndex((Cursor)cursor);
            int n2 = HoneycombMR1Util.getNameIndex((Cursor)cursor);
            int n3 = HoneycombMR1Util.getThumbnailIndex((Cursor)cursor);
            this.phoneNumber = this.guardCursorGetString(cursor, HoneycombMR1Util.getPhoneIndex((Cursor)cursor));
            string2 = this.guardCursorGetString(cursor, n);
            this.contactName = this.guardCursorGetString(cursor, n2);
            this.contactPictureUri = this.guardCursorGetString(cursor, n3);
        }
        return string2;
    }

    public void preHoneycombGetContactInfo(Cursor cursor) {
        if (cursor.moveToFirst()) {
            this.contactName = this.guardCursorGetString(cursor, 0);
            this.phoneNumber = this.guardCursorGetString(cursor, 1);
            int n = cursor.getInt(2);
            this.contactPictureUri = ContentUris.withAppendedId((Uri)Contacts.People.CONTENT_URI, (long)n).toString();
            this.emailAddress = this.getEmailAddress(this.guardCursorGetString(cursor, 3));
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void resultReturned(int n, int n2, Intent object) {
        block15: {
            block13: {
                Throwable throwable2222222;
                String string2;
                block11: {
                    String string3;
                    block14: {
                        String string4;
                        block10: {
                            if (n != this.requestCode || n2 != -1) break block15;
                            Log.i((String)LOG_TAG, (String)("received intent is " + object));
                            Uri uri = object.getData();
                            object = SdkLevel.getLevel() >= 12 ? "//com.android.contacts/data" : "//contacts/phones";
                            if (!this.checkContactUri(uri, (String)object)) break block13;
                            Object object2 = null;
                            Cursor cursor = null;
                            string4 = null;
                            String string5 = null;
                            String string6 = null;
                            object = cursor;
                            string2 = string4;
                            Cursor cursor2 = object2;
                            string3 = string5;
                            if (SdkLevel.getLevel() >= 12) {
                                object = cursor;
                                string2 = string4;
                                cursor2 = object2;
                                string3 = string5;
                                NAME_PROJECTION = HoneycombMR1Util.getNameProjection();
                                object = cursor;
                                string2 = string4;
                                cursor2 = object2;
                                string3 = string5;
                                cursor = this.activityContext.getContentResolver().query(uri, NAME_PROJECTION, null, null, null);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                string6 = this.postHoneycombGetContactNameAndPicture(cursor);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                DATA_PROJECTION = HoneycombMR1Util.getDataProjection();
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                string4 = HoneycombMR1Util.getDataCursor((String)string6, (Activity)this.activityContext, (String[])DATA_PROJECTION);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string4;
                                this.postHoneycombGetContactEmailsAndPhones((Cursor)string4);
                            } else {
                                object = cursor;
                                string2 = string4;
                                cursor2 = object2;
                                string3 = string5;
                                cursor = this.activityContext.getContentResolver().query(uri, PROJECTION, null, null, null);
                                object = cursor;
                                string2 = string4;
                                cursor2 = cursor;
                                string3 = string5;
                                this.preHoneycombGetContactInfo(cursor);
                                string4 = string6;
                            }
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            object2 = this.contactName;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            String string7 = this.phoneNumber;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            string6 = this.emailAddress;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            string5 = this.contactPictureUri;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            uri = new StringBuilder();
                            object = cursor;
                            string2 = string4;
                            cursor2 = cursor;
                            string3 = string4;
                            Log.i((String)LOG_TAG, (String)uri.append("Contact name = ").append((String)object2).append(", phone number = ").append(string7).append(", emailAddress = ").append(string6).append(", contactPhotoUri = ").append(string5).toString());
                            if (cursor == null) break block10;
                            {
                                block12: {
                                    catch (Throwable throwable2222222) {
                                        break block11;
                                    }
                                    catch (Exception exception) {}
                                    object = cursor2;
                                    string2 = string3;
                                    {
                                        Log.e((String)LOG_TAG, (String)"Exception in resultReturned", (Throwable)exception);
                                        object = cursor2;
                                        string2 = string3;
                                        this.puntContactSelection(1107);
                                        if (cursor2 == null) break block12;
                                    }
                                    cursor2.close();
                                }
                                if (string3 == null) break block13;
                                break block14;
                            }
                            cursor.close();
                        }
                        if (string4 == null) break block13;
                        string3 = string4;
                    }
                    string3.close();
                    break block13;
                }
                if (object != null) {
                    object.close();
                }
                if (string2 != null) {
                    string2.close();
                }
                throw throwable2222222;
            }
            this.AfterPicking();
        }
    }
}

