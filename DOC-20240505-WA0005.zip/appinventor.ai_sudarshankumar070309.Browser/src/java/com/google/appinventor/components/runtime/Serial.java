/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.physicaloid.lib.Physicaloid
 *  java.io.UnsupportedEncodingException
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.content.Context;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.physicaloid.lib.Physicaloid;
import java.io.UnsupportedEncodingException;

@DesignerComponent(androidMinSdk=12, category=ComponentCategory.CONNECTIVITY, description="Serial component which can be used to connect to devices like Arduino", iconName="images/arduino.png", nonVisible=true, version=1)
@SimpleObject
@UsesLibraries(libraries="physicaloid.jar")
public class Serial
extends AndroidNonvisibleComponent
implements Component {
    private static final String LOG_TAG = "Serial Component";
    private int baudRate = 9600;
    private int bytes = 256;
    private Context context;
    private Physicaloid mPhysicaloid;

    public Serial(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.context = componentContainer.$context();
        Log.d((String)LOG_TAG, (String)"Created");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the current baud rate")
    public int BaudRate() {
        return this.baudRate;
    }

    @DesignerProperty(defaultValue="9600", editorType="integer")
    @SimpleProperty
    public void BaudRate(int n) {
        this.baudRate = n;
        Log.d((String)LOG_TAG, (String)("Baud Rate: " + n));
        Physicaloid physicaloid = this.mPhysicaloid;
        if (physicaloid != null) {
            physicaloid.setBaudrate(n);
        } else {
            Log.w((String)LOG_TAG, (String)("Could not set Serial Baud Rate to " + n + ". Just saved, not applied to serial! Maybe you forgot to initialize it?"));
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns the buffer size in bytes")
    public int BufferSize() {
        return this.bytes;
    }

    @DesignerProperty(defaultValue="256", editorType="integer")
    @SimpleProperty
    public void BufferSize(int n) {
        this.bytes = n;
        Log.d((String)LOG_TAG, (String)("Buffer Size: " + n));
    }

    @SimpleFunction(description="Closes serial connection. Returns true when closed.")
    public boolean CloseSerial() {
        Log.d((String)LOG_TAG, (String)"Closing connection");
        Physicaloid physicaloid = this.mPhysicaloid;
        if (physicaloid == null) {
            this.form.dispatchErrorOccurredEvent(this, "CloseSerial", 3901, new Object[0]);
            return false;
        }
        return physicaloid.close();
    }

    @SimpleFunction(description="Initializes serial connection.")
    public void InitializeSerial() {
        this.mPhysicaloid = new Physicaloid(this.context);
        this.BaudRate(this.baudRate);
        Log.d((String)LOG_TAG, (String)"Initialized");
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns true when the Serial has been initialized.")
    public boolean IsInitialized() {
        boolean bl = this.mPhysicaloid != null;
        return bl;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Returns true when the Serial connection is open.")
    public boolean IsOpen() {
        Physicaloid physicaloid = this.mPhysicaloid;
        if (physicaloid == null) {
            this.form.dispatchErrorOccurredEvent(this, "IsOpen", 3901, new Object[0]);
            return false;
        }
        return physicaloid.isOpened();
    }

    @SimpleFunction(description="Opens serial connection. Returns true when opened.")
    public boolean OpenSerial() {
        Log.d((String)LOG_TAG, (String)"Opening connection");
        Physicaloid physicaloid = this.mPhysicaloid;
        if (physicaloid == null) {
            this.form.dispatchErrorOccurredEvent(this, "OpenSerial", 3901, new Object[0]);
            return false;
        }
        return physicaloid.open();
    }

    @SimpleFunction(description="Writes given data to serial, and appends a new line at the end.")
    public void PrintSerial(String string) {
        if (!string.isEmpty()) {
            this.WriteSerial(string + "\n");
        }
    }

    @SimpleFunction(description="Reads data from serial.")
    public String ReadSerial() {
        String string;
        String string2 = "";
        Physicaloid physicaloid = this.mPhysicaloid;
        if (physicaloid == null) {
            this.form.dispatchErrorOccurredEvent(this, "ReadSerial", 3901, new Object[0]);
            string = string2;
        } else {
            byte[] byArray = new byte[this.bytes];
            string = string2;
            if (physicaloid.read(byArray) > 0) {
                try {
                    string = new String(byArray, "UTF-8");
                }
                catch (UnsupportedEncodingException unsupportedEncodingException) {
                    Log.e((String)LOG_TAG, (String)unsupportedEncodingException.getMessage());
                    string = string2;
                }
            }
        }
        return string;
    }

    @SimpleFunction(description="Writes given data to serial.")
    public void WriteSerial(String object2) {
        block1: {
            block0: {
                if (object2.isEmpty() || this.mPhysicaloid == null) break block0;
                if (this.mPhysicaloid.write((byte[])(object2 = (Object)object2.getBytes())) != -1) break block1;
                this.form.dispatchErrorOccurredEvent((Component)this, "WriteSerial", 3902, new Object[0]);
                break block1;
            }
            if (this.mPhysicaloid != null) break block1;
            this.form.dispatchErrorOccurredEvent((Component)this, "WriteSerial", 3901, new Object[0]);
        }
    }
}

