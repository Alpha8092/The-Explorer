/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.charts.PieChart
 *  com.github.mikephil.charting.components.LegendEntry
 *  com.github.mikephil.charting.data.ChartData
 *  com.github.mikephil.charting.data.Entry
 *  com.github.mikephil.charting.data.PieData
 *  com.github.mikephil.charting.data.PieDataSet
 *  com.github.mikephil.charting.data.PieEntry
 *  com.github.mikephil.charting.interfaces.datasets.IDataSet
 *  com.github.mikephil.charting.interfaces.datasets.IPieDataSet
 *  com.google.appinventor.components.runtime.Chart2DDataModel
 *  com.google.appinventor.components.runtime.PieChartView
 *  com.google.appinventor.components.runtime.util.YailList
 *  java.io.Serializable
 *  java.lang.Float
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.interfaces.datasets.IDataSet;
import com.github.mikephil.charting.interfaces.datasets.IPieDataSet;
import com.google.appinventor.components.runtime.Chart2DDataModel;
import com.google.appinventor.components.runtime.ChartView;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.PieChartView;
import com.google.appinventor.components.runtime.util.YailList;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class PieChartDataModel
extends Chart2DDataModel<PieEntry, IPieDataSet, PieData, PieChart, PieChartView> {
    private final List<LegendEntry> legendEntries = new ArrayList();

    public PieChartDataModel(PieData pieData, PieChartView pieChartView, PieChart pieChart) {
        super((ChartData)pieData, (ChartView)pieChartView);
        this.dataset = new PieDataSet((List)new ArrayList(), "");
        ((PieData)this.data).addDataSet((IDataSet)((IPieDataSet)this.dataset));
        pieChart.setData((ChartData)pieData);
        this.setDefaultStylingProperties();
        this.view = pieChartView;
    }

    private void updateLegendColors() {
        for (int i = 0; i < this.legendEntries.size(); ++i) {
            int n = ((IPieDataSet)this.getDataset()).getColors().size();
            ((LegendEntry)this.legendEntries.get((int)i)).formColor = (Integer)((IPieDataSet)this.getDataset()).getColors().get(i % n);
        }
    }

    public void addEntryFromTuple(YailList yailList) {
        PieEntry pieEntry = (PieEntry)this.getEntryFromTuple(yailList);
        if (pieEntry != null) {
            this.entries.add((Object)pieEntry);
            pieEntry = new LegendEntry();
            pieEntry.label = yailList.getString(0);
            int n = this.entries.size();
            yailList = ((IPieDataSet)this.getDataset()).getColors();
            pieEntry.formColor = (Integer)yailList.get((n - 1) % yailList.size());
            this.legendEntries.add((Object)pieEntry);
            ((PieChartView)this.view).addLegendEntry((LegendEntry)pieEntry);
        }
    }

    protected boolean areEntriesEqual(Entry entry, Entry entry2) {
        boolean bl = entry instanceof PieEntry;
        boolean bl2 = false;
        if (bl && entry2 instanceof PieEntry) {
            entry = (PieEntry)entry;
            entry2 = (PieEntry)entry2;
            if (entry.getLabel().equals((Object)entry2.getLabel()) && entry.getY() == entry2.getY()) {
                bl2 = true;
            }
            return bl2;
        }
        return false;
    }

    public void clearEntries() {
        super.clearEntries();
        ((PieChartView)this.view).removeLegendEntries(this.legendEntries);
        this.legendEntries.clear();
    }

    public Entry getEntryFromTuple(YailList yailList) {
        String string = yailList.getString(0);
        String string2 = yailList.getString(1);
        try {
            PieEntry pieEntry = new PieEntry(Float.parseFloat((String)string2), string);
            return pieEntry;
        }
        catch (NumberFormatException numberFormatException) {
            try {
                ((PieChartView)this.view).getForm().dispatchErrorOccurredEvent((Component)((PieChartView)this.view).chartComponent, "GetEntryFromTuple", 4101, string, string2);
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                ((PieChartView)this.view).getForm().dispatchErrorOccurredEvent((Component)((PieChartView)this.view).chartComponent, "GetEntryFromTuple", 4103, this.getTupleSize(), yailList.size());
            }
            catch (NullPointerException nullPointerException) {
                ((PieChartView)this.view).getForm().dispatchErrorOccurredEvent((Component)((PieChartView)this.view).chartComponent, "GetEntryFromTuple", 4102, new Object[0]);
            }
        }
        return null;
    }

    public YailList getTupleFromEntry(Entry entry) {
        entry = (PieEntry)entry;
        return YailList.makeList((List)Arrays.asList((Object[])new Serializable[]{entry.getLabel(), Float.valueOf((float)entry.getY())}));
    }

    public void removeEntry(int n) {
        if (n >= 0) {
            this.entries.remove(n);
            LegendEntry legendEntry = (LegendEntry)this.legendEntries.remove(n);
            ((PieChartView)this.view).removeLegendEntry(legendEntry);
            super.updateLegendColors();
        }
    }

    public void setColor(int n) {
        this.setColors((List<Integer>)Collections.singletonList((Object)n));
    }

    public void setColors(List<Integer> list) {
        super.setColors(list);
        super.updateLegendColors();
    }

    protected void setDefaultStylingProperties() {
        if (this.dataset instanceof PieDataSet) {
            ((PieDataSet)this.dataset).setSliceSpace(3.0f);
        }
    }
}

