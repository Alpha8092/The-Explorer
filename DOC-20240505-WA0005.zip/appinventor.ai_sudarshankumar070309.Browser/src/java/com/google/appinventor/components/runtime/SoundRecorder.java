/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.media.MediaRecorder
 *  android.media.MediaRecorder$OnErrorListener
 *  android.media.MediaRecorder$OnInfoListener
 *  android.os.Environment
 *  android.util.Log
 *  com.google.appinventor.components.common.FileScope
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.SoundRecorder$1$1
 *  com.google.appinventor.components.runtime.util.BulkPermissionRequest
 *  com.google.appinventor.components.runtime.util.FileUtil
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.google.appinventor.components.runtime;

import android.media.MediaRecorder;
import android.os.Environment;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.SoundRecorder;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.util.BulkPermissionRequest;
import com.google.appinventor.components.runtime.util.FileUtil;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="<p>Multimedia component that records audio.</p>", iconName="images/soundRecorder.png", nonVisible=true, version=2)
@SimpleObject
@UsesPermissions(value={"android.permission.RECORD_AUDIO"})
public final class SoundRecorder
extends AndroidNonvisibleComponent
implements Component,
MediaRecorder.OnErrorListener,
MediaRecorder.OnInfoListener {
    private static final String TAG = "SoundRecorder";
    private RecordingController controller;
    private boolean havePermission = false;
    private String savedRecording = "";

    static /* bridge */ /* synthetic */ void -$$Nest$fputhavePermission(SoundRecorder soundRecorder, boolean bl) {
        soundRecorder.havePermission = bl;
    }

    public SoundRecorder(ComponentContainer componentContainer) {
        super(componentContainer.$form());
    }

    @SimpleEvent(description="Provides the location of the newly created sound.")
    public void AfterSoundRecorded(String string) {
        EventDispatcher.dispatchEvent((Component)this, "AfterSoundRecorded", string);
    }

    public void Initialize() {
        this.havePermission = this.form.isDeniedPermission("android.permission.RECORD_AUDIO") ^ true;
        if (FileUtil.needsWritePermission((FileScope)this.form.DefaultFileScope())) {
            this.havePermission &= this.form.isDeniedPermission("android.permission.WRITE_EXTERNAL_STORAGE") ^ true;
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Specifies the path to the file where the recording should be stored. If this property is the empty string, then starting a recording will create a file in an appropriate location.  If the property is not the empty string, it should specify a complete path to a file in an existing directory, including a file name with the extension .3gp.")
    public String SavedRecording() {
        return this.savedRecording;
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty
    public void SavedRecording(String string) {
        this.savedRecording = string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @SimpleFunction
    public void Start() {
        String[] stringArray = FileUtil.resolveFileName((Form)this.form, (String)this.savedRecording, (FileScope)this.form.DefaultFileScope());
        if (!this.havePermission) {
            stringArray = FileUtil.needsPermission((Form)this.form, (String)stringArray) ? new String[]{"android.permission.RECORD_AUDIO", "android.permission.WRITE_EXTERNAL_STORAGE"} : new String[]{"android.permission.RECORD_AUDIO"};
            this.form.runOnUiThread(new Runnable(this, this, stringArray){
                final SoundRecorder this$0;
                final SoundRecorder val$me;
                final String[] val$neededPermissions;
                {
                    this.this$0 = soundRecorder;
                    this.val$me = soundRecorder2;
                    this.val$neededPermissions = stringArray;
                }

                public void run() {
                    this.this$0.form.askPermission((BulkPermissionRequest)new 1(this, (Component)this.val$me, "Start", this.val$neededPermissions));
                }
            });
            return;
        }
        RecordingController recordingController = this.controller;
        if (recordingController != null) {
            stringArray = recordingController.file;
            Log.i((String)TAG, (String)("Start() called, but already recording to " + (String)stringArray));
            return;
        }
        Log.i((String)TAG, (String)"Start() called");
        if (FileUtil.isExternalStorageUri((Form)this.form, (String)stringArray) && !Environment.getExternalStorageState().equals((Object)"mounted")) {
            this.form.dispatchErrorOccurredEvent(this, "Start", 705, new Object[0]);
            return;
        }
        try {
            this.controller = stringArray = new Object(this, this.savedRecording){
                final String file;
                final MediaRecorder recorder;
                final SoundRecorder this$0;
                {
                    MediaRecorder mediaRecorder;
                    this.this$0 = soundRecorder;
                    if (string.equals((Object)"")) {
                        string = FileUtil.getRecordingFile((Form)soundRecorder.form, (String)"3gp").getAbsolutePath();
                    }
                    this.file = string;
                    this.recorder = mediaRecorder = new MediaRecorder();
                    mediaRecorder.setAudioSource(1);
                    mediaRecorder.setOutputFormat(1);
                    mediaRecorder.setAudioEncoder(1);
                    Log.i((String)SoundRecorder.TAG, (String)("Setting output file to " + string));
                    mediaRecorder.setOutputFile(string);
                    Log.i((String)SoundRecorder.TAG, (String)"preparing");
                    mediaRecorder.prepare();
                    mediaRecorder.setOnErrorListener((MediaRecorder.OnErrorListener)soundRecorder);
                    mediaRecorder.setOnInfoListener((MediaRecorder.OnInfoListener)soundRecorder);
                }

                void start() throws IllegalStateException {
                    Log.i((String)SoundRecorder.TAG, (String)"starting");
                    try {
                        this.recorder.start();
                        return;
                    }
                    catch (IllegalStateException illegalStateException) {
                        Log.e((String)SoundRecorder.TAG, (String)"got IllegalStateException. Are there two recorders running?", (Throwable)illegalStateException);
                        throw new IllegalStateException("Is there another recording running?");
                    }
                }

                void stop() {
                    this.recorder.setOnErrorListener(null);
                    this.recorder.setOnInfoListener(null);
                    this.recorder.stop();
                    this.recorder.reset();
                    this.recorder.release();
                }
            };
        }
        catch (Throwable throwable) {
            Log.e((String)TAG, (String)"Cannot record sound", (Throwable)throwable);
            this.form.dispatchErrorOccurredEvent(this, "Start", 802, throwable.getMessage());
            return;
        }
        catch (PermissionException permissionException) {
            this.form.dispatchPermissionDeniedEvent((Component)this, "Start", permissionException);
            return;
        }
        try {
            stringArray.start();
        }
        catch (Throwable throwable) {
            this.controller = null;
            Log.e((String)TAG, (String)"Cannot record sound", (Throwable)throwable);
            this.form.dispatchErrorOccurredEvent(this, "Start", 802, throwable.getMessage());
            return;
        }
        this.StartedRecording();
    }

    @SimpleEvent(description="Indicates that the recorder has started, and can be stopped.")
    public void StartedRecording() {
        EventDispatcher.dispatchEvent(this, "StartedRecording", new Object[0]);
    }

    @SimpleFunction
    public void Stop() {
        if (this.controller == null) {
            Log.i((String)TAG, (String)"Stop() called, but already stopped.");
            return;
        }
        try {
            Log.i((String)TAG, (String)"Stop() called");
            Log.i((String)TAG, (String)"stopping");
            this.controller.stop();
            String string = this.controller.file;
            StringBuilder stringBuilder = new StringBuilder();
            Log.i((String)TAG, (String)stringBuilder.append("Firing AfterSoundRecorded with ").append(string).toString());
            this.AfterSoundRecorded(this.controller.file);
        }
        catch (Throwable throwable) {
            this.form.dispatchErrorOccurredEvent(this, "Stop", 801, new Object[0]);
        }
        return;
        {
            finally {
                this.controller = null;
                this.StoppedRecording();
            }
        }
    }

    @SimpleEvent(description="Indicates that the recorder has stopped, and can be started again.")
    public void StoppedRecording() {
        EventDispatcher.dispatchEvent(this, "StoppedRecording", new Object[0]);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onError(MediaRecorder mediaRecorder, int n, int n2) {
        RecordingController recordingController = this.controller;
        if (recordingController != null && mediaRecorder == recordingController.recorder) {
            this.form.dispatchErrorOccurredEvent((Component)this, "onError", 801, new Object[0]);
            try {
                this.controller.stop();
                return;
            }
            catch (Throwable throwable) {
                try {
                    Log.w((String)TAG, (String)throwable.getMessage());
                    return;
                }
                finally {
                    this.controller = null;
                    this.StoppedRecording();
                }
            }
        }
        Log.w((String)TAG, (String)"onError called with wrong recorder. Ignoring.");
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onInfo(MediaRecorder var1, int var2_5, int var3_4) {
        var4_6 = this.controller;
        if (var4_6 != null && var1 == var4_6.recorder) {
            block11: {
                switch (var2_5) {
                    default: {
                        return;
                    }
                    case 801: {
                        this.form.dispatchErrorOccurredEvent((Component)this, "recording", 805, new Object[0]);
                        break;
                    }
                    case 800: {
                        this.form.dispatchErrorOccurredEvent((Component)this, "recording", 804, new Object[0]);
                        break;
                    }
                    case 1: {
                        this.form.dispatchErrorOccurredEvent((Component)this, "recording", 801, new Object[0]);
                    }
                }
                Log.i((String)"SoundRecorder", (String)"Recoverable condition while recording. Will attempt to stop normally.");
                this.controller.recorder.stop();
lbl18:
                // 2 sources

                while (true) {
                    this.controller = null;
                    break;
                }
                {
                    catch (Throwable var1_1) {
                        break block11;
                    }
                    catch (IllegalStateException var1_2) {}
                    {
                        Log.i((String)"SoundRecorder", (String)"SoundRecorder was not in a recording state.", (Throwable)var1_2);
                        this.form.dispatchErrorOccurredEventDialog((Component)this, "Stop", 803, new Object[0]);
                        ** continue;
                    }
                }
                this.StoppedRecording();
                return;
            }
            this.controller = null;
            this.StoppedRecording();
            throw var1_1;
        }
        Log.w((String)"SoundRecorder", (String)"onInfo called with wrong recorder. Ignoring.");
    }
}

