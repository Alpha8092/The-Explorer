/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.runtime.Component;

public interface HandlesEventDispatching {
    public boolean canDispatchEvent(Component var1, String var2);

    public void dispatchErrorOccurredEvent(Component var1, String var2, int var3, Object ... var4);

    public boolean dispatchEvent(Component var1, String var2, String var3, Object[] var4);

    public void dispatchGenericEvent(Component var1, String var2, boolean var3, Object[] var4);
}

