/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.util.Log
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.util.AsynchUtil
 *  com.google.appinventor.components.runtime.util.Base58Util
 *  java.io.ByteArrayInputStream
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.security.KeyStore
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateFactory
 *  java.security.cert.X509Certificate
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 *  javax.net.ssl.TrustManagerFactory
 *  javax.net.ssl.X509TrustManager
 */
package com.google.appinventor.components.runtime;

import android.app.Activity;
import android.util.Log;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.translate.TranslatorToken;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.Base58Util;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MEDIA, description="Use this component to translate words and sentences between differentlanguages. This component needs Internet access, as it will requesttranslations from a server at MIT (which in turn will requesttranslations from a commercial translation service).  Specify thesource and target language in the form source-target using two letterlanguage codes.  So \"en-es\" will translate from English to Spanishwhile \"es-ru\" will translate from Spanish to Russian. If you leave outthe source language, the service will attempt to detect the sourcelanguage. So providing just \"es\" will attempt to detect the sourcelanguage and translate it to Spanish.  <i>Note</i>: Translationhappens asynchronously in the background. When the translation iscomplete, the <b>GotTranslation(String, String)</b> event istriggered.", iconName="images/translator.png", nonVisible=true, version=1)
@SimpleObject
@UsesLibraries(libraries="protobuf-java-3.0.0.jar")
@UsesPermissions(permissionNames="android.permission.INTERNET")
public final class Translator
extends AndroidNonvisibleComponent {
    private static final String COMODO_ROOT = "-----BEGIN CERTIFICATE-----\nMIIENjCCAx6gAwIBAgIBATANBgkqhkiG9w0BAQUFADBvMQswCQYDVQQGEwJTRTEU\nMBIGA1UEChMLQWRkVHJ1c3QgQUIxJjAkBgNVBAsTHUFkZFRydXN0IEV4dGVybmFs\nIFRUUCBOZXR3b3JrMSIwIAYDVQQDExlBZGRUcnVzdCBFeHRlcm5hbCBDQSBSb290\nMB4XDTAwMDUzMDEwNDgzOFoXDTIwMDUzMDEwNDgzOFowbzELMAkGA1UEBhMCU0Ux\nFDASBgNVBAoTC0FkZFRydXN0IEFCMSYwJAYDVQQLEx1BZGRUcnVzdCBFeHRlcm5h\nbCBUVFAgTmV0d29yazEiMCAGA1UEAxMZQWRkVHJ1c3QgRXh0ZXJuYWwgQ0EgUm9v\ndDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALf3GjPm8gAELTngTlvt\nH7xsD821+iO2zt6bETOXpClMfZOfvUq8k+0DGuOPz+VtUFrWlymUWoCwSXrbLpX9\nuMq/NzgtHj6RQa1wVsfwTz/oMp50ysiQVOnGXw94nZpAPA6sYapeFI+eh6FqUNzX\nmk6vBbOmcZSccbNQYArHE504B4YCqOmoaSYYkKtMsE8jqzpPhNjfzp/haW+710LX\na0Tkx63ubUFfclpxCDezeWWkWaCUN/cALw3CknLa0Dhy2xSoRcRdKn23tNbE7qzN\nE0S3ySvdQwAl+mG5aWpYIxG3pzOPVnVZ9c0p10a3CitlttNCbxWyuHv77+ldU9U0\nWicCAwEAAaOB3DCB2TAdBgNVHQ4EFgQUrb2YejS0Jvf6xCZU7wO94CTLVBowCwYD\nVR0PBAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wgZkGA1UdIwSBkTCBjoAUrb2YejS0\nJvf6xCZU7wO94CTLVBqhc6RxMG8xCzAJBgNVBAYTAlNFMRQwEgYDVQQKEwtBZGRU\ncnVzdCBBQjEmMCQGA1UECxMdQWRkVHJ1c3QgRXh0ZXJuYWwgVFRQIE5ldHdvcmsx\nIjAgBgNVBAMTGUFkZFRydXN0IEV4dGVybmFsIENBIFJvb3SCAQEwDQYJKoZIhvcN\nAQEFBQADggEBALCb4IUlwtYj4g+WBpKdQZic2YR5gdkeWxQHIzZlj7DYd7usQWxH\nYINRsPkyPef89iYTx4AWpb9a/IfPeHmJIZriTAcKhjW88t5RxNKWt9x+Tu5w/Rw5\n6wwCURQtjr0W4MHfRnXnJK3s9EK0hZNwEGe6nQY1ShjTK3rMUUKhemPR5ruhxSvC\nNr4TDea9Y355e6cJDUCrat2PisP29owaQgVR1EX1n6diIWgVIEM8med8vSTYqZEX\nc4g/VhsxOBi0cQ+azcgOno4uG+GMmIPLHzHxREzGBHNJdmAPx/i9F4BrLunMTA5a\nmnkPIAou1Z5jJh5VkpTYghdae9C8x49OhgQ=\n-----END CERTIFICATE-----\n";
    private static final String COMODO_USRTRUST = "-----BEGIN CERTIFICATE-----\nMIIFdzCCBF+gAwIBAgIQE+oocFv07O0MNmMJgGFDNjANBgkqhkiG9w0BAQwFADBv\nMQswCQYDVQQGEwJTRTEUMBIGA1UEChMLQWRkVHJ1c3QgQUIxJjAkBgNVBAsTHUFk\nZFRydXN0IEV4dGVybmFsIFRUUCBOZXR3b3JrMSIwIAYDVQQDExlBZGRUcnVzdCBF\neHRlcm5hbCBDQSBSb290MB4XDTAwMDUzMDEwNDgzOFoXDTIwMDUzMDEwNDgzOFow\ngYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5MRQwEgYDVQQHEwtK\nZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBOZXR3b3JrMS4wLAYD\nVQQDEyVVU0VSVHJ1c3QgUlNBIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MIICIjAN\nBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAgBJlFzYOw9sIs9CsVw127c0n00yt\nUINh4qogTQktZAnczomfzD2p7PbPwdzx07HWezcoEStH2jnGvDoZtF+mvX2do2NC\ntnbyqTsrkfjib9DsFiCQCT7i6HTJGLSR1GJk23+jBvGIGGqQIjy8/hPwhxR79uQf\njtTkUcYRZ0YIUcuGFFQ/vDP+fmyc/xadGL1RjjWmp2bIcmfbIWax1Jt4A8BQOujM\n8Ny8nkz+rwWWNR9XWrf/zvk9tyy29lTdyOcSOk2uTIq3XJq0tyA9yn8iNK5+O2hm\nAUTnAU5GU5szYPeUvlM3kHND8zLDU+/bqv50TmnHa4xgk97Exwzf4TKuzJM7UXiV\nZ4vuPVb+DNBpDxsP8yUmazNt925H+nND5X4OpWaxKXwyhGNVicQNwZNUMBkTrNN9\nN6frXTpsNVzbQdcS2qlJC9/YgIoJk2KOtWbPJYjNhLixP6Q5D9kCnusSTJV882sF\nqV4Wg8y4Z+LoE53MW4LTTLPtW//e5XOsIzstAL81VXQJSdhJWBp/kjbmUZIO8yZ9\nHE0XvMnsQybQv0FfQKlERPSZ51eHnlAfV1SoPv10Yy+xUGUJ5lhCLkMaTLTwJUdZ\n+gQek9QmRkpQgbLevni3/GcV4clXhB4PY9bpYrrWX1Uu6lzGKAgEJTm4Diup8kyX\nHAc/DVL17e8vgg8CAwEAAaOB9DCB8TAfBgNVHSMEGDAWgBStvZh6NLQm9/rEJlTv\nA73gJMtUGjAdBgNVHQ4EFgQUU3m/WqorSs9UgOHYm8Cd8rIDZsswDgYDVR0PAQH/\nBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8wEQYDVR0gBAowCDAGBgRVHSAAMEQGA1Ud\nHwQ9MDswOaA3oDWGM2h0dHA6Ly9jcmwudXNlcnRydXN0LmNvbS9BZGRUcnVzdEV4\ndGVybmFsQ0FSb290LmNybDA1BggrBgEFBQcBAQQpMCcwJQYIKwYBBQUHMAGGGWh0\ndHA6Ly9vY3NwLnVzZXJ0cnVzdC5jb20wDQYJKoZIhvcNAQEMBQADggEBAJNl9jeD\nlQ9ew4IcH9Z35zyKwKoJ8OkLJvHgwmp1ocd5yblSYMgpEg7wrQPWCcR23+WmgZWn\nRtqCV6mVksW2jwMibDN3wXsyF24HzloUQToFJBv2FAY7qCUkDrvMKnXduXBBP3zQ\nYzYhBx9G/2CkkeFnvN4ffhkUyWNnkepnB2u0j4vAbkN9w6GAbLIevFOFfdyQoaS8\nLe9Gclc1Bb+7RrtubTeZtv8jkpHGbkD4jylW6l/VXxRTrPBPYer3IsynVgviuDQf\nJtl7GQVoP7o81DgGotPmjw7jtHFtQELFhLRAlSv0ZaBIefYdgWOWnU914Ph85I6p\n0fKtirOMxyHNwu8=\n-----END CERTIFICATE-----\n";
    private static final boolean DEBUG = false;
    private static final String ISRG_ROOT_X1 = "-----BEGIN CERTIFICATE-----\nMIIFazCCA1OgAwIBAgIRAIIQz7DSQONZRGPgu2OCiwAwDQYJKoZIhvcNAQELBQAw\nTzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\ncmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMTUwNjA0MTEwNDM4\nWhcNMzUwNjA0MTEwNDM4WjBPMQswCQYDVQQGEwJVUzEpMCcGA1UEChMgSW50ZXJu\nZXQgU2VjdXJpdHkgUmVzZWFyY2ggR3JvdXAxFTATBgNVBAMTDElTUkcgUm9vdCBY\nMTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAK3oJHP0FDfzm54rVygc\nh77ct984kIxuPOZXoHj3dcKi/vVqbvYATyjb3miGbESTtrFj/RQSa78f0uoxmyF+\n0TM8ukj13Xnfs7j/EvEhmkvBioZxaUpmZmyPfjxwv60pIgbz5MDmgK7iS4+3mX6U\nA5/TR5d8mUgjU+g4rk8Kb4Mu0UlXjIB0ttov0DiNewNwIRt18jA8+o+u3dpjq+sW\nT8KOEUt+zwvo/7V3LvSye0rgTBIlDHCNAymg4VMk7BPZ7hm/ELNKjD+Jo2FR3qyH\nB5T0Y3HsLuJvW5iB4YlcNHlsdu87kGJ55tukmi8mxdAQ4Q7e2RCOFvu396j3x+UC\nB5iPNgiV5+I3lg02dZ77DnKxHZu8A/lJBdiB3QW0KtZB6awBdpUKD9jf1b0SHzUv\nKBds0pjBqAlkd25HN7rOrFleaJ1/ctaJxQZBKT5ZPt0m9STJEadao0xAH0ahmbWn\nOlFuhjuefXKnEgV4We0+UXgVCwOPjdAvBbI+e0ocS3MFEvzG6uBQE3xDk3SzynTn\njh8BCNAw1FtxNrQHusEwMFxIt4I7mKZ9YIqioymCzLq9gwQbooMDQaHWBfEbwrbw\nqHyGO0aoSCqI3Haadr8faqU9GY/rOPNk3sgrDQoo//fb4hVC1CLQJ13hef4Y53CI\nrU7m2Ys6xt0nUW7/vGT1M0NPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNV\nHRMBAf8EBTADAQH/MB0GA1UdDgQWBBR5tFnme7bl5AFzgAiIyBpY9umbbjANBgkq\nhkiG9w0BAQsFAAOCAgEAVR9YqbyyqFDQDLHYGmkgJykIrGF1XIpu+ILlaS/V9lZL\nubhzEFnTIZd+50xx+7LSYK05qAvqFyFWhfFQDlnrzuBZ6brJFe+GnY+EgPbk6ZGQ\n3BebYhtF8GaV0nxvwuo77x/Py9auJ/GpsMiu/X1+mvoiBOv/2X/qkSsisRcOj/KK\nNFtY2PwByVS5uCbMiogziUwthDyC3+6WVwW6LLv3xLfHTjuCvjHIInNzktHCgKQ5\nORAzI4JMPJ+GslWYHb4phowim57iaztXOoJwTdwJx4nLCgdNbOhdjsnvzqvHu7Ur\nTkXWStAmzOVyyghqpZXjFaH3pO3JLF+l+/+sKAIuvtd7u+Nxe5AW0wdeRlN8NwdC\njNPElpzVmbUq4JUagEiuTDkHzsxHpFKVK7q4+63SM1N95R1NbdWhscdCb+ZAJzVc\noyi3B43njTOQ5yOf+1CceWxG1bQVs5ZufpsMljq4Ui0/1lvh+wjChP4kqKOJ2qxq\n4RgqsahDYVvTH9w7jXbyLeiNdd8XM2w9U/t7y0Ff/9yi0GE44Za4rF2LN9d11TPA\nmRGunUHBcnWEvgJBQl9nJEiU0Zsnvgc/ubhPgXRR4Xq37Z0j4r7g1SgEEzwxA57d\nemyPxgcYxn/eR44/KJ4EBs+lVDR3veyJm+kXQ99b21/+jh5Xos1AnX5iItreGCc=\n-----END CERTIFICATE-----\n";
    private static final String LOG_TAG = "Translator";
    private static final String MIT_CA = "-----BEGIN CERTIFICATE-----\nMIIFXjCCBEagAwIBAgIJAMLfrRWIaHLbMA0GCSqGSIb3DQEBCwUAMIHPMQswCQYD\nVQQGEwJVUzELMAkGA1UECBMCTUExEjAQBgNVBAcTCUNhbWJyaWRnZTEuMCwGA1UE\nChMlTWFzc2FjaHVzZXR0cyBJbnN0aXR1dGUgb2YgVGVjaG5vbG9neTEZMBcGA1UE\nCxMQTUlUIEFwcCBJbnZlbnRvcjEmMCQGA1UEAxMdQ2xvdWREQiBDZXJ0aWZpY2F0\nZSBBdXRob3JpdHkxEDAOBgNVBCkTB0Vhc3lSU0ExGjAYBgkqhkiG9w0BCQEWC2pp\nc0BtaXQuZWR1MB4XDTE3MTIyMjIyMzkyOVoXDTI3MTIyMDIyMzkyOVowgc8xCzAJ\nBgNVBAYTAlVTMQswCQYDVQQIEwJNQTESMBAGA1UEBxMJQ2FtYnJpZGdlMS4wLAYD\nVQQKEyVNYXNzYWNodXNldHRzIEluc3RpdHV0ZSBvZiBUZWNobm9sb2d5MRkwFwYD\nVQQLExBNSVQgQXBwIEludmVudG9yMSYwJAYDVQQDEx1DbG91ZERCIENlcnRpZmlj\nYXRlIEF1dGhvcml0eTEQMA4GA1UEKRMHRWFzeVJTQTEaMBgGCSqGSIb3DQEJARYL\namlzQG1pdC5lZHUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHzI3D\nFobNDv2HTWlDdedmbxZIJYSqWlzdRJC3oVJgCubdAs46WJRqUxDRWft9UpYGMKkw\nmYN8mdPby2m5OJagdVIZgnguB71zIQkC8yMzd94FC3gldX5m7R014D/0fkpzvsSt\n6fsNectJT0k7gPELOH6t4u6AUbvIsEX0nNyRWsmA/ucXCsDBwXyBJxfOKIQ9tDI4\n/WfcKk9JDpeMF7RP0CIOtlAPotKIaPoY1W3eMIi/0riOt5vTFsB8pxhxAVy0cfGX\niHukdrAkAJixTgkyS7wzk22xOeXVnRIzAMGK5xHMDw/HRQGTrUGfIXHENV3u+3Ae\nL5/ZoQwyZTixmQNzAgMBAAGjggE5MIIBNTAdBgNVHQ4EFgQUZfMKQXqtC5UJGFrZ\ngZE1nmlx+t8wggEEBgNVHSMEgfwwgfmAFGXzCkF6rQuVCRha2YGRNZ5pcfrfoYHV\npIHSMIHPMQswCQYDVQQGEwJVUzELMAkGA1UECBMCTUExEjAQBgNVBAcTCUNhbWJy\naWRnZTEuMCwGA1UEChMlTWFzc2FjaHVzZXR0cyBJbnN0aXR1dGUgb2YgVGVjaG5v\nbG9neTEZMBcGA1UECxMQTUlUIEFwcCBJbnZlbnRvcjEmMCQGA1UEAxMdQ2xvdWRE\nQiBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkxEDAOBgNVBCkTB0Vhc3lSU0ExGjAYBgkq\nhkiG9w0BCQEWC2ppc0BtaXQuZWR1ggkAwt+tFYhoctswDAYDVR0TBAUwAwEB/zAN\nBgkqhkiG9w0BAQsFAAOCAQEAIkKr3eIvwZO6a1Jsh3qXwveVnrqwxYvLw2IhTwNT\n/P6C5jbRnzUuDuzg5sEIpbBo/Bp3qIp7G5cdVOkIrqO7uCp6Kyc7d9lPsEe/cbF4\naNwNmdWroRN1y0tuMU6+z7frd5pOeAZP9E/DM/0Uaz4yVzwnlvZUttaLymyMhH54\nisGQKbAqHDFtKZvb6DxsHzrO2YgeaBAtjeVhPWiv8BhzbOo9+hhZvYHYtoM2W+Ze\nDHuvv0v+qouphftDKVBp16N8Pk5WgabTXzV6VcNee92iwbWYDEv06+S3AF/q2TBe\nxxXtAa5ywbp6IRF37QuQChcYnOx7zIylYI1PIENfQFC2BA==\n-----END CERTIFICATE-----\n";
    public static final String TRANSLATOR_SERVICE_URL = "https://tr.appinventor.mit.edu/tr/v1";
    private final Activity activity;
    private String apiKey;
    private SSLSocketFactory sslSockFactory = null;

    static /* bridge */ /* synthetic */ void -$$Nest$mperformRequest(Translator translator, String string, String string2) {
        translator.performRequest(string, string2);
    }

    public Translator(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.activity = componentContainer.$context();
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void ensureSslSockFactory() {
        Translator translator = this;
        synchronized (translator) {
            block9: {
                SSLSocketFactory sSLSocketFactory = this.sslSockFactory;
                if (sSLSocketFactory == null) break block9;
                return;
            }
            CertificateFactory certificateFactory = CertificateFactory.getInstance((String)"X.509");
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(COMODO_ROOT.getBytes("UTF-8"));
            Certificate certificate = certificateFactory.generateCertificate((InputStream)byteArrayInputStream);
            byteArrayInputStream.close();
            ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(COMODO_USRTRUST.getBytes("UTF-8"));
            byteArrayInputStream = certificateFactory.generateCertificate((InputStream)byteArrayInputStream2);
            byteArrayInputStream2.close();
            ByteArrayInputStream byteArrayInputStream3 = new ByteArrayInputStream(MIT_CA.getBytes("UTF-8"));
            byteArrayInputStream2 = certificateFactory.generateCertificate((InputStream)byteArrayInputStream3);
            byteArrayInputStream3.close();
            X509Certificate[] x509CertificateArray = new ByteArrayInputStream(ISRG_ROOT_X1.getBytes("UTF-8"));
            byteArrayInputStream3 = certificateFactory.generateCertificate((InputStream)x509CertificateArray);
            x509CertificateArray.close();
            certificateFactory = KeyStore.getInstance((String)KeyStore.getDefaultType());
            certificateFactory.load(null, null);
            int n = 1;
            x509CertificateArray = this.getSystemCertificates();
            int n2 = x509CertificateArray.length;
            for (int i = 0; i < n2; ++n, ++i) {
                X509Certificate x509Certificate = x509CertificateArray[i];
                StringBuilder stringBuilder = new StringBuilder();
                certificateFactory.setCertificateEntry(stringBuilder.append("root").append(n).toString(), (Certificate)x509Certificate);
                continue;
            }
            {
                try {
                    certificateFactory.setCertificateEntry("comodo", certificate);
                    certificateFactory.setCertificateEntry("inter", (Certificate)byteArrayInputStream);
                    certificateFactory.setCertificateEntry("mitca", (Certificate)byteArrayInputStream2);
                    certificateFactory.setCertificateEntry("isrg", (Certificate)byteArrayInputStream3);
                    TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
                    trustManagerFactory.init((KeyStore)certificateFactory);
                    byteArrayInputStream = SSLContext.getInstance((String)"TLS");
                    byteArrayInputStream.init(null, trustManagerFactory.getTrustManagers(), null);
                    this.sslSockFactory = byteArrayInputStream.getSocketFactory();
                    return;
                }
                catch (Exception exception) {
                    Log.e((String)LOG_TAG, (String)"Could not setup SSL Trust Store for Tranlate", (Throwable)exception);
                    YailRuntimeError yailRuntimeError = new YailRuntimeError("Could Not setup SSL Trust Store for Translator: ", exception.getMessage());
                    throw yailRuntimeError;
                }
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String getResponseContent(HttpsURLConnection object2, boolean bl) throws IOException {
        Object object3 = object2.getContentEncoding();
        String string = object3;
        if (object3 == null) {
            string = "UTF-8";
        }
        string = bl ? new InputStreamReader(object2.getErrorStream(), string) : new InputStreamReader(object2.getInputStream(), string);
        try {
            int n = object2.getContentLength();
            object2 = n != -1 ? new StringBuilder(n) : new StringBuilder();
            object3 = new char[1024];
            while ((n = string.read((char[])object3)) != -1) {
                object2.append((char[])object3, 0, n);
            }
            object2 = object2.toString();
            return object2;
        }
        finally {
            string.close();
        }
    }

    private X509Certificate[] getSystemCertificates() {
        try {
            X509Certificate[] x509CertificateArray = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
            KeyStore keyStore = null;
            x509CertificateArray.init(null);
            x509CertificateArray = ((X509TrustManager)x509CertificateArray.getTrustManagers()[0]).getAcceptedIssuers();
            return x509CertificateArray;
        }
        catch (Exception exception) {
            Log.e((String)LOG_TAG, (String)"Getting System Certificates", (Throwable)exception);
            return new X509Certificate[0];
        }
    }

    /*
     * Loose catch block
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void performRequest(String object2, String string) {
        void var4_19;
        block14: {
            void var5_10;
            void var4_13;
            Object var6_6;
            Object var7_5;
            block13: {
                block12: {
                    var7_5 = null;
                    var6_6 = null;
                    super.ensureSslSockFactory();
                    String[] stringArray = object2.split("-");
                    if (stringArray.length > 2) {
                        this.GotTranslation("400", "");
                        return;
                    }
                    if (stringArray.length != 2) break block12;
                    String string2 = stringArray[0];
                    String string3 = stringArray[1];
                    break block13;
                }
                String string4 = "auto";
                Object object3 = object2;
            }
            object2 = TranslatorToken.token.parseFrom(Base58Util.decode((String)this.apiKey));
            TranslatorToken.request.Builder builder = TranslatorToken.request.newBuilder().setToken((TranslatorToken.token)((Object)object2));
            object2 = var6_6;
            TranslatorToken.request request2 = builder.setTotranslate(string).setSourcelanguage((String)var4_13).setTargetlanguage((String)var5_10).build();
            object2 = var6_6;
            object2 = var6_6;
            string = new URL(TRANSLATOR_SERVICE_URL);
            object2 = var6_6;
            string = (HttpsURLConnection)string.openConnection();
            if (string == null) return;
            string.setSSLSocketFactory(this.sslSockFactory);
            string.setRequestMethod("POST");
            string.setDoOutput(true);
            request2.writeTo(string.getOutputStream());
            int n = string.getResponseCode();
            object2 = TranslatorToken.response.parseFrom(string.getInputStream());
            object2 = n == 200 ? ((TranslatorToken.response)((Object)object2)).getTranslated() : Translator.getResponseContent((HttpsURLConnection)string, false);
            StringBuilder stringBuilder = new StringBuilder();
            this.GotTranslation(stringBuilder.append(n).toString(), (String)object2);
            object2 = string;
            {
                catch (Throwable throwable) {
                    object2 = string;
                    string.disconnect();
                    object2 = string;
                    throw throwable;
                }
            }
            try {
                string.disconnect();
                return;
            }
            catch (Exception exception) {
                string = object2;
            }
            break block14;
            catch (Exception exception) {
                string = var7_5;
                Exception exception2 = exception;
            }
        }
        var4_19.printStackTrace();
        if (var4_19 instanceof FileNotFoundException && string != null) {
            try {
                object2 = Translator.getResponseContent((HttpsURLConnection)string, true);
            }
            catch (IOException iOException) {
                object2 = "Error Fetching Translation";
            }
            this.GotTranslation("404", (String)object2);
            return;
        }
        this.GotTranslation("400", "Error Fetching Translation");
    }

    @DesignerProperty(defaultValue="", editorType="string")
    @SimpleProperty(category=PropertyCategory.ADVANCED, description="The API Key to use. MIT App Inventor will automatically fill this value in. You should not need to change it.", userVisible=true)
    public void ApiKey(String string) {
        this.apiKey = string;
    }

    @SimpleEvent(description="Event triggered when the Translate service returns the translated text. This event also provides a response code for error handling. If the responseCode is not 200, then something went wrong with the call, and the translation will not be available.")
    public void GotTranslation(String string, String string2) {
        this.activity.runOnUiThread(new Runnable((Translator)this, string, string2){
            final Translator this$0;
            final String val$responseCode;
            final String val$translation;
            {
                this.this$0 = translator;
                this.val$responseCode = string;
                this.val$translation = string2;
            }

            public void run() {
                EventDispatcher.dispatchEvent((Component)((Object)this.this$0), "GotTranslation", this.val$responseCode, this.val$translation);
            }
        });
    }

    @SimpleFunction(description="By providing a target language to translate to (for instance, 'es' for Spanish, 'en' for English, or 'ru' for Russian), and a word or sentence to translate, this method will request a translation.\nOnce the text is translated by the external service, the event GotTranslation will be executed.\nNote: Translate will attempt to detect the source language. You can also specify prepending it to the language translation. I.e., es-ru will specify Spanish to Russian translation.")
    public void RequestTranslation(String string, String string2) {
        AsynchUtil.runAsynchronously((Runnable)new Runnable((Translator)this, string, string2){
            final Translator this$0;
            final String val$languageToTranslateTo;
            final String val$textToTranslate;
            {
                this.this$0 = translator;
                this.val$languageToTranslateTo = string;
                this.val$textToTranslate = string2;
            }

            public void run() {
                Translator.-$$Nest$mperformRequest(this.this$0, this.val$languageToTranslateTo, this.val$textToTranslate);
            }
        });
    }
}

