/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  com.google.appinventor.components.common.HorizontalAlignment
 *  com.google.appinventor.components.common.MapFeature
 *  com.google.appinventor.components.common.VerticalAlignment
 *  com.google.appinventor.components.runtime.Marker$1
 *  com.google.appinventor.components.runtime.Marker$2
 *  com.google.appinventor.components.runtime.util.GeometryUtil
 *  com.google.appinventor.components.runtime.util.MapFactory$HasStroke
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureContainer
 *  com.google.appinventor.components.runtime.util.MapFactory$MapFeatureVisitor
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 *  org.locationtech.jts.geom.Geometry
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.util.GeoPoint
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.appinventor.components.annotations.Asset;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.Options;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.HorizontalAlignment;
import com.google.appinventor.components.common.MapFeature;
import com.google.appinventor.components.common.VerticalAlignment;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.MapFeatureBaseWithFill;
import com.google.appinventor.components.runtime.Marker;
import com.google.appinventor.components.runtime.util.GeometryUtil;
import com.google.appinventor.components.runtime.util.MapFactory;
import org.locationtech.jts.geom.Geometry;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.MAPS, description="<p>An icon positioned at a point to indicate information on a map. Markers can be used to provide an info window, custom fill and stroke colors, and custom images to convey information to the user.</p>", version=4)
@SimpleObject
@UsesLibraries(libraries="osmdroid.aar, androidsvg.jar")
public class Marker
extends MapFeatureBaseWithFill
implements MapFactory.MapMarker {
    private static final String TAG = Marker.class.getSimpleName();
    private static final MapFactory.MapFeatureVisitor<Double> bearingComputation;
    private static final MapFactory.MapFeatureVisitor<Double> distanceComputation;
    private HorizontalAlignment anchorHAlign = HorizontalAlignment.Center;
    private VerticalAlignment anchorVAlign = VerticalAlignment.Bottom;
    private final Handler handler;
    private int height = -1;
    private String imagePath = "";
    private GeoPoint location = new GeoPoint(0.0, 0.0);
    private volatile boolean pendingUpdate = false;
    private int width = -1;

    static /* bridge */ /* synthetic */ void -$$Nest$fputpendingUpdate(Marker marker, boolean bl) {
        marker.pendingUpdate = bl;
    }

    static {
        distanceComputation = new 1();
        bearingComputation = new 2();
    }

    public Marker(MapFactory.MapFeatureContainer mapFeatureContainer) {
        super(mapFeatureContainer, distanceComputation);
        this.handler = new Handler(Looper.getMainLooper());
        mapFeatureContainer.addFeature((MapFactory.MapFeature)this);
        this.ShowShadow(false);
        this.AnchorHorizontal(3);
        this.AnchorVertical(3);
        this.ImageAsset("");
        this.Width(-1);
        this.Height(-1);
        this.Latitude(0.0);
        this.Longitude(0.0);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void setNeedsUpdate() {
        Marker marker = this;
        synchronized (marker) {
            if (this.pendingUpdate) {
                return;
            }
            this.pendingUpdate = true;
            Handler handler = this.handler;
            Runnable runnable = new Runnable(this){
                final Marker this$0;
                {
                    this.this$0 = marker;
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    Marker marker;
                    this.this$0.map.getController().updateFeatureImage((MapFactory.MapMarker)this.this$0);
                    Marker marker2 = marker = this.this$0;
                    synchronized (marker2) {
                        Marker.-$$Nest$fputpendingUpdate(this.this$0, false);
                        return;
                    }
                }
            };
            handler.postDelayed(runnable, 1L);
            return;
        }
    }

    @Override
    @SimpleProperty(description="The horizontal alignment property controls where the Marker's anchor is located relative to its width. The choices are: 1 = left aligned, 3 = horizontally centered, 2 = right aligned.")
    public int AnchorHorizontal() {
        return this.AnchorHorizontalAbstract().toUnderlyingValue();
    }

    @Override
    @DesignerProperty(defaultValue="3", editorType="horizontal_alignment")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void AnchorHorizontal(@Options(value=HorizontalAlignment.class) int n) {
        HorizontalAlignment horizontalAlignment = HorizontalAlignment.fromUnderlyingValue((Integer)n);
        if (horizontalAlignment == null) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "AnchorHorizontal", 3417, n);
            return;
        }
        this.AnchorHorizontalAbstract(horizontalAlignment);
    }

    public HorizontalAlignment AnchorHorizontalAbstract() {
        return this.anchorHAlign;
    }

    public void AnchorHorizontalAbstract(HorizontalAlignment horizontalAlignment) {
        if (horizontalAlignment != this.anchorHAlign) {
            this.anchorHAlign = horizontalAlignment;
            this.map.getController().updateFeaturePosition((MapFactory.MapMarker)this);
        }
    }

    @Override
    @SimpleProperty(description="The vertical alignment property controls where the Marker's anchor is located relative to its height. The choices are: 1 = aligned at the top, 2 = vertically centered, 3 = aligned at the bottom.")
    public int AnchorVertical() {
        return this.AnchorVerticalAbstract().toUnderlyingValue();
    }

    @Override
    @DesignerProperty(defaultValue="3", editorType="vertical_alignment")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void AnchorVertical(@Options(value=VerticalAlignment.class) int n) {
        VerticalAlignment verticalAlignment = VerticalAlignment.fromUnderlyingValue((Integer)n);
        if (verticalAlignment == null) {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "AnchorVertical", 3416, n);
            return;
        }
        this.AnchorVerticalAbstract(verticalAlignment);
    }

    public VerticalAlignment AnchorVerticalAbstract() {
        return this.anchorVAlign;
    }

    public void AnchorVerticalAbstract(VerticalAlignment verticalAlignment) {
        if (verticalAlignment != null) {
            this.anchorVAlign = verticalAlignment;
            this.map.getController().updateFeaturePosition((MapFactory.MapMarker)this);
        }
    }

    @SimpleFunction(description="Returns the bearing from the Marker to the given map feature, in degrees from due north. If the centroids parameter is true, the bearing will be to the center of the map feature. Otherwise, the bearing will be computed to the point in the feature nearest the Marker.")
    public double BearingToFeature(MapFactory.MapFeature mapFeature, boolean bl) {
        double d = mapFeature == null ? -1.0 : mapFeature.accept(bearingComputation, this, bl);
        return d;
    }

    @SimpleFunction(description="Returns the bearing from the Marker to the given latitude and longitude, in degrees from due north.")
    public double BearingToPoint(double d, double d2) {
        return this.location.bearingTo((IGeoPoint)new GeoPoint(d, d2));
    }

    @SimpleFunction(description="Compute the distance, in meters, between a Marker and a latitude, longitude point.")
    public double DistanceToPoint(double d, double d2) {
        return GeometryUtil.distanceBetween((MapFactory.MapMarker)this, (GeoPoint)new GeoPoint(d, d2));
    }

    @Override
    public double DistanceToPoint(double d, double d2, boolean bl) {
        return this.DistanceToPoint(d, d2);
    }

    @Override
    @SimpleProperty
    public int Height() {
        int n = this.height;
        if (n == -2) {
            return this.map.getView().getHeight();
        }
        if (n < -1000) {
            double d = -n;
            Double.isNaN((double)d);
            double d2 = (d - 1000.0) / 100.0;
            d = this.map.getView().getHeight();
            Double.isNaN((double)d);
            return (int)(d2 * d);
        }
        return n;
    }

    @Override
    @SimpleProperty
    public void Height(int n) {
        this.height = n;
        super.setNeedsUpdate();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void HeightPercent(int n) {
        this.height = -1000 - n;
        super.setNeedsUpdate();
    }

    @Override
    @SimpleProperty(description="The ImageAsset property is used to provide an alternative image for the Marker.")
    public String ImageAsset() {
        return this.imagePath;
    }

    @Override
    @DesignerProperty(editorType="asset")
    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void ImageAsset(@Asset String string2) {
        Log.d((String)TAG, (String)"ImageAsset");
        this.imagePath = string2;
        super.setNeedsUpdate();
    }

    @Override
    @SimpleProperty
    public double Latitude() {
        return this.location.getLatitude();
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="latitude")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void Latitude(double d) {
        Log.d((String)TAG, (String)"Latitude");
        if (!(d < -90.0) && !(d > 90.0)) {
            this.location.setLatitude(d);
            this.clearGeometry();
            this.map.getController().updateFeaturePosition((MapFactory.MapMarker)this);
        } else {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "Latitude", 3413, d);
        }
    }

    @Override
    @SimpleProperty
    public double Longitude() {
        return this.location.getLongitude();
    }

    @Override
    @DesignerProperty(defaultValue="0", editorType="longitude")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void Longitude(double d) {
        Log.d((String)TAG, (String)"Longitude");
        if (!(d < -180.0) && !(d > 180.0)) {
            this.location.setLongitude(d);
            this.clearGeometry();
            this.map.getController().updateFeaturePosition((MapFactory.MapMarker)this);
        } else {
            this.container.$form().dispatchErrorOccurredEvent((Component)this, "Longitude", 3414, d);
        }
    }

    @Override
    @SimpleFunction(description="Set the location of the marker.")
    public void SetLocation(double d, double d2) {
        Log.d((String)TAG, (String)"SetLocation");
        this.location.setCoords(d, d2);
        this.clearGeometry();
        this.map.getController().updateFeaturePosition((MapFactory.MapMarker)this);
    }

    @Override
    @SimpleProperty(userVisible=false)
    public void ShowShadow(boolean bl) {
    }

    @Override
    @SimpleProperty(description="Gets whether or not the shadow of the Marker is shown.")
    public boolean ShowShadow() {
        return false;
    }

    @Override
    @SimpleProperty
    public void StrokeColor(int n) {
        super.StrokeColor(n);
        this.map.getController().updateFeatureStroke((MapFactory.HasStroke)this);
    }

    @Override
    @SimpleProperty(description="Returns the type of the feature. For Markers, this returns MapFeature.Marker (\"Marker\").")
    public String Type() {
        return this.TypeAbstract().toUnderlyingValue();
    }

    public MapFeature TypeAbstract() {
        return MapFeature.Marker;
    }

    @Override
    @SimpleProperty
    public int Width() {
        int n = this.width;
        if (n == -2) {
            return this.map.getView().getWidth();
        }
        if (n < -1000) {
            double d = -n;
            Double.isNaN((double)d);
            double d2 = (d - 1000.0) / 100.0;
            d = this.map.getView().getWidth();
            Double.isNaN((double)d);
            return (int)(d2 * d);
        }
        return n;
    }

    @Override
    @SimpleProperty
    public void Width(int n) {
        this.width = n;
        super.setNeedsUpdate();
    }

    @SimpleProperty(category=PropertyCategory.APPEARANCE)
    public void WidthPercent(int n) {
        this.width = -1000 - n;
        super.setNeedsUpdate();
    }

    @Override
    public <T> T accept(MapFactory.MapFeatureVisitor<T> mapFeatureVisitor, Object ... objectArray) {
        return (T)mapFeatureVisitor.visit((MapFactory.MapMarker)this, objectArray);
    }

    @Override
    protected Geometry computeGeometry() {
        return GeometryUtil.createGeometry((GeoPoint)this.location);
    }

    @Override
    public IGeoPoint getLocation() {
        return this.location;
    }

    @Override
    public void updateLocation(double d, double d2) {
        this.location = new GeoPoint(d, d2);
        this.clearGeometry();
    }
}

