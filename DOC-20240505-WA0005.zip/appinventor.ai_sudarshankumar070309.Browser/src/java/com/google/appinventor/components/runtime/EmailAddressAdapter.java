/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.DatabaseUtils
 *  android.net.Uri
 *  android.provider.Contacts$ContactMethods
 *  android.text.TextUtils
 *  android.text.util.Rfc822Token
 *  android.view.View
 *  android.widget.ResourceCursorAdapter
 *  android.widget.TextView
 *  com.google.appinventor.components.runtime.util.HoneycombMR1Util
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.appinventor.components.runtime;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.net.Uri;
import android.provider.Contacts;
import android.text.TextUtils;
import android.text.util.Rfc822Token;
import android.view.View;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import com.google.appinventor.components.runtime.util.HoneycombMR1Util;
import com.google.appinventor.components.runtime.util.SdkLevel;

public class EmailAddressAdapter
extends ResourceCursorAdapter {
    private static final boolean DEBUG = false;
    private static final String[] POST_HONEYCOMB_PROJECTION;
    public static final int PRE_HONEYCOMB_DATA_INDEX = 2;
    public static final int PRE_HONEYCOMB_NAME_INDEX = 1;
    private static final String[] PRE_HONEYCOMB_PROJECTION;
    private static String SORT_ORDER;
    private static final String TAG = "EmailAddressAdapter";
    private ContentResolver contentResolver;
    private Context context;

    static {
        PRE_HONEYCOMB_PROJECTION = new String[]{"_id", "name", "data"};
        POST_HONEYCOMB_PROJECTION = HoneycombMR1Util.getEmailAdapterProjection();
    }

    public EmailAddressAdapter(Context object) {
        super(object, 17367050, null);
        this.contentResolver = object.getContentResolver();
        this.context = object;
        if (SdkLevel.getLevel() >= 12) {
            String string = HoneycombMR1Util.getTimesContacted();
            object = HoneycombMR1Util.getDisplayName();
            SORT_ORDER = string + " DESC, " + (String)object;
        } else {
            SORT_ORDER = "times_contacted DESC, name";
        }
    }

    private final String makeDisplayString(Cursor object) {
        String string;
        int n = object.getColumnIndex(HoneycombMR1Util.getDisplayName());
        int n2 = object.getColumnIndex(HoneycombMR1Util.getEmailAddress());
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = false;
        if (SdkLevel.getLevel() >= 12) {
            string = object.getString(n);
            String string2 = object.getString(n2);
            object = string;
            string = string2;
        } else {
            String string3 = object.getString(1);
            string = object.getString(2);
            object = string3;
        }
        if (!TextUtils.isEmpty((CharSequence)object)) {
            stringBuilder.append((String)object);
            bl = true;
        }
        if (bl) {
            stringBuilder.append(" <");
        }
        stringBuilder.append(string);
        if (bl) {
            stringBuilder.append(">");
        }
        return stringBuilder.toString();
    }

    public final void bindView(View view, Context context, Cursor cursor) {
        ((TextView)view).setText((CharSequence)super.makeDisplayString(cursor));
    }

    public final String convertToString(Cursor object) {
        String string;
        int n = object.getColumnIndex(HoneycombMR1Util.getDisplayName());
        int n2 = object.getColumnIndex(HoneycombMR1Util.getEmailAddress());
        if (SdkLevel.getLevel() >= 12) {
            string = object.getString(n);
            object = object.getString(n2);
        } else {
            string = object.getString(1);
            object = object.getString(2);
        }
        return new Rfc822Token(string, (String)object, null).toString();
    }

    public Cursor runQueryOnBackgroundThread(CharSequence charSequence) {
        Uri uri = null;
        StringBuilder stringBuilder = new StringBuilder();
        if (charSequence != null) {
            charSequence = charSequence.toString();
            charSequence = DatabaseUtils.sqlEscapeString((String)((String)charSequence + "%"));
            if (SdkLevel.getLevel() >= 12) {
                uri = HoneycombMR1Util.getDataContentUri();
                String string = HoneycombMR1Util.getDataMimeType();
                String string2 = HoneycombMR1Util.getEmailType();
                stringBuilder.append("(" + string + "='" + string2 + "')");
                stringBuilder.append(" AND ");
                stringBuilder.append("(display_name LIKE ");
                stringBuilder.append((String)charSequence);
                stringBuilder.append(")");
            } else {
                uri = Contacts.ContactMethods.CONTENT_EMAIL_URI;
                stringBuilder.append("(name LIKE ");
                stringBuilder.append((String)charSequence);
                stringBuilder.append(") OR (display_name LIKE ");
                stringBuilder.append((String)charSequence);
                stringBuilder.append(")");
            }
        }
        charSequence = stringBuilder.toString();
        if (SdkLevel.getLevel() >= 12) {
            return this.contentResolver.query(uri, POST_HONEYCOMB_PROJECTION, (String)charSequence, null, SORT_ORDER);
        }
        return this.contentResolver.query(uri, PRE_HONEYCOMB_PROJECTION, (String)charSequence, null, SORT_ORDER);
    }
}

