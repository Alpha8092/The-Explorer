/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  com.google.appinventor.components.common.NxtSensorMode
 *  com.google.appinventor.components.common.NxtSensorType
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.google.appinventor.components.runtime;

import android.os.Handler;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.NxtSensorMode;
import com.google.appinventor.components.common.NxtSensorType;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.LegoMindstormsNxtSensor;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@DesignerComponent(category=ComponentCategory.LEGOMINDSTORMS, description="A component that provides a high-level interface to a sound sensor on a LEGO MINDSTORMS NXT robot.", iconName="images/legoMindstormsNxt.png", nonVisible=true, version=1)
@SimpleObject
public class NxtSoundSensor
extends LegoMindstormsNxtSensor
implements Deleteable {
    private static final int DEFAULT_BOTTOM_OF_RANGE = 256;
    private static final String DEFAULT_SENSOR_PORT = "2";
    private static final int DEFAULT_TOP_OF_RANGE = 767;
    private boolean aboveRangeEventEnabled;
    private boolean belowRangeEventEnabled;
    private int bottomOfRange;
    private Handler handler = new Handler();
    private State previousState = State.UNKNOWN;
    private final Runnable sensorReader;
    private int topOfRange;
    private boolean withinRangeEventEnabled;

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetaboveRangeEventEnabled(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.aboveRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetbelowRangeEventEnabled(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.belowRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgetbottomOfRange(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.bottomOfRange;
    }

    static /* bridge */ /* synthetic */ Handler -$$Nest$fgethandler(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.handler;
    }

    static /* bridge */ /* synthetic */ State -$$Nest$fgetpreviousState(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.previousState;
    }

    static /* bridge */ /* synthetic */ Runnable -$$Nest$fgetsensorReader(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.sensorReader;
    }

    static /* bridge */ /* synthetic */ int -$$Nest$fgettopOfRange(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.topOfRange;
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$fgetwithinRangeEventEnabled(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.withinRangeEventEnabled;
    }

    static /* bridge */ /* synthetic */ void -$$Nest$fputpreviousState(NxtSoundSensor nxtSoundSensor, State state) {
        nxtSoundSensor.previousState = state;
    }

    static /* bridge */ /* synthetic */ LegoMindstormsNxtSensor.SensorValue -$$Nest$mgetSoundValue(NxtSoundSensor nxtSoundSensor, String string2) {
        return nxtSoundSensor.getSoundValue(string2);
    }

    static /* bridge */ /* synthetic */ boolean -$$Nest$misHandlerNeeded(NxtSoundSensor nxtSoundSensor) {
        return nxtSoundSensor.isHandlerNeeded();
    }

    public NxtSoundSensor(ComponentContainer componentContainer) {
        super(componentContainer, "NxtSoundSensor");
        this.sensorReader = new Runnable((NxtSoundSensor)this){
            final NxtSoundSensor this$0;
            {
                this.this$0 = nxtSoundSensor;
            }

            public void run() {
                if (this.this$0.bluetooth != null && this.this$0.bluetooth.IsConnected()) {
                    Object object = NxtSoundSensor.-$$Nest$mgetSoundValue(this.this$0, "");
                    if (object.valid) {
                        object = (Integer)object.value < NxtSoundSensor.-$$Nest$fgetbottomOfRange(this.this$0) ? State.BELOW_RANGE : ((Integer)object.value > NxtSoundSensor.-$$Nest$fgettopOfRange(this.this$0) ? State.ABOVE_RANGE : State.WITHIN_RANGE);
                        if (object != NxtSoundSensor.-$$Nest$fgetpreviousState(this.this$0)) {
                            if (object == State.BELOW_RANGE && NxtSoundSensor.-$$Nest$fgetbelowRangeEventEnabled(this.this$0)) {
                                this.this$0.BelowRange();
                            }
                            if (object == State.WITHIN_RANGE && NxtSoundSensor.-$$Nest$fgetwithinRangeEventEnabled(this.this$0)) {
                                this.this$0.WithinRange();
                            }
                            if (object == State.ABOVE_RANGE && NxtSoundSensor.-$$Nest$fgetaboveRangeEventEnabled(this.this$0)) {
                                this.this$0.AboveRange();
                            }
                        }
                        NxtSoundSensor.-$$Nest$fputpreviousState(this.this$0, (Object)object);
                    }
                }
                if (NxtSoundSensor.-$$Nest$misHandlerNeeded(this.this$0)) {
                    NxtSoundSensor.-$$Nest$fgethandler(this.this$0).post(NxtSoundSensor.-$$Nest$fgetsensorReader(this.this$0));
                }
            }
        };
        this.SensorPort(DEFAULT_SENSOR_PORT);
        this.BottomOfRange(256);
        this.TopOfRange(767);
        this.BelowRangeEventEnabled(false);
        this.WithinRangeEventEnabled(false);
        this.AboveRangeEventEnabled(false);
    }

    private LegoMindstormsNxtSensor.SensorValue<Integer> getSoundValue(String object) {
        if ((object = (Object)this.getInputValues((String)object, this.port)) != null && this.getBooleanValueFromBytes((byte[])object, 4)) {
            return new Object(true, this.getUWORDValueFromBytes((byte[])object, 10)){
                final boolean valid;
                final T value;
                {
                    this.valid = bl;
                    this.value = t;
                }
            };
        }
        return new /* invalid duplicate definition of identical inner class */;
    }

    private boolean isHandlerNeeded() {
        boolean bl = this.belowRangeEventEnabled || this.withinRangeEventEnabled || this.aboveRangeEventEnabled;
        return bl;
    }

    @SimpleEvent(description="Sound level has gone above the range.")
    public void AboveRange() {
        EventDispatcher.dispatchEvent(this, "AboveRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void AboveRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.aboveRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the AboveRange event should fire when the sound level goes above the TopOfRange.")
    public boolean AboveRangeEventEnabled() {
        return this.aboveRangeEventEnabled;
    }

    @SimpleEvent(description="Sound level has gone below the range.")
    public void BelowRange() {
        EventDispatcher.dispatchEvent(this, "BelowRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void BelowRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.belowRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the BelowRange event should fire when the sound level goes below the BottomOfRange.")
    public boolean BelowRangeEventEnabled() {
        return this.belowRangeEventEnabled;
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The bottom of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int BottomOfRange() {
        return this.bottomOfRange;
    }

    @DesignerProperty(defaultValue="256", editorType="non_negative_integer")
    @SimpleProperty
    public void BottomOfRange(int n) {
        this.bottomOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleFunction(description="Returns the current sound level as a value between 0 and 1023, or -1 if the sound level can not be read.")
    public int GetSoundLevel() {
        if (!this.checkBluetooth("GetSoundLevel")) {
            return -1;
        }
        LegoMindstormsNxtSensor.SensorValue<Integer> sensorValue = this.getSoundValue("GetSoundLevel");
        if (sensorValue.valid) {
            return (Integer)sensorValue.value;
        }
        return -1;
    }

    @Override
    @DesignerProperty(defaultValue="2", editorType="lego_nxt_sensor_port")
    @SimpleProperty(userVisible=false)
    public void SensorPort(String string2) {
        this.setSensorPort(string2);
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="The top of the range used for the BelowRange, WithinRange, and AboveRange events.")
    public int TopOfRange() {
        return this.topOfRange;
    }

    @DesignerProperty(defaultValue="767", editorType="non_negative_integer")
    @SimpleProperty
    public void TopOfRange(int n) {
        this.topOfRange = n;
        this.previousState = State.UNKNOWN;
    }

    @SimpleEvent(description="Sound level has gone within the range.")
    public void WithinRange() {
        EventDispatcher.dispatchEvent(this, "WithinRange", new Object[0]);
    }

    @DesignerProperty(defaultValue="False", editorType="boolean")
    @SimpleProperty
    public void WithinRangeEventEnabled(boolean bl) {
        boolean bl2 = super.isHandlerNeeded();
        this.withinRangeEventEnabled = bl;
        bl = super.isHandlerNeeded();
        if (bl2 && !bl) {
            this.handler.removeCallbacks(this.sensorReader);
        }
        if (!bl2 && bl) {
            this.previousState = State.UNKNOWN;
            this.handler.post(this.sensorReader);
        }
    }

    @SimpleProperty(category=PropertyCategory.BEHAVIOR, description="Whether the WithinRange event should fire when the sound level goes between the BottomOfRange and the TopOfRange.")
    public boolean WithinRangeEventEnabled() {
        return this.withinRangeEventEnabled;
    }

    @Override
    protected void initializeSensor(String string2) {
        this.setInputMode(string2, this.port, NxtSensorType.SoundDB, NxtSensorMode.Raw);
    }

    @Override
    public void onDelete() {
        this.handler.removeCallbacks(this.sensorReader);
        super.onDelete();
    }
}

