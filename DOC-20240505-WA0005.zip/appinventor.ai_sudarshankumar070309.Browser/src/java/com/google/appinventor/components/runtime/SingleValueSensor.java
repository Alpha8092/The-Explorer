/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Build$VERSION
 *  com.google.appinventor.components.runtime.AndroidNonvisibleComponent
 *  com.google.appinventor.components.runtime.SensorComponent
 *  java.lang.Object
 *  java.lang.Override
 */
package com.google.appinventor.components.runtime;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import com.google.appinventor.components.annotations.DesignerProperty;
import com.google.appinventor.components.annotations.PropertyCategory;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.Deleteable;
import com.google.appinventor.components.runtime.OnPauseListener;
import com.google.appinventor.components.runtime.OnResumeListener;
import com.google.appinventor.components.runtime.SensorComponent;

@SimpleObject
public abstract class SingleValueSensor
extends AndroidNonvisibleComponent
implements OnPauseListener,
OnResumeListener,
SensorComponent,
SensorEventListener,
Deleteable {
    private static final int DEFAULT_REFRESH_TIME = 1000;
    protected boolean enabled;
    protected int refreshTime;
    private Sensor sensor;
    protected final SensorManager sensorManager;
    protected int sensorType;
    protected float value;

    public SingleValueSensor(ComponentContainer componentContainer, int n) {
        super(componentContainer.$form());
        this.sensorType = n;
        this.form.registerForOnResume((OnResumeListener)this);
        this.form.registerForOnPause((OnPauseListener)this);
        this.refreshTime = 1000;
        this.enabled = true;
        componentContainer = (SensorManager)componentContainer.$context().getSystemService("sensor");
        this.sensorManager = componentContainer;
        this.sensor = componentContainer.getDefaultSensor(n);
        this.startListening();
    }

    @SimpleProperty(description="Specifies whether or not the device has the hardware to support the %type% component.")
    public boolean Available() {
        return this.isAvailable();
    }

    @DesignerProperty(defaultValue="True", editorType="boolean")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void Enabled(boolean bl) {
        this.setEnabled(bl);
    }

    @SimpleProperty(description="If enabled, then device will listen for changes.")
    public boolean Enabled() {
        return this.enabled;
    }

    @SimpleProperty(description="The requested minimum time in milliseconds between changes in readings being reported. Android is not guaranteed to honor the request. Setting this property has no effect on pre-Gingerbread devices.")
    public int RefreshTime() {
        return this.refreshTime;
    }

    @DesignerProperty(defaultValue="1000", editorType="non_negative_integer")
    @SimpleProperty(category=PropertyCategory.BEHAVIOR)
    public void RefreshTime(int n) {
        this.refreshTime = n;
        if (this.enabled) {
            this.stopListening();
            this.startListening();
        }
    }

    protected float getValue() {
        return this.value;
    }

    protected boolean isAvailable() {
        boolean bl = this.sensorManager.getSensorList(this.sensorType).size() > 0;
        return bl;
    }

    public void onAccuracyChanged(Sensor sensor, int n) {
    }

    @Override
    public void onDelete() {
        if (this.enabled) {
            this.stopListening();
        }
    }

    @Override
    public void onPause() {
        if (this.enabled) {
            this.stopListening();
        }
    }

    @Override
    public void onResume() {
        if (this.enabled) {
            this.startListening();
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.enabled && sensorEvent.sensor.getType() == this.sensorType) {
            float f;
            this.value = f = sensorEvent.values[0];
            this.onValueChanged(f);
        }
    }

    protected abstract void onValueChanged(float var1);

    protected void setEnabled(boolean bl) {
        if (this.enabled == bl) {
            return;
        }
        this.enabled = bl;
        if (bl) {
            this.startListening();
        } else {
            this.stopListening();
        }
    }

    protected void startListening() {
        if (Build.VERSION.SDK_INT >= 9) {
            int n = this.refreshTime;
            this.sensorManager.registerListener((SensorEventListener)this, this.sensor, n * 1000);
        } else {
            this.sensorManager.registerListener((SensorEventListener)this, this.sensor, 2);
        }
    }

    protected void stopListening() {
        this.sensorManager.unregisterListener((SensorEventListener)this);
    }
}

