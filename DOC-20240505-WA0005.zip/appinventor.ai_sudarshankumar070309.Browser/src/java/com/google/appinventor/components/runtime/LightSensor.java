/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.Override
 */
package com.google.appinventor.components.runtime;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.SimpleProperty;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.BufferedSingleValueSensor;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;

@DesignerComponent(category=ComponentCategory.SENSORS, description="A sensor component that can measure the light level.", iconName="images/lightsensor.png", nonVisible=true, version=1)
@SimpleObject
public class LightSensor
extends BufferedSingleValueSensor {
    private static final int BUFFER_SIZE = 10;

    public LightSensor(ComponentContainer componentContainer) {
        super(componentContainer.$form(), 5, 10);
    }

    @SimpleProperty(description="The average of the 10 most recent light levels measured, in lux.")
    public float AverageLux() {
        return this.getAverageValue();
    }

    @SimpleEvent(description="Called when a change is detected in the light level.")
    public void LightChanged(float f) {
        EventDispatcher.dispatchEvent((Component)this, "LightChanged", Float.valueOf((float)f));
    }

    @SimpleProperty(description="The most recent light level, in lux, if the sensor is available and enabled.")
    public float Lux() {
        return this.getValue();
    }

    @Override
    protected void onValueChanged(float f) {
        this.LightChanged(f);
    }
}

