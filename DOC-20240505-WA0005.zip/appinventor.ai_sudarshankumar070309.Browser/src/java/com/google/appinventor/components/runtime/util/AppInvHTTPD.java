/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Build
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  com.google.appinventor.components.runtime.util.AppInvHTTPD$1
 *  com.google.appinventor.components.runtime.util.EclairUtil
 *  com.google.appinventor.components.runtime.util.NanoHTTPD
 *  com.google.appinventor.components.runtime.util.NanoHTTPD$Response
 *  com.google.appinventor.components.runtime.util.RetValManager
 *  com.google.appinventor.components.runtime.util.SdkLevel
 *  gnu.expr.Language
 *  gnu.expr.ModuleExp
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.Appendable
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.Socket
 *  java.security.Key
 *  java.util.ArrayList
 *  java.util.Formatter
 *  java.util.List
 *  java.util.Properties
 *  javax.crypto.Mac
 *  javax.crypto.spec.SecretKeySpec
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.google.appinventor.components.runtime.util;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.PhoneStatus;
import com.google.appinventor.components.runtime.ReplForm;
import com.google.appinventor.components.runtime.util.AppInvHTTPD;
import com.google.appinventor.components.runtime.util.EclairUtil;
import com.google.appinventor.components.runtime.util.NanoHTTPD;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.SdkLevel;
import gnu.expr.Language;
import gnu.expr.ModuleExp;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.security.Key;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Properties;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import kawa.standard.Scheme;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class AppInvHTTPD
extends NanoHTTPD {
    private static final String LOG_TAG = "AppInvHTTPD";
    private static final String MIME_JSON = "application/json";
    private static final int YAV_SKEW_BACKWARD = 4;
    private static final int YAV_SKEW_FORWARD = 1;
    private static byte[] hmacKey;
    private static int seq;
    private final Handler androidUIHandler = new Handler();
    private ReplForm form;
    private File rootDir;
    private Language scheme;
    private boolean secure;

    static /* bridge */ /* synthetic */ ReplForm -$$Nest$fgetform(AppInvHTTPD appInvHTTPD) {
        return appInvHTTPD.form;
    }

    public AppInvHTTPD(int n, File file, boolean bl, ReplForm replForm) throws IOException {
        super(n, file);
        this.rootDir = file;
        this.scheme = Scheme.getInstance((String)"scheme");
        this.form = replForm;
        this.secure = bl;
        ModuleExp.mustNeverCompile();
    }

    private NanoHTTPD.Response addHeaders(NanoHTTPD.Response response2) {
        response2.addHeader("Access-Control-Allow-Origin", "*");
        response2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
        response2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
        response2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
        return response2;
    }

    private void adoptMainThreadClassLoader() {
        ClassLoader classLoader = Looper.getMainLooper().getThread().getContextClassLoader();
        Thread thread = Thread.currentThread();
        if (thread.getContextClassLoader() != classLoader) {
            thread.setContextClassLoader(classLoader);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private boolean copyFile(File file, File object2) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            file = new FileOutputStream(object2);
            object2 = new byte[32768];
            while (true) {
                int n;
                if ((n = fileInputStream.read((byte[])object2)) <= 0) {
                    fileInputStream.close();
                    file.close();
                    return false;
                }
                file.write((byte[])object2, 0, n);
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return true;
        }
    }

    private NanoHTTPD.Response error(String string) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("status", (Object)"BAD");
            jSONObject.put("message", (Object)string);
        }
        catch (JSONException jSONException) {
            Log.wtf((String)LOG_TAG, (String)"Unable to write basic JSON content", (Throwable)jSONException);
        }
        return super.addHeaders(new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, jSONObject.toString()));
    }

    private NanoHTTPD.Response error(Throwable throwable) {
        return super.error(throwable.toString());
    }

    private NanoHTTPD.Response json(String string) {
        return super.addHeaders(new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, string));
    }

    private NanoHTTPD.Response message(String string) {
        return super.addHeaders(new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", "text/plain", string));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private NanoHTTPD.Response processLoadExtensionsRequest(Properties properties) {
        try {
            JSONArray jSONArray = new JSONArray(properties.getProperty("extensions", "[]"));
            properties = new ArrayList();
            for (int i = 0; i < jSONArray.length(); ++i) {
                String string = jSONArray.optString(i);
                if (string != null) {
                    properties.add((Object)string);
                    continue;
                }
                properties = new StringBuilder();
                return super.error(properties.append("Invalid JSON content at index ").append(i).toString());
            }
            try {
                this.form.loadComponents((List<String>)properties);
            }
            catch (Exception exception) {
                return super.error(exception);
            }
            return super.message("OK");
        }
        catch (JSONException jSONException) {
            return super.error(jSONException);
        }
    }

    public static void setHmacKey(String string) {
        hmacKey = string.getBytes();
        seq = 1;
    }

    public void resetSeq() {
        seq = 1;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public NanoHTTPD.Response serve(String object2, String object3, Properties object4, Properties object5, Properties object6, Socket object7) {
        block43: {
            block44: {
                block45: {
                    block46: {
                        Log.d((String)LOG_TAG, (String)((String)object3 + " '" + (String)object2 + "' "));
                        boolean bl = this.secure;
                        String string = "*";
                        if (bl && !(object7 = object7.getInetAddress().getHostAddress()).equals((Object)"127.0.0.1")) {
                            Log.d((String)LOG_TAG, (String)("Debug: hostAddress = " + (String)object7 + " while in secure mode, closing connection."));
                            object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, "{\"status\" : \"BAD\", \"message\" : \"Security Error: Invalid Source Location " + (String)object7 + "\"}");
                            object2.addHeader("Access-Control-Allow-Origin", "*");
                            object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                            object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                            object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                            return object2;
                        }
                        if (object3.equals((Object)"OPTIONS")) {
                            object2 = object4.propertyNames();
                            while (true) {
                                if (!object2.hasMoreElements()) {
                                    object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", "text/plain", "OK");
                                    object2.addHeader("Access-Control-Allow-Origin", "*");
                                    object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                                    object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                                    object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                                    return object2;
                                }
                                object5 = (String)object2.nextElement();
                                object3 = object4.getProperty((String)object5);
                                Log.d((String)LOG_TAG, (String)("  HDR: '" + (String)object5 + "' = '" + (String)object3 + "'"));
                            }
                        }
                        if (object2.equals((Object)"/_newblocks")) {
                            ReplForm replForm;
                            block40: {
                                int n2;
                                Formatter formatter;
                                StringBuffer stringBuffer;
                                this.adoptMainThreadClassLoader();
                                object7 = object5.getProperty("seq", "0");
                                int n = Integer.parseInt((String)object7);
                                object4 = object5.getProperty("blockid");
                                object6 = object5.getProperty("code");
                                object5 = object5.getProperty("mac", "no key provided");
                                if (hmacKey == null) {
                                    Log.e((String)LOG_TAG, (String)"No HMAC Key");
                                    object2 = this.form;
                                    ((Form)object2).dispatchErrorOccurredEvent((Component)object2, LOG_TAG, 1801, "No HMAC Key");
                                    return new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, "{\"status\" : \"BAD\", \"message\" : \"Security Error: No HMAC Key\"}");
                                }
                                try {
                                    object2 = Mac.getInstance((String)"HmacSHA1");
                                    object3 = new SecretKeySpec(hmacKey, "RAW");
                                    object2.init((Key)object3);
                                    object3 = new StringBuilder();
                                    object3 = object2.doFinal(object3.append((String)object6).append((String)object7).append((String)object4).toString().getBytes());
                                    stringBuffer = new StringBuffer(((Object)object3).length * 2);
                                    formatter = new Formatter((Appendable)stringBuffer);
                                    n2 = ((Object)object3).length;
                                    object2 = string;
                                }
                                catch (Exception exception) {
                                    // empty catch block
                                    break block40;
                                }
                                for (int i = 0; i < n2; ++i) {
                                    try {
                                        formatter.format("%02x", new Object[]{(byte)object3[i]});
                                        continue;
                                    }
                                    catch (Exception exception) {
                                        break block40;
                                    }
                                }
                                {
                                    object3 = stringBuffer.toString();
                                }
                                Log.d((String)LOG_TAG, (String)("Incoming Mac = " + (String)object5));
                                Log.d((String)LOG_TAG, (String)("Computed Mac = " + (String)object3));
                                Log.d((String)LOG_TAG, (String)("Incoming seq = " + (String)object7));
                                n2 = seq;
                                Log.d((String)LOG_TAG, (String)("Computed seq = " + n2));
                                Log.d((String)LOG_TAG, (String)("blockid = " + (String)object4));
                                if (!object5.equals(object3)) {
                                    Log.e((String)LOG_TAG, (String)"Hmac does not match");
                                    object2 = this.form;
                                    ((Form)object2).dispatchErrorOccurredEvent((Component)object2, LOG_TAG, 1801, "Invalid HMAC");
                                    return new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, "{\"status\" : \"BAD\", \"message\" : \"Security Error: Invalid MAC\"}");
                                }
                                n2 = seq;
                                if (n2 != n && n2 != n + 1) {
                                    Log.e((String)LOG_TAG, (String)"Seq does not match");
                                    object2 = this.form;
                                    ((Form)object2).dispatchErrorOccurredEvent((Component)object2, LOG_TAG, 1801, "Invalid Seq");
                                    return new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, "{\"status\" : \"BAD\", \"message\" : \"Security Error: Invalid Seq\"}");
                                }
                                if (n2 == n + 1) {
                                    Log.e((String)LOG_TAG, (String)"Seq Fixup Invoked");
                                }
                                seq = n + 1;
                                object3 = "(begin (require <com.google.youngandroid.runtime>) (process-repl-input " + (String)object4 + " (begin " + (String)object6 + " )))";
                                Log.d((String)LOG_TAG, (String)("To Eval: " + (String)object3));
                                try {
                                    if (object6.equals((Object)"#f")) {
                                        Log.e((String)LOG_TAG, (String)"Skipping evaluation of #f");
                                    } else {
                                        this.scheme.eval((String)object3);
                                    }
                                    object3 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, RetValManager.fetch((boolean)false));
                                }
                                catch (Throwable throwable) {
                                    Log.e((String)LOG_TAG, (String)"newblocks: Scheme Failure", (Throwable)throwable);
                                    RetValManager.appendReturnValue((String)object4, (String)"BAD", (String)throwable.toString());
                                    object3 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, RetValManager.fetch((boolean)false));
                                }
                                object3.addHeader("Access-Control-Allow-Origin", (String)object2);
                                object3.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                                object3.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                                object3.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                                return object3;
                            }
                            Log.e((String)LOG_TAG, (String)"Error working with hmac", (Throwable)replForm);
                            replForm = this.form;
                            replForm.dispatchErrorOccurredEvent(replForm, LOG_TAG, 1801, "Exception working on HMAC");
                            return new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", "text/plain", "NOT");
                        }
                        if (object2.equals((Object)"/_values")) {
                            object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, RetValManager.fetch((boolean)true));
                            object2.addHeader("Access-Control-Allow-Origin", "*");
                            object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                            object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                            object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                            return object2;
                        }
                        if (object2.equals((Object)"/_getversion")) {
                            block42: {
                                block41: {
                                    try {
                                        object4 = this.form.getPackageName();
                                        object3 = this.form.getPackageManager().getPackageInfo((String)object4, 0);
                                        int n = SdkLevel.getLevel();
                                        object2 = n >= 5 ? EclairUtil.getInstallerPackageName((String)"edu.mit.appinventor.aicompanion3", (Activity)this.form) : "Not Known";
                                        object5 = ((PackageInfo)object3).versionName;
                                        object3 = object2;
                                        if (object2 == null) {
                                            object3 = "Not Known";
                                        }
                                        object6 = Build.FINGERPRINT;
                                        object7 = new StringBuilder();
                                    }
                                    catch (PackageManager.NameNotFoundException nameNotFoundException) {
                                        // empty catch block
                                        break block41;
                                    }
                                    try {
                                        object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, object7.append("{\"version\" : \"").append((String)object5).append("\", \"fingerprint\" : \"").append((String)object6).append("\", \"installer\" : \"").append((String)object3).append("\", \"package\" : \"").append((String)object4).append("\", \"fqcn\" : true }").toString());
                                        break block42;
                                    }
                                    catch (PackageManager.NameNotFoundException nameNotFoundException) {}
                                }
                                object2.printStackTrace();
                                object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", MIME_JSON, "{\"verison\" : \"Unknown\"");
                            }
                            object2.addHeader("Access-Control-Allow-Origin", "*");
                            object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                            object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                            object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                            if (this.secure) {
                                seq = 1;
                                this.androidUIHandler.post((Runnable)new 1(this));
                            }
                            return object2;
                        }
                        if (object2.equals((Object)"/_extensions")) {
                            return this.processLoadExtensionsRequest((Properties)object5);
                        }
                        if (object2.equals((Object)"/_proxy")) {
                            object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", "text/html", PhoneStatus.getPopup());
                            object2.addHeader("Access-Control-Allow-Origin", "*");
                            object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
                            object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
                            object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
                            return object2;
                        }
                        if (!object3.equals((Object)"PUT")) {
                            return this.serveFile((String)object2, (Properties)object4, this.rootDir, true);
                        }
                        object2 = object6.getProperty("content", null);
                        if (object2 == null) break block44;
                        object4 = new File((String)object2);
                        object2 = object3 = object5.getProperty("filename", null);
                        if (object3 == null) break block45;
                        if (object3.startsWith("..") || object3.endsWith("..")) break block46;
                        object2 = object3;
                        if (object3.indexOf("../") < 0) break block45;
                    }
                    Log.d((String)LOG_TAG, (String)(" Ignoring invalid filename: " + (String)object3));
                    object2 = null;
                }
                if (object2 != null) {
                    object3 = this.rootDir;
                    object2 = new File(object3 + "/" + (String)object2);
                    if (!(object3 = object2.getParentFile()).exists()) {
                        object3.mkdirs();
                    }
                    if (!object4.renameTo((File)object2)) {
                        object2 = this.copyFile((File)object4, (File)object2);
                        object4.delete();
                        break block43;
                    } else {
                        object2 = false;
                    }
                    break block43;
                } else {
                    object4.delete();
                    Log.e((String)LOG_TAG, (String)"Received content without a file name!");
                    object2 = true;
                }
                break block43;
            }
            Log.e((String)LOG_TAG, (String)"Received PUT without content.");
            object2 = true;
        }
        if (object2.booleanValue()) {
            object2 = new NanoHTTPD.Response((NanoHTTPD)this, "500 Internal Server Error", "text/plain", "NOTOK");
            object2.addHeader("Access-Control-Allow-Origin", "*");
            object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
            object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
            object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
            return object2;
        }
        object2 = new NanoHTTPD.Response((NanoHTTPD)this, "200 OK", "text/plain", "OK");
        object2.addHeader("Access-Control-Allow-Origin", "*");
        object2.addHeader("Access-Control-Allow-Headers", "origin, content-type");
        object2.addHeader("Access-Control-Allow-Methods", "POST,OPTIONS,GET,HEAD,PUT");
        object2.addHeader("Allow", "POST,OPTIONS,GET,HEAD,PUT");
        return object2;
    }
}

