/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.data.LineData
 *  com.github.mikephil.charting.data.LineDataSet
 *  com.github.mikephil.charting.interfaces.datasets.ILineDataSet
 *  com.google.appinventor.components.runtime.AreaChartView
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Override
 *  java.util.List
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.appinventor.components.runtime.AreaChartView;
import com.google.appinventor.components.runtime.LineChartBaseDataModel;
import java.util.List;

public class AreaChartDataModel
extends LineChartBaseDataModel<AreaChartView> {
    public AreaChartDataModel(LineData lineData, AreaChartView areaChartView) {
        super(lineData, areaChartView);
    }

    @Override
    public void setColor(int n) {
        super.setColor(n);
        if (this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setFillColor(n);
        }
    }

    @Override
    public void setColors(List<Integer> list) {
        super.setColors(list);
        if (!list.isEmpty() && this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setFillColor(((Integer)list.get(0)).intValue());
        }
    }

    @Override
    protected void setDefaultStylingProperties() {
        super.setDefaultStylingProperties();
        ((ILineDataSet)this.dataset).setDrawFilled(true);
        if (this.dataset instanceof LineDataSet) {
            ((LineDataSet)this.dataset).setFillAlpha(100);
        }
    }
}

