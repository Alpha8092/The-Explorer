package com.google.appinventor.components.annotations.androidmanifest;

/* renamed from: com.google.appinventor.components.annotations.androidmanifest.package-info  reason: invalid class name */
/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/3.dex */
interface packageinfo {
}
