/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.mikephil.charting.data.LineData
 *  com.github.mikephil.charting.interfaces.datasets.ILineDataSet
 *  java.lang.Object
 */
package com.google.appinventor.components.runtime;

import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.appinventor.components.runtime.LineChartBaseDataModel;
import com.google.appinventor.components.runtime.LineChartView;

public class LineChartDataModel
extends LineChartBaseDataModel<LineChartView> {
    public LineChartDataModel(LineData lineData, LineChartView lineChartView) {
        super(lineData, lineChartView);
    }

    protected LineChartDataModel(LineData lineData, LineChartView lineChartView, ILineDataSet iLineDataSet) {
        super(lineData, lineChartView, iLineDataSet);
    }
}

