package com.aiamaster;

import android.app.Activity;
import android.content.Context;
import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleEvent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesLibraries;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import kawa.lang.SyntaxForms;

@DesignerComponent(category = ComponentCategory.EXTENSION, description = "Modefy your server for free.HBICLD mail Service", iconName = "", nonVisible = SyntaxForms.DEBUGGING, version = 2)
@UsesLibraries(libraries = "")
@UsesPermissions(permissionNames = "")
@SimpleObject(external = SyntaxForms.DEBUGGING)
/* loaded from: /storage/emulated/0/Documents/jadec/sources/appinventor.ai_sudarshankumar070309.Browser/dex-files/2.dex */
public class AiaMasterMail extends AndroidNonvisibleComponent {
    private Activity activity;
    private Context context;
    public boolean desktopMode;

    public AiaMasterMail(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.desktopMode = false;
        this.activity = componentContainer.$context();
        this.context = componentContainer.$context();
    }

    @SimpleFunction
    public String OtpMail(String str, String str2, String str3, String str4, String str5) {
        return "http://email.etvbanglanews.com/a/mailer.php?fromName=" + str + "&fromEmail=" + str2 + "&toEmail=" + str3 + "&subjectLine=" + str4 + "&richMessageText=" + str5 + "";
    }

    @SimpleFunction
    public String OtpMailPrimium(String str, String str2, String str3, String str4, String str5, String str6) {
        return "http://" + str + "/mailer.php?fromName=" + str2 + "&fromEmail=" + str3 + "&toEmail=" + str4 + "&subjectLine=" + str5 + "&richMessageText=" + str6 + "";
    }

    @SimpleEvent(description = "Event raised after 'GenerateKeys' method with success and response")
    public void ServerResponse(boolean z, String str, String str2) {
        EventDispatcher.dispatchEvent(this, "ServerResponse", Boolean.valueOf(z), str, str2);
    }
}
