/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  gnu.mapping.CallContext
 *  java.lang.Boolean
 *  java.lang.ClassCastException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package appinventor.ai_sudarshankumar070309.Browser;

import android.os.Bundle;
import appinventor.ai_sudarshankumar070309.Browser.Otp;
import com.google.appinventor.components.runtime.Component;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleMethod;
import gnu.mapping.CallContext;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;

public class Otp$frame
extends ModuleBody {
    Otp $main;

    @Override
    public Object apply0(ModuleMethod moduleMethod) {
        switch (moduleMethod.selector) {
            default: {
                return super.apply0(moduleMethod);
            }
            case 46: {
                return Otp.lambda26();
            }
            case 45: {
                return Otp.lambda25();
            }
            case 44: {
                return this.$main.Button1$Click();
            }
            case 43: {
                return Otp.lambda24();
            }
            case 42: {
                return Otp.lambda23();
            }
            case 41: {
                return Otp.lambda22();
            }
            case 40: {
                return Otp.lambda21();
            }
            case 39: {
                return Otp.lambda20();
            }
            case 38: {
                return Otp.lambda19();
            }
            case 37: {
                return this.$main.Regenerate_otp$Click();
            }
            case 36: {
                return Otp.lambda18();
            }
            case 35: {
                return Otp.lambda17();
            }
            case 34: {
                return Otp.lambda16();
            }
            case 33: {
                return Otp.lambda15();
            }
            case 32: {
                return Otp.lambda14();
            }
            case 31: {
                return Otp.lambda13();
            }
            case 30: {
                return this.$main.Button2$Click();
            }
            case 29: {
                return Otp.lambda12();
            }
            case 28: {
                return Otp.lambda11();
            }
            case 27: {
                return Otp.lambda10();
            }
            case 26: {
                return Otp.lambda9();
            }
            case 25: {
                return Otp.lambda8();
            }
            case 24: {
                return Otp.lambda7();
            }
            case 23: {
                return Otp.lambda6();
            }
            case 22: {
                return Otp.lambda5();
            }
            case 21: {
                return Otp.lambda4();
            }
            case 20: {
                return Otp.lambda3();
            }
            case 19: {
                this.$main.$define();
                return Values.empty;
            }
            case 18: 
        }
        return Otp.lambda2();
    }

    @Override
    public Object apply1(ModuleMethod object, Object object2) {
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply1((ModuleMethod)object, object2);
            }
            case 14: {
                this.$main.processException(object2);
                return Values.empty;
            }
            case 13: {
                this.$main.sendError(object2);
                return Values.empty;
            }
            case 12: {
                this.$main.addToFormDoAfterCreation(object2);
                return Values.empty;
            }
            case 7: {
                Symbol symbol;
                object = this.$main;
                try {
                    symbol = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "is-bound-in-form-environment", 1, object2);
                }
                object = ((Otp)object).isBoundInFormEnvironment(symbol) ? Boolean.TRUE : Boolean.FALSE;
                return object;
            }
            case 5: {
                Otp otp = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return otp.lookupInFormEnvironment((Symbol)object);
            }
            case 3: {
                this.$main.androidLogForm(object2);
                return Values.empty;
            }
            case 2: {
                Bundle bundle;
                object = this.$main;
                try {
                    bundle = (Bundle)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "onCreate", 1, object2);
                }
                ((Otp)object).onCreate(bundle);
                return Values.empty;
            }
            case 1: 
        }
        return this.$main.getSimpleName(object2);
    }

    @Override
    public Object apply2(ModuleMethod object, Object object2, Object object3) {
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply2((ModuleMethod)object, object2, object3);
            }
            case 17: {
                return this.$main.lookupHandler(object2, object3);
            }
            case 11: {
                this.$main.addToGlobalVars(object2, object3);
                return Values.empty;
            }
            case 9: {
                this.$main.addToEvents(object2, object3);
                return Values.empty;
            }
            case 8: {
                Symbol symbol;
                object = this.$main;
                try {
                    symbol = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "add-to-global-var-environment", 1, object2);
                }
                ((Otp)object).addToGlobalVarEnvironment(symbol, object3);
                return Values.empty;
            }
            case 5: {
                Otp otp = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return otp.lookupInFormEnvironment((Symbol)object, object3);
            }
            case 4: 
        }
        Otp otp = this.$main;
        try {
            object = (Symbol)object2;
        }
        catch (ClassCastException classCastException) {
            throw new WrongType(classCastException, "add-to-form-environment", 1, object2);
        }
        otp.addToFormEnvironment((Symbol)object, object3);
        return Values.empty;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object apply4(ModuleMethod object, Object object2, Object objectArray, Object objectArray2, Object object3) {
        int n = ((ModuleMethod)object).selector;
        boolean bl = true;
        switch (n) {
            default: {
                return super.apply4((ModuleMethod)object, object2, objectArray, objectArray2, object3);
            }
            case 16: {
                Otp otp = this.$main;
                try {
                    object = (Component)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 1, object2);
                }
                try {
                    object2 = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = Boolean.FALSE;
                    if (objectArray2 == objectArray) {
                        bl = false;
                    }
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray = (Object[])object3;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 4, object3);
                }
                otp.dispatchGenericEvent((Component)object, (String)object2, bl, objectArray);
                return Values.empty;
            }
            case 15: {
                Otp otp = this.$main;
                try {
                    object = (Component)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 1, object2);
                }
                try {
                    object2 = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = (String)objectArray2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray2 = (Object[])object3;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 4, object3);
                }
                if (!otp.dispatchEvent((Component)object, (String)object2, (String)objectArray, objectArray2)) return Boolean.FALSE;
                return Boolean.TRUE;
            }
            case 10: 
        }
        this.$main.addToComponents(object2, objectArray, objectArray2, object3);
        return Values.empty;
    }

    @Override
    public int match0(ModuleMethod moduleMethod, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match0(moduleMethod, callContext);
            }
            case 20: 
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 30: 
            case 31: 
            case 32: 
            case 33: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 38: 
            case 39: 
            case 40: 
            case 41: 
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 46: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 19: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 18: 
        }
        callContext.proc = moduleMethod;
        callContext.pc = 0;
        return 0;
    }

    @Override
    public int match1(ModuleMethod moduleMethod, Object object, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match1(moduleMethod, object, callContext);
            }
            case 14: {
                if (!(object instanceof Otp)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 13: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 12: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 7: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 3: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 2: {
                if (!(object instanceof Otp)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 1: 
        }
        callContext.value1 = object;
        callContext.proc = moduleMethod;
        callContext.pc = 1;
        return 0;
    }

    @Override
    public int match2(ModuleMethod moduleMethod, Object object, Object object2, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match2(moduleMethod, object, object2, callContext);
            }
            case 17: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 11: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 9: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 8: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 4: 
        }
        if (!(object instanceof Symbol)) {
            return -786431;
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.proc = moduleMethod;
        callContext.pc = 2;
        return 0;
    }

    @Override
    public int match4(ModuleMethod moduleMethod, Object object, Object object2, Object object3, Object object4, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match4(moduleMethod, object, object2, object3, object4, callContext);
            }
            case 16: {
                if (!(object instanceof Otp)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 15: {
                if (!(object instanceof Otp)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                if (!(object4 instanceof String)) {
                    return -786428;
                }
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 10: 
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.value3 = object3;
        callContext.value4 = object4;
        callContext.proc = moduleMethod;
        callContext.pc = 4;
        return 0;
    }
}

