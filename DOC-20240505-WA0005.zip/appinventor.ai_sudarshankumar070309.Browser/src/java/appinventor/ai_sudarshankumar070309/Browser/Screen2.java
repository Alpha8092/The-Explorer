/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.aiamaster.AiaMasterMail
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.Button
 *  com.google.appinventor.components.runtime.EmailPicker
 *  com.google.appinventor.components.runtime.Label
 *  com.google.appinventor.components.runtime.Notifier
 *  com.google.appinventor.components.runtime.util.RetValManager
 *  com.google.appinventor.components.runtime.util.RuntimeErrorAlert
 *  gnu.expr.Language
 *  gnu.expr.ModuleInfo
 *  gnu.lists.Consumer
 *  gnu.mapping.CallContext
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.ClassCastException
 *  java.lang.Comparable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Package
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 */
package appinventor.ai_sudarshankumar070309.Browser;

import android.os.Bundle;
import appinventor.ai_sudarshankumar070309.Browser.Screen2$frame;
import com.aiamaster.AiaMasterMail;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EmailPicker;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.PasswordTextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Web;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.StopBlocksExecution;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;

public class Screen2
extends Form
implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final IntNum Lit100;
    static final IntNum Lit101;
    static final FString Lit102;
    static final PairWithPosition Lit103;
    static final SimpleSymbol Lit104;
    static final FString Lit105;
    static final SimpleSymbol Lit106;
    static final FString Lit107;
    static final SimpleSymbol Lit108;
    static final SimpleSymbol Lit109;
    static final SimpleSymbol Lit11;
    static final SimpleSymbol Lit110;
    static final FString Lit111;
    static final SimpleSymbol Lit112;
    static final FString Lit113;
    static final FString Lit114;
    static final FString Lit115;
    static final SimpleSymbol Lit116;
    static final SimpleSymbol Lit117;
    static final SimpleSymbol Lit118;
    static final SimpleSymbol Lit119;
    static final SimpleSymbol Lit12;
    static final SimpleSymbol Lit120;
    static final SimpleSymbol Lit121;
    static final SimpleSymbol Lit122;
    static final SimpleSymbol Lit123;
    static final SimpleSymbol Lit124;
    static final SimpleSymbol Lit125;
    static final SimpleSymbol Lit126;
    static final SimpleSymbol Lit127;
    static final SimpleSymbol Lit128;
    static final SimpleSymbol Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final SimpleSymbol Lit131;
    static final SimpleSymbol Lit132;
    static final SimpleSymbol Lit14;
    static final SimpleSymbol Lit15;
    static final SimpleSymbol Lit16;
    static final SimpleSymbol Lit17;
    static final FString Lit18;
    static final SimpleSymbol Lit19;
    static final SimpleSymbol Lit2;
    static final IntNum Lit20;
    static final SimpleSymbol Lit21;
    static final IntNum Lit22;
    static final SimpleSymbol Lit23;
    static final IntNum Lit24;
    static final SimpleSymbol Lit25;
    static final IntNum Lit26;
    static final FString Lit27;
    static final FString Lit28;
    static final SimpleSymbol Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final SimpleSymbol Lit31;
    static final IntNum Lit32;
    static final SimpleSymbol Lit33;
    static final SimpleSymbol Lit34;
    static final FString Lit35;
    static final FString Lit36;
    static final SimpleSymbol Lit37;
    static final FString Lit38;
    static final FString Lit39;
    static final SimpleSymbol Lit4;
    static final SimpleSymbol Lit40;
    static final SimpleSymbol Lit41;
    static final FString Lit42;
    static final FString Lit43;
    static final SimpleSymbol Lit44;
    static final FString Lit45;
    static final FString Lit46;
    static final SimpleSymbol Lit47;
    static final FString Lit48;
    static final FString Lit49;
    static final SimpleSymbol Lit5;
    static final SimpleSymbol Lit50;
    static final SimpleSymbol Lit51;
    static final IntNum Lit52;
    static final SimpleSymbol Lit53;
    static final FString Lit54;
    static final FString Lit55;
    static final SimpleSymbol Lit56;
    static final IntNum Lit57;
    static final SimpleSymbol Lit58;
    static final IntNum Lit59;
    static final SimpleSymbol Lit6;
    static final SimpleSymbol Lit60;
    static final IntNum Lit61;
    static final IntNum Lit62;
    static final FString Lit63;
    static final PairWithPosition Lit64;
    static final SimpleSymbol Lit65;
    static final SimpleSymbol Lit66;
    static final FString Lit67;
    static final SimpleSymbol Lit68;
    static final FString Lit69;
    static final IntNum Lit7;
    static final FString Lit70;
    static final SimpleSymbol Lit71;
    static final IntNum Lit72;
    static final FString Lit73;
    static final FString Lit74;
    static final SimpleSymbol Lit75;
    static final IntNum Lit76;
    static final FString Lit77;
    static final SimpleSymbol Lit78;
    static final SimpleSymbol Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final PairWithPosition Lit81;
    static final SimpleSymbol Lit82;
    static final PairWithPosition Lit83;
    static final IntNum Lit84;
    static final PairWithPosition Lit85;
    static final PairWithPosition Lit86;
    static final PairWithPosition Lit87;
    static final PairWithPosition Lit88;
    static final PairWithPosition Lit89;
    static final SimpleSymbol Lit9;
    static final PairWithPosition Lit90;
    static final PairWithPosition Lit91;
    static final PairWithPosition Lit92;
    static final SimpleSymbol Lit93;
    static final SimpleSymbol Lit94;
    static final PairWithPosition Lit95;
    static final PairWithPosition Lit96;
    static final SimpleSymbol Lit97;
    static final FString Lit98;
    static final SimpleSymbol Lit99;
    public static Screen2 Screen2;
    static final ModuleMethod lambda$Fn1;
    static final ModuleMethod lambda$Fn10;
    static final ModuleMethod lambda$Fn11;
    static final ModuleMethod lambda$Fn12;
    static final ModuleMethod lambda$Fn13;
    static final ModuleMethod lambda$Fn14;
    static final ModuleMethod lambda$Fn15;
    static final ModuleMethod lambda$Fn16;
    static final ModuleMethod lambda$Fn17;
    static final ModuleMethod lambda$Fn18;
    static final ModuleMethod lambda$Fn19;
    static final ModuleMethod lambda$Fn2;
    static final ModuleMethod lambda$Fn20;
    static final ModuleMethod lambda$Fn21;
    static final ModuleMethod lambda$Fn22;
    static final ModuleMethod lambda$Fn23;
    static final ModuleMethod lambda$Fn25;
    static final ModuleMethod lambda$Fn26;
    static final ModuleMethod lambda$Fn27;
    static final ModuleMethod lambda$Fn28;
    static final ModuleMethod lambda$Fn3;
    static final ModuleMethod lambda$Fn4;
    static final ModuleMethod lambda$Fn5;
    static final ModuleMethod lambda$Fn6;
    static final ModuleMethod lambda$Fn7;
    static final ModuleMethod lambda$Fn8;
    static final ModuleMethod lambda$Fn9;
    static final ModuleMethod proc$Fn24;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public AiaMasterMail AiaMasterMail1;
    public EmailPicker EmailPicker1;
    public Button Forgot_Password;
    public final ModuleMethod Forgot_Password$Click;
    public HorizontalArrangement HorizontalArrangement2;
    public Label Label1;
    public Label Label2;
    public Label Label3;
    public Label Label4;
    public Notifier Notifier1;
    public PasswordTextBox PasswordTextBox1;
    public Label Password_did_not_amtch;
    public Button Sign_In;
    public final ModuleMethod Sign_In$Click;
    public Button Sign_up;
    public final ModuleMethod Sign_up$Click;
    public VerticalArrangement VerticalArrangement1;
    public Web Web1;
    public final ModuleMethod Web1$GotText;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod onCreate;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        SimpleSymbol simpleSymbol;
        Object object = (SimpleSymbol)new SimpleSymbol("list").readResolve();
        Lit132 = object;
        Lit131 = simpleSymbol = (SimpleSymbol)new SimpleSymbol("any").readResolve();
        Lit130 = (SimpleSymbol)new SimpleSymbol("proc").readResolve();
        Lit129 = (SimpleSymbol)new SimpleSymbol("lookup-handler").readResolve();
        Lit128 = (SimpleSymbol)new SimpleSymbol("dispatchGenericEvent").readResolve();
        Lit127 = (SimpleSymbol)new SimpleSymbol("dispatchEvent").readResolve();
        Lit126 = (SimpleSymbol)new SimpleSymbol("send-error").readResolve();
        Lit125 = (SimpleSymbol)new SimpleSymbol("add-to-form-do-after-creation").readResolve();
        Lit124 = (SimpleSymbol)new SimpleSymbol("add-to-global-vars").readResolve();
        Lit123 = (SimpleSymbol)new SimpleSymbol("add-to-components").readResolve();
        Lit122 = (SimpleSymbol)new SimpleSymbol("add-to-events").readResolve();
        Lit121 = (SimpleSymbol)new SimpleSymbol("add-to-global-var-environment").readResolve();
        Lit120 = (SimpleSymbol)new SimpleSymbol("is-bound-in-form-environment").readResolve();
        Lit119 = (SimpleSymbol)new SimpleSymbol("lookup-in-form-environment").readResolve();
        Lit118 = (SimpleSymbol)new SimpleSymbol("add-to-form-environment").readResolve();
        Lit117 = (SimpleSymbol)new SimpleSymbol("android-log-form").readResolve();
        Lit116 = (SimpleSymbol)new SimpleSymbol("get-simple-name").readResolve();
        Lit115 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit114 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit113 = new FString("com.aiamaster.AiaMasterMail");
        Lit112 = (SimpleSymbol)new SimpleSymbol("AiaMasterMail1").readResolve();
        Lit111 = new FString("com.aiamaster.AiaMasterMail");
        Lit110 = (SimpleSymbol)new SimpleSymbol("GotText").readResolve();
        Lit109 = (SimpleSymbol)new SimpleSymbol("Web1$GotText").readResolve();
        Lit108 = (SimpleSymbol)new SimpleSymbol("$responseContent").readResolve();
        Lit107 = new FString("com.google.appinventor.components.runtime.Web");
        Lit106 = (SimpleSymbol)new SimpleSymbol("Url").readResolve();
        Lit105 = new FString("com.google.appinventor.components.runtime.Web");
        Lit104 = (SimpleSymbol)new SimpleSymbol("Sign_up$Click").readResolve();
        Object object2 = (SimpleSymbol)new SimpleSymbol("text").readResolve();
        Lit11 = object2;
        Lit103 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 688206);
        Lit102 = new FString("com.google.appinventor.components.runtime.Button");
        Object object3 = new int[2];
        object3[0] = -256;
        Lit101 = IntNum.make(object3);
        Lit100 = IntNum.make(0xFFFFFF);
        Lit99 = (SimpleSymbol)new SimpleSymbol("Sign_up").readResolve();
        Lit98 = new FString("com.google.appinventor.components.runtime.Button");
        Lit97 = (SimpleSymbol)new SimpleSymbol("Sign_In$Click").readResolve();
        Lit96 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611978);
        Lit95 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611873);
        Lit94 = (SimpleSymbol)new SimpleSymbol("LogInfo").readResolve();
        Lit93 = (SimpleSymbol)new SimpleSymbol("Notifier1").readResolve();
        Lit92 = PairWithPosition.make(simpleSymbol, PairWithPosition.make(simpleSymbol, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611716), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611711);
        Lit91 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611684), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611678);
        Lit90 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611394), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611388);
        object3 = (SimpleSymbol)new SimpleSymbol("number").readResolve();
        Lit8 = object3;
        Lit89 = PairWithPosition.make(object, PairWithPosition.make(object3, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611319), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611313);
        Lit88 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611139), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 611133);
        Lit87 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610973);
        Lit86 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610876), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610870);
        Lit85 = PairWithPosition.make(object, PairWithPosition.make(object3, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610801), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610795);
        Lit84 = IntNum.make(5);
        Lit83 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610621), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610615);
        Lit82 = (SimpleSymbol)new SimpleSymbol("$item").readResolve();
        Lit81 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 610464);
        Lit80 = (SimpleSymbol)new SimpleSymbol("PostText").readResolve();
        Lit79 = (SimpleSymbol)new SimpleSymbol("Get").readResolve();
        Lit78 = (SimpleSymbol)new SimpleSymbol("Web1").readResolve();
        Lit77 = new FString("com.google.appinventor.components.runtime.Button");
        object = new int[2];
        object[0] = -2492673;
        Lit76 = IntNum.make((int[])object);
        Lit75 = (SimpleSymbol)new SimpleSymbol("Sign_In").readResolve();
        Lit74 = new FString("com.google.appinventor.components.runtime.Button");
        Lit73 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit72 = IntNum.make(0xFFFFFF);
        Lit71 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement2").readResolve();
        Lit70 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit69 = new FString("com.google.appinventor.components.runtime.Label");
        Lit68 = (SimpleSymbol)new SimpleSymbol("Label2").readResolve();
        Lit67 = new FString("com.google.appinventor.components.runtime.Label");
        Lit66 = (SimpleSymbol)new SimpleSymbol("Click").readResolve();
        Lit65 = (SimpleSymbol)new SimpleSymbol("Forgot_Password$Click").readResolve();
        Lit64 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen2.yail", 475210);
        Lit63 = new FString("com.google.appinventor.components.runtime.Button");
        object2 = new int[2];
        object2[0] = -16776961;
        Lit62 = IntNum.make((int[])object2);
        Lit61 = IntNum.make(1);
        Lit60 = (SimpleSymbol)new SimpleSymbol("Shape").readResolve();
        Lit59 = IntNum.make(14);
        Lit58 = (SimpleSymbol)new SimpleSymbol("FontItalic").readResolve();
        Lit57 = IntNum.make(0xFFFFFF);
        Lit56 = (SimpleSymbol)new SimpleSymbol("Forgot_Password").readResolve();
        Lit55 = new FString("com.google.appinventor.components.runtime.Button");
        Lit54 = new FString("com.google.appinventor.components.runtime.Label");
        Lit53 = (SimpleSymbol)new SimpleSymbol("Visible").readResolve();
        object2 = new int[2];
        object2[0] = -65536;
        Lit52 = IntNum.make((int[])object2);
        Lit51 = (SimpleSymbol)new SimpleSymbol("TextColor").readResolve();
        Lit50 = (SimpleSymbol)new SimpleSymbol("Password_did_not_amtch").readResolve();
        Lit49 = new FString("com.google.appinventor.components.runtime.Label");
        Lit48 = new FString("com.google.appinventor.components.runtime.PasswordTextBox");
        Lit47 = (SimpleSymbol)new SimpleSymbol("PasswordTextBox1").readResolve();
        Lit46 = new FString("com.google.appinventor.components.runtime.PasswordTextBox");
        Lit45 = new FString("com.google.appinventor.components.runtime.Label");
        Lit44 = (SimpleSymbol)new SimpleSymbol("Label4").readResolve();
        Lit43 = new FString("com.google.appinventor.components.runtime.Label");
        Lit42 = new FString("com.google.appinventor.components.runtime.EmailPicker");
        Lit41 = (SimpleSymbol)new SimpleSymbol("Hint").readResolve();
        Lit40 = (SimpleSymbol)new SimpleSymbol("EmailPicker1").readResolve();
        Lit39 = new FString("com.google.appinventor.components.runtime.EmailPicker");
        Lit38 = new FString("com.google.appinventor.components.runtime.Label");
        Lit37 = (SimpleSymbol)new SimpleSymbol("Label3").readResolve();
        Lit36 = new FString("com.google.appinventor.components.runtime.Label");
        Lit35 = new FString("com.google.appinventor.components.runtime.Label");
        Lit34 = (SimpleSymbol)new SimpleSymbol("Text").readResolve();
        Lit33 = (SimpleSymbol)new SimpleSymbol("FontTypeface").readResolve();
        Lit32 = IntNum.make(20);
        Lit31 = (SimpleSymbol)new SimpleSymbol("FontSize").readResolve();
        Lit30 = (SimpleSymbol)new SimpleSymbol("FontBold").readResolve();
        Lit29 = (SimpleSymbol)new SimpleSymbol("Label1").readResolve();
        Lit28 = new FString("com.google.appinventor.components.runtime.Label");
        Lit27 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit26 = IntNum.make(-2);
        Lit25 = (SimpleSymbol)new SimpleSymbol("Width").readResolve();
        Lit24 = IntNum.make(-1050);
        Lit23 = (SimpleSymbol)new SimpleSymbol("Height").readResolve();
        Lit22 = IntNum.make(0xFFFFFF);
        Lit21 = (SimpleSymbol)new SimpleSymbol("BackgroundColor").readResolve();
        Lit20 = IntNum.make(3);
        Lit19 = (SimpleSymbol)new SimpleSymbol("VerticalArrangement1").readResolve();
        Lit18 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit17 = (SimpleSymbol)new SimpleSymbol("TitleVisible").readResolve();
        Lit16 = (SimpleSymbol)new SimpleSymbol("Title").readResolve();
        Lit15 = (SimpleSymbol)new SimpleSymbol("Sizing").readResolve();
        Lit14 = (SimpleSymbol)new SimpleSymbol("ShowListsAsJson").readResolve();
        Lit13 = (SimpleSymbol)new SimpleSymbol("ScreenOrientation").readResolve();
        Lit12 = (SimpleSymbol)new SimpleSymbol("BackgroundImage").readResolve();
        Lit10 = (SimpleSymbol)new SimpleSymbol("AppName").readResolve();
        Lit9 = (SimpleSymbol)new SimpleSymbol("AlignVertical").readResolve();
        Lit7 = IntNum.make(2);
        Lit6 = (SimpleSymbol)new SimpleSymbol("AlignHorizontal").readResolve();
        Lit5 = (SimpleSymbol)new SimpleSymbol("boolean").readResolve();
        Lit4 = (SimpleSymbol)new SimpleSymbol("ActionBar").readResolve();
        Lit3 = (SimpleSymbol)new SimpleSymbol("g$password").readResolve();
        Lit2 = (SimpleSymbol)new SimpleSymbol("*the-null-value*").readResolve();
        Lit1 = (SimpleSymbol)new SimpleSymbol("getMessage").readResolve();
        Lit0 = (SimpleSymbol)new SimpleSymbol("Screen2").readResolve();
    }

    public Screen2() {
        ModuleInfo.register((Object)this);
        Screen2$frame screen2$frame = new Screen2$frame();
        screen2$frame.$main = this;
        this.get$Mnsimple$Mnname = new ModuleMethod(screen2$frame, 1, Lit116, 4097);
        this.onCreate = new ModuleMethod(screen2$frame, 2, "onCreate", 4097);
        this.android$Mnlog$Mnform = new ModuleMethod(screen2$frame, 3, Lit117, 4097);
        this.add$Mnto$Mnform$Mnenvironment = new ModuleMethod(screen2$frame, 4, Lit118, 8194);
        this.lookup$Mnin$Mnform$Mnenvironment = new ModuleMethod(screen2$frame, 5, Lit119, 8193);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = new ModuleMethod(screen2$frame, 7, Lit120, 4097);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = new ModuleMethod(screen2$frame, 8, Lit121, 8194);
        this.add$Mnto$Mnevents = new ModuleMethod(screen2$frame, 9, Lit122, 8194);
        this.add$Mnto$Mncomponents = new ModuleMethod(screen2$frame, 10, Lit123, 16388);
        this.add$Mnto$Mnglobal$Mnvars = new ModuleMethod(screen2$frame, 11, Lit124, 8194);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = new ModuleMethod(screen2$frame, 12, Lit125, 4097);
        this.send$Mnerror = new ModuleMethod(screen2$frame, 13, Lit126, 4097);
        this.process$Mnexception = new ModuleMethod(screen2$frame, 14, "process-exception", 4097);
        this.dispatchEvent = new ModuleMethod(screen2$frame, 15, Lit127, 16388);
        this.dispatchGenericEvent = new ModuleMethod(screen2$frame, 16, Lit128, 16388);
        this.lookup$Mnhandler = new ModuleMethod(screen2$frame, 17, Lit129, 8194);
        ModuleMethod moduleMethod = new ModuleMethod(screen2$frame, 18, null, 0);
        moduleMethod.setProperty("source-location", "/tmp/runtime15289563291066899343.scm:634");
        lambda$Fn1 = moduleMethod;
        this.$define = new ModuleMethod(screen2$frame, 19, "$define", 0);
        lambda$Fn2 = new ModuleMethod(screen2$frame, 20, null, 0);
        lambda$Fn3 = new ModuleMethod(screen2$frame, 21, null, 0);
        lambda$Fn4 = new ModuleMethod(screen2$frame, 22, null, 0);
        lambda$Fn5 = new ModuleMethod(screen2$frame, 23, null, 0);
        lambda$Fn6 = new ModuleMethod(screen2$frame, 24, null, 0);
        lambda$Fn7 = new ModuleMethod(screen2$frame, 25, null, 0);
        lambda$Fn8 = new ModuleMethod(screen2$frame, 26, null, 0);
        lambda$Fn9 = new ModuleMethod(screen2$frame, 27, null, 0);
        lambda$Fn10 = new ModuleMethod(screen2$frame, 28, null, 0);
        lambda$Fn11 = new ModuleMethod(screen2$frame, 29, null, 0);
        lambda$Fn12 = new ModuleMethod(screen2$frame, 30, null, 0);
        lambda$Fn13 = new ModuleMethod(screen2$frame, 31, null, 0);
        lambda$Fn14 = new ModuleMethod(screen2$frame, 32, null, 0);
        lambda$Fn15 = new ModuleMethod(screen2$frame, 33, null, 0);
        lambda$Fn16 = new ModuleMethod(screen2$frame, 34, null, 0);
        lambda$Fn17 = new ModuleMethod(screen2$frame, 35, null, 0);
        this.Forgot_Password$Click = new ModuleMethod(screen2$frame, 36, Lit65, 0);
        lambda$Fn18 = new ModuleMethod(screen2$frame, 37, null, 0);
        lambda$Fn19 = new ModuleMethod(screen2$frame, 38, null, 0);
        lambda$Fn20 = new ModuleMethod(screen2$frame, 39, null, 0);
        lambda$Fn21 = new ModuleMethod(screen2$frame, 40, null, 0);
        lambda$Fn22 = new ModuleMethod(screen2$frame, 41, null, 0);
        lambda$Fn23 = new ModuleMethod(screen2$frame, 42, null, 0);
        proc$Fn24 = new ModuleMethod(screen2$frame, 43, Lit130, 4097);
        this.Sign_In$Click = new ModuleMethod(screen2$frame, 44, Lit97, 0);
        lambda$Fn25 = new ModuleMethod(screen2$frame, 45, null, 0);
        lambda$Fn26 = new ModuleMethod(screen2$frame, 46, null, 0);
        this.Sign_up$Click = new ModuleMethod(screen2$frame, 47, Lit104, 0);
        lambda$Fn27 = new ModuleMethod(screen2$frame, 48, null, 0);
        lambda$Fn28 = new ModuleMethod(screen2$frame, 49, null, 0);
        this.Web1$GotText = new ModuleMethod(screen2$frame, 50, Lit109, 16388);
    }

    static Object lambda10() {
        SimpleSymbol simpleSymbol = Lit37;
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Email Address ", simpleSymbol3);
    }

    static Object lambda11() {
        return runtime.setAndCoerceProperty$Ex(Lit40, Lit41, " EmailPicker1", Lit11);
    }

    static Object lambda12() {
        return runtime.setAndCoerceProperty$Ex(Lit40, Lit41, " EmailPicker1", Lit11);
    }

    static Object lambda13() {
        SimpleSymbol simpleSymbol = Lit44;
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Password ", simpleSymbol3);
    }

    static Object lambda14() {
        SimpleSymbol simpleSymbol = Lit44;
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Password ", simpleSymbol3);
    }

    static Object lambda15() {
        SimpleSymbol simpleSymbol = Lit50;
        SimpleSymbol simpleSymbol2 = Lit30;
        Object object = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit5;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, object, simpleSymbol3);
        simpleSymbol2 = Lit33;
        object = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Password did not match! Try again!", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit52, Lit8);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit53, Boolean.FALSE, simpleSymbol3);
    }

    static Object lambda16() {
        SimpleSymbol simpleSymbol = Lit50;
        SimpleSymbol simpleSymbol2 = Lit30;
        Object object = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit5;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, object, simpleSymbol3);
        simpleSymbol2 = Lit33;
        object = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Password did not match! Try again!", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit52, Lit8);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit53, Boolean.FALSE, simpleSymbol3);
    }

    static Object lambda17() {
        SimpleSymbol simpleSymbol = Lit56;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit57;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, Boolean.TRUE, Lit5);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, (Object)Lit59, simpleSymbol3);
        simpleSymbol2 = Lit33;
        comparable = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Forgot Password ?", comparable);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit62, simpleSymbol3);
    }

    static Object lambda18() {
        SimpleSymbol simpleSymbol = Lit56;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit57;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, Boolean.TRUE, Lit5);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, (Object)Lit59, simpleSymbol3);
        comparable = Lit33;
        simpleSymbol2 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Forgot Password ?", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit62, simpleSymbol3);
    }

    static Object lambda19() {
        return runtime.setAndCoerceProperty$Ex(Lit68, Lit31, (Object)Lit32, Lit8);
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SimpleSymbol lambda1symbolAppend$V(Object[] objectArray) {
        Object object = LList.makeList(objectArray, 0);
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        LList lList = LList.Empty;
        while (true) {
            Symbol symbol;
            Object object2;
            void var0_2;
            if (object == LList.Empty) {
                Object object3 = ((Procedure)apply).apply2(moduleMethod, LList.reverseInPlace(var0_2));
                try {
                    object = (CharSequence)object3;
                    return misc.string$To$Symbol((CharSequence)object);
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "string->symbol", 1, object3);
                }
            }
            try {
                object2 = (Pair)object;
            }
            catch (ClassCastException classCastException) {
                WrongType wrongType = new WrongType(classCastException, "arg0", -2, object);
                throw wrongType;
            }
            object = ((Pair)object2).getCdr();
            object2 = ((Pair)object2).getCar();
            try {
                symbol = (Symbol)object2;
            }
            catch (ClassCastException classCastException) {
                throw new WrongType(classCastException, "symbol->string", 1, object2);
            }
            Pair pair = Pair.make(misc.symbol$To$String(symbol), var0_2);
        }
    }

    static Object lambda2() {
        return null;
    }

    static Object lambda20() {
        return runtime.setAndCoerceProperty$Ex(Lit68, Lit31, (Object)Lit32, Lit8);
    }

    static Object lambda21() {
        SimpleSymbol simpleSymbol = Lit71;
        SimpleSymbol simpleSymbol2 = Lit6;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit72, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit25, (Object)Lit26, simpleSymbol3);
    }

    static Object lambda22() {
        SimpleSymbol simpleSymbol = Lit71;
        SimpleSymbol simpleSymbol2 = Lit6;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit72, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit25, (Object)Lit26, simpleSymbol3);
    }

    static Object lambda23() {
        SimpleSymbol simpleSymbol = Lit75;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit76;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit33;
        comparable = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Sign In", comparable);
    }

    static Object lambda24() {
        SimpleSymbol simpleSymbol = Lit75;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit76;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit33;
        simpleSymbol2 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Sign In", simpleSymbol2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Object lambda25proc(Object object) {
        SimpleSymbol simpleSymbol;
        Object object2;
        ModuleMethod moduleMethod;
        ModuleMethod moduleMethod2 = runtime.string$Mncontains;
        Object object3 = object instanceof Package ? runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit82), " is not bound in the current context"), "Unbound Variable") : object;
        if (runtime.callYailPrimitive(moduleMethod2, LList.list2(object3, ((Procedure)(moduleMethod = runtime.get$Mnproperty)).apply2(object2 = Lit40, simpleSymbol = Lit34)), Lit83, "string contains") != Boolean.FALSE) {
            object3 = strings.string$Eq$Qu;
            object2 = runtime.yail$Mnlist$Mnget$Mnitem;
            if (object instanceof Package) {
                object = runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit82), " is not bound in the current context"), "Unbound Variable");
            }
            if (runtime.callYailPrimitive(object3, LList.list2(runtime.callYailPrimitive(object2, LList.list2(object, (Object)Lit84), Lit85, "select list item"), ((Procedure)runtime.get$Mnproperty).apply2(Lit47, simpleSymbol)), Lit86, "text=") == Boolean.FALSE) return Values.empty;
            return runtime.callYailPrimitive(runtime.open$Mnanother$Mnscreen, LList.list1("Screen4"), Lit87, "open another screen");
        }
        moduleMethod2 = runtime.string$Mncontains;
        object3 = object instanceof Package ? runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit82), " is not bound in the current context"), "Unbound Variable") : object;
        if (runtime.callYailPrimitive(moduleMethod2, LList.list2(object3, ((Procedure)runtime.get$Mnproperty).apply2(object2, simpleSymbol)), Lit88, "string contains") != Boolean.FALSE) {
            object3 = strings.string$Eq$Qu;
            object2 = runtime.yail$Mnlist$Mnget$Mnitem;
            if (object instanceof Package) {
                object = runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit82), " is not bound in the current context"), "Unbound Variable");
            }
            if (runtime.callYailPrimitive(object3, LList.list2(runtime.callYailPrimitive(object2, LList.list2(object, (Object)Lit84), Lit89, "select list item"), ((Procedure)runtime.get$Mnproperty).apply2(Lit47, simpleSymbol)), Lit90, "text=") == Boolean.FALSE) return Values.empty;
            return runtime.setAndCoerceProperty$Ex(Lit50, Lit53, Boolean.TRUE, Lit5);
        }
        moduleMethod2 = runtime.yail$Mnequal$Qu;
        object3 = Boolean.FALSE;
        moduleMethod = runtime.string$Mncontains;
        if (object instanceof Package) {
            object = runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit82), " is not bound in the current context"), "Unbound Variable");
        }
        if (runtime.callYailPrimitive(moduleMethod2, LList.list2(object3, runtime.callYailPrimitive(moduleMethod, LList.list2(object, ((Procedure)runtime.get$Mnproperty).apply2(object2, simpleSymbol)), Lit91, "string contains")), Lit92, "=") == Boolean.FALSE) return Values.empty;
        return runtime.callComponentMethod(Lit93, Lit94, LList.list1("Your Email is not registered in VedaPages, please sign up to continue."), Lit95);
    }

    static Object lambda26() {
        SimpleSymbol simpleSymbol = Lit99;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit100;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, Boolean.TRUE, Lit5);
        comparable = Lit33;
        simpleSymbol2 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Don't have an account? Sign Up ", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit101, simpleSymbol3);
    }

    static Object lambda27() {
        SimpleSymbol simpleSymbol = Lit99;
        SimpleSymbol simpleSymbol2 = Lit21;
        Comparable comparable = Lit100;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, Boolean.TRUE, Lit5);
        comparable = Lit33;
        simpleSymbol2 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit60, (Object)Lit61, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Don't have an account? Sign Up ", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit101, simpleSymbol3);
    }

    static Object lambda28() {
        return runtime.setAndCoerceProperty$Ex(Lit78, Lit106, "https://docs.google.com/spreadsheets/d/1NF1neDkgSsO6Ib7Y360IvCot6riD8e4CvOvcx9hV4wk/export?format=csv", Lit11);
    }

    static Object lambda29() {
        return runtime.setAndCoerceProperty$Ex(Lit78, Lit106, "https://docs.google.com/spreadsheets/d/1NF1neDkgSsO6Ib7Y360IvCot6riD8e4CvOvcx9hV4wk/export?format=csv", Lit11);
    }

    static Object lambda3() {
        return runtime.callYailPrimitive(runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list");
    }

    static Object lambda4() {
        SimpleSymbol simpleSymbol = Lit0;
        Comparable comparable = Lit4;
        Object object = Boolean.TRUE;
        SimpleSymbol simpleSymbol2 = Lit5;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, object, simpleSymbol2);
        SimpleSymbol simpleSymbol3 = Lit6;
        comparable = Lit7;
        object = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol3, comparable, object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit9, comparable, object);
        object = Lit10;
        comparable = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, object, "Browser", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit12, "artwork-7141130_640.webp", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit13, "unspecified", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit14, Boolean.TRUE, simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit15, "Responsive", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit16, "Screen2", comparable);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit17, Boolean.FALSE, simpleSymbol2);
    }

    static Object lambda5() {
        SimpleSymbol simpleSymbol = Lit19;
        SimpleSymbol simpleSymbol2 = Lit6;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit9, (Object)Lit7, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit22, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, (Object)Lit24, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit25, (Object)Lit26, simpleSymbol3);
    }

    static Object lambda6() {
        SimpleSymbol simpleSymbol = Lit19;
        SimpleSymbol simpleSymbol2 = Lit6;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit8;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit9, (Object)Lit7, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit22, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, (Object)Lit24, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit25, (Object)Lit26, simpleSymbol3);
    }

    static Object lambda7() {
        SimpleSymbol simpleSymbol = Lit29;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit5);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, (Object)Lit32, Lit8);
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Login", simpleSymbol3);
    }

    static Object lambda8() {
        SimpleSymbol simpleSymbol = Lit29;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit5);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, (Object)Lit32, Lit8);
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Login", simpleSymbol3);
    }

    static Object lambda9() {
        SimpleSymbol simpleSymbol = Lit37;
        SimpleSymbol simpleSymbol2 = Lit33;
        SimpleSymbol simpleSymbol3 = Lit11;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Email Address ", simpleSymbol3);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void $define() {
        Language.setDefaults((Language)Scheme.getInstance());
        try {
            this.run();
        }
        catch (Exception var1_1) {
            this.androidLogForm(var1_1.getMessage());
            this.processException((Object)var1_1);
        }
        appinventor.ai_sudarshankumar070309.Browser.Screen2.Screen2 = this;
        this.addToFormEnvironment(appinventor.ai_sudarshankumar070309.Browser.Screen2.Lit0, this);
        var1_2 /* !! */  = this.events$Mnto$Mnregister;
        var3_4 /* !! */  = var1_2 /* !! */ ;
        while (true) {
            block33: {
                if (var1_2 /* !! */  != LList.Empty) break block33;
                try {
                    var1_2 /* !! */  = lists.reverse(this.components$Mnto$Mncreate);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    this.addToGlobalVars(appinventor.ai_sudarshankumar070309.Browser.Screen2.Lit2, appinventor.ai_sudarshankumar070309.Browser.Screen2.lambda$Fn1);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_6 /* !! */  = lists.reverse(this.form$Mndo$Mnafter$Mncreation);
lbl20:
                    // 2 sources

                    while (true) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        if (var2_6 /* !! */  != LList.Empty) ** GOTO lbl181
                        var2_6 /* !! */  = null;
                        var4_5 /* !! */  = var1_2 /* !! */ ;
lbl25:
                        // 2 sources

                        while (true) {
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            if (var4_5 /* !! */  != LList.Empty) ** GOTO lbl128
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            var4_5 /* !! */  = lists.reverse(this.global$Mnvars$Mnto$Mncreate);
lbl30:
                            // 2 sources

                            while (true) {
                                var3_4 /* !! */  = var1_2 /* !! */ ;
                                if (var4_5 /* !! */  != LList.Empty) ** GOTO lbl97
                                var4_5 /* !! */  = var1_2 /* !! */ ;
lbl34:
                                // 2 sources

                                while (true) {
                                    var3_4 /* !! */  = var1_2 /* !! */ ;
                                    if (var4_5 /* !! */  == LList.Empty) {
                                        var3_4 /* !! */  = var1_2 /* !! */ ;
                                        var4_5 /* !! */  = var2_6 /* !! */ ;
                                        var2_6 /* !! */  = var3_4 /* !! */ ;
lbl40:
                                        // 2 sources

                                        while (true) {
                                            var3_4 /* !! */  = var1_2 /* !! */ ;
                                            var3_4 /* !! */  = LList.Empty;
                                            if (var2_6 /* !! */  == var3_4 /* !! */ ) {
                                                return;
                                            }
                                            var3_4 /* !! */  = var1_2 /* !! */ ;
                                            break;
                                        }
                                    }
                                    ** GOTO lbl74
                                    break;
                                }
                                break;
                            }
                            break;
                        }
                        break;
                    }
                }
                catch (YailRuntimeError var1_3) {
                    this.processException((Object)var1_3);
                    return;
                }
                {
                    try {
                        var5_13 = (Pair)var2_6 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_14) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var4_5 /* !! */  = new WrongType(var5_14, "arg0", -2, var2_6 /* !! */ );
                        var2_6 /* !! */  = var4_5 /* !! */ ;
lbl60:
                        // 2 sources

                        while (true) {
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            throw var2_6 /* !! */ ;
                        }
                    }
                    var2_6 /* !! */  = var5_13.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.caddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.cadddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    this.callInitialize(SlotGet.field.apply2(this, var4_5 /* !! */ ));
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_6 /* !! */  = var5_13.getCdr();
                    ** continue;
lbl74:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_13 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_7) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_6 /* !! */  = new WrongType(var2_7, "arg0", -2, (Object)var4_5 /* !! */ );
                        ** continue;
                    }
                    var2_6 /* !! */  = var5_13.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.caddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_6 /* !! */  = lists.cadddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    if (var2_6 /* !! */  != Boolean.FALSE) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        Scheme.applyToArgs.apply1(var2_6 /* !! */ );
                    }
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_13.getCdr();
                    ** continue;
lbl97:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_13 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_9) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var5_13 = new WrongType(var2_9, "arg0", -2, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var5_13;
                    }
                    var2_6 /* !! */  = var5_13.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.car.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var7_18 = lists.cadr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var6_19 = (Symbol)var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_8) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var5_13 = new WrongType(var2_8, "add-to-global-var-environment", 0, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var5_13;
                    }
                    this.addToGlobalVarEnvironment((Symbol)var6_19, Scheme.applyToArgs.apply1(var7_18));
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_13.getCdr();
                    ** continue;
lbl128:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_13 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_16) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_6 /* !! */  = new WrongType(var5_16, "arg0", -2, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_6 /* !! */ ;
                    }
                    var2_6 /* !! */  = var5_13.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.caddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.cadddr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var7_18 = lists.cadr.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var6_19 = lists.car.apply1(var2_6 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var8_12 = (Symbol)var6_19;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_10) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var4_5 /* !! */  = new WrongType(var2_10, "lookup-in-form-environment", 0, var6_19);
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var4_5 /* !! */ ;
                    }
                    var6_19 = this.lookupInFormEnvironment(var8_12);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var6_19 = Invoke.make.apply2(var7_18, var6_19);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    SlotSet.set$Mnfield$Ex.apply3(this, var4_5 /* !! */ , var6_19);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var7_18 = (Symbol)var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_15) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_6 /* !! */  = new WrongType(var5_15, "add-to-form-environment", 0, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_6 /* !! */ ;
                    }
                    this.addToFormEnvironment((Symbol)var7_18, var6_19);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_13.getCdr();
                    ** continue;
lbl181:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var4_5 /* !! */  = (Pair)var2_6 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_17) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var4_5 /* !! */  = new WrongType(var5_17, "arg0", -2, var2_6 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var4_5 /* !! */ ;
                    }
                    misc.force(var4_5 /* !! */ .getCar());
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_6 /* !! */  = var4_5 /* !! */ .getCdr();
                    ** continue;
                }
            }
            try {
                var4_5 /* !! */  = (Pair)var1_2 /* !! */ ;
            }
            catch (ClassCastException var2_11) {
                var1_2 /* !! */  = new WrongType(var2_11, "arg0", -2, var1_2 /* !! */ );
                throw var1_2 /* !! */ ;
            }
            var2_6 /* !! */  = var4_5 /* !! */ .getCar();
            var1_2 /* !! */  = lists.car.apply1(var2_6 /* !! */ );
            var1_2 /* !! */  = var1_2 /* !! */  == null ? null : var1_2 /* !! */ .toString();
            var2_6 /* !! */  = lists.cdr.apply1(var2_6 /* !! */ );
            var2_6 /* !! */  = var2_6 /* !! */  == null ? null : var2_6 /* !! */ .toString();
            EventDispatcher.registerEventForDelegation(this, (String)var1_2 /* !! */ , (String)var2_6 /* !! */ );
            var1_2 /* !! */  = var4_5 /* !! */ .getCdr();
        }
    }

    public Object Forgot_Password$Click() {
        runtime.setThisForm();
        return runtime.callYailPrimitive(runtime.open$Mnanother$Mnscreen, LList.list1("Otp"), Lit64, "open another screen");
    }

    public Object Sign_In$Click() {
        runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit78;
        runtime.callComponentMethod(simpleSymbol, Lit79, LList.Empty, LList.Empty);
        runtime.callComponentMethod(simpleSymbol, Lit80, LList.list1(((Procedure)runtime.get$Mnproperty).apply2(Lit40, Lit34)), Lit81);
        return runtime.yailForEach(proc$Fn24, runtime.callYailPrimitive(runtime.yail$Mnlist$Mnfrom$Mncsv$Mntable, LList.list1(runtime.lookupGlobalVarInCurrentFormEnvironment(Lit3, runtime.$Stthe$Mnnull$Mnvalue$St)), Lit96, "list from csv table"));
    }

    public Object Sign_up$Click() {
        runtime.setThisForm();
        return runtime.callYailPrimitive(runtime.open$Mnanother$Mnscreen, LList.list1("Screen5"), Lit103, "open another screen");
    }

    public Object Web1$GotText(Object object, Object object2, Object object3, Object object4) {
        block0: {
            runtime.sanitizeComponentData(object);
            runtime.sanitizeComponentData(object2);
            runtime.sanitizeComponentData(object3);
            object = runtime.sanitizeComponentData(object4);
            runtime.setThisForm();
            object2 = Lit3;
            if (!(object instanceof Package)) break block0;
            object = runtime.signalRuntimeError(strings.stringAppend("The variable ", runtime.getDisplayRepresentation(Lit108), " is not bound in the current context"), "Unbound Variable");
        }
        return runtime.addGlobalVarToCurrentFormEnvironment((Symbol)object2, object);
    }

    public void addToComponents(Object object, Object object2, Object object3, Object object4) {
        this.components$Mnto$Mncreate = lists.cons(LList.list4(object, object2, object3, object4), this.components$Mnto$Mncreate);
    }

    public void addToEvents(Object object, Object object2) {
        this.events$Mnto$Mnregister = lists.cons(lists.cons(object, object2), this.events$Mnto$Mnregister);
    }

    public void addToFormDoAfterCreation(Object object) {
        this.form$Mndo$Mnafter$Mncreation = lists.cons(object, this.form$Mndo$Mnafter$Mncreation);
    }

    public void addToFormEnvironment(Symbol symbol, Object object) {
        this.androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", symbol, this.form$Mnenvironment, object));
        this.form$Mnenvironment.put(symbol, object);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object object) {
        this.androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", symbol, this.global$Mnvar$Mnenvironment, object));
        this.global$Mnvar$Mnenvironment.put(symbol, object);
    }

    public void addToGlobalVars(Object object, Object object2) {
        this.global$Mnvars$Mnto$Mncreate = lists.cons(LList.list2(object, object2), this.global$Mnvars$Mnto$Mncreate);
    }

    public void androidLogForm(Object object) {
    }

    @Override
    public boolean dispatchEvent(Component component, String object, String string2, Object[] objectArray) {
        SimpleSymbol simpleSymbol = misc.string$To$Symbol((CharSequence)object);
        boolean bl = this.isBoundInFormEnvironment(simpleSymbol);
        boolean bl2 = false;
        boolean bl3 = false;
        if (bl) {
            if (this.lookupInFormEnvironment(simpleSymbol) == component) {
                object = this.lookupHandler(object, string2);
                boolean bl4 = true;
                try {
                    ((Procedure)Scheme.apply).apply2(object, LList.makeList(objectArray, 0));
                    bl2 = true;
                }
                catch (Throwable throwable) {
                    this.androidLogForm(throwable.getMessage());
                    throwable.printStackTrace();
                    this.processException(throwable);
                    bl2 = bl3;
                }
                catch (PermissionException permissionException) {
                    permissionException.printStackTrace();
                    if (this != component) {
                        bl4 = false;
                    }
                    if (bl4 ? IsEqual.apply(string2, "PermissionNeeded") : bl4) {
                        this.processException((Object)permissionException);
                    } else {
                        this.PermissionDenied(component, string2, permissionException.getPermissionNeeded());
                    }
                    bl2 = bl3;
                }
                catch (StopBlocksExecution stopBlocksExecution) {
                    bl2 = bl3;
                }
            }
        } else {
            EventDispatcher.unregisterEventForDelegation((HandlesEventDispatching)this, (String)object, string2);
        }
        return bl2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void dispatchGenericEvent(Component component, String string2, boolean bl, Object[] objectArray) {
        boolean bl2 = false;
        Object object = this.lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend("any$", this.getSimpleName(component), "$", string2)));
        if (object == Boolean.FALSE) return;
        try {
            Apply apply = Scheme.apply;
            Boolean bl3 = bl ? Boolean.TRUE : Boolean.FALSE;
            ((Procedure)apply).apply2(object, lists.cons(component, lists.cons(bl3, LList.makeList(objectArray, 0))));
            return;
        }
        catch (Throwable throwable) {
            this.androidLogForm(throwable.getMessage());
            throwable.printStackTrace();
            this.processException(throwable);
            return;
        }
        catch (PermissionException permissionException) {
            permissionException.printStackTrace();
            if (this == component) {
                bl2 = true;
            }
            if (bl2 ? IsEqual.apply(string2, "PermissionNeeded") : bl2) {
                this.processException((Object)permissionException);
                return;
            }
            this.PermissionDenied(component, string2, permissionException.getPermissionNeeded());
            return;
        }
        catch (StopBlocksExecution stopBlocksExecution) {
            // empty catch block
        }
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public boolean isBoundInFormEnvironment(Symbol symbol) {
        return this.form$Mnenvironment.isBound(symbol);
    }

    public Object lookupHandler(Object object, Object object2) {
        Object var3_3 = null;
        object = object == null ? null : object.toString();
        object2 = object2 == null ? var3_3 : object2.toString();
        return this.lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName((String)object, (String)object2)));
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return this.lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object object) {
        block0: {
            Environment environment = this.form$Mnenvironment;
            int n = environment == null ? 1 : 0;
            if (!((n = 1 & n + 1) != 0 ? environment.isBound(symbol) : n != 0)) break block0;
            object = this.form$Mnenvironment.get(symbol);
        }
        return object;
    }

    @Override
    public void onCreate(Bundle bundle) {
        AppInventorCompatActivity.setClassicModeFromYail((boolean)true);
        super.onCreate(bundle);
    }

    public void processException(Object object) {
        Object object2 = ((Procedure)Scheme.applyToArgs).apply1(((Procedure)GetNamedPart.getNamedPart).apply2(object, Lit1));
        object2 = object2 == null ? null : object2.toString();
        object = object instanceof YailRuntimeError ? ((YailRuntimeError)((Object)object)).getErrorType() : "Runtime Error";
        RuntimeErrorAlert.alert((Object)this, (String)object2, (String)object, (String)"End Application");
    }

    public void run() {
        Object var1_3;
        CallContext callContext = CallContext.getInstance();
        Consumer consumer = callContext.consumer;
        callContext.consumer = VoidConsumer.instance;
        try {
            this.run(callContext);
            var1_3 = null;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        ModuleBody.runCleanup(callContext, var1_3, consumer);
    }

    public final void run(CallContext object) {
        Consumer consumer = object.consumer;
        runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        SimpleSymbol simpleSymbol = Lit0;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(simpleSymbol));
        object = strings.stringAppend(misc.symbol$To$String(simpleSymbol), "-global-vars");
        object = object == null ? null : object.toString();
        this.global$Mnvar$Mnenvironment = Environment.make((String)object);
        Screen2 = null;
        this.form$Mnname$Mnsymbol = simpleSymbol;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        runtime.$instance.run();
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addGlobalVarToCurrentFormEnvironment(Lit3, runtime.callYailPrimitive(runtime.make$Mnyail$Mnlist, LList.Empty, LList.Empty, "make a list")), consumer);
        } else {
            this.addToGlobalVars(Lit3, lambda$Fn2);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Comparable comparable = Lit4;
            Object object2 = Boolean.TRUE;
            object = Lit5;
            runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, object2, object);
            object2 = Lit6;
            comparable = Lit7;
            SimpleSymbol simpleSymbol2 = Lit8;
            runtime.setAndCoerceProperty$Ex(simpleSymbol, object2, comparable, simpleSymbol2);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit9, comparable, simpleSymbol2);
            object2 = Lit10;
            comparable = Lit11;
            runtime.setAndCoerceProperty$Ex(simpleSymbol, object2, "Browser", comparable);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit12, "artwork-7141130_640.webp", comparable);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit13, "unspecified", comparable);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit14, Boolean.TRUE, object);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit15, "Responsive", comparable);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit16, "Screen2", comparable);
            Values.writeValues(runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit17, Boolean.FALSE, object), consumer);
        } else {
            this.addToFormDoAfterCreation(new Promise(lambda$Fn3));
        }
        this.VerticalArrangement1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit18, Lit19, lambda$Fn4), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit27, Lit19, lambda$Fn5);
        }
        this.Label1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit28, Lit29, lambda$Fn6), consumer);
        } else {
            this.addToComponents(Lit19, Lit35, Lit29, lambda$Fn7);
        }
        this.Label3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit36, Lit37, lambda$Fn8), consumer);
        } else {
            this.addToComponents(Lit19, Lit38, Lit37, lambda$Fn9);
        }
        this.EmailPicker1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit39, Lit40, lambda$Fn10), consumer);
        } else {
            this.addToComponents(Lit19, Lit42, Lit40, lambda$Fn11);
        }
        this.Label4 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit43, Lit44, lambda$Fn12), consumer);
        } else {
            this.addToComponents(Lit19, Lit45, Lit44, lambda$Fn13);
        }
        this.PasswordTextBox1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit46, Lit47, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(Lit19, Lit48, Lit47, Boolean.FALSE);
        }
        this.Password_did_not_amtch = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit19, Lit49, Lit50, lambda$Fn14), consumer);
        } else {
            this.addToComponents(Lit19, Lit54, Lit50, lambda$Fn15);
        }
        this.Forgot_Password = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit55, Lit56, lambda$Fn16), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit63, Lit56, lambda$Fn17);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit65, this.Forgot_Password$Click);
        } else {
            this.addToFormEnvironment(Lit65, this.Forgot_Password$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Forgot_Password", "Click");
        } else {
            this.addToEvents(Lit56, Lit66);
        }
        this.Label2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit67, Lit68, lambda$Fn18), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit69, Lit68, lambda$Fn19);
        }
        this.HorizontalArrangement2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit70, Lit71, lambda$Fn20), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit73, Lit71, lambda$Fn21);
        }
        this.Sign_In = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit71, Lit74, Lit75, lambda$Fn22), consumer);
        } else {
            this.addToComponents(Lit71, Lit77, Lit75, lambda$Fn23);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit97, this.Sign_In$Click);
        } else {
            this.addToFormEnvironment(Lit97, this.Sign_In$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Sign_In", "Click");
        } else {
            this.addToEvents(Lit75, Lit66);
        }
        this.Sign_up = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit98, Lit99, lambda$Fn25), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit102, Lit99, lambda$Fn26);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit104, this.Sign_up$Click);
        } else {
            this.addToFormEnvironment(Lit104, this.Sign_up$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Sign_up", "Click");
        } else {
            this.addToEvents(Lit99, Lit66);
        }
        this.Web1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit105, Lit78, lambda$Fn27), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit107, Lit78, lambda$Fn28);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit109, this.Web1$GotText);
        } else {
            this.addToFormEnvironment(Lit109, this.Web1$GotText);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Web1", "GotText");
        } else {
            this.addToEvents(Lit78, Lit110);
        }
        this.AiaMasterMail1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit111, Lit112, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit113, Lit112, Boolean.FALSE);
        }
        this.Notifier1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit114, Lit93, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit115, Lit93, Boolean.FALSE);
        }
        runtime.initRuntime();
    }

    public void sendError(Object object) {
        object = object == null ? null : object.toString();
        RetValManager.sendError((String)object);
    }
}

