/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  appinventor.ai_sudarshankumar070309.Browser.Screen1
 *  gnu.mapping.CallContext
 *  java.lang.Boolean
 *  java.lang.ClassCastException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package appinventor.ai_sudarshankumar070309.Browser;

import android.os.Bundle;
import appinventor.ai_sudarshankumar070309.Browser.Screen1;
import com.google.appinventor.components.runtime.Component;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleMethod;
import gnu.mapping.CallContext;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;

public class Screen1$frame
extends ModuleBody {
    Screen1 $main;

    @Override
    public Object apply0(ModuleMethod moduleMethod) {
        switch (moduleMethod.selector) {
            default: {
                return super.apply0(moduleMethod);
            }
            case 31: {
                return Screen1.lambda13();
            }
            case 30: {
                return Screen1.lambda12();
            }
            case 29: {
                return this.$main.Button1$Click();
            }
            case 28: {
                return Screen1.lambda11();
            }
            case 27: {
                return Screen1.lambda10();
            }
            case 26: {
                return Screen1.lambda9();
            }
            case 25: {
                return Screen1.lambda8();
            }
            case 24: {
                return Screen1.lambda7();
            }
            case 23: {
                return Screen1.lambda6();
            }
            case 22: {
                return Screen1.lambda5();
            }
            case 21: {
                return Screen1.lambda4();
            }
            case 20: {
                return Screen1.lambda3();
            }
            case 19: {
                this.$main.$define();
                return Values.empty;
            }
            case 18: 
        }
        return Screen1.lambda2();
    }

    @Override
    public Object apply1(ModuleMethod object, Object object2) {
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply1((ModuleMethod)object, object2);
            }
            case 14: {
                this.$main.processException(object2);
                return Values.empty;
            }
            case 13: {
                this.$main.sendError(object2);
                return Values.empty;
            }
            case 12: {
                this.$main.addToFormDoAfterCreation(object2);
                return Values.empty;
            }
            case 7: {
                Screen1 screen1 = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "is-bound-in-form-environment", 1, object2);
                }
                object = screen1.isBoundInFormEnvironment((Symbol)object) ? Boolean.TRUE : Boolean.FALSE;
                return object;
            }
            case 5: {
                Symbol symbol;
                object = this.$main;
                try {
                    symbol = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return object.lookupInFormEnvironment(symbol);
            }
            case 3: {
                this.$main.androidLogForm(object2);
                return Values.empty;
            }
            case 2: {
                Bundle bundle;
                object = this.$main;
                try {
                    bundle = (Bundle)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "onCreate", 1, object2);
                }
                object.onCreate(bundle);
                return Values.empty;
            }
            case 1: 
        }
        return this.$main.getSimpleName(object2);
    }

    @Override
    public Object apply2(ModuleMethod object, Object object2, Object object3) {
        Symbol symbol;
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply2((ModuleMethod)object, object2, object3);
            }
            case 17: {
                return this.$main.lookupHandler(object2, object3);
            }
            case 11: {
                this.$main.addToGlobalVars(object2, object3);
                return Values.empty;
            }
            case 9: {
                this.$main.addToEvents(object2, object3);
                return Values.empty;
            }
            case 8: {
                Screen1 screen1 = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "add-to-global-var-environment", 1, object2);
                }
                screen1.addToGlobalVarEnvironment((Symbol)object, object3);
                return Values.empty;
            }
            case 5: {
                Symbol symbol2;
                object = this.$main;
                try {
                    symbol2 = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return object.lookupInFormEnvironment(symbol2, object3);
            }
            case 4: 
        }
        object = this.$main;
        try {
            symbol = (Symbol)object2;
        }
        catch (ClassCastException classCastException) {
            throw new WrongType(classCastException, "add-to-form-environment", 1, object2);
        }
        object.addToFormEnvironment(symbol, object3);
        return Values.empty;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object apply4(ModuleMethod moduleMethod, Object object, Object objectArray, Object objectArray2, Object object2) {
        int n = moduleMethod.selector;
        boolean bl = true;
        switch (n) {
            default: {
                return super.apply4(moduleMethod, object, objectArray, objectArray2, object2);
            }
            case 16: {
                Component component;
                moduleMethod = this.$main;
                try {
                    component = (Component)object;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 1, object);
                }
                try {
                    object = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = Boolean.FALSE;
                    if (objectArray2 == objectArray) {
                        bl = false;
                    }
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray = (Object[])object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 4, object2);
                }
                moduleMethod.dispatchGenericEvent(component, (String)object, bl, objectArray);
                return Values.empty;
            }
            case 15: {
                Component component;
                moduleMethod = this.$main;
                try {
                    component = (Component)object;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 1, object);
                }
                try {
                    object = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = (String)objectArray2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray2 = (Object[])object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 4, object2);
                }
                if (!moduleMethod.dispatchEvent(component, (String)object, (String)objectArray, objectArray2)) return Boolean.FALSE;
                return Boolean.TRUE;
            }
            case 10: 
        }
        this.$main.addToComponents(object, (Object)objectArray, (Object)objectArray2, object2);
        return Values.empty;
    }

    @Override
    public int match0(ModuleMethod moduleMethod, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match0(moduleMethod, callContext);
            }
            case 20: 
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 30: 
            case 31: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 19: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 18: 
        }
        callContext.proc = moduleMethod;
        callContext.pc = 0;
        return 0;
    }

    @Override
    public int match1(ModuleMethod moduleMethod, Object object, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match1(moduleMethod, object, callContext);
            }
            case 14: {
                if (!(object instanceof Screen1)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 13: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 12: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 7: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 3: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 2: {
                if (!(object instanceof Screen1)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 1: 
        }
        callContext.value1 = object;
        callContext.proc = moduleMethod;
        callContext.pc = 1;
        return 0;
    }

    @Override
    public int match2(ModuleMethod moduleMethod, Object object, Object object2, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match2(moduleMethod, object, object2, callContext);
            }
            case 17: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 11: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 9: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 8: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 4: 
        }
        if (!(object instanceof Symbol)) {
            return -786431;
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.proc = moduleMethod;
        callContext.pc = 2;
        return 0;
    }

    @Override
    public int match4(ModuleMethod moduleMethod, Object object, Object object2, Object object3, Object object4, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match4(moduleMethod, object, object2, object3, object4, callContext);
            }
            case 16: {
                if (!(object instanceof Screen1)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 15: {
                if (!(object instanceof Screen1)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                if (!(object4 instanceof String)) {
                    return -786428;
                }
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 10: 
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.value3 = object3;
        callContext.value4 = object4;
        callContext.proc = moduleMethod;
        callContext.pc = 4;
        return 0;
    }
}

