/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  com.google.appinventor.components.runtime.AppInventorCompatActivity
 *  com.google.appinventor.components.runtime.Button
 *  com.google.appinventor.components.runtime.Image
 *  com.google.appinventor.components.runtime.Label
 *  com.google.appinventor.components.runtime.Notifier
 *  com.google.appinventor.components.runtime.util.RetValManager
 *  com.google.appinventor.components.runtime.util.RuntimeErrorAlert
 *  gnu.expr.Language
 *  gnu.expr.ModuleInfo
 *  gnu.lists.Consumer
 *  gnu.mapping.CallContext
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.ClassCastException
 *  java.lang.Comparable
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.Runnable
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.Throwable
 */
package appinventor.ai_sudarshankumar070309.Browser;

import android.os.Bundle;
import appinventor.ai_sudarshankumar070309.Browser.Screen4$frame;
import com.google.appinventor.components.runtime.AppInventorCompatActivity;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.HorizontalScrollArrangement;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.Notifier;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.WebViewer;
import com.google.appinventor.components.runtime.errors.PermissionException;
import com.google.appinventor.components.runtime.errors.StopBlocksExecution;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.RetValManager;
import com.google.appinventor.components.runtime.util.RuntimeErrorAlert;
import com.google.youngandroid.runtime;
import gnu.expr.Language;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleInfo;
import gnu.expr.ModuleMethod;
import gnu.kawa.functions.Apply;
import gnu.kawa.functions.Format;
import gnu.kawa.functions.GetNamedPart;
import gnu.kawa.functions.IsEqual;
import gnu.kawa.reflect.Invoke;
import gnu.kawa.reflect.SlotGet;
import gnu.kawa.reflect.SlotSet;
import gnu.lists.Consumer;
import gnu.lists.FString;
import gnu.lists.LList;
import gnu.lists.Pair;
import gnu.lists.PairWithPosition;
import gnu.lists.VoidConsumer;
import gnu.mapping.CallContext;
import gnu.mapping.Environment;
import gnu.mapping.Procedure;
import gnu.mapping.SimpleSymbol;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;
import gnu.math.IntNum;
import kawa.lang.Promise;
import kawa.lib.lists;
import kawa.lib.misc;
import kawa.lib.strings;
import kawa.standard.Scheme;

public class Screen4
extends Form
implements Runnable {
    static final SimpleSymbol Lit0;
    static final SimpleSymbol Lit1;
    static final SimpleSymbol Lit10;
    static final PairWithPosition Lit100;
    static final PairWithPosition Lit101;
    static final SimpleSymbol Lit102;
    static final FString Lit103;
    static final IntNum Lit104;
    static final FString Lit105;
    static final FString Lit106;
    static final SimpleSymbol Lit107;
    static final IntNum Lit108;
    static final IntNum Lit109;
    static final SimpleSymbol Lit11;
    static final FString Lit110;
    static final FString Lit111;
    static final SimpleSymbol Lit112;
    static final FString Lit113;
    static final SimpleSymbol Lit114;
    static final SimpleSymbol Lit115;
    static final SimpleSymbol Lit116;
    static final FString Lit117;
    static final IntNum Lit118;
    static final FString Lit119;
    static final SimpleSymbol Lit12;
    static final FString Lit120;
    static final SimpleSymbol Lit121;
    static final FString Lit122;
    static final SimpleSymbol Lit123;
    static final PairWithPosition Lit124;
    static final SimpleSymbol Lit125;
    static final FString Lit126;
    static final SimpleSymbol Lit127;
    static final FString Lit128;
    static final SimpleSymbol Lit129;
    static final SimpleSymbol Lit13;
    static final SimpleSymbol Lit130;
    static final FString Lit131;
    static final SimpleSymbol Lit132;
    static final FString Lit133;
    static final SimpleSymbol Lit134;
    static final SimpleSymbol Lit135;
    static final FString Lit136;
    static final SimpleSymbol Lit137;
    static final FString Lit138;
    static final SimpleSymbol Lit139;
    static final SimpleSymbol Lit14;
    static final SimpleSymbol Lit140;
    static final FString Lit141;
    static final SimpleSymbol Lit142;
    static final FString Lit143;
    static final FString Lit144;
    static final IntNum Lit145;
    static final FString Lit146;
    static final SimpleSymbol Lit147;
    static final PairWithPosition Lit148;
    static final SimpleSymbol Lit149;
    static final SimpleSymbol Lit15;
    static final SimpleSymbol Lit150;
    static final FString Lit151;
    static final IntNum Lit152;
    static final FString Lit153;
    static final FString Lit154;
    static final SimpleSymbol Lit155;
    static final SimpleSymbol Lit156;
    static final IntNum Lit157;
    static final IntNum Lit158;
    static final FString Lit159;
    static final SimpleSymbol Lit16;
    static final FString Lit160;
    static final SimpleSymbol Lit161;
    static final IntNum Lit162;
    static final IntNum Lit163;
    static final FString Lit164;
    static final FString Lit165;
    static final SimpleSymbol Lit166;
    static final IntNum Lit167;
    static final IntNum Lit168;
    static final FString Lit169;
    static final FString Lit17;
    static final FString Lit170;
    static final SimpleSymbol Lit171;
    static final IntNum Lit172;
    static final FString Lit173;
    static final FString Lit174;
    static final IntNum Lit175;
    static final SimpleSymbol Lit176;
    static final IntNum Lit177;
    static final FString Lit178;
    static final FString Lit179;
    static final SimpleSymbol Lit18;
    static final SimpleSymbol Lit180;
    static final FString Lit181;
    static final PairWithPosition Lit182;
    static final PairWithPosition Lit183;
    static final SimpleSymbol Lit184;
    static final PairWithPosition Lit185;
    static final SimpleSymbol Lit186;
    static final FString Lit187;
    static final SimpleSymbol Lit188;
    static final IntNum Lit189;
    static final SimpleSymbol Lit19;
    static final FString Lit190;
    static final FString Lit191;
    static final SimpleSymbol Lit192;
    static final FString Lit193;
    static final SimpleSymbol Lit194;
    static final SimpleSymbol Lit195;
    static final SimpleSymbol Lit196;
    static final SimpleSymbol Lit197;
    static final SimpleSymbol Lit198;
    static final SimpleSymbol Lit199;
    static final SimpleSymbol Lit2;
    static final IntNum Lit20;
    static final SimpleSymbol Lit200;
    static final FString Lit201;
    static final IntNum Lit202;
    static final IntNum Lit203;
    static final FString Lit204;
    static final SimpleSymbol Lit205;
    static final FString Lit206;
    static final SimpleSymbol Lit207;
    static final FString Lit208;
    static final SimpleSymbol Lit209;
    static final SimpleSymbol Lit21;
    static final FString Lit210;
    static final IntNum Lit211;
    static final IntNum Lit212;
    static final FString Lit213;
    static final SimpleSymbol Lit214;
    static final FString Lit215;
    static final IntNum Lit216;
    static final IntNum Lit217;
    static final IntNum Lit218;
    static final FString Lit219;
    static final IntNum Lit22;
    static final SimpleSymbol Lit220;
    static final FString Lit221;
    static final IntNum Lit222;
    static final IntNum Lit223;
    static final FString Lit224;
    static final SimpleSymbol Lit225;
    static final FString Lit226;
    static final SimpleSymbol Lit227;
    static final IntNum Lit228;
    static final IntNum Lit229;
    static final SimpleSymbol Lit23;
    static final FString Lit230;
    static final FString Lit231;
    static final IntNum Lit232;
    static final SimpleSymbol Lit233;
    static final SimpleSymbol Lit234;
    static final FString Lit235;
    static final FString Lit236;
    static final SimpleSymbol Lit237;
    static final IntNum Lit238;
    static final IntNum Lit239;
    static final SimpleSymbol Lit24;
    static final FString Lit240;
    static final FString Lit241;
    static final SimpleSymbol Lit242;
    static final IntNum Lit243;
    static final FString Lit244;
    static final FString Lit245;
    static final FString Lit246;
    static final FString Lit247;
    static final SimpleSymbol Lit248;
    static final FString Lit249;
    static final IntNum Lit25;
    static final SimpleSymbol Lit250;
    static final SimpleSymbol Lit251;
    static final SimpleSymbol Lit252;
    static final SimpleSymbol Lit253;
    static final SimpleSymbol Lit254;
    static final SimpleSymbol Lit255;
    static final SimpleSymbol Lit256;
    static final SimpleSymbol Lit257;
    static final SimpleSymbol Lit258;
    static final SimpleSymbol Lit259;
    static final FString Lit26;
    static final SimpleSymbol Lit260;
    static final SimpleSymbol Lit261;
    static final SimpleSymbol Lit262;
    static final SimpleSymbol Lit263;
    static final SimpleSymbol Lit264;
    static final FString Lit27;
    static final SimpleSymbol Lit28;
    static final IntNum Lit29;
    static final SimpleSymbol Lit3;
    static final SimpleSymbol Lit30;
    static final SimpleSymbol Lit31;
    static final SimpleSymbol Lit32;
    static final IntNum Lit33;
    static final SimpleSymbol Lit34;
    static final FString Lit35;
    static final FString Lit36;
    static final SimpleSymbol Lit37;
    static final IntNum Lit38;
    static final FString Lit39;
    static final SimpleSymbol Lit4;
    static final FString Lit40;
    static final SimpleSymbol Lit41;
    static final IntNum Lit42;
    static final FString Lit43;
    static final FString Lit44;
    static final SimpleSymbol Lit45;
    static final FString Lit46;
    static final FString Lit47;
    static final SimpleSymbol Lit48;
    static final SimpleSymbol Lit49;
    static final SimpleSymbol Lit5;
    static final IntNum Lit50;
    static final SimpleSymbol Lit51;
    static final FString Lit52;
    static final FString Lit53;
    static final SimpleSymbol Lit54;
    static final IntNum Lit55;
    static final SimpleSymbol Lit56;
    static final SimpleSymbol Lit57;
    static final SimpleSymbol Lit58;
    static final SimpleSymbol Lit59;
    static final IntNum Lit6;
    static final IntNum Lit60;
    static final IntNum Lit61;
    static final FString Lit62;
    static final FString Lit63;
    static final SimpleSymbol Lit64;
    static final IntNum Lit65;
    static final IntNum Lit66;
    static final FString Lit67;
    static final FString Lit68;
    static final SimpleSymbol Lit69;
    static final SimpleSymbol Lit7;
    static final SimpleSymbol Lit70;
    static final SimpleSymbol Lit71;
    static final FString Lit72;
    static final SimpleSymbol Lit73;
    static final SimpleSymbol Lit74;
    static final SimpleSymbol Lit75;
    static final SimpleSymbol Lit76;
    static final FString Lit77;
    static final SimpleSymbol Lit78;
    static final FString Lit79;
    static final SimpleSymbol Lit8;
    static final SimpleSymbol Lit80;
    static final SimpleSymbol Lit81;
    static final PairWithPosition Lit82;
    static final SimpleSymbol Lit83;
    static final PairWithPosition Lit84;
    static final SimpleSymbol Lit85;
    static final PairWithPosition Lit86;
    static final PairWithPosition Lit87;
    static final PairWithPosition Lit88;
    static final PairWithPosition Lit89;
    static final SimpleSymbol Lit9;
    static final PairWithPosition Lit90;
    static final PairWithPosition Lit91;
    static final SimpleSymbol Lit92;
    static final PairWithPosition Lit93;
    static final PairWithPosition Lit94;
    static final PairWithPosition Lit95;
    static final PairWithPosition Lit96;
    static final PairWithPosition Lit97;
    static final PairWithPosition Lit98;
    static final PairWithPosition Lit99;
    public static Screen4 Screen4;
    static final ModuleMethod lambda$Fn1;
    static final ModuleMethod lambda$Fn10;
    static final ModuleMethod lambda$Fn11;
    static final ModuleMethod lambda$Fn12;
    static final ModuleMethod lambda$Fn13;
    static final ModuleMethod lambda$Fn14;
    static final ModuleMethod lambda$Fn15;
    static final ModuleMethod lambda$Fn16;
    static final ModuleMethod lambda$Fn17;
    static final ModuleMethod lambda$Fn18;
    static final ModuleMethod lambda$Fn19;
    static final ModuleMethod lambda$Fn2;
    static final ModuleMethod lambda$Fn20;
    static final ModuleMethod lambda$Fn21;
    static final ModuleMethod lambda$Fn22;
    static final ModuleMethod lambda$Fn23;
    static final ModuleMethod lambda$Fn24;
    static final ModuleMethod lambda$Fn25;
    static final ModuleMethod lambda$Fn26;
    static final ModuleMethod lambda$Fn27;
    static final ModuleMethod lambda$Fn28;
    static final ModuleMethod lambda$Fn29;
    static final ModuleMethod lambda$Fn3;
    static final ModuleMethod lambda$Fn30;
    static final ModuleMethod lambda$Fn31;
    static final ModuleMethod lambda$Fn32;
    static final ModuleMethod lambda$Fn33;
    static final ModuleMethod lambda$Fn34;
    static final ModuleMethod lambda$Fn35;
    static final ModuleMethod lambda$Fn36;
    static final ModuleMethod lambda$Fn37;
    static final ModuleMethod lambda$Fn38;
    static final ModuleMethod lambda$Fn39;
    static final ModuleMethod lambda$Fn4;
    static final ModuleMethod lambda$Fn40;
    static final ModuleMethod lambda$Fn41;
    static final ModuleMethod lambda$Fn42;
    static final ModuleMethod lambda$Fn43;
    static final ModuleMethod lambda$Fn44;
    static final ModuleMethod lambda$Fn45;
    static final ModuleMethod lambda$Fn46;
    static final ModuleMethod lambda$Fn47;
    static final ModuleMethod lambda$Fn48;
    static final ModuleMethod lambda$Fn49;
    static final ModuleMethod lambda$Fn5;
    static final ModuleMethod lambda$Fn50;
    static final ModuleMethod lambda$Fn51;
    static final ModuleMethod lambda$Fn52;
    static final ModuleMethod lambda$Fn53;
    static final ModuleMethod lambda$Fn54;
    static final ModuleMethod lambda$Fn55;
    static final ModuleMethod lambda$Fn56;
    static final ModuleMethod lambda$Fn57;
    static final ModuleMethod lambda$Fn58;
    static final ModuleMethod lambda$Fn59;
    static final ModuleMethod lambda$Fn6;
    static final ModuleMethod lambda$Fn60;
    static final ModuleMethod lambda$Fn61;
    static final ModuleMethod lambda$Fn62;
    static final ModuleMethod lambda$Fn63;
    static final ModuleMethod lambda$Fn64;
    static final ModuleMethod lambda$Fn65;
    static final ModuleMethod lambda$Fn66;
    static final ModuleMethod lambda$Fn67;
    static final ModuleMethod lambda$Fn68;
    static final ModuleMethod lambda$Fn69;
    static final ModuleMethod lambda$Fn7;
    static final ModuleMethod lambda$Fn70;
    static final ModuleMethod lambda$Fn71;
    static final ModuleMethod lambda$Fn72;
    static final ModuleMethod lambda$Fn73;
    static final ModuleMethod lambda$Fn74;
    static final ModuleMethod lambda$Fn75;
    static final ModuleMethod lambda$Fn76;
    static final ModuleMethod lambda$Fn77;
    static final ModuleMethod lambda$Fn78;
    static final ModuleMethod lambda$Fn79;
    static final ModuleMethod lambda$Fn8;
    static final ModuleMethod lambda$Fn80;
    static final ModuleMethod lambda$Fn81;
    static final ModuleMethod lambda$Fn82;
    static final ModuleMethod lambda$Fn83;
    static final ModuleMethod lambda$Fn84;
    static final ModuleMethod lambda$Fn9;
    public Boolean $Stdebug$Mnform$St;
    public final ModuleMethod $define;
    public Image Before;
    public final ModuleMethod Before$Click;
    public Button Button2;
    public final ModuleMethod Button2$Click;
    public Button Button3;
    public final ModuleMethod Button3$Click;
    public Button Cache;
    public Image Close;
    public final ModuleMethod Close$Click;
    public Button Cookie;
    public Image Home;
    public final ModuleMethod Home$Click;
    public HorizontalArrangement HorizontalArrangement1;
    public HorizontalArrangement HorizontalArrangement2;
    public HorizontalArrangement HorizontalArrangement3;
    public HorizontalArrangement HorizontalArrangement4;
    public HorizontalArrangement HorizontalArrangement5;
    public HorizontalArrangement HorizontalArrangement6;
    public HorizontalScrollArrangement HorizontalScrollArrangement1;
    public Button IPL_2024;
    public final ModuleMethod IPL_2024$Click;
    public Image Image3;
    public Image Image5;
    public Image Image6;
    public final ModuleMethod Image6$Click;
    public Label Label1;
    public Image Latest_rels;
    public final ModuleMethod Latest_rels$Click;
    public ListView ListView1;
    public Button Locatuon;
    public Image News;
    public final ModuleMethod News$Click;
    public Image Next;
    public final ModuleMethod Next$Click;
    public Notifier Notifier1;
    public Notifier Notifier2;
    public Image Refresh;
    public final ModuleMethod Refresh$Click;
    public Image Search;
    public final ModuleMethod Search$Click;
    public Image Search1;
    public final ModuleMethod Search1$Click;
    public Label Search_engine;
    public Button Sky;
    public final ModuleMethod Sky$Click;
    public Label Space_divider;
    public TextBox TextBox1;
    public TextBox TextBox2;
    public VerticalArrangement VerticalArrangement1;
    public VerticalArrangement VerticalArrangement2;
    public VerticalArrangement VerticalArrangement3;
    public WebViewer WebViewer1;
    public WebViewer WebViewer2;
    public WebViewer WebViewer3;
    public final ModuleMethod WebViewer3$ErrorOccurred;
    public final ModuleMethod add$Mnto$Mncomponents;
    public final ModuleMethod add$Mnto$Mnevents;
    public final ModuleMethod add$Mnto$Mnform$Mndo$Mnafter$Mncreation;
    public final ModuleMethod add$Mnto$Mnform$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvar$Mnenvironment;
    public final ModuleMethod add$Mnto$Mnglobal$Mnvars;
    public final ModuleMethod android$Mnlog$Mnform;
    public LList components$Mnto$Mncreate;
    public final ModuleMethod dispatchEvent;
    public final ModuleMethod dispatchGenericEvent;
    public LList events$Mnto$Mnregister;
    public LList form$Mndo$Mnafter$Mncreation;
    public Environment form$Mnenvironment;
    public Symbol form$Mnname$Mnsymbol;
    public final ModuleMethod get$Mnsimple$Mnname;
    public Environment global$Mnvar$Mnenvironment;
    public LList global$Mnvars$Mnto$Mncreate;
    public final ModuleMethod is$Mnbound$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod lookup$Mnhandler;
    public final ModuleMethod lookup$Mnin$Mnform$Mnenvironment;
    public final ModuleMethod onCreate;
    public final ModuleMethod process$Mnexception;
    public final ModuleMethod send$Mnerror;

    static {
        Object object = (SimpleSymbol)new SimpleSymbol("any").readResolve();
        Lit264 = object;
        Lit263 = (SimpleSymbol)new SimpleSymbol("lookup-handler").readResolve();
        Lit262 = (SimpleSymbol)new SimpleSymbol("dispatchGenericEvent").readResolve();
        Lit261 = (SimpleSymbol)new SimpleSymbol("dispatchEvent").readResolve();
        Lit260 = (SimpleSymbol)new SimpleSymbol("send-error").readResolve();
        Lit259 = (SimpleSymbol)new SimpleSymbol("add-to-form-do-after-creation").readResolve();
        Lit258 = (SimpleSymbol)new SimpleSymbol("add-to-global-vars").readResolve();
        Lit257 = (SimpleSymbol)new SimpleSymbol("add-to-components").readResolve();
        Lit256 = (SimpleSymbol)new SimpleSymbol("add-to-events").readResolve();
        Lit255 = (SimpleSymbol)new SimpleSymbol("add-to-global-var-environment").readResolve();
        Lit254 = (SimpleSymbol)new SimpleSymbol("is-bound-in-form-environment").readResolve();
        Lit253 = (SimpleSymbol)new SimpleSymbol("lookup-in-form-environment").readResolve();
        Lit252 = (SimpleSymbol)new SimpleSymbol("add-to-form-environment").readResolve();
        Lit251 = (SimpleSymbol)new SimpleSymbol("android-log-form").readResolve();
        Lit250 = (SimpleSymbol)new SimpleSymbol("get-simple-name").readResolve();
        Lit249 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit248 = (SimpleSymbol)new SimpleSymbol("Notifier2").readResolve();
        Lit247 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit246 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit245 = new FString("com.google.appinventor.components.runtime.Notifier");
        Lit244 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit243 = IntNum.make(-1100);
        Lit242 = (SimpleSymbol)new SimpleSymbol("WebViewer2").readResolve();
        Lit241 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit240 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit239 = IntNum.make(-1010);
        Lit238 = IntNum.make(0xFFFFFF);
        Lit237 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement2").readResolve();
        Lit236 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit235 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit234 = (SimpleSymbol)new SimpleSymbol("UsesLocation").readResolve();
        Lit233 = (SimpleSymbol)new SimpleSymbol("IgnoreSslErrors").readResolve();
        Lit232 = IntNum.make(5777);
        Lit231 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit230 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit229 = IntNum.make(-1001);
        Lit228 = IntNum.make(0xFFFFFF);
        Lit227 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement3").readResolve();
        Lit226 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit225 = (SimpleSymbol)new SimpleSymbol("Button2$Click").readResolve();
        Lit224 = new FString("com.google.appinventor.components.runtime.Button");
        Lit223 = IntNum.make(-1020);
        Lit222 = IntNum.make(0xFFFFFF);
        Lit221 = new FString("com.google.appinventor.components.runtime.Button");
        Lit220 = (SimpleSymbol)new SimpleSymbol("IPL_2024$Click").readResolve();
        Lit219 = new FString("com.google.appinventor.components.runtime.Button");
        Lit218 = IntNum.make(-1021);
        Object object2 = new int[2];
        object2[0] = -16777216;
        Lit217 = IntNum.make(object2);
        Lit216 = IntNum.make(0xFFFFFF);
        Lit215 = new FString("com.google.appinventor.components.runtime.Button");
        Lit214 = (SimpleSymbol)new SimpleSymbol("Sky$Click").readResolve();
        Lit213 = new FString("com.google.appinventor.components.runtime.Button");
        Lit212 = IntNum.make(-1027);
        Lit211 = IntNum.make(0xFFFFFF);
        Lit210 = new FString("com.google.appinventor.components.runtime.Button");
        Lit209 = (SimpleSymbol)new SimpleSymbol("Latest_rels$Click").readResolve();
        Lit208 = new FString("com.google.appinventor.components.runtime.Image");
        Lit207 = (SimpleSymbol)new SimpleSymbol("Latest_rels").readResolve();
        Lit206 = new FString("com.google.appinventor.components.runtime.Image");
        Lit205 = (SimpleSymbol)new SimpleSymbol("Button3$Click").readResolve();
        Lit204 = new FString("com.google.appinventor.components.runtime.Button");
        Lit203 = IntNum.make(-1027);
        Lit202 = IntNum.make(0xFFFFFF);
        Lit201 = new FString("com.google.appinventor.components.runtime.Button");
        Lit200 = (SimpleSymbol)new SimpleSymbol("News$Click").readResolve();
        Lit199 = (SimpleSymbol)new SimpleSymbol("Sky").readResolve();
        Lit198 = (SimpleSymbol)new SimpleSymbol("IPL_2024").readResolve();
        Lit197 = (SimpleSymbol)new SimpleSymbol("Button2").readResolve();
        Lit196 = (SimpleSymbol)new SimpleSymbol("Button3").readResolve();
        Lit195 = (SimpleSymbol)new SimpleSymbol("HomeUrl").readResolve();
        Lit194 = (SimpleSymbol)new SimpleSymbol("WebViewer1").readResolve();
        Lit193 = new FString("com.google.appinventor.components.runtime.Image");
        Lit192 = (SimpleSymbol)new SimpleSymbol("News").readResolve();
        Lit191 = new FString("com.google.appinventor.components.runtime.Image");
        Lit190 = new FString("com.google.appinventor.components.runtime.HorizontalScrollArrangement");
        object2 = new int[2];
        object2[0] = -1876;
        Lit189 = IntNum.make(object2);
        Lit188 = (SimpleSymbol)new SimpleSymbol("HorizontalScrollArrangement1").readResolve();
        Lit187 = new FString("com.google.appinventor.components.runtime.HorizontalScrollArrangement");
        Lit186 = (SimpleSymbol)new SimpleSymbol("Search1$Click").readResolve();
        object2 = (SimpleSymbol)new SimpleSymbol("text").readResolve();
        Lit9 = object2;
        Lit185 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 1409724);
        Lit184 = (SimpleSymbol)new SimpleSymbol("LogWarning").readResolve();
        Lit183 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 1409530), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 1409524);
        Lit182 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 1409126);
        Lit181 = new FString("com.google.appinventor.components.runtime.Image");
        Lit180 = (SimpleSymbol)new SimpleSymbol("Search1").readResolve();
        Lit179 = new FString("com.google.appinventor.components.runtime.Image");
        Lit178 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit177 = IntNum.make(-1077);
        Lit176 = (SimpleSymbol)new SimpleSymbol("Hint").readResolve();
        int[] nArray = new int[2];
        nArray[0] = -1;
        Lit175 = IntNum.make(nArray);
        Lit174 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit173 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit172 = IntNum.make(0xFFFFFF);
        Lit171 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement1").readResolve();
        Lit170 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit169 = new FString("com.google.appinventor.components.runtime.Label");
        nArray = new int[2];
        nArray[0] = Short.MIN_VALUE;
        Lit168 = IntNum.make(nArray);
        Lit167 = IntNum.make(17);
        Lit166 = (SimpleSymbol)new SimpleSymbol("Label1").readResolve();
        Lit165 = new FString("com.google.appinventor.components.runtime.Label");
        Lit164 = new FString("com.google.appinventor.components.runtime.Image");
        Lit163 = IntNum.make(-1037);
        Lit162 = IntNum.make(-1037);
        Lit161 = (SimpleSymbol)new SimpleSymbol("Image3").readResolve();
        Lit160 = new FString("com.google.appinventor.components.runtime.Image");
        Lit159 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit158 = IntNum.make(-1037);
        Lit157 = IntNum.make(0xFFFFFF);
        Lit156 = (SimpleSymbol)new SimpleSymbol("AlignVertical").readResolve();
        Lit155 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement6").readResolve();
        Lit154 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit153 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit152 = IntNum.make(0xFFFFFF);
        Lit151 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit150 = (SimpleSymbol)new SimpleSymbol("ErrorOccurred").readResolve();
        Lit149 = (SimpleSymbol)new SimpleSymbol("WebViewer3$ErrorOccurred").readResolve();
        Lit148 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 0x1010B0);
        Lit147 = (SimpleSymbol)new SimpleSymbol("LogError").readResolve();
        Lit146 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit145 = IntNum.make(2777);
        Lit144 = new FString("com.google.appinventor.components.runtime.WebViewer");
        Lit143 = new FString("com.google.appinventor.components.runtime.Image");
        Lit142 = (SimpleSymbol)new SimpleSymbol("Image5").readResolve();
        Lit141 = new FString("com.google.appinventor.components.runtime.Image");
        Lit140 = (SimpleSymbol)new SimpleSymbol("Next$Click").readResolve();
        Lit139 = (SimpleSymbol)new SimpleSymbol("GoForward").readResolve();
        Lit138 = new FString("com.google.appinventor.components.runtime.Image");
        Lit137 = (SimpleSymbol)new SimpleSymbol("Next").readResolve();
        Lit136 = new FString("com.google.appinventor.components.runtime.Image");
        Lit135 = (SimpleSymbol)new SimpleSymbol("Before$Click").readResolve();
        Lit134 = (SimpleSymbol)new SimpleSymbol("GoBack").readResolve();
        Lit133 = new FString("com.google.appinventor.components.runtime.Image");
        Lit132 = (SimpleSymbol)new SimpleSymbol("Before").readResolve();
        Lit131 = new FString("com.google.appinventor.components.runtime.Image");
        Lit130 = (SimpleSymbol)new SimpleSymbol("Close$Click").readResolve();
        Lit129 = (SimpleSymbol)new SimpleSymbol("StopLoading").readResolve();
        Lit128 = new FString("com.google.appinventor.components.runtime.Image");
        Lit127 = (SimpleSymbol)new SimpleSymbol("Close").readResolve();
        Lit126 = new FString("com.google.appinventor.components.runtime.Image");
        Lit125 = (SimpleSymbol)new SimpleSymbol("Search$Click").readResolve();
        Lit124 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 843878);
        Lit123 = (SimpleSymbol)new SimpleSymbol("GoToUrl").readResolve();
        Lit122 = new FString("com.google.appinventor.components.runtime.Image");
        Lit121 = (SimpleSymbol)new SimpleSymbol("Search").readResolve();
        Lit120 = new FString("com.google.appinventor.components.runtime.Image");
        Lit119 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit118 = IntNum.make(-1052);
        Lit117 = new FString("com.google.appinventor.components.runtime.TextBox");
        Lit116 = (SimpleSymbol)new SimpleSymbol("Refresh$Click").readResolve();
        Lit115 = (SimpleSymbol)new SimpleSymbol("Reload").readResolve();
        Lit114 = (SimpleSymbol)new SimpleSymbol("WebViewer3").readResolve();
        Lit113 = new FString("com.google.appinventor.components.runtime.Image");
        Lit112 = (SimpleSymbol)new SimpleSymbol("Refresh").readResolve();
        Lit111 = new FString("com.google.appinventor.components.runtime.Image");
        Lit110 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit109 = IntNum.make(-1007);
        nArray = new int[2];
        nArray[0] = -553;
        Lit108 = IntNum.make(nArray);
        Lit107 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement5").readResolve();
        Lit106 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit105 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit104 = IntNum.make(0xFFFFFF);
        Lit103 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit102 = (SimpleSymbol)new SimpleSymbol("Image6$Click").readResolve();
        Lit101 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 621132), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 621126);
        Lit100 = PairWithPosition.make(object, PairWithPosition.make(object, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620941), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620936);
        Lit99 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620909), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620903);
        Lit98 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620875), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620869);
        Lit97 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620748), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620742);
        Lit96 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620621), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620615);
        Lit95 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620493), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620487);
        Lit94 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620140), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620134);
        Lit93 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620007), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 620001);
        Lit92 = (SimpleSymbol)new SimpleSymbol("TextBox1").readResolve();
        Lit91 = PairWithPosition.make(object, PairWithPosition.make(object, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619818), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619813);
        Lit90 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619786), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619780);
        Lit89 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619752), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619746);
        Lit88 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619625), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619619);
        Lit87 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619498), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619492);
        Lit86 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619370), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619364);
        Lit85 = (SimpleSymbol)new SimpleSymbol("TextBox2").readResolve();
        Lit84 = PairWithPosition.make(object2, PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619025), "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 619019);
        Lit83 = (SimpleSymbol)new SimpleSymbol("Selection").readResolve();
        Lit82 = PairWithPosition.make(object2, LList.Empty, "/tmp/1714903909418_0.8178354366605112-0/youngandroidproject/../src/appinventor/ai_sudarshankumar070309/Browser/Screen4.yail", 618912);
        Lit81 = (SimpleSymbol)new SimpleSymbol("LogInfo").readResolve();
        Lit80 = (SimpleSymbol)new SimpleSymbol("Notifier1").readResolve();
        Lit79 = new FString("com.google.appinventor.components.runtime.Image");
        Lit78 = (SimpleSymbol)new SimpleSymbol("Image6").readResolve();
        Lit77 = new FString("com.google.appinventor.components.runtime.Image");
        Lit76 = (SimpleSymbol)new SimpleSymbol("Click").readResolve();
        Lit75 = (SimpleSymbol)new SimpleSymbol("Home$Click").readResolve();
        Lit74 = (SimpleSymbol)new SimpleSymbol("VerticalArrangement1").readResolve();
        Lit73 = (SimpleSymbol)new SimpleSymbol("VerticalArrangement2").readResolve();
        Lit72 = new FString("com.google.appinventor.components.runtime.Image");
        Lit71 = (SimpleSymbol)new SimpleSymbol("Picture").readResolve();
        Lit70 = (SimpleSymbol)new SimpleSymbol("Clickable").readResolve();
        Lit69 = (SimpleSymbol)new SimpleSymbol("Home").readResolve();
        Lit68 = new FString("com.google.appinventor.components.runtime.Image");
        Lit67 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        object = new int[2];
        object[0] = -4669953;
        Lit66 = IntNum.make((int[])object);
        Lit65 = IntNum.make(2);
        Lit64 = (SimpleSymbol)new SimpleSymbol("HorizontalArrangement4").readResolve();
        Lit63 = new FString("com.google.appinventor.components.runtime.HorizontalArrangement");
        Lit62 = new FString("com.google.appinventor.components.runtime.ListView");
        Lit61 = IntNum.make(-1040);
        object = new int[2];
        object[0] = -16777216;
        Lit60 = IntNum.make((int[])object);
        Lit59 = (SimpleSymbol)new SimpleSymbol("TextColor").readResolve();
        Lit58 = (SimpleSymbol)new SimpleSymbol("ListData").readResolve();
        Lit57 = (SimpleSymbol)new SimpleSymbol("FontTypefaceDetail").readResolve();
        Lit56 = (SimpleSymbol)new SimpleSymbol("ElementsFromString").readResolve();
        Lit55 = IntNum.make(0xFFFFFF);
        Lit54 = (SimpleSymbol)new SimpleSymbol("ListView1").readResolve();
        Lit53 = new FString("com.google.appinventor.components.runtime.ListView");
        Lit52 = new FString("com.google.appinventor.components.runtime.Label");
        Lit51 = (SimpleSymbol)new SimpleSymbol("TextAlignment").readResolve();
        Lit50 = IntNum.make(12);
        Lit49 = (SimpleSymbol)new SimpleSymbol("FontSize").readResolve();
        Lit48 = (SimpleSymbol)new SimpleSymbol("Space_divider").readResolve();
        Lit47 = new FString("com.google.appinventor.components.runtime.Label");
        Lit46 = new FString("com.google.appinventor.components.runtime.Label");
        Lit45 = (SimpleSymbol)new SimpleSymbol("Search_engine").readResolve();
        Lit44 = new FString("com.google.appinventor.components.runtime.Label");
        Lit43 = new FString("com.google.appinventor.components.runtime.Button");
        Lit42 = IntNum.make(0xFFFFFF);
        Lit41 = (SimpleSymbol)new SimpleSymbol("Locatuon").readResolve();
        Lit40 = new FString("com.google.appinventor.components.runtime.Button");
        Lit39 = new FString("com.google.appinventor.components.runtime.Button");
        Lit38 = IntNum.make(0xFFFFFF);
        Lit37 = (SimpleSymbol)new SimpleSymbol("Cache").readResolve();
        Lit36 = new FString("com.google.appinventor.components.runtime.Button");
        Lit35 = new FString("com.google.appinventor.components.runtime.Button");
        Lit34 = (SimpleSymbol)new SimpleSymbol("Text").readResolve();
        Lit33 = IntNum.make(1);
        Lit32 = (SimpleSymbol)new SimpleSymbol("Shape").readResolve();
        Lit31 = (SimpleSymbol)new SimpleSymbol("FontTypeface").readResolve();
        Lit30 = (SimpleSymbol)new SimpleSymbol("FontBold").readResolve();
        Lit29 = IntNum.make(0xFFFFFF);
        Lit28 = (SimpleSymbol)new SimpleSymbol("Cookie").readResolve();
        Lit27 = new FString("com.google.appinventor.components.runtime.Button");
        Lit26 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit25 = IntNum.make(-2);
        Lit24 = (SimpleSymbol)new SimpleSymbol("Width").readResolve();
        Lit23 = (SimpleSymbol)new SimpleSymbol("Visible").readResolve();
        Lit22 = IntNum.make(2000);
        Lit21 = (SimpleSymbol)new SimpleSymbol("Height").readResolve();
        object = new int[2];
        object[0] = -1;
        Lit20 = IntNum.make((int[])object);
        Lit19 = (SimpleSymbol)new SimpleSymbol("BackgroundColor").readResolve();
        Lit18 = (SimpleSymbol)new SimpleSymbol("VerticalArrangement3").readResolve();
        Lit17 = new FString("com.google.appinventor.components.runtime.VerticalArrangement");
        Lit16 = (SimpleSymbol)new SimpleSymbol("TitleVisible").readResolve();
        Lit15 = (SimpleSymbol)new SimpleSymbol("Title").readResolve();
        Lit14 = (SimpleSymbol)new SimpleSymbol("Sizing").readResolve();
        Lit13 = (SimpleSymbol)new SimpleSymbol("ShowListsAsJson").readResolve();
        Lit12 = (SimpleSymbol)new SimpleSymbol("Scrollable").readResolve();
        Lit11 = (SimpleSymbol)new SimpleSymbol("ScreenOrientation").readResolve();
        Lit10 = (SimpleSymbol)new SimpleSymbol("BackgroundImage").readResolve();
        Lit8 = (SimpleSymbol)new SimpleSymbol("AppName").readResolve();
        Lit7 = (SimpleSymbol)new SimpleSymbol("number").readResolve();
        Lit6 = IntNum.make(3);
        Lit5 = (SimpleSymbol)new SimpleSymbol("AlignHorizontal").readResolve();
        Lit4 = (SimpleSymbol)new SimpleSymbol("boolean").readResolve();
        Lit3 = (SimpleSymbol)new SimpleSymbol("ActionBar").readResolve();
        Lit2 = (SimpleSymbol)new SimpleSymbol("*the-null-value*").readResolve();
        Lit1 = (SimpleSymbol)new SimpleSymbol("getMessage").readResolve();
        Lit0 = (SimpleSymbol)new SimpleSymbol("Screen4").readResolve();
    }

    public Screen4() {
        ModuleInfo.register((Object)this);
        Screen4$frame screen4$frame = new Screen4$frame();
        screen4$frame.$main = this;
        this.get$Mnsimple$Mnname = new ModuleMethod(screen4$frame, 1, Lit250, 4097);
        this.onCreate = new ModuleMethod(screen4$frame, 2, "onCreate", 4097);
        this.android$Mnlog$Mnform = new ModuleMethod(screen4$frame, 3, Lit251, 4097);
        this.add$Mnto$Mnform$Mnenvironment = new ModuleMethod(screen4$frame, 4, Lit252, 8194);
        this.lookup$Mnin$Mnform$Mnenvironment = new ModuleMethod(screen4$frame, 5, Lit253, 8193);
        this.is$Mnbound$Mnin$Mnform$Mnenvironment = new ModuleMethod(screen4$frame, 7, Lit254, 4097);
        this.add$Mnto$Mnglobal$Mnvar$Mnenvironment = new ModuleMethod(screen4$frame, 8, Lit255, 8194);
        this.add$Mnto$Mnevents = new ModuleMethod(screen4$frame, 9, Lit256, 8194);
        this.add$Mnto$Mncomponents = new ModuleMethod(screen4$frame, 10, Lit257, 16388);
        this.add$Mnto$Mnglobal$Mnvars = new ModuleMethod(screen4$frame, 11, Lit258, 8194);
        this.add$Mnto$Mnform$Mndo$Mnafter$Mncreation = new ModuleMethod(screen4$frame, 12, Lit259, 4097);
        this.send$Mnerror = new ModuleMethod(screen4$frame, 13, Lit260, 4097);
        this.process$Mnexception = new ModuleMethod(screen4$frame, 14, "process-exception", 4097);
        this.dispatchEvent = new ModuleMethod(screen4$frame, 15, Lit261, 16388);
        this.dispatchGenericEvent = new ModuleMethod(screen4$frame, 16, Lit262, 16388);
        this.lookup$Mnhandler = new ModuleMethod(screen4$frame, 17, Lit263, 8194);
        ModuleMethod moduleMethod = new ModuleMethod(screen4$frame, 18, null, 0);
        moduleMethod.setProperty("source-location", "/tmp/runtime15289563291066899343.scm:634");
        lambda$Fn1 = moduleMethod;
        this.$define = new ModuleMethod(screen4$frame, 19, "$define", 0);
        lambda$Fn2 = new ModuleMethod(screen4$frame, 20, null, 0);
        lambda$Fn3 = new ModuleMethod(screen4$frame, 21, null, 0);
        lambda$Fn4 = new ModuleMethod(screen4$frame, 22, null, 0);
        lambda$Fn5 = new ModuleMethod(screen4$frame, 23, null, 0);
        lambda$Fn6 = new ModuleMethod(screen4$frame, 24, null, 0);
        lambda$Fn7 = new ModuleMethod(screen4$frame, 25, null, 0);
        lambda$Fn8 = new ModuleMethod(screen4$frame, 26, null, 0);
        lambda$Fn9 = new ModuleMethod(screen4$frame, 27, null, 0);
        lambda$Fn10 = new ModuleMethod(screen4$frame, 28, null, 0);
        lambda$Fn11 = new ModuleMethod(screen4$frame, 29, null, 0);
        lambda$Fn12 = new ModuleMethod(screen4$frame, 30, null, 0);
        lambda$Fn13 = new ModuleMethod(screen4$frame, 31, null, 0);
        lambda$Fn14 = new ModuleMethod(screen4$frame, 32, null, 0);
        lambda$Fn15 = new ModuleMethod(screen4$frame, 33, null, 0);
        lambda$Fn16 = new ModuleMethod(screen4$frame, 34, null, 0);
        lambda$Fn17 = new ModuleMethod(screen4$frame, 35, null, 0);
        lambda$Fn18 = new ModuleMethod(screen4$frame, 36, null, 0);
        this.Home$Click = new ModuleMethod(screen4$frame, 37, Lit75, 0);
        lambda$Fn19 = new ModuleMethod(screen4$frame, 38, null, 0);
        lambda$Fn20 = new ModuleMethod(screen4$frame, 39, null, 0);
        lambda$Fn21 = new ModuleMethod(screen4$frame, 40, null, 0);
        lambda$Fn22 = new ModuleMethod(screen4$frame, 41, null, 0);
        lambda$Fn23 = new ModuleMethod(screen4$frame, 42, null, 0);
        lambda$Fn24 = new ModuleMethod(screen4$frame, 43, null, 0);
        lambda$Fn25 = new ModuleMethod(screen4$frame, 44, null, 0);
        lambda$Fn26 = new ModuleMethod(screen4$frame, 45, null, 0);
        lambda$Fn27 = new ModuleMethod(screen4$frame, 46, null, 0);
        lambda$Fn28 = new ModuleMethod(screen4$frame, 47, null, 0);
        this.Image6$Click = new ModuleMethod(screen4$frame, 48, Lit102, 0);
        lambda$Fn29 = new ModuleMethod(screen4$frame, 49, null, 0);
        lambda$Fn30 = new ModuleMethod(screen4$frame, 50, null, 0);
        lambda$Fn31 = new ModuleMethod(screen4$frame, 51, null, 0);
        lambda$Fn32 = new ModuleMethod(screen4$frame, 52, null, 0);
        lambda$Fn33 = new ModuleMethod(screen4$frame, 53, null, 0);
        lambda$Fn34 = new ModuleMethod(screen4$frame, 54, null, 0);
        this.Refresh$Click = new ModuleMethod(screen4$frame, 55, Lit116, 0);
        lambda$Fn35 = new ModuleMethod(screen4$frame, 56, null, 0);
        lambda$Fn36 = new ModuleMethod(screen4$frame, 57, null, 0);
        lambda$Fn37 = new ModuleMethod(screen4$frame, 58, null, 0);
        lambda$Fn38 = new ModuleMethod(screen4$frame, 59, null, 0);
        this.Search$Click = new ModuleMethod(screen4$frame, 60, Lit125, 0);
        lambda$Fn39 = new ModuleMethod(screen4$frame, 61, null, 0);
        lambda$Fn40 = new ModuleMethod(screen4$frame, 62, null, 0);
        this.Close$Click = new ModuleMethod(screen4$frame, 63, Lit130, 0);
        lambda$Fn41 = new ModuleMethod(screen4$frame, 64, null, 0);
        lambda$Fn42 = new ModuleMethod(screen4$frame, 65, null, 0);
        this.Before$Click = new ModuleMethod(screen4$frame, 66, Lit135, 0);
        lambda$Fn43 = new ModuleMethod(screen4$frame, 67, null, 0);
        lambda$Fn44 = new ModuleMethod(screen4$frame, 68, null, 0);
        this.Next$Click = new ModuleMethod(screen4$frame, 69, Lit140, 0);
        lambda$Fn45 = new ModuleMethod(screen4$frame, 70, null, 0);
        lambda$Fn46 = new ModuleMethod(screen4$frame, 71, null, 0);
        lambda$Fn47 = new ModuleMethod(screen4$frame, 72, null, 0);
        lambda$Fn48 = new ModuleMethod(screen4$frame, 73, null, 0);
        this.WebViewer3$ErrorOccurred = new ModuleMethod(screen4$frame, 74, Lit149, 12291);
        lambda$Fn49 = new ModuleMethod(screen4$frame, 75, null, 0);
        lambda$Fn50 = new ModuleMethod(screen4$frame, 76, null, 0);
        lambda$Fn51 = new ModuleMethod(screen4$frame, 77, null, 0);
        lambda$Fn52 = new ModuleMethod(screen4$frame, 78, null, 0);
        lambda$Fn53 = new ModuleMethod(screen4$frame, 79, null, 0);
        lambda$Fn54 = new ModuleMethod(screen4$frame, 80, null, 0);
        lambda$Fn55 = new ModuleMethod(screen4$frame, 81, null, 0);
        lambda$Fn56 = new ModuleMethod(screen4$frame, 82, null, 0);
        lambda$Fn57 = new ModuleMethod(screen4$frame, 83, null, 0);
        lambda$Fn58 = new ModuleMethod(screen4$frame, 84, null, 0);
        lambda$Fn59 = new ModuleMethod(screen4$frame, 85, null, 0);
        lambda$Fn60 = new ModuleMethod(screen4$frame, 86, null, 0);
        lambda$Fn61 = new ModuleMethod(screen4$frame, 87, null, 0);
        lambda$Fn62 = new ModuleMethod(screen4$frame, 88, null, 0);
        this.Search1$Click = new ModuleMethod(screen4$frame, 89, Lit186, 0);
        lambda$Fn63 = new ModuleMethod(screen4$frame, 90, null, 0);
        lambda$Fn64 = new ModuleMethod(screen4$frame, 91, null, 0);
        lambda$Fn65 = new ModuleMethod(screen4$frame, 92, null, 0);
        lambda$Fn66 = new ModuleMethod(screen4$frame, 93, null, 0);
        this.News$Click = new ModuleMethod(screen4$frame, 94, Lit200, 0);
        lambda$Fn67 = new ModuleMethod(screen4$frame, 95, null, 0);
        lambda$Fn68 = new ModuleMethod(screen4$frame, 96, null, 0);
        this.Button3$Click = new ModuleMethod(screen4$frame, 97, Lit205, 0);
        lambda$Fn69 = new ModuleMethod(screen4$frame, 98, null, 0);
        lambda$Fn70 = new ModuleMethod(screen4$frame, 99, null, 0);
        this.Latest_rels$Click = new ModuleMethod(screen4$frame, 100, Lit209, 0);
        lambda$Fn71 = new ModuleMethod(screen4$frame, 101, null, 0);
        lambda$Fn72 = new ModuleMethod(screen4$frame, 102, null, 0);
        this.Sky$Click = new ModuleMethod(screen4$frame, 103, Lit214, 0);
        lambda$Fn73 = new ModuleMethod(screen4$frame, 104, null, 0);
        lambda$Fn74 = new ModuleMethod(screen4$frame, 105, null, 0);
        this.IPL_2024$Click = new ModuleMethod(screen4$frame, 106, Lit220, 0);
        lambda$Fn75 = new ModuleMethod(screen4$frame, 107, null, 0);
        lambda$Fn76 = new ModuleMethod(screen4$frame, 108, null, 0);
        this.Button2$Click = new ModuleMethod(screen4$frame, 109, Lit225, 0);
        lambda$Fn77 = new ModuleMethod(screen4$frame, 110, null, 0);
        lambda$Fn78 = new ModuleMethod(screen4$frame, 111, null, 0);
        lambda$Fn79 = new ModuleMethod(screen4$frame, 112, null, 0);
        lambda$Fn80 = new ModuleMethod(screen4$frame, 113, null, 0);
        lambda$Fn81 = new ModuleMethod(screen4$frame, 114, null, 0);
        lambda$Fn82 = new ModuleMethod(screen4$frame, 115, null, 0);
        lambda$Fn83 = new ModuleMethod(screen4$frame, 116, null, 0);
        lambda$Fn84 = new ModuleMethod(screen4$frame, 117, null, 0);
    }

    static Object lambda10() {
        SimpleSymbol simpleSymbol = Lit41;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit42;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear all locations stored", comparable);
    }

    static Object lambda11() {
        SimpleSymbol simpleSymbol = Lit41;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit42;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear all locations stored", comparable);
    }

    static Object lambda12() {
        SimpleSymbol simpleSymbol = Lit48;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        SimpleSymbol simpleSymbol2 = Lit49;
        Comparable comparable = Lit50;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Search Engine ( when there is a search in web not any URL)", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit33, simpleSymbol3);
    }

    static Object lambda13() {
        SimpleSymbol simpleSymbol = Lit48;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        SimpleSymbol simpleSymbol2 = Lit49;
        Comparable comparable = Lit50;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Search Engine ( when there is a search in web not any URL)", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit51, (Object)Lit33, simpleSymbol3);
    }

    static Object lambda14() {
        SimpleSymbol simpleSymbol = Lit54;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit55;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit56;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "Google,Bing", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit57, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, "[]", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit60, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit61, simpleSymbol3);
    }

    static Object lambda15() {
        SimpleSymbol simpleSymbol = Lit54;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit55;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit56;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "Google,Bing", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit31, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit57, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit58, "[]", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit60, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit61, simpleSymbol3);
    }

    static Object lambda16() {
        SimpleSymbol simpleSymbol = Lit64;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit65;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit66, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda17() {
        SimpleSymbol simpleSymbol = Lit64;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit65;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit66, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda18() {
        SimpleSymbol simpleSymbol = Lit69;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "home_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda19() {
        SimpleSymbol simpleSymbol = Lit69;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "home_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    /*
     * WARNING - void declaration
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SimpleSymbol lambda1symbolAppend$V(Object[] objectArray) {
        Object object = LList.makeList(objectArray, 0);
        Apply apply = Scheme.apply;
        ModuleMethod moduleMethod = strings.string$Mnappend;
        LList lList = LList.Empty;
        while (true) {
            Symbol symbol;
            Object object2;
            void var0_2;
            if (object == LList.Empty) {
                Object object3 = ((Procedure)apply).apply2(moduleMethod, LList.reverseInPlace(var0_2));
                try {
                    object = (CharSequence)object3;
                    return misc.string$To$Symbol((CharSequence)object);
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "string->symbol", 1, object3);
                }
            }
            try {
                object2 = (Pair)object;
            }
            catch (ClassCastException classCastException) {
                WrongType wrongType = new WrongType(classCastException, "arg0", -2, object);
                throw wrongType;
            }
            object = ((Pair)object2).getCdr();
            object2 = ((Pair)object2).getCar();
            try {
                symbol = (Symbol)object2;
            }
            catch (ClassCastException classCastException) {
                throw new WrongType(classCastException, "symbol->string", 1, object2);
            }
            Pair pair = Pair.make(misc.symbol$To$String(symbol), var0_2);
        }
    }

    static Object lambda2() {
        return null;
    }

    static Object lambda20() {
        SimpleSymbol simpleSymbol = Lit78;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "settings_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda21() {
        SimpleSymbol simpleSymbol = Lit78;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "settings_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda22() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".org"), Lit86, "string contains");
    }

    static Object lambda23() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".com"), Lit87, "string contains");
    }

    static Object lambda24() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".in"), Lit88, "string contains");
    }

    static Object lambda25() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".co"), Lit89, "string contains");
    }

    static Object lambda26() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".org"), Lit95, "string contains");
    }

    static Object lambda27() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".com"), Lit96, "string contains");
    }

    static Object lambda28() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".in"), Lit97, "string contains");
    }

    static Object lambda29() {
        return runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34), ".co"), Lit98, "string contains");
    }

    static Object lambda3() {
        SimpleSymbol simpleSymbol = Lit0;
        SimpleSymbol simpleSymbol2 = Lit3;
        Object object = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, object, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit5, (Object)Lit6, Lit7);
        simpleSymbol2 = Lit8;
        object = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "Browser", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit10, "jellyfish-7340188_640.jpg", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit11, "unspecified", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit12, Boolean.TRUE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit13, Boolean.TRUE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit14, "Responsive", object);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit15, "Screen4", object);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit16, Boolean.FALSE, simpleSymbol3);
    }

    static Object lambda30() {
        SimpleSymbol simpleSymbol = Lit73;
        Comparable comparable = Lit19;
        Comparable comparable2 = Lit104;
        SimpleSymbol simpleSymbol2 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, comparable2, simpleSymbol2);
        comparable2 = Lit21;
        comparable = Lit25;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable2, comparable, simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, comparable, simpleSymbol2);
    }

    static Object lambda31() {
        SimpleSymbol simpleSymbol = Lit73;
        Comparable comparable = Lit19;
        Comparable comparable2 = Lit104;
        SimpleSymbol simpleSymbol2 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, comparable2, simpleSymbol2);
        comparable2 = Lit21;
        comparable = Lit25;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable2, comparable, simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, comparable, simpleSymbol2);
    }

    static Object lambda32() {
        SimpleSymbol simpleSymbol = Lit107;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit108, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit109, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda33() {
        SimpleSymbol simpleSymbol = Lit107;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit108, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit109, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda34() {
        SimpleSymbol simpleSymbol = Lit112;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "refresh_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda35() {
        SimpleSymbol simpleSymbol = Lit112;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "refresh_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda36() {
        return runtime.setAndCoerceProperty$Ex(Lit85, Lit24, (Object)Lit118, Lit7);
    }

    static Object lambda37() {
        return runtime.setAndCoerceProperty$Ex(Lit85, Lit24, (Object)Lit118, Lit7);
    }

    static Object lambda38() {
        SimpleSymbol simpleSymbol = Lit121;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "search_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda39() {
        SimpleSymbol simpleSymbol = Lit121;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "search_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda4() {
        SimpleSymbol simpleSymbol = Lit18;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit22, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda40() {
        SimpleSymbol simpleSymbol = Lit127;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "close_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda41() {
        SimpleSymbol simpleSymbol = Lit127;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "close_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda42() {
        SimpleSymbol simpleSymbol = Lit132;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "arrow_back_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda43() {
        SimpleSymbol simpleSymbol = Lit132;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "arrow_back_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda44() {
        SimpleSymbol simpleSymbol = Lit137;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "arrow_forward_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda45() {
        SimpleSymbol simpleSymbol = Lit137;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "arrow_forward_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda46() {
        return runtime.setAndCoerceProperty$Ex(Lit142, Lit71, "account_circle_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda47() {
        return runtime.setAndCoerceProperty$Ex(Lit142, Lit71, "account_circle_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda48() {
        SimpleSymbol simpleSymbol = Lit114;
        SimpleSymbol simpleSymbol2 = Lit21;
        IntNum intNum = Lit145;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda49() {
        SimpleSymbol simpleSymbol = Lit114;
        SimpleSymbol simpleSymbol2 = Lit21;
        IntNum intNum = Lit145;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda5() {
        SimpleSymbol simpleSymbol = Lit18;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit20;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit22, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda50() {
        SimpleSymbol simpleSymbol = Lit74;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit152;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda51() {
        SimpleSymbol simpleSymbol = Lit74;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit152;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda52() {
        SimpleSymbol simpleSymbol = Lit155;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit157, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit158, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda53() {
        SimpleSymbol simpleSymbol = Lit155;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit157, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit158, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda54() {
        SimpleSymbol simpleSymbol = Lit161;
        SimpleSymbol simpleSymbol2 = Lit21;
        IntNum intNum = Lit162;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "17292", Lit9);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit163, simpleSymbol3);
    }

    static Object lambda55() {
        SimpleSymbol simpleSymbol = Lit161;
        SimpleSymbol simpleSymbol2 = Lit21;
        IntNum intNum = Lit162;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "17292", Lit9);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit163, simpleSymbol3);
    }

    static Object lambda56() {
        SimpleSymbol simpleSymbol = Lit166;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        SimpleSymbol simpleSymbol2 = Lit49;
        Comparable comparable = Lit167;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "VedaPages", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit168, simpleSymbol3);
    }

    static Object lambda57() {
        SimpleSymbol simpleSymbol = Lit166;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        SimpleSymbol simpleSymbol2 = Lit49;
        Comparable comparable = Lit167;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "VedaPages", comparable);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit168, simpleSymbol3);
    }

    static Object lambda58() {
        SimpleSymbol simpleSymbol = Lit171;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit172, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda59() {
        SimpleSymbol simpleSymbol = Lit171;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit172, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda6() {
        SimpleSymbol simpleSymbol = Lit28;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit29;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear Cookies", simpleSymbol2);
    }

    static Object lambda60() {
        SimpleSymbol simpleSymbol = Lit92;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit175;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit176, "Search In The Web", comparable);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit177, simpleSymbol3);
    }

    static Object lambda61() {
        SimpleSymbol simpleSymbol = Lit92;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit175;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit176, "Search In The Web", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit177, simpleSymbol3);
    }

    static Object lambda62() {
        SimpleSymbol simpleSymbol = Lit180;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "search_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda63() {
        SimpleSymbol simpleSymbol = Lit180;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "search_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda64() {
        SimpleSymbol simpleSymbol = Lit188;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit189;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda65() {
        SimpleSymbol simpleSymbol = Lit188;
        SimpleSymbol simpleSymbol2 = Lit19;
        IntNum intNum = Lit189;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda66() {
        return runtime.setAndCoerceProperty$Ex(Lit192, Lit71, "news_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda67() {
        return runtime.setAndCoerceProperty$Ex(Lit192, Lit71, "news_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda68() {
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit202;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "News", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit203, simpleSymbol3);
    }

    static Object lambda69() {
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit202;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "News", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit203, simpleSymbol3);
    }

    static Object lambda7() {
        SimpleSymbol simpleSymbol = Lit28;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit29;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear Cookies", simpleSymbol2);
    }

    static Object lambda70() {
        SimpleSymbol simpleSymbol = Lit207;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "new_releases_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda71() {
        SimpleSymbol simpleSymbol = Lit207;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit70, Boolean.TRUE, Lit4);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit71, "new_releases_FILL0_wght400_GRAD0_opsz24.png", Lit9);
    }

    static Object lambda72() {
        SimpleSymbol simpleSymbol = Lit199;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit211;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "SKY", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit212, simpleSymbol3);
    }

    static Object lambda73() {
        SimpleSymbol simpleSymbol = Lit199;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit211;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "SKY", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit212, simpleSymbol3);
    }

    static Object lambda74() {
        SimpleSymbol simpleSymbol = Lit198;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit216;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "IPL 2024", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit217, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit218, simpleSymbol3);
    }

    static Object lambda75() {
        SimpleSymbol simpleSymbol = Lit198;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit216;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "IPL 2024", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit59, (Object)Lit217, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit218, simpleSymbol3);
    }

    static Object lambda76() {
        SimpleSymbol simpleSymbol = Lit197;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit222;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "New", simpleSymbol2);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit223, simpleSymbol3);
    }

    static Object lambda77() {
        SimpleSymbol simpleSymbol = Lit197;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit222;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "New", comparable);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit223, simpleSymbol3);
    }

    static Object lambda78() {
        SimpleSymbol simpleSymbol = Lit227;
        SimpleSymbol simpleSymbol2 = Lit156;
        IntNum intNum = Lit65;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit228, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit229, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda79() {
        SimpleSymbol simpleSymbol = Lit227;
        SimpleSymbol simpleSymbol2 = Lit156;
        IntNum intNum = Lit65;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit228, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit229, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda8() {
        SimpleSymbol simpleSymbol = Lit37;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit38;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        simpleSymbol2 = Lit31;
        comparable = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "2", comparable);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear Caches", comparable);
    }

    static Object lambda80() {
        SimpleSymbol simpleSymbol = Lit194;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit232, Lit7);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit195, "https://sites.google.com/view/news-editor-sanatan-kumar/home", Lit9);
        SimpleSymbol simpleSymbol2 = Lit233;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit234, Boolean.TRUE, simpleSymbol3);
    }

    static Object lambda81() {
        SimpleSymbol simpleSymbol = Lit194;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit232, Lit7);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit195, "https://sites.google.com/view/news-editor-sanatan-kumar/home", Lit9);
        SimpleSymbol simpleSymbol2 = Lit233;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit234, Boolean.TRUE, simpleSymbol3);
    }

    static Object lambda82() {
        SimpleSymbol simpleSymbol = Lit237;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit238, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit239, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda83() {
        SimpleSymbol simpleSymbol = Lit237;
        SimpleSymbol simpleSymbol2 = Lit5;
        IntNum intNum = Lit6;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, (Object)intNum, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit156, (Object)Lit65, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit19, (Object)Lit238, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit239, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit24, (Object)Lit25, simpleSymbol3);
    }

    static Object lambda84() {
        SimpleSymbol simpleSymbol = Lit242;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit243, Lit7);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit195, "https://sites.google.com/view/ latest-releases", Lit9);
        SimpleSymbol simpleSymbol2 = Lit233;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, simpleSymbol3);
    }

    static Object lambda85() {
        SimpleSymbol simpleSymbol = Lit242;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit21, (Object)Lit243, Lit7);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit195, "https://sites.google.com/view/ latest-releases", Lit9);
        SimpleSymbol simpleSymbol2 = Lit233;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit23, Boolean.FALSE, simpleSymbol3);
    }

    static Object lambda9() {
        SimpleSymbol simpleSymbol = Lit37;
        SimpleSymbol simpleSymbol2 = Lit19;
        Comparable comparable = Lit38;
        SimpleSymbol simpleSymbol3 = Lit7;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, comparable, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit30, Boolean.TRUE, Lit4);
        comparable = Lit31;
        simpleSymbol2 = Lit9;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, comparable, "2", simpleSymbol2);
        runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit32, (Object)Lit33, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit34, "Clear Caches", simpleSymbol2);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void $define() {
        Language.setDefaults((Language)Scheme.getInstance());
        try {
            this.run();
        }
        catch (Exception var1_1) {
            this.androidLogForm(var1_1.getMessage());
            this.processException((Object)var1_1);
        }
        appinventor.ai_sudarshankumar070309.Browser.Screen4.Screen4 = this;
        this.addToFormEnvironment(appinventor.ai_sudarshankumar070309.Browser.Screen4.Lit0, this);
        var1_2 /* !! */  = this.events$Mnto$Mnregister;
        var3_4 /* !! */  = var1_2 /* !! */ ;
        while (true) {
            block33: {
                if (var1_2 /* !! */  != LList.Empty) break block33;
                try {
                    var1_2 /* !! */  = lists.reverse(this.components$Mnto$Mncreate);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    this.addToGlobalVars(appinventor.ai_sudarshankumar070309.Browser.Screen4.Lit2, appinventor.ai_sudarshankumar070309.Browser.Screen4.lambda$Fn1);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_7 /* !! */  = lists.reverse(this.form$Mndo$Mnafter$Mncreation);
lbl20:
                    // 2 sources

                    while (true) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        if (var2_7 /* !! */  != LList.Empty) ** GOTO lbl181
                        var2_7 /* !! */  = null;
                        var4_5 /* !! */  = var1_2 /* !! */ ;
lbl25:
                        // 2 sources

                        while (true) {
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            if (var4_5 /* !! */  != LList.Empty) ** GOTO lbl128
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            var4_5 /* !! */  = lists.reverse(this.global$Mnvars$Mnto$Mncreate);
lbl30:
                            // 2 sources

                            while (true) {
                                var3_4 /* !! */  = var1_2 /* !! */ ;
                                if (var4_5 /* !! */  != LList.Empty) ** GOTO lbl97
                                var4_5 /* !! */  = var1_2 /* !! */ ;
lbl34:
                                // 2 sources

                                while (true) {
                                    var3_4 /* !! */  = var1_2 /* !! */ ;
                                    if (var4_5 /* !! */  == LList.Empty) {
                                        var3_4 /* !! */  = var1_2 /* !! */ ;
                                        var4_5 /* !! */  = var2_7 /* !! */ ;
                                        var2_7 /* !! */  = var3_4 /* !! */ ;
lbl40:
                                        // 2 sources

                                        while (true) {
                                            var3_4 /* !! */  = var1_2 /* !! */ ;
                                            var3_4 /* !! */  = LList.Empty;
                                            if (var2_7 /* !! */  == var3_4 /* !! */ ) {
                                                return;
                                            }
                                            var3_4 /* !! */  = var1_2 /* !! */ ;
                                            break;
                                        }
                                    }
                                    ** GOTO lbl74
                                    break;
                                }
                                break;
                            }
                            break;
                        }
                        break;
                    }
                }
                catch (YailRuntimeError var1_3) {
                    this.processException((Object)var1_3);
                    return;
                }
                {
                    try {
                        var5_12 = (Pair)var2_7 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_13) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var4_5 /* !! */  = new WrongType(var5_13, "arg0", -2, var2_7 /* !! */ );
                        var2_7 /* !! */  = var4_5 /* !! */ ;
lbl60:
                        // 2 sources

                        while (true) {
                            var3_4 /* !! */  = var1_2 /* !! */ ;
                            throw var2_7 /* !! */ ;
                        }
                    }
                    var2_7 /* !! */  = var5_12.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.caddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.cadddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    this.callInitialize(SlotGet.field.apply2(this, var4_5 /* !! */ ));
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_7 /* !! */  = var5_12.getCdr();
                    ** continue;
lbl74:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_12 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_8) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_7 /* !! */  = new WrongType(var2_8, "arg0", -2, (Object)var4_5 /* !! */ );
                        ** continue;
                    }
                    var2_7 /* !! */  = var5_12.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.caddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_7 /* !! */  = lists.cadddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    if (var2_7 /* !! */  != Boolean.FALSE) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        Scheme.applyToArgs.apply1(var2_7 /* !! */ );
                    }
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_12.getCdr();
                    ** continue;
lbl97:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_12 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_15) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_7 /* !! */  = new WrongType(var5_15, "arg0", -2, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_7 /* !! */ ;
                    }
                    var2_7 /* !! */  = var5_12.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.car.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var7_18 = lists.cadr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var6_19 = (Symbol)var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_14) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_7 /* !! */  = new WrongType(var5_14, "add-to-global-var-environment", 0, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_7 /* !! */ ;
                    }
                    this.addToGlobalVarEnvironment((Symbol)var6_19, Scheme.applyToArgs.apply1(var7_18));
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_12.getCdr();
                    ** continue;
lbl128:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var5_12 = var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_16) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_7 /* !! */  = new WrongType(var5_16, "arg0", -2, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_7 /* !! */ ;
                    }
                    var2_7 /* !! */  = var5_12.getCar();
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = lists.caddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    lists.cadddr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var7_18 = lists.cadr.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var6_19 = lists.car.apply1(var2_7 /* !! */ );
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var8_11 = (Symbol)var6_19;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var4_6) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var2_7 /* !! */  = new WrongType(var4_6, "lookup-in-form-environment", 0, var6_19);
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var2_7 /* !! */ ;
                    }
                    var6_19 = this.lookupInFormEnvironment(var8_11);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var7_18 = Invoke.make.apply2(var7_18, var6_19);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    SlotSet.set$Mnfield$Ex.apply3(this, var4_5 /* !! */ , var7_18);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var6_19 = (Symbol)var4_5 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var2_9) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var5_12 = new WrongType(var2_9, "add-to-form-environment", 0, (Object)var4_5 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var5_12;
                    }
                    this.addToFormEnvironment((Symbol)var6_19, var7_18);
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var4_5 /* !! */  = var5_12.getCdr();
                    ** continue;
lbl181:
                    // 1 sources

                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    try {
                        var4_5 /* !! */  = (Pair)var2_7 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                    }
                    catch (ClassCastException var5_17) {
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        var4_5 /* !! */  = new WrongType(var5_17, "arg0", -2, var2_7 /* !! */ );
                        var3_4 /* !! */  = var1_2 /* !! */ ;
                        throw var4_5 /* !! */ ;
                    }
                    misc.force(var4_5 /* !! */ .getCar());
                    var3_4 /* !! */  = var1_2 /* !! */ ;
                    var2_7 /* !! */  = var4_5 /* !! */ .getCdr();
                    ** continue;
                }
            }
            try {
                var4_5 /* !! */  = (Pair)var1_2 /* !! */ ;
            }
            catch (ClassCastException var2_10) {
                var1_2 /* !! */  = new WrongType(var2_10, "arg0", -2, var1_2 /* !! */ );
                throw var1_2 /* !! */ ;
            }
            var2_7 /* !! */  = var4_5 /* !! */ .getCar();
            var1_2 /* !! */  = lists.car.apply1(var2_7 /* !! */ );
            var1_2 /* !! */  = var1_2 /* !! */  == null ? null : var1_2 /* !! */ .toString();
            var2_7 /* !! */  = lists.cdr.apply1(var2_7 /* !! */ );
            var2_7 /* !! */  = var2_7 /* !! */  == null ? null : var2_7 /* !! */ .toString();
            EventDispatcher.registerEventForDelegation(this, (String)var1_2 /* !! */ , (String)var2_7 /* !! */ );
            var1_2 /* !! */  = var4_5 /* !! */ .getCdr();
        }
    }

    public Object Before$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit114, Lit134, LList.Empty, LList.Empty);
    }

    public Object Button2$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://sites.google.com/view/latest-releases/home", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.FALSE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.TRUE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
    }

    public Object Button3$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://sites.google.com/view/news-editor-sanatan-kumar/home", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
    }

    public Object Close$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit114, Lit129, LList.Empty, LList.Empty);
    }

    public Object Home$Click() {
        runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit18;
        SimpleSymbol simpleSymbol2 = Lit23;
        Boolean bl = Boolean.FALSE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit73, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit74, simpleSymbol2, Boolean.TRUE, simpleSymbol3);
    }

    public Object IPL_2024$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://www.google.com/search?q=ipl&oq=s#sie=m;/g/11vyrznwrm;5;/m/03b_lm1;dt;fp;1;;;", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.FALSE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.TRUE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
    }

    public Object Image6$Click() {
        ModuleMethod moduleMethod;
        runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit18;
        SimpleSymbol simpleSymbol2 = Lit23;
        Object object = Boolean.TRUE;
        Object object2 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, object, object2);
        runtime.setAndCoerceProperty$Ex(Lit73, simpleSymbol2, Boolean.FALSE, object2);
        runtime.setAndCoerceProperty$Ex(Lit74, simpleSymbol2, Boolean.FALSE, object2);
        runtime.callComponentMethod(Lit80, Lit81, LList.list1("You can now choose the search engine in which you want to search if you are surfing on web without containing .com , .co , .in or .org ."), Lit82);
        ModuleMethod moduleMethod2 = strings.string$Eq$Qu;
        ModuleMethod moduleMethod3 = runtime.get$Mnproperty;
        object = Lit54;
        simpleSymbol = Lit83;
        if (runtime.callYailPrimitive(moduleMethod2, LList.list2(((Procedure)moduleMethod3).apply2(object, simpleSymbol), "Bing"), Lit84, "text=") != Boolean.FALSE) {
            runtime.setAndCoerceProperty$Ex(object, simpleSymbol2, Boolean.FALSE, object2);
            moduleMethod3 = runtime.yail$Mnequal$Qu;
            object2 = Boolean.FALSE;
            moduleMethod = runtime.string$Mncontains;
            moduleMethod2 = runtime.get$Mnproperty;
            SimpleSymbol simpleSymbol3 = Lit85;
            simpleSymbol2 = Lit34;
            if (runtime.callYailPrimitive(moduleMethod3, LList.list2(object2, runtime.callYailPrimitive(moduleMethod, LList.list2(((Procedure)moduleMethod2).apply2(simpleSymbol3, simpleSymbol2), runtime.processOrDelayed$V(new Object[]{lambda$Fn21, lambda$Fn22, lambda$Fn23, lambda$Fn24})), Lit90, "string contains")), Lit91, "=") != Boolean.FALSE) {
                object2 = Lit92;
                runtime.setAndCoerceProperty$Ex(object2, simpleSymbol2, runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("https://www.bing.com/search?q=", ((Procedure)runtime.get$Mnproperty).apply2(object2, simpleSymbol2)), Lit93, "join"), Lit9);
            }
        }
        if (runtime.callYailPrimitive(strings.string$Eq$Qu, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(object, simpleSymbol), "Google"), Lit94, "text=") != Boolean.FALSE) {
            simpleSymbol2 = Lit56;
            object2 = Boolean.FALSE;
            simpleSymbol = Lit9;
            runtime.setAndCoerceProperty$Ex(object, simpleSymbol2, object2, simpleSymbol);
            object2 = runtime.yail$Mnequal$Qu;
            moduleMethod = Boolean.FALSE;
            moduleMethod2 = runtime.string$Mncontains;
            moduleMethod3 = runtime.get$Mnproperty;
            simpleSymbol2 = Lit85;
            object = Lit34;
            object = runtime.callYailPrimitive(object2, LList.list2(moduleMethod, runtime.callYailPrimitive(moduleMethod2, LList.list2(((Procedure)moduleMethod3).apply2(simpleSymbol2, object), runtime.processOrDelayed$V(new Object[]{lambda$Fn25, lambda$Fn26, lambda$Fn27, lambda$Fn28})), Lit99, "string contains")), Lit100, "=") != Boolean.FALSE ? runtime.setAndCoerceProperty$Ex(simpleSymbol2, object, runtime.callYailPrimitive(strings.string$Mnappend, LList.list2("https://www.google.com/search?q=", ((Procedure)runtime.get$Mnproperty).apply2(simpleSymbol2, object)), Lit101, "join"), simpleSymbol) : Values.empty;
        } else {
            object = Values.empty;
        }
        return object;
    }

    public Object Latest_rels$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://sites.google.com/view/latest-releases/home", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.FALSE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.TRUE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
    }

    public Object News$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://sites.google.com/view/news-editor-sanatan-kumar/home", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.TRUE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
    }

    public Object Next$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit114, Lit139, LList.Empty, LList.Empty);
    }

    public Object Refresh$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit114, Lit115, LList.Empty, LList.Empty);
    }

    public Object Search$Click() {
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit114, Lit123, LList.list1(((Procedure)runtime.get$Mnproperty).apply2(Lit85, Lit34)), Lit124);
    }

    public Object Search1$Click() {
        runtime.setThisForm();
        SimpleSymbol simpleSymbol = Lit114;
        Object object = Lit123;
        Object object2 = runtime.get$Mnproperty;
        SimpleSymbol simpleSymbol2 = Lit92;
        Object object3 = Lit34;
        runtime.callComponentMethod(simpleSymbol, object, LList.list1(((Procedure)object2).apply2(simpleSymbol2, object3)), Lit182);
        object = runtime.get$Mnproperty;
        simpleSymbol = Lit85;
        runtime.setAndCoerceProperty$Ex(simpleSymbol2, object3, ((Procedure)object).apply2(simpleSymbol, object3), Lit9);
        object = Lit18;
        simpleSymbol2 = Lit23;
        Boolean bl = Boolean.FALSE;
        object2 = Lit4;
        runtime.setAndCoerceProperty$Ex(object, simpleSymbol2, bl, object2);
        runtime.setAndCoerceProperty$Ex(Lit73, simpleSymbol2, Boolean.TRUE, object2);
        runtime.setAndCoerceProperty$Ex(Lit74, simpleSymbol2, Boolean.FALSE, object2);
        object3 = runtime.callYailPrimitive(runtime.string$Mncontains, LList.list2(((Procedure)runtime.get$Mnproperty).apply2(simpleSymbol, object3), "https://"), Lit183, "string contains") != Boolean.FALSE ? runtime.callComponentMethod(Lit80, Lit184, LList.list1("This URL does not contain https//: check if https//: is missed or this URL is not secure!"), Lit185) : Values.empty;
        return object3;
    }

    public Object Sky$Click() {
        runtime.setThisForm();
        runtime.setAndCoerceProperty$Ex(Lit194, Lit195, "https://sites.google.com/view/sky-unity/home", Lit9);
        SimpleSymbol simpleSymbol = Lit196;
        SimpleSymbol simpleSymbol2 = Lit30;
        Boolean bl = Boolean.FALSE;
        SimpleSymbol simpleSymbol3 = Lit4;
        runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, bl, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit197, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        runtime.setAndCoerceProperty$Ex(Lit198, simpleSymbol2, Boolean.FALSE, simpleSymbol3);
        return runtime.setAndCoerceProperty$Ex(Lit199, simpleSymbol2, Boolean.TRUE, simpleSymbol3);
    }

    public Object WebViewer3$ErrorOccurred(Object object, Object object2, Object object3) {
        runtime.sanitizeComponentData(object);
        runtime.sanitizeComponentData(object2);
        runtime.sanitizeComponentData(object3);
        runtime.setThisForm();
        return runtime.callComponentMethod(Lit80, Lit147, LList.list1("There is an error occured. Check if the site address contains https or http and has .com , .in or .org"), Lit148);
    }

    public void addToComponents(Object object, Object object2, Object object3, Object object4) {
        this.components$Mnto$Mncreate = lists.cons(LList.list4(object, object2, object3, object4), this.components$Mnto$Mncreate);
    }

    public void addToEvents(Object object, Object object2) {
        this.events$Mnto$Mnregister = lists.cons(lists.cons(object, object2), this.events$Mnto$Mnregister);
    }

    public void addToFormDoAfterCreation(Object object) {
        this.form$Mndo$Mnafter$Mncreation = lists.cons(object, this.form$Mndo$Mnafter$Mncreation);
    }

    public void addToFormEnvironment(Symbol symbol, Object object) {
        this.androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", symbol, this.form$Mnenvironment, object));
        this.form$Mnenvironment.put(symbol, object);
    }

    public void addToGlobalVarEnvironment(Symbol symbol, Object object) {
        this.androidLogForm(Format.formatToString(0, "Adding ~A to env ~A with value ~A", symbol, this.global$Mnvar$Mnenvironment, object));
        this.global$Mnvar$Mnenvironment.put(symbol, object);
    }

    public void addToGlobalVars(Object object, Object object2) {
        this.global$Mnvars$Mnto$Mncreate = lists.cons(LList.list2(object, object2), this.global$Mnvars$Mnto$Mncreate);
    }

    public void androidLogForm(Object object) {
    }

    @Override
    public boolean dispatchEvent(Component component, String object, String string2, Object[] objectArray) {
        boolean bl;
        block10: {
            SimpleSymbol simpleSymbol = misc.string$To$Symbol((CharSequence)object);
            boolean bl2 = this.isBoundInFormEnvironment(simpleSymbol);
            boolean bl3 = false;
            bl = false;
            if (bl2) {
                if (this.lookupInFormEnvironment(simpleSymbol) == component) {
                    object = this.lookupHandler(object, string2);
                    boolean bl4 = true;
                    try {
                        ((Procedure)Scheme.apply).apply2(object, LList.makeList(objectArray, 0));
                        bl = true;
                    }
                    catch (Throwable throwable) {
                        this.androidLogForm(throwable.getMessage());
                        throwable.printStackTrace();
                        this.processException(throwable);
                    }
                    catch (PermissionException permissionException) {
                        permissionException.printStackTrace();
                        if (this != component) {
                            bl4 = false;
                        }
                        if (bl4 ? IsEqual.apply(string2, "PermissionNeeded") : bl4) {
                            this.processException((Object)permissionException);
                            break block10;
                        }
                        this.PermissionDenied(component, string2, permissionException.getPermissionNeeded());
                    }
                    catch (StopBlocksExecution stopBlocksExecution) {}
                } else {
                    bl = bl3;
                }
            } else {
                EventDispatcher.unregisterEventForDelegation((HandlesEventDispatching)this, (String)object, string2);
                bl = bl3;
            }
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void dispatchGenericEvent(Component component, String string2, boolean bl, Object[] objectArray) {
        boolean bl2 = false;
        Object object = this.lookupInFormEnvironment(misc.string$To$Symbol(strings.stringAppend("any$", this.getSimpleName(component), "$", string2)));
        if (object == Boolean.FALSE) return;
        try {
            Apply apply = Scheme.apply;
            Boolean bl3 = bl ? Boolean.TRUE : Boolean.FALSE;
            ((Procedure)apply).apply2(object, lists.cons(component, lists.cons(bl3, LList.makeList(objectArray, 0))));
            return;
        }
        catch (Throwable throwable) {
            this.androidLogForm(throwable.getMessage());
            throwable.printStackTrace();
            this.processException(throwable);
            return;
        }
        catch (PermissionException permissionException) {
            permissionException.printStackTrace();
            if (this == component) {
                bl2 = true;
            }
            if (bl2 ? IsEqual.apply(string2, "PermissionNeeded") : bl2) {
                this.processException((Object)permissionException);
                return;
            }
            this.PermissionDenied(component, string2, permissionException.getPermissionNeeded());
            return;
        }
        catch (StopBlocksExecution stopBlocksExecution) {
            // empty catch block
        }
    }

    public String getSimpleName(Object object) {
        return object.getClass().getSimpleName();
    }

    public boolean isBoundInFormEnvironment(Symbol symbol) {
        return this.form$Mnenvironment.isBound(symbol);
    }

    public Object lookupHandler(Object object, Object object2) {
        Object var3_3 = null;
        object = object == null ? null : object.toString();
        object2 = object2 == null ? var3_3 : object2.toString();
        return this.lookupInFormEnvironment(misc.string$To$Symbol(EventDispatcher.makeFullEventName((String)object, (String)object2)));
    }

    public Object lookupInFormEnvironment(Symbol symbol) {
        return this.lookupInFormEnvironment(symbol, Boolean.FALSE);
    }

    public Object lookupInFormEnvironment(Symbol symbol, Object object) {
        block0: {
            Environment environment = this.form$Mnenvironment;
            int n = environment == null ? 1 : 0;
            if (!((n = 1 & n + 1) != 0 ? environment.isBound(symbol) : n != 0)) break block0;
            object = this.form$Mnenvironment.get(symbol);
        }
        return object;
    }

    @Override
    public void onCreate(Bundle bundle) {
        AppInventorCompatActivity.setClassicModeFromYail((boolean)true);
        super.onCreate(bundle);
    }

    public void processException(Object object) {
        Object object2 = ((Procedure)Scheme.applyToArgs).apply1(((Procedure)GetNamedPart.getNamedPart).apply2(object, Lit1));
        object2 = object2 == null ? null : object2.toString();
        object = object instanceof YailRuntimeError ? ((YailRuntimeError)((Object)object)).getErrorType() : "Runtime Error";
        RuntimeErrorAlert.alert((Object)this, (String)object2, (String)object, (String)"End Application");
    }

    public void run() {
        Object var1_3;
        CallContext callContext = CallContext.getInstance();
        Consumer consumer = callContext.consumer;
        callContext.consumer = VoidConsumer.instance;
        try {
            this.run(callContext);
            var1_3 = null;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        ModuleBody.runCleanup(callContext, var1_3, consumer);
    }

    public final void run(CallContext object) {
        Consumer consumer = object.consumer;
        runtime.$instance.run();
        this.$Stdebug$Mnform$St = Boolean.FALSE;
        SimpleSymbol simpleSymbol = Lit0;
        this.form$Mnenvironment = Environment.make(misc.symbol$To$String(simpleSymbol));
        object = strings.stringAppend(misc.symbol$To$String(simpleSymbol), "-global-vars");
        object = object == null ? null : object.toString();
        this.global$Mnvar$Mnenvironment = Environment.make((String)object);
        Screen4 = null;
        this.form$Mnname$Mnsymbol = simpleSymbol;
        this.events$Mnto$Mnregister = LList.Empty;
        this.components$Mnto$Mncreate = LList.Empty;
        this.global$Mnvars$Mnto$Mncreate = LList.Empty;
        this.form$Mndo$Mnafter$Mncreation = LList.Empty;
        runtime.$instance.run();
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            SimpleSymbol simpleSymbol2 = Lit3;
            Object object2 = Boolean.TRUE;
            object = Lit4;
            runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, object2, object);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit5, (Object)Lit6, Lit7);
            simpleSymbol2 = Lit8;
            object2 = Lit9;
            runtime.setAndCoerceProperty$Ex(simpleSymbol, simpleSymbol2, "Browser", object2);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit10, "jellyfish-7340188_640.jpg", object2);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit11, "unspecified", object2);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit12, Boolean.TRUE, object);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit13, Boolean.TRUE, object);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit14, "Responsive", object2);
            runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit15, "Screen4", object2);
            Values.writeValues(runtime.setAndCoerceProperty$Ex(simpleSymbol, Lit16, Boolean.FALSE, object), consumer);
        } else {
            this.addToFormDoAfterCreation(new Promise(lambda$Fn2));
        }
        this.VerticalArrangement3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit17, Lit18, lambda$Fn3), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit26, Lit18, lambda$Fn4);
        }
        this.Cookie = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit27, Lit28, lambda$Fn5), consumer);
        } else {
            this.addToComponents(Lit18, Lit35, Lit28, lambda$Fn6);
        }
        this.Cache = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit36, Lit37, lambda$Fn7), consumer);
        } else {
            this.addToComponents(Lit18, Lit39, Lit37, lambda$Fn8);
        }
        this.Locatuon = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit40, Lit41, lambda$Fn9), consumer);
        } else {
            this.addToComponents(Lit18, Lit43, Lit41, lambda$Fn10);
        }
        this.Search_engine = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit44, Lit45, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(Lit18, Lit46, Lit45, Boolean.FALSE);
        }
        this.Space_divider = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit47, Lit48, lambda$Fn11), consumer);
        } else {
            this.addToComponents(Lit18, Lit52, Lit48, lambda$Fn12);
        }
        this.ListView1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit18, Lit53, Lit54, lambda$Fn13), consumer);
        } else {
            this.addToComponents(Lit18, Lit62, Lit54, lambda$Fn14);
        }
        this.HorizontalArrangement4 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit63, Lit64, lambda$Fn15), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit67, Lit64, lambda$Fn16);
        }
        this.Home = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit64, Lit68, Lit69, lambda$Fn17), consumer);
        } else {
            this.addToComponents(Lit64, Lit72, Lit69, lambda$Fn18);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit75, this.Home$Click);
        } else {
            this.addToFormEnvironment(Lit75, this.Home$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Home", "Click");
        } else {
            this.addToEvents(Lit69, Lit76);
        }
        this.Image6 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit64, Lit77, Lit78, lambda$Fn19), consumer);
        } else {
            this.addToComponents(Lit64, Lit79, Lit78, lambda$Fn20);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit102, this.Image6$Click);
        } else {
            this.addToFormEnvironment(Lit102, this.Image6$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Image6", "Click");
        } else {
            this.addToEvents(Lit78, Lit76);
        }
        this.VerticalArrangement2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit103, Lit73, lambda$Fn29), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit105, Lit73, lambda$Fn30);
        }
        this.HorizontalArrangement5 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit73, Lit106, Lit107, lambda$Fn31), consumer);
        } else {
            this.addToComponents(Lit73, Lit110, Lit107, lambda$Fn32);
        }
        this.Refresh = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit111, Lit112, lambda$Fn33), consumer);
        } else {
            this.addToComponents(Lit107, Lit113, Lit112, lambda$Fn34);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit116, this.Refresh$Click);
        } else {
            this.addToFormEnvironment(Lit116, this.Refresh$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Refresh", "Click");
        } else {
            this.addToEvents(Lit112, Lit76);
        }
        this.TextBox2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit117, Lit85, lambda$Fn35), consumer);
        } else {
            this.addToComponents(Lit107, Lit119, Lit85, lambda$Fn36);
        }
        this.Search = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit120, Lit121, lambda$Fn37), consumer);
        } else {
            this.addToComponents(Lit107, Lit122, Lit121, lambda$Fn38);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit125, this.Search$Click);
        } else {
            this.addToFormEnvironment(Lit125, this.Search$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Search", "Click");
        } else {
            this.addToEvents(Lit121, Lit76);
        }
        this.Close = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit126, Lit127, lambda$Fn39), consumer);
        } else {
            this.addToComponents(Lit107, Lit128, Lit127, lambda$Fn40);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit130, this.Close$Click);
        } else {
            this.addToFormEnvironment(Lit130, this.Close$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Close", "Click");
        } else {
            this.addToEvents(Lit127, Lit76);
        }
        this.Before = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit131, Lit132, lambda$Fn41), consumer);
        } else {
            this.addToComponents(Lit107, Lit133, Lit132, lambda$Fn42);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit135, this.Before$Click);
        } else {
            this.addToFormEnvironment(Lit135, this.Before$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Before", "Click");
        } else {
            this.addToEvents(Lit132, Lit76);
        }
        this.Next = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit136, Lit137, lambda$Fn43), consumer);
        } else {
            this.addToComponents(Lit107, Lit138, Lit137, lambda$Fn44);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit140, this.Next$Click);
        } else {
            this.addToFormEnvironment(Lit140, this.Next$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Next", "Click");
        } else {
            this.addToEvents(Lit137, Lit76);
        }
        this.Image5 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit107, Lit141, Lit142, lambda$Fn45), consumer);
        } else {
            this.addToComponents(Lit107, Lit143, Lit142, lambda$Fn46);
        }
        this.WebViewer3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit73, Lit144, Lit114, lambda$Fn47), consumer);
        } else {
            this.addToComponents(Lit73, Lit146, Lit114, lambda$Fn48);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit149, this.WebViewer3$ErrorOccurred);
        } else {
            this.addToFormEnvironment(Lit149, this.WebViewer3$ErrorOccurred);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "WebViewer3", "ErrorOccurred");
        } else {
            this.addToEvents(Lit114, Lit150);
        }
        this.VerticalArrangement1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit151, Lit74, lambda$Fn49), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit153, Lit74, lambda$Fn50);
        }
        this.HorizontalArrangement6 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit154, Lit155, lambda$Fn51), consumer);
        } else {
            this.addToComponents(Lit74, Lit159, Lit155, lambda$Fn52);
        }
        this.Image3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit155, Lit160, Lit161, lambda$Fn53), consumer);
        } else {
            this.addToComponents(Lit155, Lit164, Lit161, lambda$Fn54);
        }
        this.Label1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit155, Lit165, Lit166, lambda$Fn55), consumer);
        } else {
            this.addToComponents(Lit155, Lit169, Lit166, lambda$Fn56);
        }
        this.HorizontalArrangement1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit170, Lit171, lambda$Fn57), consumer);
        } else {
            this.addToComponents(Lit74, Lit173, Lit171, lambda$Fn58);
        }
        this.TextBox1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit171, Lit174, Lit92, lambda$Fn59), consumer);
        } else {
            this.addToComponents(Lit171, Lit178, Lit92, lambda$Fn60);
        }
        this.Search1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit171, Lit179, Lit180, lambda$Fn61), consumer);
        } else {
            this.addToComponents(Lit171, Lit181, Lit180, lambda$Fn62);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit186, this.Search1$Click);
        } else {
            this.addToFormEnvironment(Lit186, this.Search1$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Search1", "Click");
        } else {
            this.addToEvents(Lit180, Lit76);
        }
        this.HorizontalScrollArrangement1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit187, Lit188, lambda$Fn63), consumer);
        } else {
            this.addToComponents(Lit74, Lit190, Lit188, lambda$Fn64);
        }
        this.News = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit191, Lit192, lambda$Fn65), consumer);
        } else {
            this.addToComponents(Lit188, Lit193, Lit192, lambda$Fn66);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit200, this.News$Click);
        } else {
            this.addToFormEnvironment(Lit200, this.News$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "News", "Click");
        } else {
            this.addToEvents(Lit192, Lit76);
        }
        this.Button3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit201, Lit196, lambda$Fn67), consumer);
        } else {
            this.addToComponents(Lit188, Lit204, Lit196, lambda$Fn68);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit205, this.Button3$Click);
        } else {
            this.addToFormEnvironment(Lit205, this.Button3$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Button3", "Click");
        } else {
            this.addToEvents(Lit196, Lit76);
        }
        this.Latest_rels = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit206, Lit207, lambda$Fn69), consumer);
        } else {
            this.addToComponents(Lit188, Lit208, Lit207, lambda$Fn70);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit209, this.Latest_rels$Click);
        } else {
            this.addToFormEnvironment(Lit209, this.Latest_rels$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Latest_rels", "Click");
        } else {
            this.addToEvents(Lit207, Lit76);
        }
        this.Sky = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit210, Lit199, lambda$Fn71), consumer);
        } else {
            this.addToComponents(Lit188, Lit213, Lit199, lambda$Fn72);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit214, this.Sky$Click);
        } else {
            this.addToFormEnvironment(Lit214, this.Sky$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Sky", "Click");
        } else {
            this.addToEvents(Lit199, Lit76);
        }
        this.IPL_2024 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit215, Lit198, lambda$Fn73), consumer);
        } else {
            this.addToComponents(Lit188, Lit219, Lit198, lambda$Fn74);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit220, this.IPL_2024$Click);
        } else {
            this.addToFormEnvironment(Lit220, this.IPL_2024$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "IPL_2024", "Click");
        } else {
            this.addToEvents(Lit198, Lit76);
        }
        this.Button2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit188, Lit221, Lit197, lambda$Fn75), consumer);
        } else {
            this.addToComponents(Lit188, Lit224, Lit197, lambda$Fn76);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            runtime.addToCurrentFormEnvironment(Lit225, this.Button2$Click);
        } else {
            this.addToFormEnvironment(Lit225, this.Button2$Click);
        }
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            EventDispatcher.registerEventForDelegation((HandlesEventDispatching)runtime.$Stthis$Mnform$St, "Button2", "Click");
        } else {
            this.addToEvents(Lit197, Lit76);
        }
        this.HorizontalArrangement3 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit226, Lit227, lambda$Fn77), consumer);
        } else {
            this.addToComponents(Lit74, Lit230, Lit227, lambda$Fn78);
        }
        this.WebViewer1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit231, Lit194, lambda$Fn79), consumer);
        } else {
            this.addToComponents(Lit74, Lit235, Lit194, lambda$Fn80);
        }
        this.HorizontalArrangement2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit236, Lit237, lambda$Fn81), consumer);
        } else {
            this.addToComponents(Lit74, Lit240, Lit237, lambda$Fn82);
        }
        this.WebViewer2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(Lit74, Lit241, Lit242, lambda$Fn83), consumer);
        } else {
            this.addToComponents(Lit74, Lit244, Lit242, lambda$Fn84);
        }
        this.Notifier1 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit245, Lit80, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit246, Lit80, Boolean.FALSE);
        }
        this.Notifier2 = null;
        if (runtime.$Stthis$Mnis$Mnthe$Mnrepl$St != Boolean.FALSE) {
            Values.writeValues(runtime.addComponentWithinRepl(simpleSymbol, Lit247, Lit248, Boolean.FALSE), consumer);
        } else {
            this.addToComponents(simpleSymbol, Lit249, Lit248, Boolean.FALSE);
        }
        runtime.initRuntime();
    }

    public void sendError(Object object) {
        object = object == null ? null : object.toString();
        RetValManager.sendError((String)object);
    }
}

