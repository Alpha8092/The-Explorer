/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  gnu.mapping.CallContext
 *  java.lang.Boolean
 *  java.lang.ClassCastException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 */
package appinventor.ai_sudarshankumar070309.Browser;

import android.os.Bundle;
import appinventor.ai_sudarshankumar070309.Browser.Screen4;
import com.google.appinventor.components.runtime.Component;
import gnu.expr.ModuleBody;
import gnu.expr.ModuleMethod;
import gnu.mapping.CallContext;
import gnu.mapping.Symbol;
import gnu.mapping.Values;
import gnu.mapping.WrongType;

public class Screen4$frame
extends ModuleBody {
    Screen4 $main;

    @Override
    public Object apply0(ModuleMethod moduleMethod) {
        switch (moduleMethod.selector) {
            default: {
                return super.apply0(moduleMethod);
            }
            case 117: {
                return Screen4.lambda85();
            }
            case 116: {
                return Screen4.lambda84();
            }
            case 115: {
                return Screen4.lambda83();
            }
            case 114: {
                return Screen4.lambda82();
            }
            case 113: {
                return Screen4.lambda81();
            }
            case 112: {
                return Screen4.lambda80();
            }
            case 111: {
                return Screen4.lambda79();
            }
            case 110: {
                return Screen4.lambda78();
            }
            case 109: {
                return this.$main.Button2$Click();
            }
            case 108: {
                return Screen4.lambda77();
            }
            case 107: {
                return Screen4.lambda76();
            }
            case 106: {
                return this.$main.IPL_2024$Click();
            }
            case 105: {
                return Screen4.lambda75();
            }
            case 104: {
                return Screen4.lambda74();
            }
            case 103: {
                return this.$main.Sky$Click();
            }
            case 102: {
                return Screen4.lambda73();
            }
            case 101: {
                return Screen4.lambda72();
            }
            case 100: {
                return this.$main.Latest_rels$Click();
            }
            case 99: {
                return Screen4.lambda71();
            }
            case 98: {
                return Screen4.lambda70();
            }
            case 97: {
                return this.$main.Button3$Click();
            }
            case 96: {
                return Screen4.lambda69();
            }
            case 95: {
                return Screen4.lambda68();
            }
            case 94: {
                return this.$main.News$Click();
            }
            case 93: {
                return Screen4.lambda67();
            }
            case 92: {
                return Screen4.lambda66();
            }
            case 91: {
                return Screen4.lambda65();
            }
            case 90: {
                return Screen4.lambda64();
            }
            case 89: {
                return this.$main.Search1$Click();
            }
            case 88: {
                return Screen4.lambda63();
            }
            case 87: {
                return Screen4.lambda62();
            }
            case 86: {
                return Screen4.lambda61();
            }
            case 85: {
                return Screen4.lambda60();
            }
            case 84: {
                return Screen4.lambda59();
            }
            case 83: {
                return Screen4.lambda58();
            }
            case 82: {
                return Screen4.lambda57();
            }
            case 81: {
                return Screen4.lambda56();
            }
            case 80: {
                return Screen4.lambda55();
            }
            case 79: {
                return Screen4.lambda54();
            }
            case 78: {
                return Screen4.lambda53();
            }
            case 77: {
                return Screen4.lambda52();
            }
            case 76: {
                return Screen4.lambda51();
            }
            case 75: {
                return Screen4.lambda50();
            }
            case 73: {
                return Screen4.lambda49();
            }
            case 72: {
                return Screen4.lambda48();
            }
            case 71: {
                return Screen4.lambda47();
            }
            case 70: {
                return Screen4.lambda46();
            }
            case 69: {
                return this.$main.Next$Click();
            }
            case 68: {
                return Screen4.lambda45();
            }
            case 67: {
                return Screen4.lambda44();
            }
            case 66: {
                return this.$main.Before$Click();
            }
            case 65: {
                return Screen4.lambda43();
            }
            case 64: {
                return Screen4.lambda42();
            }
            case 63: {
                return this.$main.Close$Click();
            }
            case 62: {
                return Screen4.lambda41();
            }
            case 61: {
                return Screen4.lambda40();
            }
            case 60: {
                return this.$main.Search$Click();
            }
            case 59: {
                return Screen4.lambda39();
            }
            case 58: {
                return Screen4.lambda38();
            }
            case 57: {
                return Screen4.lambda37();
            }
            case 56: {
                return Screen4.lambda36();
            }
            case 55: {
                return this.$main.Refresh$Click();
            }
            case 54: {
                return Screen4.lambda35();
            }
            case 53: {
                return Screen4.lambda34();
            }
            case 52: {
                return Screen4.lambda33();
            }
            case 51: {
                return Screen4.lambda32();
            }
            case 50: {
                return Screen4.lambda31();
            }
            case 49: {
                return Screen4.lambda30();
            }
            case 48: {
                return this.$main.Image6$Click();
            }
            case 47: {
                return Screen4.lambda29();
            }
            case 46: {
                return Screen4.lambda28();
            }
            case 45: {
                return Screen4.lambda27();
            }
            case 44: {
                return Screen4.lambda26();
            }
            case 43: {
                return Screen4.lambda25();
            }
            case 42: {
                return Screen4.lambda24();
            }
            case 41: {
                return Screen4.lambda23();
            }
            case 40: {
                return Screen4.lambda22();
            }
            case 39: {
                return Screen4.lambda21();
            }
            case 38: {
                return Screen4.lambda20();
            }
            case 37: {
                return this.$main.Home$Click();
            }
            case 36: {
                return Screen4.lambda19();
            }
            case 35: {
                return Screen4.lambda18();
            }
            case 34: {
                return Screen4.lambda17();
            }
            case 33: {
                return Screen4.lambda16();
            }
            case 32: {
                return Screen4.lambda15();
            }
            case 31: {
                return Screen4.lambda14();
            }
            case 30: {
                return Screen4.lambda13();
            }
            case 29: {
                return Screen4.lambda12();
            }
            case 28: {
                return Screen4.lambda11();
            }
            case 27: {
                return Screen4.lambda10();
            }
            case 26: {
                return Screen4.lambda9();
            }
            case 25: {
                return Screen4.lambda8();
            }
            case 24: {
                return Screen4.lambda7();
            }
            case 23: {
                return Screen4.lambda6();
            }
            case 22: {
                return Screen4.lambda5();
            }
            case 21: {
                return Screen4.lambda4();
            }
            case 20: {
                return Screen4.lambda3();
            }
            case 19: {
                this.$main.$define();
                return Values.empty;
            }
            case 18: 
        }
        return Screen4.lambda2();
    }

    @Override
    public Object apply1(ModuleMethod object, Object object2) {
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply1((ModuleMethod)object, object2);
            }
            case 14: {
                this.$main.processException(object2);
                return Values.empty;
            }
            case 13: {
                this.$main.sendError(object2);
                return Values.empty;
            }
            case 12: {
                this.$main.addToFormDoAfterCreation(object2);
                return Values.empty;
            }
            case 7: {
                Screen4 screen4 = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "is-bound-in-form-environment", 1, object2);
                }
                object = screen4.isBoundInFormEnvironment((Symbol)object) ? Boolean.TRUE : Boolean.FALSE;
                return object;
            }
            case 5: {
                Screen4 screen4 = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return screen4.lookupInFormEnvironment((Symbol)object);
            }
            case 3: {
                this.$main.androidLogForm(object2);
                return Values.empty;
            }
            case 2: {
                Bundle bundle;
                object = this.$main;
                try {
                    bundle = (Bundle)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "onCreate", 1, object2);
                }
                ((Screen4)object).onCreate(bundle);
                return Values.empty;
            }
            case 1: 
        }
        return this.$main.getSimpleName(object2);
    }

    @Override
    public Object apply2(ModuleMethod object, Object object2, Object object3) {
        switch (((ModuleMethod)object).selector) {
            default: {
                return super.apply2((ModuleMethod)object, object2, object3);
            }
            case 17: {
                return this.$main.lookupHandler(object2, object3);
            }
            case 11: {
                this.$main.addToGlobalVars(object2, object3);
                return Values.empty;
            }
            case 9: {
                this.$main.addToEvents(object2, object3);
                return Values.empty;
            }
            case 8: {
                Screen4 screen4 = this.$main;
                try {
                    object = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "add-to-global-var-environment", 1, object2);
                }
                screen4.addToGlobalVarEnvironment((Symbol)object, object3);
                return Values.empty;
            }
            case 5: {
                Symbol symbol;
                object = this.$main;
                try {
                    symbol = (Symbol)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "lookup-in-form-environment", 1, object2);
                }
                return ((Screen4)object).lookupInFormEnvironment(symbol, object3);
            }
            case 4: 
        }
        Screen4 screen4 = this.$main;
        try {
            object = (Symbol)object2;
        }
        catch (ClassCastException classCastException) {
            throw new WrongType(classCastException, "add-to-form-environment", 1, object2);
        }
        screen4.addToFormEnvironment((Symbol)object, object3);
        return Values.empty;
    }

    @Override
    public Object apply3(ModuleMethod moduleMethod, Object object, Object object2, Object object3) {
        if (moduleMethod.selector == 74) {
            return this.$main.WebViewer3$ErrorOccurred(object, object2, object3);
        }
        return super.apply3(moduleMethod, object, object2, object3);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object apply4(ModuleMethod object, Object object2, Object objectArray, Object objectArray2, Object object3) {
        int n = ((ModuleMethod)object).selector;
        boolean bl = true;
        switch (n) {
            default: {
                return super.apply4((ModuleMethod)object, object2, objectArray, objectArray2, object3);
            }
            case 16: {
                Component component;
                object = this.$main;
                try {
                    component = (Component)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 1, object2);
                }
                try {
                    object2 = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = Boolean.FALSE;
                    if (objectArray2 == objectArray) {
                        bl = false;
                    }
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray = (Object[])object3;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchGenericEvent", 4, object3);
                }
                ((Screen4)object).dispatchGenericEvent(component, (String)object2, bl, objectArray);
                return Values.empty;
            }
            case 15: {
                Screen4 screen4 = this.$main;
                try {
                    object = (Component)object2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 1, object2);
                }
                try {
                    object2 = (String)objectArray;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 2, (Object)objectArray);
                }
                try {
                    objectArray = (String)objectArray2;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 3, (Object)objectArray2);
                }
                try {
                    objectArray2 = (Object[])object3;
                }
                catch (ClassCastException classCastException) {
                    throw new WrongType(classCastException, "dispatchEvent", 4, object3);
                }
                if (!screen4.dispatchEvent((Component)object, (String)object2, (String)objectArray, objectArray2)) return Boolean.FALSE;
                return Boolean.TRUE;
            }
            case 10: 
        }
        this.$main.addToComponents(object2, objectArray, objectArray2, object3);
        return Values.empty;
    }

    @Override
    public int match0(ModuleMethod moduleMethod, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match0(moduleMethod, callContext);
            }
            case 20: 
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: 
            case 26: 
            case 27: 
            case 28: 
            case 29: 
            case 30: 
            case 31: 
            case 32: 
            case 33: 
            case 34: 
            case 35: 
            case 36: 
            case 37: 
            case 38: 
            case 39: 
            case 40: 
            case 41: 
            case 42: 
            case 43: 
            case 44: 
            case 45: 
            case 46: 
            case 47: 
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 54: 
            case 55: 
            case 56: 
            case 57: 
            case 58: 
            case 59: 
            case 60: 
            case 61: 
            case 62: 
            case 63: 
            case 64: 
            case 65: 
            case 66: 
            case 67: 
            case 68: 
            case 69: 
            case 70: 
            case 71: 
            case 72: 
            case 73: 
            case 75: 
            case 76: 
            case 77: 
            case 78: 
            case 79: 
            case 80: 
            case 81: 
            case 82: 
            case 83: 
            case 84: 
            case 85: 
            case 86: 
            case 87: 
            case 88: 
            case 89: 
            case 90: 
            case 91: 
            case 92: 
            case 93: 
            case 94: 
            case 95: 
            case 96: 
            case 97: 
            case 98: 
            case 99: 
            case 100: 
            case 101: 
            case 102: 
            case 103: 
            case 104: 
            case 105: 
            case 106: 
            case 107: 
            case 108: 
            case 109: 
            case 110: 
            case 111: 
            case 112: 
            case 113: 
            case 114: 
            case 115: 
            case 116: 
            case 117: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 19: {
                callContext.proc = moduleMethod;
                callContext.pc = 0;
                return 0;
            }
            case 18: 
        }
        callContext.proc = moduleMethod;
        callContext.pc = 0;
        return 0;
    }

    @Override
    public int match1(ModuleMethod moduleMethod, Object object, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match1(moduleMethod, object, callContext);
            }
            case 14: {
                if (!(object instanceof Screen4)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 13: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 12: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 7: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 3: {
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 2: {
                if (!(object instanceof Screen4)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.proc = moduleMethod;
                callContext.pc = 1;
                return 0;
            }
            case 1: 
        }
        callContext.value1 = object;
        callContext.proc = moduleMethod;
        callContext.pc = 1;
        return 0;
    }

    @Override
    public int match2(ModuleMethod moduleMethod, Object object, Object object2, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match2(moduleMethod, object, object2, callContext);
            }
            case 17: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 11: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 9: {
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 8: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 5: {
                if (!(object instanceof Symbol)) {
                    return -786431;
                }
                callContext.value1 = object;
                callContext.value2 = object2;
                callContext.proc = moduleMethod;
                callContext.pc = 2;
                return 0;
            }
            case 4: 
        }
        if (!(object instanceof Symbol)) {
            return -786431;
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.proc = moduleMethod;
        callContext.pc = 2;
        return 0;
    }

    @Override
    public int match3(ModuleMethod moduleMethod, Object object, Object object2, Object object3, CallContext callContext) {
        if (moduleMethod.selector == 74) {
            callContext.value1 = object;
            callContext.value2 = object2;
            callContext.value3 = object3;
            callContext.proc = moduleMethod;
            callContext.pc = 3;
            return 0;
        }
        return super.match3(moduleMethod, object, object2, object3, callContext);
    }

    @Override
    public int match4(ModuleMethod moduleMethod, Object object, Object object2, Object object3, Object object4, CallContext callContext) {
        switch (moduleMethod.selector) {
            default: {
                return super.match4(moduleMethod, object, object2, object3, object4, callContext);
            }
            case 16: {
                if (!(object instanceof Screen4)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 15: {
                if (!(object instanceof Screen4)) {
                    return -786431;
                }
                callContext.value1 = object;
                if (!(object2 instanceof Component)) {
                    return -786430;
                }
                callContext.value2 = object2;
                if (!(object3 instanceof String)) {
                    return -786429;
                }
                callContext.value3 = object3;
                if (!(object4 instanceof String)) {
                    return -786428;
                }
                callContext.value4 = object4;
                callContext.proc = moduleMethod;
                callContext.pc = 4;
                return 0;
            }
            case 10: 
        }
        callContext.value1 = object;
        callContext.value2 = object2;
        callContext.value3 = object3;
        callContext.value4 = object4;
        callContext.proc = moduleMethod;
        callContext.pc = 4;
        return 0;
    }
}

